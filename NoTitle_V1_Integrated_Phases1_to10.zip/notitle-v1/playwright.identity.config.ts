import {defineConfig} from '@playwright/test';
export default defineConfig({
  testDir:'tests/qualification',testMatch:'phase3.spec.ts',timeout:60000,fullyParallel:false,workers:1,
  use:{baseURL:'http://127.0.0.1:8080',trace:'off',screenshot:'off',video:'off',acceptDownloads:true},
  reporter:[['list'],['json',{outputFile:'evidence/phase3/browser-results.json'}]],
  projects:[{name:'identity-chromium',use:{browserName:'chromium'}}],
});
// Start the fixed local identity stack first. Credential flows deliberately do
// not record traces/screenshots/video that could contain a saved secret.
