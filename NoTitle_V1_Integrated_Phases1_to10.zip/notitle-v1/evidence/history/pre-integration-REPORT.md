# Phase 3 verification report — 17 October 2026

Implemented against recovered Master Blueprint V6 chapter 57 on the current Phase 2 project. This delivers identity, consent and privacy source, connected frontend flows, contract/schema changes and local automation. It does not certify production or legal readiness.

## Delivered

- Guest/account sessions, strict owner projections, generic login, Argon2id, prepared recovery proofs, guarded registration/recovery/credential retries, session inventory/revocation and database-enforced five-session challenges.
- Exact deployed policy and purpose/control digests, four explicit choices, immutable account proof, temporary downloadable guest proof, reacceptance, revisioned preferences/profile and professional withdrawal erasure.
- Separate authentication/participation fences so core withdrawal keeps support/privacy reachable, including restricted accounts and maintenance login.
- Scoped case/financial/deletion receipts, rights-case skeleton, bounded encrypted exports, independent deletion/hold ordering, startup replay and restored-export/session invalidation.
- Shared in-memory frontend coordinator with generated request/response validation, correct scoped CSRF, response/time bounds, stale-response cleanup and explicit unknown-result handling. Set-Cookie without JSON can refresh read authority while preserving the exact RAM intent.
- Migration 0008 / compatibility contract 3, restricted support account-capability checks, forward-compatible envelope reads, local-only identity profile, setup/evidence commands, CI and real-stack test specifications.

## Executed results

- **162 Python unit tests passed**, zero failures/skips: preserved 136 plus 26 Phase 3 tests. Real Argon2id, AES-GCM/version/scope/tamper, verifier and actor behavior run directly. Database service fault tests use explicitly scripted I/O, not a PostgreSQL substitute.
- **11 Node tests passed** while executing the actual shared TypeScript coordinator with Node 24 type erasure and mocked fetch streams. They cover coalesced loading/no mutation on mount, strict contracts, unknown-result no-retry, rotated/scoped CSRF, stale responses, owner cleanup, response size, safe routes, sanitized failures and lost-JSON authority synchronization. They are not React/browser tests.
- Generated HTTP/peer/socket/identity contract checks, policy consistency, public/private fixed routes, build guard and source boundary checks passed.
- **111 Python files** parsed without failures; Python byte compilation passed.
- **104 TypeScript/TSX files** passed syntax parsing with the provided runtime Playwright Babel parser. This is not a TypeScript compiler or Next build result.
- JSON/YAML parsing, Node build-guard syntax and host-bootstrap Bash syntax passed. Their supplemental status is in `additional-checks.json`.
- The full-stack collector was requested and exited nonzero at actual prerequisites. It correctly records integration/build/browser as blocked, not passed. `phase3_accepted` and `production_ready` remain false.

Hashed command logs and environment versions are referenced by `latest.json`. Available test libraries were Pydantic 2.14.0 and cryptography 50.0.2; this was not a hash-locked production environment. The source digest in that report covers implementation inputs, not merely this prose.

## Not executed

Docker/PostgreSQL, FastAPI/Uvicorn/Psycopg/httpx and the application frontend toolchain are not installed here. Normal PyPI/npm probes during this session returned HTTP 403. No bypass or fabricated lock was used. The project still needs real reviewed Python/web/image locks after the changed manifests.

Consequently there is no claim that SQL migrations/triggers/grants/concurrent transactions, Next TypeScript/build/export, real browser/Caddy/HTTPS/mobile/assistive technology, independent object-store permissions, old-backup/host-loss restore, or genuine operator/legal review passed. The expanded PostgreSQL and browser suites are included but unrun. Included deletion row-restore integration is a simulation against real PostgreSQL when executed; it is not a full backup/host-loss drill.

## Preservation and remaining work

Byte comparison against the saved Phase 2 archive confirmed unchanged migrations 0001–0007 (7 files), relay source (7), policy source/publication data (8), Phase 1 evidence (13) and Phase 2 evidence (14). No original source file was removed. Identity boundaries, runtime/privacy/support checks, HTTP DTOs, worker cleanup, shared UI and operations were deliberately updated. `change-inventory.json` lists exact paths.

Read `docs/PHASE3_ACCEPTANCE.md` for the concurrency, lost-response, guest conversion, withdrawal, authorization, expiry, export and deletion/hold qualification matrix. Commit-window behavior and real transaction rollback cannot be accepted from scripted I/O. Read `docs/HANDOFF.md` for later source findings, including provider dashboard adjustments, Annual365, journal lifecycle/10,000-instruction bound, automatic key rotation, financial expiry/invoicing and external legal operations.

No public deployment, live billing action, external message or legal publication was performed. Existing policy drafts remain labelled and ineffective. No support email was added. No-voluntary-refund rules preserve non-waivable remedies.

## Next action

On Linux/WSL2 with approved registries and Docker, follow `README.md` and `docs/PHASE3.md`. Use `python3 ops/nt.py identity setup` for a new local installation or the existing-installation commands. After stopping the owner and installing browser OS prerequisites, run `.venv/bin/python ops/nt.py identity verify --level stack`, review/fix actual failures, then complete external/manual acceptance before enabling dependent phases.
