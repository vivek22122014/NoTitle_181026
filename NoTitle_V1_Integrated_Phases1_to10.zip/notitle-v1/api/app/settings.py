from dataclasses import dataclass
from pathlib import Path
import os

@dataclass(frozen=True)
class Settings:
    dsn: str
    public_port: int = 8000
    private_port: int = 8001
    mode: str = "product"

    @classmethod
    def load(cls):
        if os.environ.get("APP_ENV", "local") not in {"local", "staging", "production"}:
            raise ValueError("Unknown environment")
        mode = os.environ.get("APP_MODE", "product")
        if mode not in {"product", "foundation", "identity", "realtime"}:
            raise ValueError("Unknown application mode")
        if mode in {"foundation","identity","realtime"} and os.environ.get("APP_ENV", "local") != "local":
            raise ValueError("Partial-phase modes are restricted to isolated local development")
        if os.environ.get("APP_ENV") == "production" and not os.environ.get("NT_CONFIG_FILE"):
            raise ValueError("Qualified production configuration required")
        path = Path(os.environ["DATABASE_DSN_FILE"])
        from app.domain.private_files import read_private
        dsn=read_private(path)
        ports = [int(os.environ.get(k, d)) for k, d in
                 [("PUBLIC_PORT", "8000"), ("PRIVATE_PORT", "8001")]]
        if ports[0] == ports[1] or any(not 1024 <= p <= 65535 for p in ports):
            raise ValueError("Distinct unprivileged listener ports required")
        if not dsn or len(dsn.encode()) > 8192:
            raise ValueError("A bounded nonempty DSN is required")
        return cls(dsn, *ports, mode)
