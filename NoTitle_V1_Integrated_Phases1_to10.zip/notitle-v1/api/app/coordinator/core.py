"""Single-owner authority primitive. Only the event-loop owner may call transitions.
No I/O or await occurs inside these methods. Matching transitions use this authority before reading or mutating RAM state.
"""
from dataclasses import dataclass
import time

class Fenced(RuntimeError):
    pass

@dataclass(frozen=True)
class Stamp:
    owner_epoch: int
    subject: str
    revision: int

class Coordinator:
    def __init__(self, epoch: int, clock=time.monotonic):
        self.epoch = epoch
        self.clock = clock
        self.last_proof = clock()
        self.alive = True
        self.revisions: dict[str, int] = {}
        self.live: dict[str, bytes] = {}

    def assert_authority(self):
        if not self.alive or self.clock() - self.last_proof >= 2:
            self.fence()
            raise Fenced("OWNER_UNAVAILABLE")

    def heartbeat(self):
        if not self.alive or self.clock() - self.last_proof >= 2:
            self.fence()
            raise Fenced("OWNER_FENCED")
        self.last_proof = self.clock()

    def reserve(self, subject: str) -> Stamp:
        self.assert_authority()
        if subject not in self.revisions and len(self.revisions) >= 200:
            raise Fenced("CAPACITY")
        self.revisions.setdefault(subject, 0)
        return Stamp(self.epoch, subject, self.revisions[subject])

    def publish(self, stamp: Stamp, result: bytes):
        self.assert_authority()
        if (stamp.owner_epoch != self.epoch or
                self.revisions.get(stamp.subject) != stamp.revision):
            raise Fenced("STALE_RESULT")
        if len(result) > 512:
            raise ValueError("Effect acknowledgment limit")
        self.live[stamp.subject] = result

    def end(self, subject: str):
        self.assert_authority()
        if subject in self.revisions:
            self.revisions[subject] += 1
        self.live.pop(subject, None)

    def fence(self):
        self.alive = False
        self.live.clear()
        self.revisions.clear()
