"""Bounded event-loop mailbox: control reserve cannot be consumed by ordinary work."""
from collections import deque
import inspect

class MailboxFull(RuntimeError): pass

class Mailbox:
    def __init__(self, coordinator):
        self.coordinator=coordinator
        self.control=deque();self.ordinary=deque()

    def submit(self, transition, *, control=False):
        if not callable(transition) or inspect.iscoroutinefunction(transition):
            raise TypeError("Transitions must be synchronous")
        queue=self.control if control else self.ordinary
        limit=256 if control else 2048
        if len(queue)>=limit:
            if control:self.coordinator.fence()
            raise MailboxFull("CONTROL_SATURATED" if control else "ORDINARY_SATURATED")
        queue.append(transition)

    def drain_tick(self):
        self.coordinator.assert_authority()
        try:
            for queue in (self.control,self.ordinary):
                for _ in range(min(64,len(queue))):
                    result=queue.popleft()()
                    if inspect.isawaitable(result):
                        if inspect.iscoroutine(result):result.close()
                        raise TypeError("I/O must run outside coordinator transitions")
        except BaseException:
            self.coordinator.fence()
            self.control.clear();self.ordinary.clear()
            raise
