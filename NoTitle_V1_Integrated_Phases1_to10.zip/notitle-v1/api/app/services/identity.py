"""Account authority with locked mutations and bounded, proof-bound retries."""
import time
from datetime import datetime,timezone,timedelta
from uuid import UUID,uuid4
from app.domain.errors import require
from app.domain.security import token,normalize_username,totp_counter,canonical
from app.repositories.database import one,many
from .primitives import Principal,Passwords,Reservations,Limiter

def now():return datetime.now(timezone.utc)

class Identity:
    def __init__(self,db,security,realtime,policy_version='v1-draft',policy_digest='',policy=None):
        self.db,self.security,self.realtime=db,security,realtime
        self.passwords,self.reservations,self.limiter=Passwords(),Reservations(security),Limiter()
        self.policy_version,self.policy_digest,self.policy=policy_version,policy_digest,policy
        self.bootstrap,self.guests,self.challenges,self.tickets={},{},{},{}
        self.fenced_subjects=set()
        self.participation_fences=set()

    def prune(self):
        current=time.monotonic()
        for store in (self.bootstrap,self.guests,self.challenges,self.tickets):
            for key in [k for k,v in store.items() if v['until']<=current]:
                value=store.pop(key)
                if store is self.guests:
                    self.participation_fences.discard(value['ref'])
                    if value['ref'] in self.realtime.people:self.realtime.retire(value['ref'])

    def new_bootstrap(self,realm='public'):
        self.prune();require(realm in ('public','private'),'REALM_INVALID')
        require(len(self.bootstrap)<512,'BOOTSTRAP_CAPACITY',503)
        secret=token();ref=uuid4().hex
        self.bootstrap[self.security.digest('bootstrap:'+realm,secret)]={'until':time.monotonic()+1800,'ref':ref,'realm':realm}
        return Principal('bootstrap',ref,secret,bootstrap_ref=ref)

    def bootstrap_principal(self,secret,realm='public'):
        entry=self.bootstrap.get(self.security.digest('bootstrap:'+realm,secret)) if secret else None
        return Principal('bootstrap',entry['ref'],secret,bootstrap_ref=entry['ref']) if entry and entry['realm']==realm else None

    async def resolve(self,cookies,private=False,scope=None):
        self.prune()
        boot=self.bootstrap_principal(cookies.get('admin_bootstrap' if private else 'bootstrap'),'private' if private else 'public')
        if private:
            secret=cookies.get('admin')
            if not secret:return boot
            async with self.db.transaction('private') as connection:
                row=await one(connection,"""SELECT s.*,a.username,a.status FROM nt.staff_sessions s JOIN nt.staff_accounts a
                  ON a.id=s.staff_id AND a.role_version=s.role_version WHERE s.token_hmac=%s AND s.key_version=%s
                  AND s.expires_at>now() AND s.absolute_expires>now() AND a.status='active'""",(self.security.digest('staff_session',secret),self.security.key_version))
                if not row:return boot
                grants=await many(connection,'SELECT permission FROM nt.staff_roles WHERE staff_id=%s',(row['staff_id'],))
                return Principal('staff',str(row['staff_id']),secret,account_id=row['staff_id'],grants=frozenset(g['permission'] for g in grants),mfa_at=row['mfa_at'])
        if scope:
            require(scope in {'case','financial','deletion'},'AUTHORITY_INVALID',400)
            secret=cookies.get(scope)
            if not secret:return None
            async with self.db.transaction('support') as connection:
                row=await one(connection,"""SELECT r.* FROM nt.scoped_status_sessions s JOIN nt.scoped_receipts r ON r.public_ref=s.receipt_ref
                  WHERE s.token_hmac=%s AND s.key_version=%s AND r.kind=%s AND r.revoked_at IS NULL
                  AND s.expires_at>now() AND s.absolute_expires>now()""",(self.security.digest('scope_session',secret),self.security.key_version,scope))
                return Principal(scope,row['public_ref'],secret,scope=row['subject_ref']) if row else None
        secret=cookies.get('account')
        if secret:
            async with self.db.transaction() as connection:
                row=await one(connection,"""SELECT a.*,s.id AS session_id,s.reauth_at,s.expires_at AS session_expires_at,s.absolute_expires AS session_absolute_expires FROM nt.account_sessions s JOIN nt.accounts a
                  ON a.id=s.account_id AND a.auth_generation=s.auth_generation WHERE s.token_hmac=%s AND s.key_version=%s
                  AND s.revoked_at IS NULL AND s.expires_at>now() AND s.absolute_expires>now() AND a.status IN ('active','restricted')""",
                  (self.security.digest('account_session',secret),self.security.key_version))
                if row and row['public_ref'] not in self.fenced_subjects:
                    return Principal('account',row['public_ref'],secret,row['id'],row['session_id'],row,bootstrap_ref=boot.ref if boot else None)
        secret=cookies.get('guest')
        if secret:
            guest=self.guests.get(self.security.digest('guest',secret))
            if guest and guest['ref'] not in self.fenced_subjects:
                return Principal('guest',guest['ref'],secret,account=guest['profile'],bootstrap_ref=boot.ref if boot else None)
        return boot

    def consents(self,value):
        require(value.adult and value.terms and value.core,'CURRENT_CONSENTS_REQUIRED',422)
        require(self.policy is not None,'POLICY_UNAVAILABLE',503)
        self.policy.validate(value)

    async def guest_access(self,principal):
        """Guest safety decisions survive conversion because public_ref is retained."""
        require(principal.kind=='guest','GUEST_REQUIRED',401)
        guest=self.guests.get(self.security.digest('guest',principal.token))
        require(guest and guest['until']>time.monotonic() and guest['absolute']>time.monotonic(),'SESSION_EXPIRED',401)
        async with self.db.transaction() as connection:
            restriction=await one(connection,"SELECT 1 FROM nt.restrictions WHERE subject_ref=%s AND starts_at<=now() AND (ends_at IS NULL OR ends_at>now()) LIMIT 1",(principal.ref,))
        require(not restriction,'PARTICIPATION_RESTRICTED',403)
        return guest['profile']

    def fence(self,ref,reason='authority_changed'):
        if ref not in self.realtime.people:return
        self.realtime.end(ref,reason)
        person=self.realtime.people[ref];person.connected=False;person.generation+=1;person.commands.clear()
        for key in [k for k,v in self.tickets.items() if v['ref']==ref]:self.tickets.pop(key,None)

    async def lock_account(self,connection,principal,*,fresh=False):
        require(principal.kind=='account','ACCOUNT_REQUIRED',401)
        row=await one(connection,"""SELECT a.*,s.reauth_at,s.id AS session_id,s.expires_at AS session_expires_at,s.absolute_expires AS session_absolute_expires FROM nt.accounts a JOIN nt.account_sessions s ON s.account_id=a.id
          WHERE a.id=%s AND s.id=%s AND s.token_hmac=%s AND s.key_version=%s AND s.auth_generation=a.auth_generation
          AND s.revoked_at IS NULL AND s.expires_at>now() AND s.absolute_expires>now() AND a.status IN ('active','restricted') FOR UPDATE OF a""",
          (principal.account_id,principal.session_id,self.security.digest('account_session',principal.token),self.security.key_version))
        require(row and row['public_ref'] not in self.fenced_subjects and row['auth_generation']==principal.account['auth_generation'],'AUTHENTICATION_REQUIRED',401)
        if fresh:require(row['reauth_at'] and timedelta(0)<=now()-row['reauth_at']<=timedelta(minutes=5),'REAUTH_REQUIRED',401)
        return row

    def guest(self,principal,dto):
        self.consents(dto.consents);require(principal.kind=='bootstrap','ALREADY_AUTHENTICATED')
        self.prune();require(len(self.guests)<200,'GUEST_CAPACITY',503)
        secret,ref=token(),uuid4().hex
        profile=dto.model_dump(exclude={'consents'})|{'core_consent':True,'professional_consent':dto.consents.professional,
                  'consent_revision':1,'profile_revision':1,'preference_revision':1,'professional':{},'preferences':{}}
        profile['display_name']='Guest '+ref[:8]
        profile['safety_revision']=1
        proof=[{'purpose':p,'choice':getattr(dto.consents,p),'policy_version':self.policy_version,'publication_digest':self.policy_digest,
                'text_digest':self.policy.purposes[p]['text_digest'],'decision_text':self.policy.purposes[p]['label'],'proof_format':2,'decision_revision':1,'recorded_at':now().isoformat()} for p in self.policy.purposes]
        self.realtime.enter(ref,profile)
        self.guests[self.security.digest('guest',secret)]={'ref':ref,'profile':profile,'proof':proof,'until':time.monotonic()+1800,
                                                        'last_active':time.monotonic(),'absolute':time.monotonic()+86400}
        return Principal('guest',ref,secret,account=profile,bootstrap_ref=principal.ref)

    async def record_consents(self,connection,account_id,ref,values,revision=1):
        for purpose,choice in values.items():
            await connection.execute("""INSERT INTO nt.consent_records(id,account_id,retained_subject_ref,purpose,choice,policy_version,text_digest,publication_digest,proof_format,decision_text,decision_revision)
              VALUES(%s,%s,%s,%s,%s,%s,%s,%s,2,%s,%s)""",(uuid4(),account_id,ref,purpose,choice,self.policy_version,self.policy.purposes[purpose]['text_digest'],self.policy_digest,self.policy.purposes[purpose]['label'],revision))

    def request_digest(self,kind,dto):return self.security.digest('operation:'+kind,canonical(dto.model_dump()).decode())

    async def previous(self,connection,ref,kind,nonce,payload_digest):
        row=await one(connection,"SELECT * FROM nt.operation_results WHERE scope_ref=%s AND kind=%s AND client_nonce=%s AND expires_at>now()",(ref,kind,UUID(nonce)))
        if row:require(row['keyed_digest']==payload_digest,'NONCE_CONFLICT',409)
        return row['result'] if row else None

    async def save_operation(self,connection,ref,kind,nonce,payload_digest,result):
        from psycopg.types.json import Jsonb
        await connection.execute("INSERT INTO nt.operation_results(scope_ref,kind,client_nonce,keyed_digest,result,key_version) VALUES(%s,%s,%s,%s,%s,%s)",
                                 (ref,kind,UUID(nonce),payload_digest,Jsonb(result),self.security.key_version))

    async def create_session(self,connection,account_id,generation,secret=None):
        row=await one(connection,"SELECT auth_generation,status FROM nt.accounts WHERE id=%s FOR UPDATE",(account_id,))
        require(row and row['auth_generation']==generation and row['status'] in ('active','restricted'),'AUTHENTICATION_REQUIRED',401)
        count=await one(connection,"SELECT count(*) AS n FROM nt.account_sessions WHERE account_id=%s AND revoked_at IS NULL AND expires_at>now() AND absolute_expires>now()",(account_id,))
        require(count['n']<5,'SESSION_LIMIT',409);secret=secret or token();sid=uuid4()
        await connection.execute("""INSERT INTO nt.account_sessions(id,account_id,token_hmac,auth_generation,expires_at,absolute_expires,reauth_at,key_version)
          VALUES(%s,%s,%s,%s,now()+interval '7 days',now()+interval '30 days',now(),%s)""",(sid,account_id,self.security.digest('account_session',secret),generation,self.security.key_version))
        return secret,str(sid)

    async def live_result_session(self,connection,account,result,secret):
        require(result['generation']==account['auth_generation'],'OPERATION_AUTHORITY_CHANGED',409)
        row=await one(connection,"SELECT id FROM nt.account_sessions WHERE id=%s AND account_id=%s AND auth_generation=%s AND token_hmac=%s AND revoked_at IS NULL AND expires_at>now() AND absolute_expires>now()",
                      (UUID(result['session_id']),account['id'],account['auth_generation'],self.security.digest('account_session',secret)))
        require(row,'OPERATION_SESSION_EXPIRED',401)
        return secret

    async def registration(self,principal,dto):
        username=normalize_username(dto.username);payload=self.request_digest('registration',dto)
        async def retry(connection):
            account=await one(connection,'SELECT * FROM nt.accounts WHERE username=%s FOR UPDATE',(username,))
            if not account:return None
            old=await self.previous(connection,account['public_ref'],'registration',dto.client_nonce,payload)
            if not old:return None
            require(account['status']=='active' and self.security.verify('receipt',dto.proof.secret,account['recovery_verifier']),'REGISTRATION_RETRY_INVALID',401)
            require(principal.kind in ('bootstrap','guest') or principal.kind=='account' and principal.account_id==account['id'],'REGISTRATION_RETRY_INVALID',401)
            secret=self.security.derived_token('registration',dto.proof.secret,dto.client_nonce,account['public_ref'])
            return await self.live_result_session(connection,account,old,secret)
        async with self.db.transaction() as connection:
            previous=await retry(connection)
            if previous:
                self.reservations.items.pop(dto.proof.reservation_id,None)
                return previous
        require(principal.kind in ('bootstrap','guest'),'ALREADY_AUTHENTICATED',409);self.consents(dto.consents)
        proof=self.reservations.claim(principal.ref,'recovery',dto.proof,dto.client_nonce,payload)
        guest=self.guests.get(self.security.digest('guest',principal.token)) if principal.kind=='guest' else None
        require(principal.kind!='guest' or guest is not None,'SESSION_EXPIRED',401)
        person=self.realtime.people.get(principal.ref)
        captured=(tuple(guest['profile'].get(k,1) for k in ('profile_revision','preference_revision','consent_revision')),person.revision,person.generation) if guest and person else None
        encoded=await self.passwords.hash(dto.password)
        async with self.db.transaction() as connection:
            await connection.execute('SELECT pg_advisory_xact_lock(hashtextextended(%s,0))',('register:'+username,))
            if guest:await connection.execute('SELECT pg_advisory_xact_lock(hashtextextended(%s,0))',('subject:'+principal.ref,))
            previous=await retry(connection)
            if previous:return previous
            self.reservations.proof(principal.ref,'recovery',**dto.proof.model_dump())
            require(not await one(connection,'SELECT id FROM nt.accounts WHERE username=%s',(username,)),'USERNAME_UNAVAILABLE',409)
            # Expiry/withdrawal while hashing cannot create a converted identity.
            if guest:
                require(self.guests.get(self.security.digest('guest',principal.token)) is guest and guest['until']>time.monotonic() and guest['profile']['core_consent'],'SESSION_EXPIRED',401)
                current=self.realtime.people.get(principal.ref)
                require(current and captured==(tuple(guest['profile'].get(k,1) for k in ('profile_revision','preference_revision','consent_revision')),current.revision,current.generation),'CONVERSION_CHANGED',409)
            aid,subject,financial=uuid4(),uuid4(),uuid4();ref=principal.ref if guest else uuid4().hex
            await connection.execute("""INSERT INTO nt.accounts(id,public_ref,username,password_hash,recovery_verifier,recovery_key_version,display_name,gender,topic_id,bio,core_consent,professional_consent)
              VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,true,%s)""",(aid,ref,username,encoded,proof['verifier'],proof['key_version'],dto.display_name,dto.gender,dto.topic_id,dto.bio,dto.consents.professional))
            # Only new-account conversion imports private guest choices, and only
            # under fresh optional consent. Login never imports a guest profile.
            if guest and dto.consents.professional and guest['profile']['professional_consent']:
                from psycopg.types.json import Jsonb
                await connection.execute('UPDATE nt.accounts SET professional=%s,preferences=%s WHERE id=%s',
                    (Jsonb(dict(guest['profile'].get('professional',{}))),Jsonb(dict(guest['profile'].get('preferences',{}))),aid))
            await connection.execute('INSERT INTO nt.financial_subjects(id,account_id) VALUES(%s,%s)',(financial,aid))
            await connection.execute('INSERT INTO nt.subject_controls(subject_id,account_id,financial_subject_id) VALUES(%s,%s,%s)',(subject,aid,financial))
            await self.record_consents(connection,aid,ref,{p:getattr(dto.consents,p) for p in self.policy.purposes})
            secret=self.security.derived_token('registration',dto.proof.secret,dto.client_nonce,ref)
            secret,sid=await self.create_session(connection,aid,1,secret)
            await self.save_operation(connection,ref,'registration',dto.client_nonce,payload,{'registered':True,'session_id':sid,'generation':1})
            await connection.execute("INSERT INTO nt.outbox(id,kind,object_ref,metric_id) VALUES(%s,'metric',%s,1)",(uuid4(),ref))
            if guest:
                current=self.realtime.people.get(principal.ref)
                require(self.guests.get(self.security.digest('guest',principal.token)) is guest and guest['until']>time.monotonic() and current and captured==(tuple(guest['profile'].get(k,1) for k in ('profile_revision','preference_revision','consent_revision')),current.revision,current.generation),'CONVERSION_CHANGED',409)
        if guest:
            person=self.realtime.people.get(principal.ref)
            if person:
                if captured[1:]!=(person.revision,person.generation):self.fence(principal.ref,'conversion_changed')
                person.registered=True;person.connected=False;person.disconnected_at=self.realtime.clock();person.generation+=1
                interaction=self.realtime.interactions.get(person.interaction)
                if interaction and interaction.call:self.realtime.end_call(interaction,'credentials_changed')
            self.guests.pop(self.security.digest('guest',principal.token),None)
        self.reservations.items.pop(dto.proof.reservation_id,None)
        return secret

    async def login(self,principal,dto):
        require(principal.kind in ('bootstrap','guest'),'ALREADY_AUTHENTICATED',409)
        require(principal.kind!='guest' or dto.end_guest,'GUEST_END_CONFIRMATION_REQUIRED',409)
        username=normalize_username(dto.username);self.limiter.take(('login',self.security.digest('username',username)),5,300)
        async with self.db.transaction() as connection:
            account=await one(connection,"SELECT * FROM nt.accounts WHERE username=%s AND status IN ('active','restricted')",(username,))
        valid=await self.passwords.verify(dto.password,account['password_hash'] if account else None)
        require(valid and account['public_ref'] not in self.fenced_subjects,'CREDENTIALS_INVALID',401)
        replacement=await self.passwords.hash(dto.password) if self.passwords.needs_rehash(account['password_hash']) else None
        async with self.db.transaction() as connection:
            locked=await one(connection,'SELECT * FROM nt.accounts WHERE id=%s FOR UPDATE',(account['id'],))
            require(locked['password_hash']==account['password_hash'] and locked['auth_generation']==account['auth_generation'] and locked['status'] in ('active','restricted'),'CREDENTIALS_INVALID',401)
            if replacement:await connection.execute('UPDATE nt.accounts SET password_hash=%s WHERE id=%s',(replacement,account['id']))
            count=await one(connection,"SELECT count(*) AS n FROM nt.account_sessions WHERE account_id=%s AND revoked_at IS NULL AND expires_at>now() AND absolute_expires>now()",(account['id'],))
            if count['n']>=5:
                self.prune();key=principal.bootstrap_ref
                require(key,'BOOTSTRAP_REQUIRED',401);require(key in self.challenges or len(self.challenges)<64,'CHALLENGE_CAPACITY',429)
                self.challenges[key]={'principal':principal.ref,'account':account['id'],'generation':locked['auth_generation'],'until':time.monotonic()+300}
                return {'session_limit':True}
            secret,_=await self.create_session(connection,account['id'],locked['auth_generation'])
        if principal.kind=='guest':self.guests.pop(self.security.digest('guest',principal.token),None);self.realtime.retire(principal.ref)
        return {'secret':secret}

    async def session_limit(self,principal,revoke=None):
        self.prune();key=principal.bootstrap_ref;challenge=self.challenges.get(key)
        require(challenge and challenge['principal']==principal.ref,'CHALLENGE_EXPIRED',401)
        if revoke:self.challenges.pop(key,None) # Consume before awaiting; failures require a new password-verified challenge.
        async with self.db.transaction() as connection:
            account=await one(connection,'SELECT * FROM nt.accounts WHERE id=%s FOR UPDATE',(challenge['account'],))
            require(account and account['auth_generation']==challenge['generation'] and account['status'] in ('active','restricted') and account['public_ref'] not in self.fenced_subjects,'CHALLENGE_EXPIRED',401)
            if revoke:
                row=await one(connection,"UPDATE nt.account_sessions SET revoked_at=now() WHERE id=%s AND account_id=%s AND revoked_at IS NULL AND expires_at>now() AND absolute_expires>now() RETURNING id",(UUID(revoke),account['id']))
                require(row,'NOT_FOUND',404);secret,_=await self.create_session(connection,account['id'],account['auth_generation'])
            else:return {'sessions':await many(connection,"SELECT id,created_at,last_active FROM nt.account_sessions WHERE account_id=%s AND revoked_at IS NULL AND expires_at>now() AND absolute_expires>now() ORDER BY created_at",(account['id'],))}
        self.fence(account['public_ref'],'session_revoked')
        if principal.kind=='guest':self.guests.pop(self.security.digest('guest',principal.token),None);self.realtime.retire(principal.ref)
        return {'secret':secret}

    async def reauthenticate(self,principal,password):
        require(principal.kind=='account','ACCOUNT_REQUIRED',401);self.limiter.take(('reauth',principal.ref),5,300)
        require(await self.passwords.verify(password,principal.account['password_hash']),'CREDENTIALS_INVALID',401)
        async with self.db.transaction() as connection:
            row=await self.lock_account(connection,principal)
            require(row['password_hash']==principal.account['password_hash'],'AUTHENTICATION_REQUIRED',401)
            await connection.execute('UPDATE nt.account_sessions SET reauth_at=now() WHERE id=%s',(principal.session_id,))

    def fresh(self,principal):
        require(principal.kind=='account' and principal.account.get('reauth_at') and timedelta(0)<=now()-principal.account['reauth_at']<=timedelta(minutes=5),'REAUTH_REQUIRED',401)

    async def recover(self,principal,dto):
        require(principal.kind in ('bootstrap','guest'),'LOG_OUT_BEFORE_RECOVERY',409)
        username=normalize_username(dto.username);self.limiter.take(('recovery',self.security.digest('username',username)),3,3600)
        payload=self.request_digest('recovery',dto)
        async with self.db.transaction() as connection:
            account=await one(connection,'SELECT * FROM nt.accounts WHERE username=%s FOR UPDATE',(username,))
            old=await self.previous(connection,account['public_ref'],'recovery',dto.client_nonce,payload) if account else None
            if old:
                require(account['status'] in ('active','restricted') and account['public_ref'] not in self.fenced_subjects and account['auth_generation']==old['generation'] and self.security.verify('receipt',dto.proof.secret,account['recovery_verifier']),'OPERATION_AUTHORITY_CHANGED',409)
                self.reservations.items.pop(dto.proof.reservation_id,None)
                return
        proof=self.reservations.claim(principal.ref,'recovery',dto.proof,dto.client_nonce,payload)
        encoded=await self.passwords.hash(dto.password)
        async with self.db.transaction() as connection:
            account=await one(connection,'SELECT * FROM nt.accounts WHERE username=%s FOR UPDATE',(username,))
            require(account and account['status'] in ('active','restricted') and account['public_ref'] not in self.fenced_subjects,'CREDENTIALS_INVALID',401)
            old=await self.previous(connection,account['public_ref'],'recovery',dto.client_nonce,payload)
            if old:
                require(old['generation']==account['auth_generation'] and self.security.verify('receipt',dto.proof.secret,account['recovery_verifier']),'OPERATION_AUTHORITY_CHANGED',409);return
            self.reservations.proof(principal.ref,'recovery',**dto.proof.model_dump())
            require(self.security.verify('receipt',dto.recovery_secret,account['recovery_verifier']),'CREDENTIALS_INVALID',401)
            await connection.execute('UPDATE nt.accounts SET password_hash=%s,recovery_verifier=%s,recovery_key_version=%s,auth_generation=auth_generation+1 WHERE id=%s',(encoded,proof['verifier'],proof['key_version'],account['id']))
            await connection.execute('UPDATE nt.account_sessions SET revoked_at=now() WHERE account_id=%s',(account['id'],))
            await self.save_operation(connection,account['public_ref'],'recovery',dto.client_nonce,payload,{'recovered':True,'generation':account['auth_generation']+1})
        self.reservations.items.pop(dto.proof.reservation_id,None)
        self.fence(account['public_ref'],'credentials_rotated')

    async def credential_change(self,principal,dto,kind):
        require(principal.kind in ('account','credential_retry'),'ACCOUNT_REQUIRED',401)
        payload=self.request_digest(kind,dto)
        # Find only this cookie's account; a case/financial/deletion principal never enters here.
        async with self.db.transaction() as connection:
            source=await one(connection,"SELECT a.*,s.id AS source_session FROM nt.accounts a JOIN nt.account_sessions s ON s.account_id=a.id WHERE s.token_hmac=%s FOR UPDATE OF a",(self.security.digest('account_session',principal.token),))
            require(source and source['status'] in ('active','restricted') and source['public_ref'] not in self.fenced_subjects,'AUTHENTICATION_REQUIRED',401)
            old=await self.previous(connection,source['public_ref'],kind,dto.client_nonce,payload)
            if old:
                require(str(source['source_session']) in (old['source_session'],old['session_id']),'AUTHENTICATION_REQUIRED',401)
                secret=principal.token if str(source['source_session'])==old['session_id'] else self.security.derived_token(kind,dto.proof.secret if kind=='rotate_recovery' else principal.token,dto.client_nonce,source['public_ref'])
                return await self.live_result_session(connection,source,old,secret)
            await self.lock_account(connection,principal,fresh=True)
        proof=self.reservations.claim(principal.ref,'recovery',dto.proof,dto.client_nonce,payload) if kind=='rotate_recovery' else None
        encoded=await self.passwords.hash(dto.password) if kind=='password_change' else None
        async with self.db.transaction() as connection:
            account=await self.lock_account(connection,principal,fresh=True)
            old=await self.previous(connection,account['public_ref'],kind,dto.client_nonce,payload)
            if old:
                secret=self.security.derived_token(kind,dto.proof.secret if proof else principal.token,dto.client_nonce,account['public_ref'])
                return await self.live_result_session(connection,account,old,secret)
            if proof:
                self.reservations.proof(principal.ref,'recovery',**dto.proof.model_dump())
                await connection.execute('UPDATE nt.accounts SET recovery_verifier=%s,recovery_key_version=%s,auth_generation=auth_generation+1 WHERE id=%s',(proof['verifier'],proof['key_version'],principal.account_id))
            else:await connection.execute('UPDATE nt.accounts SET password_hash=%s,auth_generation=auth_generation+1 WHERE id=%s',(encoded,principal.account_id))
            await connection.execute('UPDATE nt.account_sessions SET revoked_at=now() WHERE account_id=%s',(principal.account_id,))
            secret=self.security.derived_token(kind,dto.proof.secret if proof else principal.token,dto.client_nonce,account['public_ref'])
            secret,sid=await self.create_session(connection,principal.account_id,account['auth_generation']+1,secret)
            await self.save_operation(connection,principal.ref,kind,dto.client_nonce,payload,{'source_session':str(principal.session_id),'session_id':sid,'generation':account['auth_generation']+1})
        if proof:self.reservations.items.pop(dto.proof.reservation_id,None)
        self.fence(principal.ref,'credentials_rotated');return secret

    async def logout(self,principal,all_sessions=False):
        if principal.kind=='account':
            async with self.db.transaction() as connection:
                await self.lock_account(connection,principal)
                if all_sessions:
                    await connection.execute('UPDATE nt.accounts SET auth_generation=auth_generation+1 WHERE id=%s',(principal.account_id,))
                    await connection.execute('UPDATE nt.account_sessions SET revoked_at=now() WHERE account_id=%s',(principal.account_id,))
                else:await connection.execute('UPDATE nt.account_sessions SET revoked_at=now() WHERE id=%s',(principal.session_id,))
        elif principal.kind=='guest':self.guests.pop(self.security.digest('guest',principal.token),None)
        self.fence(principal.ref,'logout')
        if principal.kind=='guest':self.realtime.retire(principal.ref);self.participation_fences.discard(principal.ref)

    async def foreground(self,principal):
        if principal.kind=='account':
            async with self.db.transaction() as connection:
                await self.lock_account(connection,principal)
                await connection.execute("UPDATE nt.account_sessions SET last_active=now(),expires_at=LEAST(absolute_expires,now()+interval '7 days') WHERE id=%s AND last_active<now()-interval '1 minute'",(principal.session_id,))
        elif principal.kind=='guest':
            guest=self.guests.get(self.security.digest('guest',principal.token));current=time.monotonic()
            if guest and current-guest['last_active']>=60:guest.update(last_active=current,until=min(current+1800,guest['absolute']))
        elif principal.kind in ('case','financial','deletion'):
            async with self.db.transaction('support') as connection:
                await connection.execute("UPDATE nt.scoped_status_sessions SET last_active=now(),expires_at=LEAST(absolute_expires,now()+interval '30 minutes') WHERE token_hmac=%s AND last_active<now()-interval '1 minute' AND expires_at>now() AND absolute_expires>now()",(self.security.digest('scope_session',principal.token),))
        elif principal.kind=='staff':
            async with self.db.transaction('private') as connection:
                await connection.execute("UPDATE nt.staff_sessions SET last_active=now(),expires_at=LEAST(absolute_expires,now()+interval '15 minutes') WHERE token_hmac=%s AND last_active<now()-interval '1 minute' AND expires_at>now() AND absolute_expires>now()",(self.security.digest('staff_session',principal.token),))

    async def scoped_access(self,kind,reference,secret):
        require(kind in ('case','financial','deletion'),'AUTHORITY_INVALID',400)
        self.limiter.take(('scope_access',reference),5,300)
        async with self.db.transaction('support') as connection:
            row=await one(connection,'SELECT * FROM nt.scoped_receipts WHERE public_ref=%s AND kind=%s AND revoked_at IS NULL',(reference,kind))
            require(row and self.security.verify('receipt',secret,row['verifier']),'CREDENTIALS_INVALID',401)
            session=token()
            await connection.execute("INSERT INTO nt.scoped_status_sessions(token_hmac,receipt_ref,expires_at,absolute_expires,key_version) VALUES(%s,%s,now()+interval '30 minutes',now()+interval '24 hours',%s)",(self.security.digest('scope_session',session),reference,self.security.key_version))
        return session

    async def staff_login(self,dto):
        self.limiter.take(('staff_login',self.security.digest('username',dto.username.lower())),5,300)
        async with self.db.transaction('private') as connection:
            row=await one(connection,"SELECT * FROM nt.staff_accounts WHERE username=%s AND status='active'",(dto.username.lower(),))
        require(await self.passwords.verify(dto.password,row['password_hash'] if row else None),'CREDENTIALS_INVALID',401)
        async with self.db.transaction('private') as connection:
            staff=await one(connection,"SELECT * FROM nt.staff_accounts WHERE id=%s AND status='active' FOR UPDATE",(row['id'],))
            require(staff and staff['password_hash']==row['password_hash'],'CREDENTIALS_INVALID',401)
            counter=totp_counter(self.security.decrypt('staff:'+str(staff['id']),staff['totp_ciphertext']),dto.code,staff['last_totp_counter'])
            await connection.execute('UPDATE nt.staff_accounts SET last_totp_counter=%s WHERE id=%s',(counter,staff['id']))
            secret=token()
            await connection.execute("INSERT INTO nt.staff_sessions(token_hmac,staff_id,role_version,mfa_at,expires_at,absolute_expires) VALUES(%s,%s,%s,now(),now()+interval '15 minutes',now()+interval '4 hours')",(self.security.digest('staff_session',secret),staff['id'],staff['role_version']))
            return secret


    async def staff_recovery(self,dto):
        self.limiter.take(('staff_recovery',self.security.digest('username',dto.username)),3,3600)
        async with self.db.transaction('private') as connection:
            row=await one(connection,"SELECT * FROM nt.staff_accounts WHERE username=%s AND status='active'",(dto.username.lower(),))
        require(await self.passwords.verify(dto.password,row['password_hash'] if row else None),'CREDENTIALS_INVALID',401)
        async with self.db.transaction('private') as connection:
            staff=await one(connection,"SELECT * FROM nt.staff_accounts WHERE id=%s AND status='active' FOR UPDATE",(row['id'],))
            require(staff and staff['password_hash']==row['password_hash'],'CREDENTIALS_INVALID',401)
            code=await one(connection,'UPDATE nt.staff_recovery_codes SET consumed_at=now() WHERE staff_id=%s AND verifier=%s AND consumed_at IS NULL RETURNING staff_id',(row['id'],self.security.digest('staff_recovery',dto.recovery_code)))
            require(code,'CREDENTIALS_INVALID',401)
            secret=token()
            await connection.execute("INSERT INTO nt.staff_sessions(token_hmac,staff_id,role_version,mfa_at,expires_at,absolute_expires) VALUES(%s,%s,%s,now(),now()+interval '15 minutes',now()+interval '4 hours')",(self.security.digest('staff_session',secret),staff['id'],staff['role_version']))
        return secret


    async def staff_step_up(self,principal,dto):
        require(principal.kind=='staff','FORBIDDEN',403)
        self.limiter.take(('staff_step_up',principal.ref),5,300)
        async with self.db.transaction('private') as connection:
            row=await one(connection,"SELECT * FROM nt.staff_accounts WHERE id=%s AND status='active'",(principal.account_id,))
        require(row and await self.passwords.verify(dto.password,row['password_hash']),'CREDENTIALS_INVALID',401)
        async with self.db.transaction('private') as connection:
            staff=await one(connection,"SELECT * FROM nt.staff_accounts WHERE id=%s AND status='active' FOR UPDATE",(principal.account_id,))
            require(staff and staff['password_hash']==row['password_hash'],'CREDENTIALS_INVALID',401)
            counter=totp_counter(self.security.decrypt('staff:'+str(staff['id']),staff['totp_ciphertext']),dto.code,staff['last_totp_counter'])
            updated=await one(connection,"UPDATE nt.staff_sessions SET mfa_at=now() WHERE token_hmac=%s AND role_version=%s AND expires_at>now() AND absolute_expires>now() RETURNING staff_id",(self.security.digest('staff_session',principal.token),staff['role_version']))
            require(updated,'AUTHENTICATION_REQUIRED',401)
            await connection.execute('UPDATE nt.staff_accounts SET last_totp_counter=%s WHERE id=%s',(counter,staff['id']))
        return {'verified_for_seconds':300}


