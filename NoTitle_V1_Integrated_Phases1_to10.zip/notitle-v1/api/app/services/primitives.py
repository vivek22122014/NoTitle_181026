import asyncio
from collections import OrderedDict
from dataclasses import dataclass
import os
import re
import time
from uuid import uuid4
from cryptography.hazmat.primitives.kdf.argon2 import Argon2id
from cryptography.exceptions import InvalidKey
from app.domain.errors import require
from app.domain.security import token, validate_password


class Passwords:
    def __init__(self):
        self.semaphore = asyncio.Semaphore(2)
        self.running=set()
        self.dummy = Argon2id(salt=os.urandom(16), length=32, iterations=3, lanes=1, memory_cost=65536).derive_phc_encoded(os.urandom(32))

    async def work(self,function):
        try:
            async with asyncio.timeout(2):await self.semaphore.acquire()
        except TimeoutError:require(False,'AUTH_BUSY',503)
        async def execute():
            try:return await asyncio.to_thread(function)
            finally:self.semaphore.release()
        task=asyncio.create_task(execute());self.running.add(task)
        def finished(result):
            self.running.discard(result)
            if not result.cancelled():result.exception()
        task.add_done_callback(finished)
        # Client cancellation cannot release the permit while its CPU work continues.
        return await asyncio.shield(task)

    async def hash(self, password):
        validate_password(password)
        return await self.work(lambda: Argon2id(salt=os.urandom(16), length=32, iterations=3, lanes=1,
                                                memory_cost=65536).derive_phc_encoded(password.encode()))

    async def verify(self, password, encoded):
        validate_password(password)
        parameters=re.match(r'^\$argon2id\$v=19\$m=(\d+),t=(\d+),p=(\d+)\$',encoded or '')
        safe=bool(parameters and 8*int(parameters[3])<=int(parameters[1])<=65536 and 1<=int(parameters[2])<=6 and 1<=int(parameters[3])<=4)
        def verify():
            try:
                Argon2id.verify_phc_encoded(password.encode(), encoded if safe else self.dummy)
                return bool(encoded and safe)
            except (InvalidKey,ValueError):return False
        return await self.work(verify)

    @staticmethod
    def needs_rehash(encoded):
        match=re.match(r'^\$argon2id\$v=19\$m=(\d+),t=(\d+),p=(\d+)\$',encoded)
        return not match or tuple(map(int,match.groups()))!=(65536,3,1)


class Limiter:
    def __init__(self, clock=time.monotonic, max_keys=4096):
        self.clock, self.max_keys, self.entries = clock, max_keys, OrderedDict()

    def take(self, key, capacity, per_seconds):
        now = self.clock()
        for stale in [k for k, (_, t, expiry) in self.entries.items() if expiry <= now]:
            del self.entries[stale]
        previous = self.entries.get(key)
        require(previous is not None or len(self.entries) < self.max_keys, "RATE_CAPACITY", 429)
        tokens, last, _ = previous or (capacity, now, now)
        tokens = min(capacity, tokens + (now - last) * capacity / per_seconds)
        require(tokens >= 1, "RATE_LIMITED", 429)
        self.entries[key] = (tokens - 1, now, now + per_seconds)


class Reservations:
    def __init__(self, security, clock=time.monotonic):
        self.security, self.clock, self.items = security, clock, {}

    def prepare(self, principal, kind, nonce):
        require(kind in {"recovery", "case", "financial", "deletion"}, "OPERATION_KIND", 422)
        self.items = {k: v for k, v in self.items.items() if v["until"] > self.clock()}
        require(not any(v["principal"] == principal and v["nonce"] == nonce for v in self.items.values()),
                "SECRET_ALREADY_SHOWN_PREPARE_NEW_NONCE")
        require(len(self.items) < 512 and sum(v["principal"] == principal for v in self.items.values()) < 4, "RESERVATION_CAPACITY", 429)
        reference, secret = uuid4().hex, token()
        self.items[reference] = {"principal": principal, "kind": kind, "nonce": nonce,
            "verifier": self.security.verifier("receipt", secret), "key_version":self.security.key_version,"until": self.clock() + 600}
        return {"reservation_id": reference, "secret": secret, "expires_in": 600}

    def proof(self, principal, kind, reservation_id, secret, saved):
        item = self.items.get(reservation_id)
        require(saved is True and item and item["until"] > self.clock() and item["principal"] == principal and item["kind"] == kind
                and self.security.verify("receipt", secret, item["verifier"]), "PREPARATION_REQUIRED", 422)
        return item

    def claim(self,principal,kind,proof,nonce,payload_digest):
        item=self.proof(principal,kind,**proof.model_dump())
        expected=(nonce,payload_digest)
        require(item.get('commit') in (None,expected),'NONCE_CONFLICT',409)
        item['commit']=expected
        return item


@dataclass
class Principal:
    kind: str
    ref: str
    token: str
    account_id: object = None
    session_id: object = None
    account: dict | None = None
    scope: str | None = None
    grants: frozenset = frozenset()
    mfa_at: object = None
    bootstrap_ref: str | None = None

    def permission(self, grant):
        require(self.kind == "staff" and grant in self.grants, "FORBIDDEN", 403)
