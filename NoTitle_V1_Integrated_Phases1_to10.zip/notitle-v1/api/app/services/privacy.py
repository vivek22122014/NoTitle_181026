import asyncio
import json
from uuid import uuid4, UUID
from datetime import timedelta
from app.domain.errors import require
from app.repositories.database import one, many
from .identity import now


class Privacy:
    def __init__(self,db,security,identity,journal=None):
        self.db,self.security,self.identity,self.journal=db,security,identity,journal
        self.serial=asyncio.Lock()

    async def bind_receipt(self,principal,kind,proof):
        self.identity.fresh(principal)
        reservation=self.identity.reservations.proof(principal.ref,kind,**proof.model_dump())
        async with self.db.transaction() as connection:
            await self.identity.lock_account(connection,principal,fresh=True)
            subject=await one(connection,'SELECT * FROM nt.subject_controls WHERE account_id=%s FOR UPDATE',(principal.account_id,))
            scope=str(subject['financial_subject_id'] if kind=='financial' else subject['subject_id'])
            existing=await one(connection,'SELECT * FROM nt.scoped_receipts WHERE public_ref=%s FOR UPDATE',(proof.reservation_id,))
            if existing:require(existing['kind']==kind and existing['subject_ref']==scope and existing['verifier']==reservation['verifier'],'RECEIPT_CONFLICT',409)
            else:await connection.execute('INSERT INTO nt.scoped_receipts(public_ref,kind,subject_ref,verifier,key_version) VALUES(%s,%s,%s,%s,%s)',(proof.reservation_id,kind,scope,reservation['verifier'],reservation['key_version']))
        return {'receipt_ref':proof.reservation_id,'kind':kind}

    async def delete(self,principal,dto):
        async with self.serial:
            return await self._delete(principal,dto)

    async def _delete(self,principal,dto):
        self.identity.fresh(principal)
        require(self.journal is not None,'JOURNAL_UNAVAILABLE',503)
        self.identity.reservations.proof(principal.ref,'deletion',**dto.proof.model_dump())
        await self.bind_receipt(principal,'deletion',dto.proof)
        async with self.db.transaction() as connection:
            subject=await one(connection,'SELECT * FROM nt.subject_controls WHERE account_id=%s',(principal.account_id,))
        # Fence first, before IO. Do not allow reconnect while remote acknowledgment is pending.
        async with self.db.transaction() as connection:
            await self.identity.lock_account(connection,principal,fresh=True)
            self.identity.fenced_subjects.add(principal.ref)
            self.identity.fence(principal.ref,'deletion')
            await one(connection,'SELECT * FROM nt.subject_controls WHERE subject_id=%s FOR UPDATE',(subject['subject_id'],))
            await connection.execute("UPDATE nt.subject_controls SET deletion_state='pending_confirmation',revision=revision+1 WHERE subject_id=%s",(subject['subject_id'],))
            await connection.execute("UPDATE nt.accounts SET status='deleting',deleted_at=COALESCE(deleted_at,now()),auth_generation=auth_generation+1 WHERE id=%s",(principal.account_id,))
            await connection.execute('UPDATE nt.account_sessions SET revoked_at=now() WHERE account_id=%s',(principal.account_id,))
            await connection.execute('DELETE FROM nt.privacy_exports WHERE subject_id=%s',(subject['subject_id'],))
            await connection.execute("INSERT INTO nt.durable_jobs(id,kind,dedupe_key,object_ref) VALUES(%s,'delete_confirm',%s,%s) ON CONFLICT DO NOTHING",(uuid4(),'delete_confirm:'+dto.proof.reservation_id,dto.proof.reservation_id))
        try:await self._confirm_delete(dto.proof.reservation_id)
        except Exception:
            return {'state':'pending_confirmation','durably_accepted':False,'receipt_ref':dto.proof.reservation_id}
        return {'state':'accepted','durably_accepted':True,'receipt_ref':dto.proof.reservation_id}

    async def confirm_delete(self,receipt_ref):
        async with self.serial:await self._confirm_delete(receipt_ref)

    async def _confirm_delete(self,receipt_ref):
        async with self.db.transaction('jobs') as connection:
            receipt=await one(connection,"SELECT * FROM nt.scoped_receipts WHERE public_ref=%s AND kind='deletion'",(receipt_ref,))
        require(receipt,'DELETION_RECEIPT_MISSING')
        operation={'operation_id':str(UUID(receipt_ref)),'subject_ref':receipt['subject_ref'],'action':'delete',
                   'receipt_ref':receipt_ref,'receipt_verifier':receipt['verifier']}
        anchor=await asyncio.to_thread(self.journal.append,operation)
        async with self.db.transaction('jobs') as connection:
            subject=await one(connection,'SELECT * FROM nt.subject_controls WHERE subject_id=%s FOR UPDATE',(UUID(receipt['subject_ref']),))
            await connection.execute("UPDATE nt.subject_controls SET deletion_state=CASE WHEN deletion_state='operationally_deleted' THEN deletion_state ELSE 'accepted' END,journal_applied_seq=GREATEST(journal_applied_seq,%s),revision=revision+1 WHERE subject_id=%s",(anchor['seq'],subject['subject_id']))
            await connection.execute("INSERT INTO nt.durable_jobs(id,kind,dedupe_key,object_ref) VALUES(%s,'delete',%s,%s) ON CONFLICT DO NOTHING",(uuid4(),'delete:'+receipt['subject_ref'],receipt['subject_ref']))

    async def replay(self):
        require(self.journal is not None,'JOURNAL_UNAVAILABLE',503)
        state=await asyncio.to_thread(self.journal.verified_state)
        async with self.db.transaction('jobs') as connection:
            for subject_ref,value in state.items():
                if not value['deleted']: continue
                subject=await one(connection,'SELECT * FROM nt.subject_controls WHERE subject_id=%s FOR UPDATE',(UUID(subject_ref),))
                if not subject: continue
                for receipt_ref,verifier in value.get('receipts',{}).items():
                    await connection.execute("INSERT INTO nt.scoped_receipts(public_ref,kind,subject_ref,verifier) VALUES(%s,'deletion',%s,%s) ON CONFLICT DO NOTHING",(receipt_ref,subject_ref,verifier))
                account=await one(connection,'SELECT public_ref FROM nt.accounts WHERE id=%s',(subject['account_id'],))
                if account: self.identity.fenced_subjects.add(account['public_ref'])
                await connection.execute("UPDATE nt.accounts SET status='deleting',deleted_at=COALESCE(deleted_at,now()),auth_generation=auth_generation+1 WHERE id=%s AND status NOT IN ('deleted','deleting')",(subject['account_id'],))
                await connection.execute('UPDATE nt.account_sessions SET revoked_at=COALESCE(revoked_at,now()) WHERE account_id=%s',(subject['account_id'],))
                await connection.execute('DELETE FROM nt.privacy_exports WHERE subject_id=%s',(subject['subject_id'],))
                await connection.execute("UPDATE nt.subject_controls SET deletion_state='accepted' WHERE subject_id=%s AND deletion_state='active'",(UUID(subject_ref),))
                await connection.execute("INSERT INTO nt.durable_jobs(id,kind,dedupe_key,object_ref) VALUES(%s,'delete',%s,%s) ON CONFLICT DO NOTHING",(uuid4(),'delete:'+subject_ref,subject_ref))

    async def purge(self,subject_ref):
        async with self.serial:
            return await self._purge(subject_ref)

    async def _purge(self,subject_ref):
        require(self.journal is not None,'JOURNAL_UNAVAILABLE',503)
        state=await asyncio.to_thread(self.journal.verified_state)
        require(state.get(subject_ref,{}).get('deleted'),'JOURNAL_CONTINUITY_REQUIRED',503)
        require(not state.get(subject_ref,{}).get('held'),'HOLD_ACTIVE',409)
        async with self.db.transaction('jobs') as connection:
            subject=await one(connection,'SELECT * FROM nt.subject_controls WHERE subject_id=%s FOR UPDATE',(UUID(subject_ref),))
            hold=await one(connection,"SELECT 1 FROM nt.legal_holds WHERE subject_ref=%s AND state IN ('active','pending','pending_release') LIMIT 1",(subject_ref,))
            require(not hold,'HOLD_ACTIVE')
            if subject['account_id']:
                account=subject['account_id']
                await connection.execute('DELETE FROM nt.friendships WHERE low_account_id=%s OR high_account_id=%s',(account,account))
                await connection.execute('DELETE FROM nt.blocks WHERE blocker_id=%s OR blocked_id=%s',(account,account))
                await connection.execute('DELETE FROM nt.account_sessions WHERE account_id=%s',(account,))
                await connection.execute("UPDATE nt.accounts SET username=%s,password_hash='deleted',recovery_verifier=%s,display_name='Deleted',gender='other',topic_id='general',bio='',professional='{}',preferences='{}',core_consent=false,professional_consent=false,status='deleted' WHERE id=%s",('deleted_'+uuid4().hex,uuid4().hex,account))
                await connection.execute('UPDATE nt.financial_subjects SET account_id=NULL WHERE account_id=%s',(account,))
            await connection.execute("UPDATE nt.subject_controls SET deletion_state='operationally_deleted',revision=revision+1 WHERE subject_id=%s",(UUID(subject_ref),))
        return {'state':'operationally_deleted'}

    async def status(self,principal):
        require(principal.kind in {'account','deletion'},'AUTHENTICATION_REQUIRED',401)
        async with self.db.transaction() as connection:
            row=await one(connection,'SELECT deletion_state,journal_applied_seq FROM nt.subject_controls WHERE subject_id=%s' if principal.kind=='deletion' else 'SELECT deletion_state,journal_applied_seq FROM nt.subject_controls WHERE account_id=%s',
                (UUID(principal.scope) if principal.kind=='deletion' else principal.account_id,))
        require(row,'NOT_FOUND',404)
        return {**row,'retained_categories':['required finance facts','open or lawfully retained cases','minimal consent and rights proof'],
                'backup_expiry_days':None,'backup_retention':'The reviewed operator/provider schedule and applicable holds govern backup expiry.'}

    async def request_export(self,principal,dto):
        self.identity.fresh(principal)
        ref=uuid4().hex
        async with self.db.transaction() as connection:
            await self.identity.lock_account(connection,principal,fresh=True)
            subject=await one(connection,'SELECT * FROM nt.subject_controls WHERE account_id=%s FOR UPDATE',(principal.account_id,))
            require(subject['deletion_state']=='active','SUBJECT_UNAVAILABLE')
            previous=await one(connection,'SELECT public_ref,state,expires_at FROM nt.privacy_exports WHERE subject_id=%s AND client_nonce=%s',(subject['subject_id'],UUID(dto.client_nonce)))
            if previous:return {'export_ref':previous['public_ref'],'state':previous['state'],'expires_at':previous['expires_at']}
            pending=await one(connection,"SELECT count(*) AS n FROM nt.privacy_exports WHERE subject_id=%s AND expires_at>now()",(subject['subject_id'],))
            require(pending['n']<2,'EXPORT_CAPACITY',429)
            await connection.execute("INSERT INTO nt.privacy_exports(public_ref,subject_id,client_nonce,expires_at) VALUES(%s,%s,%s,now()+interval '24 hours')",(ref,subject['subject_id'],UUID(dto.client_nonce)))
            await connection.execute("INSERT INTO nt.durable_jobs(id,kind,dedupe_key,object_ref) VALUES(%s,'export',%s,%s)",(uuid4(),'export:'+ref,ref))
        return {'export_ref':ref,'state':'pending'}

    async def build_export(self,ref):
        async with self.db.transaction('jobs') as connection:
            export=await one(connection,'SELECT e.*,s.account_id,s.financial_subject_id,s.deletion_state FROM nt.privacy_exports e JOIN nt.subject_controls s ON s.subject_id=e.subject_id WHERE e.public_ref=%s FOR UPDATE OF s,e',(ref,))
            require(export and export['deletion_state']=='active' and export['expires_at']>now(),'EXPORT_EXPIRED')
            account=await one(connection,'SELECT public_ref,username,display_name,gender,topic_id,bio,professional,preferences,created_at FROM nt.accounts WHERE id=%s',(export['account_id'],))
            consent=await many(connection,'SELECT purpose,choice,policy_version,text_digest,publication_digest,proof_format,decision_text,recorded_at FROM nt.consent_records WHERE account_id=%s ORDER BY recorded_at,id LIMIT 10001',(export['account_id'],))
            require(len(consent)<=10000,'EXPORT_REVIEW_REQUIRED')
            receipts=await many(connection,'SELECT public_ref,facts,created_at FROM nt.receipts WHERE subject_id=%s',(export['financial_subject_id'],))
            messages=await many(connection,'''SELECT c.public_ref,m.sequence,m.sender_kind,m.body_ciphertext,m.created_at FROM nt.support_cases c
                JOIN nt.case_messages m ON m.case_id=c.id WHERE c.account_id=%s ORDER BY c.public_ref,m.sequence LIMIT 10001''',(export['account_id'],))
            require(len(messages)<=10000,'EXPORT_REVIEW_REQUIRED')
            public_messages=[{k:v for k,v in r.items() if k!='body_ciphertext'} | {'body':self.security.decrypt('case:'+r['public_ref']+':'+str(r['sequence']),r['body_ciphertext'])} for r in messages]
            friends=await many(connection,"SELECT a.display_name,a.gender,a.topic_id,a.bio FROM nt.friendships f JOIN nt.accounts a ON a.id=CASE WHEN f.low_account_id=%s THEN f.high_account_id ELSE f.low_account_id END WHERE f.low_account_id=%s OR f.high_account_id=%s LIMIT 101",(export['account_id'],export['account_id'],export['account_id']))
            package=json.dumps({'account':account,'consents':consent,'friends':friends,'receipts':receipts,'support':public_messages},default=str,separators=(',',':'))
            require(len(package.encode())<=8*1024*1024,'EXPORT_REVIEW_REQUIRED')
            await connection.execute("UPDATE nt.privacy_exports SET state='ready',object_ciphertext=%s WHERE public_ref=%s",(self.security.encrypt('export:'+ref,package),ref))

    async def export(self,principal,ref,download=False):
        require(principal.kind=='account','ACCOUNT_REQUIRED',401)
        async with self.db.transaction() as connection:
            await self.identity.lock_account(connection,principal)
            export=await one(connection,'''SELECT e.* FROM nt.privacy_exports e JOIN nt.subject_controls s ON s.subject_id=e.subject_id
                WHERE e.public_ref=%s AND s.account_id=%s AND s.deletion_state='active' AND e.expires_at>now()''',(ref,principal.account_id))
            require(export,'NOT_FOUND',404)
            if download:
                require(export['state']=='ready','EXPORT_NOT_READY')
                await connection.execute('UPDATE nt.privacy_exports SET delivered_at=now() WHERE public_ref=%s',(ref,))
        if download: return self.security.decrypt('export:'+ref,export['object_ciphertext'])
        return {'export_ref':ref,'state':export['state'],'expires_at':export['expires_at']}

    async def request_rights(self,principal,dto,support,request_id):
        from app.http.models import CaseCreate
        require(principal.kind=='account','ACCOUNT_REQUIRED',401)
        result=await support.create(principal,CaseCreate(category='privacy',subject='Privacy: '+dto.kind,body=dto.body,client_nonce=dto.client_nonce),request_id)
        async with self.db.transaction() as connection:
            await self.identity.lock_account(connection,principal)
            subject=await one(connection,'SELECT subject_id FROM nt.subject_controls WHERE account_id=%s',(principal.account_id,))
            case=await one(connection,'SELECT id FROM nt.support_cases WHERE public_ref=%s AND account_id=%s',(result['case_ref'],principal.account_id))
            require(subject and case,'NOT_FOUND',404)
            await connection.execute("INSERT INTO nt.privacy_requests(id,subject_id,case_id,kind,client_nonce) VALUES(%s,%s,%s,%s,%s) ON CONFLICT(subject_id,client_nonce) DO NOTHING",(uuid4(),subject['subject_id'],case['id'],dto.kind,UUID(dto.client_nonce)))
        return result|{'verification_state':'pending','deadline':'Set only by the applicable reviewed rule; no universal deadline is asserted.'}

    async def hold_preview(self,principal,dto):
        from psycopg.types.json import Jsonb
        from app.domain.security import canonical
        principal.permission('privacy.holds')
        require(now()-principal.mfa_at<timedelta(minutes=5),'FRESH_MFA_REQUIRED',401)
        require(dto.review_days<=dto.expires_days,'HOLD_REVIEW_INVALID',422)
        async with self.db.transaction('private') as connection:
            subject=await one(connection,'SELECT * FROM nt.subject_controls WHERE subject_id=%s',(UUID(dto.subject_ref),))
            require(subject,'NOT_FOUND',404)
            nonce=uuid4().hex;payload=dto.model_dump()
            await connection.execute("INSERT INTO nt.sensitive_previews(nonce,actor_id,object_ref,payload_digest,payload,revisions,expires_at) VALUES(%s,%s,%s,%s,%s,%s,now()+interval '2 minutes')",(nonce,principal.account_id,dto.subject_ref,self.security.digest('preview',canonical(payload).decode()),Jsonb(payload),Jsonb({'subject':subject['revision']})))
        return {'preview':nonce,'payload':payload,'expires_in':120}

    async def hold_confirm(self,principal,nonce):
        async with self.serial:
            return await self._hold_confirm(principal,nonce)

    async def _hold_confirm(self,principal,nonce):
        import asyncio
        from app.domain.security import canonical
        principal.permission('privacy.holds')
        require(now()-principal.mfa_at<timedelta(minutes=5),'FRESH_MFA_REQUIRED',401)
        require(self.journal,'JOURNAL_UNAVAILABLE',503)
        async with self.db.transaction('private') as connection:
            preview=await one(connection,'SELECT * FROM nt.sensitive_previews WHERE nonce=%s FOR UPDATE',(nonce,))
            require(preview and preview['actor_id']==principal.account_id and preview['expires_at']>now() and not preview['consumed_at'],'PREVIEW_EXPIRED')
            payload=preview['payload'];require('scope' in payload and 'subject_ref' in payload,'PREVIEW_KIND')
            require(self.security.verify('preview',canonical(payload).decode(),preview['payload_digest']),'PREVIEW_INVALID')
            subject=await one(connection,'SELECT * FROM nt.subject_controls WHERE subject_id=%s FOR UPDATE',(UUID(payload['subject_ref']),))
            require(subject['revision']==preview['revisions']['subject'],'PREVIEW_STALE')
            # Durable authorization precedes the remote effect. A pending hold immediately
            # blocks deletion, even if checkpoint publication later fails.
            await connection.execute('UPDATE nt.sensitive_previews SET consumed_at=now() WHERE nonce=%s',(nonce,))
            await connection.execute('UPDATE nt.subject_controls SET revision=revision+1 WHERE subject_id=%s',(subject['subject_id'],))
            await connection.execute("INSERT INTO nt.legal_holds(id,subject_ref,scope,basis,approver,review_at,expires_at,journal_seq,state) VALUES(%s,%s,%s,%s,%s,now()+(%s*interval '1 day'),now()+(%s*interval '1 day'),0,'pending')",(UUID(nonce),payload['subject_ref'],payload['scope'],payload['basis'],principal.account_id,payload['review_days'],payload['expires_days']))
            await connection.execute("INSERT INTO nt.durable_jobs(id,kind,dedupe_key,object_ref) VALUES(%s,'hold_confirm',%s,%s) ON CONFLICT DO NOTHING",(uuid4(),'hold_confirm:'+nonce,nonce))
        anchor=await asyncio.to_thread(self.journal.append,{'operation_id':str(UUID(nonce)),'subject_ref':payload['subject_ref'],'action':'hold'})
        async with self.db.transaction('private') as connection:
            await one(connection,'SELECT * FROM nt.subject_controls WHERE subject_id=%s FOR UPDATE',(UUID(payload['subject_ref']),))
            await connection.execute("UPDATE nt.legal_holds SET journal_seq=%s,state='active' WHERE id=%s",(anchor['seq'],UUID(nonce)))
        return {'hold_ref':nonce,'state':'active','review_at':(now()+timedelta(days=payload['review_days'])).isoformat()}

    async def release_preview(self,principal,hold_ref,reason):
        from psycopg.types.json import Jsonb
        from app.domain.security import canonical
        principal.permission('privacy.holds')
        require(now()-principal.mfa_at<timedelta(minutes=5),'FRESH_MFA_REQUIRED',401)
        async with self.db.transaction('private') as connection:
            hold=await one(connection,"SELECT * FROM nt.legal_holds WHERE id=%s AND state='active'",(UUID(hold_ref),))
            require(hold,'NOT_FOUND',404)
            subject=await one(connection,'SELECT revision FROM nt.subject_controls WHERE subject_id=%s',(UUID(hold['subject_ref']),))
            payload={'release':True,'hold_ref':hold_ref,'subject_ref':hold['subject_ref'],'reason':reason}
            nonce=uuid4().hex
            await connection.execute("INSERT INTO nt.sensitive_previews(nonce,actor_id,object_ref,payload_digest,payload,revisions,expires_at) VALUES(%s,%s,%s,%s,%s,%s,now()+interval '2 minutes')",(nonce,principal.account_id,hold_ref,self.security.digest('preview',canonical(payload).decode()),Jsonb(payload),Jsonb({'subject':subject['revision']})))
        return {'preview':nonce,'payload':payload,'expires_in':120}

    async def release_confirm(self,principal,nonce):
        async with self.serial:
            return await self._release_confirm(principal,nonce)

    async def _release_confirm(self,principal,nonce):
        from app.domain.security import canonical
        principal.permission('privacy.holds')
        require(now()-principal.mfa_at<timedelta(minutes=5),'FRESH_MFA_REQUIRED',401)
        require(self.journal,'JOURNAL_UNAVAILABLE',503)
        async with self.db.transaction('private') as connection:
            preview=await one(connection,'SELECT * FROM nt.sensitive_previews WHERE nonce=%s FOR UPDATE',(nonce,))
            require(preview and preview['actor_id']==principal.account_id and preview['expires_at']>now() and not preview['consumed_at'],'PREVIEW_EXPIRED')
            payload=preview['payload'];require(payload.get('release') is True,'PREVIEW_KIND')
            require(self.security.verify('preview',canonical(payload).decode(),preview['payload_digest']),'PREVIEW_INVALID')
            subject=await one(connection,'SELECT * FROM nt.subject_controls WHERE subject_id=%s FOR UPDATE',(UUID(payload['subject_ref']),))
            require(subject['revision']==preview['revisions']['subject'],'PREVIEW_STALE')
            hold=await one(connection,"SELECT * FROM nt.legal_holds WHERE id=%s AND state='active' FOR UPDATE",(UUID(payload['hold_ref']),))
            require(hold,'HOLD_NOT_ACTIVE')
            others=await one(connection,"SELECT count(*) AS n FROM nt.legal_holds WHERE subject_ref=%s AND id<>%s AND state IN ('active','pending','pending_release')",(payload['subject_ref'],hold['id']))
            await connection.execute("UPDATE nt.legal_holds SET state='pending_release',release_nonce=%s WHERE id=%s",(UUID(nonce),hold['id']))
            await connection.execute('UPDATE nt.subject_controls SET revision=revision+1 WHERE subject_id=%s',(subject['subject_id'],))
            await connection.execute('UPDATE nt.sensitive_previews SET consumed_at=now() WHERE nonce=%s',(nonce,))
            await connection.execute("INSERT INTO nt.durable_jobs(id,kind,dedupe_key,object_ref) VALUES(%s,'hold_release',%s,%s) ON CONFLICT DO NOTHING",(uuid4(),'hold_release:'+payload['hold_ref'],payload['hold_ref']))
        if not others['n']:
            await asyncio.to_thread(self.journal.append,{'operation_id':str(UUID(nonce)),'subject_ref':payload['subject_ref'],'action':'release_hold'})
        async with self.db.transaction('private') as connection:
            await connection.execute("UPDATE nt.legal_holds SET state='released' WHERE id=%s",(hold['id'],))
            await connection.execute("UPDATE nt.durable_jobs SET state='ready',attempts=0,available_at=now() WHERE dedupe_key=%s AND state<>'running'",('delete:'+payload['subject_ref'],))
        return {'hold_ref':payload['hold_ref'],'state':'released'}

    async def retention_cases(self):
        # Bounded encrypted case deletion, paused whenever independent authority cannot
        # be verified. Holds are not silently expired; a reviewed release is required.
        async with self.serial:
            require(self.journal,'JOURNAL_UNAVAILABLE',503)
            journal_state=await asyncio.to_thread(self.journal.verified_state)
            held_subjects=[UUID(ref) for ref,value in journal_state.items() if value.get('held')]
            async with self.db.transaction('jobs') as connection:
                subjects=await many(connection,"SELECT a.id,s.subject_id FROM nt.accounts a JOIN nt.subject_controls s ON s.account_id=a.id WHERE a.status='deleted' AND a.deleted_at<now()-interval '180 days' AND EXISTS(SELECT 1 FROM nt.consent_records c WHERE c.account_id=a.id) AND NOT(s.subject_id=ANY(%s::uuid[])) AND NOT EXISTS(SELECT 1 FROM nt.legal_holds h WHERE h.subject_ref=s.subject_id::text AND h.state IN ('active','pending','pending_release')) LIMIT 100",(held_subjects,))
                for subject in subjects:
                    if journal_state.get(str(subject['subject_id']),{}).get('held'):continue
                    hold=await one(connection,"SELECT 1 FROM nt.legal_holds WHERE subject_ref=%s AND state IN ('active','pending','pending_release') LIMIT 1",(str(subject['subject_id']),))
                    if not hold:await connection.execute('DELETE FROM nt.consent_records WHERE account_id=%s',(subject['id'],))
                withdrawn=await many(connection,"""WITH latest AS (SELECT DISTINCT ON(c.account_id,c.purpose) c.account_id,c.purpose,c.choice,c.recorded_at,s.subject_id FROM nt.consent_records c JOIN nt.subject_controls s ON s.account_id=c.account_id ORDER BY c.account_id,c.purpose,c.recorded_at DESC) SELECT * FROM latest l WHERE NOT choice AND recorded_at<now()-interval '180 days' AND NOT(subject_id=ANY(%s::uuid[])) AND NOT EXISTS(SELECT 1 FROM nt.legal_holds h WHERE h.subject_ref=l.subject_id::text AND h.state IN ('active','pending','pending_release')) LIMIT 100""",(held_subjects,))
                for row in withdrawn:
                    if row['choice'] or row['recorded_at']>=now()-timedelta(days=180) or journal_state.get(str(row['subject_id']),{}).get('held'):continue
                    hold=await one(connection,"SELECT 1 FROM nt.legal_holds WHERE subject_ref=%s AND state IN ('active','pending','pending_release') LIMIT 1",(str(row['subject_id']),))
                    if not hold:await connection.execute('DELETE FROM nt.consent_records WHERE account_id=%s AND purpose=%s AND recorded_at<=%s',(row['account_id'],row['purpose'],row['recorded_at']))
                cases=await many(connection,"""SELECT c.*,s.subject_id FROM nt.support_cases c
                    LEFT JOIN nt.subject_controls s ON s.account_id=c.account_id WHERE c.status='closed'
                    AND c.closed_at<now()-(CASE WHEN c.category IN ('safety','privacy','appeal','security') THEN 180 ELSE 90 END * interval '1 day')
                    AND (s.subject_id IS NULL OR NOT(s.subject_id=ANY(%s::uuid[])))
                    AND NOT EXISTS(SELECT 1 FROM nt.legal_holds h WHERE (h.subject_ref=s.subject_id::text OR h.scope=c.public_ref) AND h.state IN ('active','pending','pending_release'))
                    AND NOT EXISTS(SELECT 1 FROM nt.case_obligations o WHERE o.case_id=c.id AND o.status<>'completed')
                    AND NOT EXISTS(SELECT 1 FROM nt.restrictions r JOIN nt.moderation_decisions d ON d.id=r.decision_id WHERE d.case_id=c.id AND (r.ends_at IS NULL OR r.ends_at>now()))
                    ORDER BY c.closed_at LIMIT 100 FOR UPDATE OF c SKIP LOCKED""",(held_subjects,))
                for case in cases:
                    subject=str(case['subject_id']) if case['subject_id'] else None
                    if subject and journal_state.get(subject,{}).get('held'):continue
                    hold=await one(connection,"SELECT 1 FROM nt.legal_holds WHERE (subject_ref=%s OR scope=%s) AND state IN ('active','pending','pending_release') LIMIT 1",(subject,case['public_ref']))
                    obligation=await one(connection,"SELECT 1 FROM nt.case_obligations WHERE case_id=%s AND status<>'completed' LIMIT 1",(case['id'],))
                    active=await one(connection,"SELECT 1 FROM nt.restrictions r JOIN nt.moderation_decisions d ON d.id=r.decision_id WHERE d.case_id=%s AND (r.ends_at IS NULL OR r.ends_at>now()) LIMIT 1",(case['id'],))
                    if hold or obligation or active:continue
                    await connection.execute('DELETE FROM nt.report_evidence WHERE report_id IN (SELECT id FROM nt.reports WHERE case_id=%s)',(case['id'],))
                    await connection.execute('DELETE FROM nt.reports WHERE case_id=%s',(case['id'],))
                    await connection.execute('DELETE FROM nt.restrictions WHERE decision_id IN (SELECT id FROM nt.moderation_decisions WHERE case_id=%s)',(case['id'],))
                    for table in ('moderation_decisions','case_messages','case_internal_notes','case_events','case_obligations','privacy_requests'):
                        # Identifier is from this fixed source-code allowlist, never request input.
                        await connection.execute('DELETE FROM nt.'+table+' WHERE case_id=%s',(case['id'],))
                    await connection.execute('DELETE FROM nt.scoped_status_sessions WHERE receipt_ref IN (SELECT public_ref FROM nt.scoped_receipts WHERE kind=\'case\' AND subject_ref=%s)',(case['public_ref'],))
                    await connection.execute("DELETE FROM nt.scoped_receipts WHERE kind='case' AND subject_ref=%s",(case['public_ref'],))
                    await connection.execute('UPDATE nt.support_cases SET parent_case_id=NULL WHERE parent_case_id=%s',(case['id'],))
                    await connection.execute('DELETE FROM nt.support_cases WHERE id=%s',(case['id'],))

    async def recover_hold(self,hold_ref,release=False):
        async with self.serial:
            async with self.db.transaction('jobs') as connection:
                hold=await one(connection,'SELECT * FROM nt.legal_holds WHERE id=%s',(UUID(hold_ref),))
                require(hold,'HOLD_NOT_FOUND')
                if release and hold['state']=='released' or not release and hold['state'] in {'active','released','pending_release'}:return
                require(hold['state']==('pending_release' if release else 'pending'),'HOLD_STATE_INVALID')
                others=await one(connection,"SELECT count(*) AS n FROM nt.legal_holds WHERE subject_ref=%s AND id<>%s AND state IN ('active','pending','pending_release')",(hold['subject_ref'],hold['id']))
            anchor=None
            if not release or not others['n']:
                anchor=await asyncio.to_thread(self.journal.append,{'operation_id':str(hold['release_nonce'] if release else hold['id']),'subject_ref':hold['subject_ref'],'action':'release_hold' if release else 'hold'})
            async with self.db.transaction('jobs') as connection:
                await connection.execute('UPDATE nt.legal_holds SET state=%s,journal_seq=CASE WHEN %s::bigint IS NULL THEN journal_seq ELSE %s END WHERE id=%s',('released' if release else 'active',anchor['seq'] if anchor else None,anchor['seq'] if anchor else None,hold['id']))
                if release:await connection.execute("UPDATE nt.durable_jobs SET state='ready',attempts=0,available_at=now() WHERE dedupe_key=%s AND state<>'running'",('delete:'+hold['subject_ref'],))

    async def recover_hold_release(self,hold_ref):
        await self.recover_hold(hold_ref,True)
