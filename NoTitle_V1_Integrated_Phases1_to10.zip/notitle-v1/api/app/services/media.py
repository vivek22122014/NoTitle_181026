"""Relay effects are separated from synchronous consent and publication transitions."""
import asyncio,re
from dataclasses import dataclass
from app.domain.errors import require
from app.domain.media import candidate,sdp

@dataclass(frozen=True)
class Provision:
    interaction:object
    call:dict
    revision:int
    members:tuple
    generations:tuple
    refresh:bool=False

class Media:
    def __init__(self,realtime,controller=None,relay_ip=None):
        self.realtime,self.controller,self.relay_ip=realtime,controller,relay_ip
        self.reserved=set();self.provisioning=set();self.unavailable=controller is None;self.closing=False
        self.pump_lock=asyncio.Lock()

    def reserve_accept(self,identity,accept):
        require(not self.closing and not self.unavailable and self.controller,'AUDIO_UNAVAILABLE',503)
        interaction=self.realtime.current(identity)
        if accept:require(len(self.reserved)<25,'CALL_CAPACITY',503)
        call=self.realtime.call_respond(identity,accept)
        if not call:return None
        current=interaction.call;self.reserved.add(current['id'])
        self.provisioning.add(current['id'])
        members=(interaction.left,interaction.right)
        return Provision(interaction,current,current['revision'],members,tuple((self.realtime.people[p].revision,self.realtime.people[p].generation) for p in members))

    def reserve_refresh(self,identity,call_id):
        require(not self.closing and not self.unavailable and self.controller,'AUDIO_UNAVAILABLE',503)
        interaction=self.realtime.current(identity);call=interaction.call
        require(call and call['id']==call_id and call['state']=='connected','CALL_EXPIRED')
        require(identity==call['from'],'OFFERER_REQUIRED',403)
        require(self.realtime.clock()-call.get('refreshed_at',call['connecting_at'])>=240,'REFRESH_TOO_EARLY',429)
        call.update(state='connecting',until=self.realtime.clock()+20,client_ready=set(),relay_ready=False,connecting_at=self.realtime.clock(),revision=call['revision']+1,descriptions={})
        members=(interaction.left,interaction.right)
        self.provisioning.add(call['id'])
        return Provision(interaction,call,call['revision'],members,tuple((self.realtime.people[p].revision,self.realtime.people[p].generation) for p in members),True)

    def valid(self,effect):
        interaction,call=effect.interaction,effect.call
        require(not self.closing and self.realtime.interactions.get(interaction.id) is interaction and interaction.call is call and call['revision']==effect.revision and call['state']=='connecting'
            and all((self.realtime.people[p].revision,self.realtime.people[p].generation)==stamp and self.realtime.people[p].connected for p,stamp in zip(effect.members,effect.generations)),'STALE_MEDIA')

    async def provision(self,effect,transition=None,validate=None):
        async def apply(function):return await transition(function) if transition else function()
        call=effect.call
        try:
            require(not self.closing,'AUDIO_UNAVAILABLE',503)
            path='/calls/'+call['id']+'/refresh' if effect.refresh else '/calls'
            payload={'owner_epoch':self.realtime.authority.epoch}
            if not effect.refresh:payload.update(call_id=call['id'],members=list(effect.members))
            result=await self.controller.request('POST',path,payload)
            def publish():
                if validate:validate()
                self.valid(effect)
                from app.domain.audio_contracts import IceServer
                servers=result.get('ice_servers',{})
                for index in range(2):
                    require(str(index) in servers and 1<=len(servers[str(index)])<=4,'RELAY_CREDENTIALS_INVALID',503)
                    for server in servers[str(index)]:
                        value=IceServer.model_validate(server)
                        require(all(re.fullmatch(r'turns?:[A-Za-z0-9.-]+:(?:3478|443)\?transport=(?:udp|tcp)',url) for url in value.urls),'RELAY_CREDENTIALS_INVALID',503)
                call['refreshed_at']=self.realtime.clock()
                for index,member in enumerate(effect.members):
                    self.realtime.emit(member,'call.refresh' if effect.refresh else 'call.connect',{'interaction_handle':effect.interaction.id,'call_id':call['id'],'negotiation_revision':effect.revision,'offerer':member==call['from'],'ice_servers':servers[str(index)]})
            await apply(publish)
        except BaseException:
            # A late successful create must be denied too. Capacity stays reserved
            # until pump obtains allocations_absent; cancellation never frees it.
            def fail():
                if self.realtime.interactions.get(effect.interaction.id) is effect.interaction and effect.interaction.call is call and call['state']!='teardown':self.realtime.end_call(effect.interaction,'unavailable')
                elif call['id'] not in self.realtime.media_ends:self.realtime.media_ends.append(call['id'])
            try:await asyncio.shield(apply(fail))
            except BaseException:
                # Shutdown can already have closed/fenced the actor mailbox.
                # This fallback only adds monotonic deny work; it cannot publish
                # a call, renew authority or release an unconfirmed slot.
                if call['id'] not in self.realtime.media_ends:self.realtime.media_ends.append(call['id'])
            raise
        finally:self.provisioning.discard(call['id'])

    async def accept(self,identity,accept):
        effect=self.reserve_accept(identity,accept)
        if effect:await self.provision(effect)

    async def refresh(self,identity,call_id):await self.provision(self.reserve_refresh(identity,call_id))

    def connected(self,identity,call_id):
        require(not self.closing,'AUDIO_UNAVAILABLE',503)
        interaction=self.realtime.current(identity);call=interaction.call
        require(call and call['id']==call_id and call['state'] in {'connecting','connected'},'CALL_EXPIRED')
        call.setdefault('client_ready',set()).add(identity);self.maybe_connected(interaction)

    def maybe_connected(self,interaction):
        if self.closing:return
        call=interaction.call
        if call and call['state']=='connecting' and call.get('relay_ready') and call.get('client_ready')=={interaction.left,interaction.right}:
            call['state']='connected'
            if not call.get('counted'):
                self.realtime.metrics.add('calls_connected');self.realtime.metrics.add('call_setup_ms',(self.realtime.clock()-call['connecting_at'])*1000);call['counted']=True
            for member in (interaction.left,interaction.right):self.realtime.emit(member,'call.connected',{'interaction_handle':interaction.id,'call_id':call['id'],'negotiation_revision':call['revision']})

    def prepare_signal(self,identity,kind,payload):
        require(not self.closing,'AUDIO_UNAVAILABLE',503)
        interaction=self.realtime.current(identity);call=interaction.call
        require(call and call['id']==payload['call_id'] and call['state'] in {'connecting','connected'},'CALL_EXPIRED')
        require(call['revision']==payload.get('negotiation_revision',call['revision']),'STALE_NEGOTIATION')
        if kind=='call.sdp':
            require(payload.get('description_type')==('offer' if identity==call['from'] else 'answer'),'SDP_TYPE',422)
            descriptions=call.setdefault('descriptions',{})
            require(identity not in descriptions,'SDP_ALREADY_SET')
            if identity!=call['from']:require(call['from'] in descriptions,'OFFER_REQUIRED')
            value=sdp(payload['sdp'],self.relay_ip)
            candidates=[line[2:] for line in value.splitlines() if line.startswith('a=candidate:')]
            require(len(candidates)<=32 and len({item.split()[5] for item in candidates})<=4,'ICE_LIMIT',422)
            return interaction,call,call['revision'],value,candidates
        value=candidate(payload['candidate'],self.relay_ip)
        return interaction,call,call['revision'],value,[value]

    async def forward_signal(self,identity,kind,payload,transition,validate):
        effect=await transition(lambda:self.prepare_signal(identity,kind,payload))
        interaction,call,revision,value,candidates=effect
        # Exact call/participant allocation attribution is checked by mTLS controller.
        for port in sorted({int(item.split()[5]) for item in candidates}):
            result=await self.controller.request('POST','/calls/'+call['id']+'/candidate',{'owner_epoch':self.realtime.authority.epoch,'side':0 if identity==interaction.left else 1,'port':port})
            require(result.get('authorized') is True,'ALLOCATION_UNAUTHORIZED',422)
        def publish():
            validate();require(not self.closing and interaction.call is call and call['revision']==revision and call['state'] in {'connecting','connected'},'STALE_MEDIA')
            other=interaction.right if identity==interaction.left else interaction.left
            data={'interaction_handle':interaction.id,'call_id':call['id'],'negotiation_revision':revision}
            if kind=='call.sdp':
                # Re-check ordering after the external allocation lookup.
                require(identity not in call.setdefault('descriptions',{}),'SDP_ALREADY_SET')
                call['descriptions'][identity]=True;data.update(description_type=payload['description_type'],sdp=value)
            else:data.update(candidate=value,sdpMid='0',sdpMLineIndex=0)
            self.realtime.emit(other,kind,data)
        await transition(publish)

    def signal(self,identity,kind,payload):
        # Legacy direct signaling cannot bypass controller attribution.
        require(False,'ASYNC_SIGNAL_REQUIRED',503)

    async def pump(self):
        if not self.controller or self.closing:return
        async with self.pump_lock:
            if self.closing:return
            while self.realtime.media_ends:
                ref=self.realtime.media_ends[0]
                # End may precede a late create response. Do not acknowledge absence
                # or release capacity until that in-flight effect is fenced.
                if ref in self.provisioning:break
                result=await self.controller.request('POST','/calls/'+ref+'/end',{'owner_epoch':self.realtime.authority.epoch})
                require(result.get('allocations_absent') is True,'TEARDOWN_UNCONFIRMED',503)
                if self.realtime.media_ends and self.realtime.media_ends[0]==ref:self.realtime.media_ends.popleft()
                self.reserved.discard(ref)
                for interaction in self.realtime.interactions.values():
                    if interaction.call and interaction.call['id']==ref and interaction.call['state']=='teardown':interaction.call=None
            if self.closing:return
            calls=[i.call['id'] for i in self.realtime.interactions.values() if i.call and i.call['state'] in {'connecting','connected'}]
            result=await self.controller.request('POST','/heartbeat',{'owner_epoch':self.realtime.authority.epoch,'calls':calls})
            for call_id in result.get('connected',[]):
                for interaction in self.realtime.interactions.values():
                    if interaction.call and interaction.call['id']==call_id and interaction.call['state']=='connecting':interaction.call['relay_ready']=True;self.maybe_connected(interaction)

    async def shutdown(self,timeout=4):
        """Request explicit denial without renewing a fenced owner's lease.

        Unknown outcomes remain queued/reserved. The kernel's independently
        expiring packet leases remain the final containment boundary; returning
        from this method never constitutes packet-denial qualification.
        """
        self.closing=True;self.unavailable=True
        refs=set(self.reserved)|set(self.provisioning)|set(self.realtime.media_ends)
        refs.update(i.call['id'] for i in self.realtime.interactions.values() if i.call)
        for ref in refs:
            if ref not in self.realtime.media_ends:self.realtime.media_ends.append(ref)
        confirmed=set()
        if not self.controller:return {'confirmed':0,'pending':len(refs)}
        semaphore=asyncio.Semaphore(4)
        async def deny(ref):
            async with semaphore:
                try:
                    result=await self.controller.request('POST','/calls/'+ref+'/end',{'owner_epoch':self.realtime.authority.epoch})
                    if result.get('allocations_absent') is True:
                        confirmed.add(ref);self.reserved.discard(ref)
                        # A successful late create is already revoked by the
                        # controller's tombstone; no live state can be revived.
                        while ref in self.realtime.media_ends:self.realtime.media_ends.remove(ref)
                        for interaction in self.realtime.interactions.values():
                            if interaction.call and interaction.call['id']==ref:interaction.call=None
                except asyncio.CancelledError:raise
                except Exception:return
        tasks=[asyncio.create_task(deny(ref)) for ref in sorted(refs)]
        try:
            async with asyncio.timeout(min(4,max(.01,timeout))):await asyncio.gather(*tasks)
        except TimeoutError:pass
        finally:
            for task in tasks:
                if not task.done():task.cancel()
            await asyncio.gather(*tasks,return_exceptions=True)
        return {'confirmed':len(confirmed),'pending':len(refs-confirmed)}

class RelayClient:
    def __init__(self,base,certificate,key,ca):
        import ssl,httpx
        require(base.startswith('https://') and '?' not in base,'RELAY_URL_INVALID')
        context=ssl.create_default_context(cafile=ca);context.load_cert_chain(certificate,key)
        self.client=httpx.AsyncClient(base_url=base,verify=context,timeout=httpx.Timeout(2,connect=1),follow_redirects=False)
    async def request(self,method,path,payload):
        response=await self.client.request(method,path,json=payload)
        require(response.status_code==200 and len(response.content)<=65536,'RELAY_UNAVAILABLE',503)
        return response.json()
    async def close(self):await self.client.aclose()
