"""Mutual relationship transitions, with durable effects outside the owner mailbox."""
from uuid import uuid4
from app.domain.errors import require,DomainError

class ConversationSocial:
    def __init__(self,service):
        self.service=service;self.rt=service.rt;self.social=service.social

    def check(self,binding,command,revision):
        person=self.service.check(binding,command)
        require(person.revision==revision,'STALE_INTERACTION')
        require((person.id,person.generation,command.command_id) in self.service.pending,'COMMAND_CANCELLED')
        return person

    def emit_relation(self,pair,kind):
        for identity,other in (pair,tuple(reversed(pair))):
            if identity in self.rt.people and other in self.rt.people:
                self.rt.emit(identity,kind,{'relationship':self.social.view(identity,other)})

    def accept(self,pair):
        self.social.prune()
        require(not self.social.relationship(pair).get('removing'),'FRIEND_UNAVAILABLE')
        require(not self.rt.blocked(*pair),'FRIEND_UNAVAILABLE')
        require(all(sum(ref in item for item in self.rt.friends)<100 for ref in pair),'FRIEND_LIMIT')
        self.rt.friends.add(pair);state=self.social.invalidate(pair)
        state['persistence']='temporary';self.rt.metrics.add('friend_acceptances')
        self.emit_relation(pair,'friend.accepted')
        if all(self.rt.people[ref].registered for ref in pair):
            state['persistence']='saving';self.emit_relation(pair,'friend.saving')
            return pair,{ref:self.rt.people[ref].revision for ref in pair},state['version']
        return None

    async def execute(self,binding,command,captured_revision):
        require(self.social is not None,'FRIENDS_UNAVAILABLE',503)
        if command.type in {'friend.invite','friend.invite.respond'}:
            return await self.invitation(binding,command,captured_revision)
        def apply():
            person=self.check(binding,command,captured_revision);identity=person.id
            self.social.prune()
            interaction=self.rt.current(identity)
            other=interaction.right if interaction.left==identity else interaction.left
            require(self.rt.people[other].connected and not self.rt.blocked(identity,other),'FRIEND_UNAVAILABLE')
            pair=self.rt.pair(identity,other);request=self.rt.requests.get(pair)
            require(pair not in self.rt.friends,'ALREADY_FRIENDS')
            if command.type=='friend.request':
                require(command.payload.interaction_handle==interaction.id,'STALE_INTERACTION')
                if request and request['from']==other and request['interaction']==interaction.id:
                    self.rt.requests.pop(pair,None)
                    for ref in pair:self.rt.emit(ref,'friend.request_closed',{'request_handle':request['handle']})
                    return self.accept(pair)
                if request and request['from']==identity:return None
                require(all(sum(ref in p for p in self.rt.friends)<100 for ref in pair),'FRIEND_LIMIT')
                require(len(self.rt.requests)<100,'FRIEND_REQUEST_CAPACITY',503)
                request={'handle':uuid4().hex,'from':identity,'interaction':interaction.id,'revision':person.revision}
                self.rt.requests[pair]=request
                for ref,peer in ((identity,other),(other,identity)):
                    self.rt.emit(ref,'friend.pending',{'request_handle':request['handle'],'interaction_handle':interaction.id,
                        'peer':self.rt.peer(peer,ref),'incoming':ref==other})
                return None
            require(command.type=='friend.respond','COMMAND_TYPE',422)
            require(request and request['handle']==command.payload.request_handle and request['from']==other and request['interaction']==interaction.id,'REQUEST_EXPIRED')
            self.rt.requests.pop(pair,None)
            # Decline is deliberately generic; no rejection notification or reason.
            for ref in pair:self.rt.emit(ref,'friend.request_closed',{'request_handle':request['handle']})
            return self.accept(pair) if command.payload.accept else None
        reserved=await self.service.transition(apply)
        if not reserved:return {'status':'closed' if command.type=='friend.respond' else 'pending'}
        pair,revisions,version=reserved
        try:await self.social.save_friend(*pair,revisions)
        except DomainError as error:
            def stale():
                if error.code in {'FRIEND_LIMIT','FRIEND_UNAVAILABLE','FRIEND_RESERVATION_STALE'} and self.social.relationship(pair)['version']==version:self.rt.friends.discard(pair)
                if pair not in self.rt.friends:
                    for ref in pair:
                        if ref in self.rt.people:self.rt.emit(ref,'friend.removed',{'relationship_handle':self.social.relationship(pair)['handle']})
                elif self.social.relationship(pair)['version']==version:self.social.relationship(pair)['persistence']='temporary';self.emit_relation(pair,'friend.accepted')
            await self.service.transition(stale,control=True)
            raise
        except Exception:
            def failed():
                if pair in self.rt.friends and self.social.relationship(pair)['version']==version:
                    self.social.relationship(pair)['persistence']='temporary';self.emit_relation(pair,'friend.accepted')
            await self.service.transition(failed)
            raise DomainError('FRIEND_SAVE_UNAVAILABLE',503) from None
        def persisted():
            state=self.social.relationship(pair)
            require(pair in self.rt.friends and state['version']==version and state['persistence']=='saved' and not self.rt.blocked(*pair),'FRIEND_RESERVATION_STALE')
            self.emit_relation(pair,'friend.persisted')
        await self.service.transition(persisted)
        return {'status':'saved'}

    async def invitation(self,binding,command,revision):
        identity=binding.principal.ref
        def reserve():
            person=self.check(binding,command,revision)
            require(not self.rt.maintenance,'ADMISSION_CLOSED',503)
            if command.type=='friend.invite':
                other=self.social.target(identity,command.payload.relationship_handle)
                pair=self.rt.pair(identity,other);invite=self.rt.invites.get(pair)
                if invite and invite['until']<=self.rt.clock():self.rt.invites.pop(pair,None);invite=None
                crossed=bool(invite and invite['from']==other)
                if invite and not crossed:return {'status':'pending'}
            else:
                pair=next((pair for pair,invite in self.rt.invites.items() if invite.get('handle')==command.payload.invite_handle and identity in pair),None)
                require(pair,'INVITE_EXPIRED');invite=self.rt.invites[pair]
                other=pair[1] if pair[0]==identity else pair[0]
                require(invite['from']==other and invite['until']>self.rt.clock(),'INVITE_EXPIRED')
                if not command.payload.accept:
                    self.rt.invites.pop(pair,None);self.close_invite(pair,invite,'closed');return {'status':'closed'}
                crossed=True
            require(pair in self.rt.friends and not self.rt.blocked(*pair),'FRIEND_UNAVAILABLE')
            require(all(ref in self.rt.people and self.rt.people[ref].connected and not self.rt.people[ref].interaction for ref in pair),'FRIEND_UNAVAILABLE')
            if not crossed:
                require(len(self.rt.invites)<100,'INVITE_CAPACITY',503)
                invite={'handle':uuid4().hex,'from':identity,'until':self.rt.clock()+30,'expires_at':self.rt.wall()+30}
                self.rt.invites[pair]=invite
                for ref,peer in ((identity,other),(other,identity)):
                    self.rt.emit(ref,'friend.invite.sent' if ref==identity else 'friend.invite.received',{
                        'invite_handle':invite['handle'],'relationship_handle':self.social.relationship(pair)['handle'],
                        'peer':self.social.view(ref,peer)['peer'],'expires_at':invite['expires_at'],'incoming':ref==other})
                return {'status':'invited'}
            return pair,invite,{ref:(self.rt.people[ref].revision,self.rt.people[ref].generation) for ref in pair}
        result=await self.service.transition(reserve)
        if isinstance(result,dict):return result
        pair,invite,stamps=result
        accesses=[]
        for ref in pair:
            current=self.service.bindings.get(ref);require(current,'FRIEND_UNAVAILABLE')
            access=await self.service.authorize(current.principal,strict=True);accesses.append(access)
            await self.social.hydrate(access.principal)
        def start():
            self.check(binding,command,revision)
            require(self.rt.invites.get(pair) is invite and invite['until']>self.rt.clock(),'INVITE_EXPIRED')
            require(pair in self.rt.friends and not self.rt.blocked(*pair) and not self.rt.maintenance,'FRIEND_UNAVAILABLE')
            for ref,access in zip(pair,accesses):
                person=self.rt.people.get(ref);current=self.service.bindings.get(ref)
                require(person and current and person.connected and not person.interaction and (person.revision,person.generation)==stamps[ref]
                        and current.access.revisions==access.revisions and access.deadline>self.rt.clock(),'FRIEND_UNAVAILABLE')
            self.rt.invites.pop(pair,None);self.close_invite(pair,invite,'accepted')
            for ref in pair:self.rt.invalidate(ref)
            interaction=self.rt.start(*pair)
            # Named invitations are explicit and free; no paid random-match filters apply.
            interaction.source='friend';interaction.relationship=self.social.relationship(pair)['handle']
            return {'status':'accepted'}
        return await self.service.transition(start)

    def close_invite(self,pair,invite,reason):
        for ref in pair:
            if ref in self.rt.people:self.rt.emit(ref,'friend.invite.closed',{'invite_handle':invite['handle'],'reason':reason})
