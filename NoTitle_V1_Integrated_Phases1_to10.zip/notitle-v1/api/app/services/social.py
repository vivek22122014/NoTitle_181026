from uuid import UUID, uuid4
from app.domain.errors import require
from app.repositories.database import one, many
from app.domain.social_contracts import FriendItem
import asyncio


class Social:
    def __init__(self,db,realtime):
        self.db,self.realtime=db,realtime
        self.relationships={};self.relationship_handles={}
        self.durable_tasks=set();self.closed=False
        self.safety_generation=0

    def relationship(self,pair):
        pair=self.realtime.pair(*pair)
        if pair not in self.relationships:
            if len(self.relationships)>=10000:
                for previous,state in list(self.relationships.items()):
                    if state['persistence']!='saving' and not any(ref in self.realtime.people for ref in previous):
                        self.relationship_handles.pop(state['handle'],None);self.relationships.pop(previous,None)
            # At most 200 live identities and 100 relationships per identity.
            require(len(self.relationships)<20000,'FRIEND_CAPACITY',503)
            handle=uuid4().hex
            self.relationships[pair]={'handle':handle,'version':1,'revision':1,'persistence':'temporary'}
            self.relationship_handles[handle]=pair
        return self.relationships[pair]

    def target(self,identity,handle):
        pair=self.relationship_handles.get(handle)
        require(pair and identity in pair and pair in self.realtime.friends,'NOT_FOUND',404)
        return pair[1] if pair[0]==identity else pair[0]

    def prune(self):
        """Retired guest links cannot consume another person's friend quota."""
        for pair in tuple(self.realtime.friends):
            state=self.relationships.get(pair)
            if state and state['persistence']=='temporary' and any(ref not in self.realtime.people for ref in pair):
                self.realtime.friends.discard(pair);state['version']+=1
                for ref in pair:
                    if ref in self.realtime.people:self.realtime.emit(ref,'friend.expired',{'relationship_handle':state['handle']})

    def invalidate(self,pair):
        state=self.relationship(pair);state['version']+=1
        return state

    def view(self,identity,other,profile=None):
        pair=self.realtime.pair(identity,other);state=self.relationship(pair)
        if profile is None:
            person=self.realtime.people.get(other)
            require(person,'FRIEND_UNAVAILABLE')
            profile=person.profile
        peer={'peer_handle':state['handle'],**{key:profile[key] for key in ('display_name','gender','topic_id','bio')}}
        return FriendItem(relationship_handle=state['handle'],peer=peer,revision=state['revision'],persistence=state['persistence'],presence=self.presence(other)).model_dump()

    async def hydrate(self,principal):
        if principal.kind!='account':return
        safety_generation=self.safety_generation
        versions={pair:state['version'] for pair,state in self.relationships.items()}
        async with self.db.transaction() as connection:
            blocks=await many(connection,'''SELECT a.public_ref AS left_ref,b.public_ref AS right_ref FROM nt.blocks x
                JOIN nt.accounts a ON a.id=x.blocker_id JOIN nt.accounts b ON b.id=x.blocked_id
                WHERE x.blocker_id=%s OR x.blocked_id=%s''',(principal.account_id,principal.account_id))
            friends=await many(connection,'''SELECT a.public_ref AS left_ref,b.public_ref AS right_ref FROM nt.friendships x
                JOIN nt.accounts a ON a.id=x.low_account_id JOIN nt.accounts b ON b.id=x.high_account_id
                WHERE x.low_account_id=%s OR x.high_account_id=%s''',(principal.account_id,principal.account_id))
        require(safety_generation==self.safety_generation,'SAFETY_CHANGED')
        self.realtime.blocks.update((r['left_ref'],r['right_ref']) for r in blocks)
        for row in friends:
            pair=self.realtime.pair(row['left_ref'],row['right_ref'])
            current=self.relationships.get(pair)
            if current and (current.get('removing') or current['version']!=versions.get(pair,current['version'])):continue
            if not self.realtime.blocked(*pair):
                self.realtime.friends.add(pair);state=self.relationship(pair)
                if state['persistence']!='saving':state['persistence']='saved'

    async def save_friend(self,left,right,revisions):
        require(not self.closed,'FRIENDS_UNAVAILABLE',503)
        pair=self.realtime.pair(left,right);state=self.relationship(pair);version=state['version']
        generations={ref:self.realtime.people[ref].generation for ref in pair if ref in self.realtime.people}
        task=asyncio.create_task(self._save_friend(left,right,revisions,version,generations))
        self.durable_tasks.add(task)
        def done(value):
            self.durable_tasks.discard(value)
            if not value.cancelled():value.exception()
        task.add_done_callback(done)
        try:return await asyncio.shield(task)
        except asyncio.CancelledError:
            # End/Block must survive a cancelled command worker, including the
            # instant after COMMIT. The independent task compensates its own row.
            if not task.done() and state['version']==version:
                state['version']+=1;self.realtime.friends.discard(pair)
            try:await asyncio.shield(task)
            except Exception:pass
            raise

    async def _save_friend(self,left,right,revisions,version,generations):
        people=self.realtime.people
        if not all(p in people and people[p].registered for p in (left,right)): return
        pair=self.realtime.pair(left,right);state=self.relationship(pair);created=None
        require(state['version']==version and pair in self.realtime.friends,'FRIEND_RESERVATION_STALE')
        async with self.db.transaction() as connection:
            rows=await many(connection,'SELECT id,public_ref FROM nt.accounts WHERE public_ref=ANY(%s) AND status=\'active\' AND core_consent ORDER BY id FOR UPDATE',([left,right],))
            require(len(rows)==2,'FRIEND_UNAVAILABLE')
            low,high=rows[0]['id'],rows[1]['id']
            existing=await one(connection,'SELECT revision,accepted_at FROM nt.friendships WHERE low_account_id=%s AND high_account_id=%s',(low,high))
            blocked=await one(connection,'SELECT 1 FROM nt.blocks WHERE (blocker_id=%s AND blocked_id=%s) OR (blocker_id=%s AND blocked_id=%s)',(low,high,high,low))
            require(not blocked,'FRIEND_UNAVAILABLE')
            for account in (() if existing else (low,high)):
                count=await one(connection,'SELECT count(*) AS n FROM nt.friendships WHERE low_account_id=%s OR high_account_id=%s',(account,account))
                require(count['n']<100,'FRIEND_LIMIT')
            if not existing:
                created=await one(connection,'INSERT INTO nt.friendships(low_account_id,high_account_id) VALUES(%s,%s) ON CONFLICT DO NOTHING RETURNING revision,accepted_at',(low,high))
        # End/Block may have interleaved with IO; compensate the exact pair before acknowledgement.
        if state['version']!=version or pair not in self.realtime.friends or any(p not in people or (people[p].revision,people[p].generation)!=(revisions[p],generations.get(p)) for p in pair) or self.realtime.blocked(left,right):
            if created:
                async with self.db.transaction() as connection:
                    await connection.execute('DELETE FROM nt.friendships WHERE low_account_id=%s AND high_account_id=%s AND revision=%s AND accepted_at=%s',(low,high,created['revision'],created['accepted_at']))
            self.realtime.friends.discard(pair)
            require(False,'FRIEND_RESERVATION_STALE')
        persisted=existing or created
        require(persisted,'FRIEND_UNAVAILABLE')
        state['persistence']='saved';state['revision']=persisted['revision']
        return {'saved':True}

    async def close(self):
        self.closed=True
        # Caller cancellation never abandons a possibly committed friendship.
        while self.durable_tasks:await asyncio.gather(*tuple(self.durable_tasks),return_exceptions=True)

    async def promote(self,principal):
        people=self.realtime.people
        for pair in tuple(self.realtime.friends):
            if principal.ref not in pair or not all(ref in people and people[ref].registered for ref in pair):continue
            state=self.relationship(pair)
            if state['persistence'] in {'saved','saving'}:continue
            revisions={ref:people[ref].revision for ref in pair}
            state['persistence']='saving'
            try:await self.save_friend(*pair,revisions)
            except Exception:
                if pair in self.realtime.friends:state['persistence']='temporary'
                raise

    async def friends(self,principal):
        require(principal.kind in {'account','guest'},'AUTHENTICATION_REQUIRED',401)
        self.prune()
        if principal.kind=='guest':
            refs=[p[1] if p[0]==principal.ref else p[0] for p in self.realtime.friends if principal.ref in p]
            return {'items':[self.view(principal.ref,ref) for ref in refs if ref in self.realtime.people][:100]}
        await self.promote(principal)
        versions={pair:state['version'] for pair,state in self.relationships.items()}
        async with self.db.transaction() as connection:
            rows=await many(connection,'''SELECT a.public_ref AS peer_handle,a.display_name,a.gender,a.topic_id,a.bio,f.revision
                FROM nt.friendships f JOIN nt.accounts a ON a.id=CASE WHEN f.low_account_id=%s THEN f.high_account_id ELSE f.low_account_id END
                WHERE (f.low_account_id=%s OR f.high_account_id=%s) AND a.status='active' ORDER BY f.accepted_at LIMIT 100''',(principal.account_id,principal.account_id,principal.account_id))
        known={row['peer_handle'] for row in rows};items=[]
        for row in rows:
            ref=row['peer_handle'];pair=self.realtime.pair(principal.ref,ref)
            current=self.relationships.get(pair)
            if current and (current.get('removing') or current['version']!=versions.get(pair,current['version'])):continue
            if self.realtime.blocked(*pair):continue
            self.realtime.friends.add(pair);state=self.relationship(pair)
            if state['persistence']!='saving':state['persistence']='saved'
            state['revision']=row['revision']
            items.append(self.view(principal.ref,ref,row))
        temporary=[pair[1] if pair[0]==principal.ref else pair[0] for pair in self.realtime.friends if principal.ref in pair]
        items += [self.view(principal.ref,ref) for ref in temporary if ref not in known and ref in self.realtime.people]
        return {'items':items[:100]}

    def presence(self,ref):
        p=self.realtime.people.get(ref)
        return 'offline' if not p or not p.connected else 'busy' if p.interaction else 'available'

    async def remove(self,principal,ref,revision):
        require(principal.kind in {'account','guest'},'AUTHENTICATION_REQUIRED',401)
        ref=self.target(principal.ref,ref);pair=self.realtime.pair(principal.ref,ref);known=pair in self.realtime.friends
        state=self.relationship(pair);require(revision==state['revision'],'VERSION_CONFLICT');self.invalidate(pair)
        version=state['version'];state['removing']=version
        self.realtime.friends.discard(pair)
        self.realtime.invites.pop(pair,None);self.realtime.requests.pop(pair,None)
        if principal.ref in self.realtime.people and ref in self.realtime.people and self.realtime.people[principal.ref].interaction and self.realtime.people[principal.ref].interaction==self.realtime.people[ref].interaction:
            self.realtime.end(principal.ref,'friend_removed')
        try:
            if principal.kind=='account':
                async with self.db.transaction() as connection:
                    peer=await one(connection,'SELECT id FROM nt.accounts WHERE public_ref=%s',(ref,))
                    if state['persistence']!='saved':return {'removed':True,'scope':'current_identity'}
                    if not peer and known:return {'removed':True,'scope':'current_identity'}
                    require(peer,'NOT_FOUND',404)
                    low,high=sorted((principal.account_id,peer['id']))
                    deleted=await one(connection,'DELETE FROM nt.friendships WHERE low_account_id=%s AND high_account_id=%s AND revision=%s RETURNING revision',(low,high,revision))
                    require(deleted,'VERSION_CONFLICT')
            return {'removed':True}
        finally:
            if state.get('removing')==version:
                state.pop('removing',None)
                if state['version']==version:state['version']+=1
                self.realtime.friends.discard(pair)

    async def block(self,principal,peer,snapshot_ref=None):
        if peer in self.relationship_handles:peer=self.target(principal.ref,peer)
        self.safety_generation+=1
        self.invalidate(self.realtime.pair(principal.ref,peer))
        self.realtime.block(principal.ref,peer,snapshot_ref)
        self.realtime.invites.pop(self.realtime.pair(principal.ref,peer),None)
        self.realtime.requests.pop(self.realtime.pair(principal.ref,peer),None)
        if principal.kind!='account':
            return {'scope':'current_identity','persisted':False}
        async with self.db.transaction() as connection:
            other=await one(connection,'SELECT id FROM nt.accounts WHERE public_ref=%s',(peer,))
            if not other:return {'scope':'current_identity','persisted':False}
            low,high=sorted((principal.account_id,other['id']))
            await many(connection,'SELECT id FROM nt.accounts WHERE id=ANY(%s) ORDER BY id FOR UPDATE',([low,high],))
            row=await one(connection,'''INSERT INTO nt.blocks(blocker_id,blocked_id,public_ref) VALUES(%s,%s,%s)
                ON CONFLICT(blocker_id,blocked_id) DO UPDATE SET blocker_id=EXCLUDED.blocker_id RETURNING public_ref''',(principal.account_id,other['id'],uuid4().hex))
            await connection.execute('DELETE FROM nt.friendships WHERE low_account_id=%s AND high_account_id=%s',(low,high))
        self.safety_generation+=1
        return {'scope':'account','persisted':True,'block_ref':row['public_ref']}

    async def blocks(self,principal,remove=None,cursor=None):
        require(principal.kind=='account','ACCOUNT_REQUIRED',401)
        if remove:
            self.safety_generation+=1
            async with self.db.transaction() as connection:
                row=await one(connection,'DELETE FROM nt.blocks WHERE public_ref=%s AND blocker_id=%s RETURNING blocked_id',(remove,principal.account_id))
                require(row,'NOT_FOUND',404)
                other=await one(connection,'SELECT public_ref FROM nt.accounts WHERE id=%s',(row['blocked_id'],))
            self.safety_generation+=1
            self.realtime.blocks.discard((principal.ref,other['public_ref']))
            return {'removed':True}
        async with self.db.transaction() as connection:
            boundary=None
            if cursor:
                boundary=await one(connection,'SELECT public_ref,created_at FROM nt.blocks WHERE public_ref=%s AND blocker_id=%s',(cursor,principal.account_id))
                require(boundary,'NOT_FOUND',404)
            rows=await many(connection,'''SELECT public_ref,created_at FROM nt.blocks WHERE blocker_id=%s
                AND (%s::timestamptz IS NULL OR (created_at,public_ref)<(%s::timestamptz,%s)) ORDER BY created_at DESC,public_ref DESC LIMIT 101''',
                (principal.account_id,boundary['created_at'] if boundary else None,boundary['created_at'] if boundary else None,boundary['public_ref'] if boundary else ''))
        return {'items':rows[:100],'next_cursor':rows[99]['public_ref'] if len(rows)>100 else None}
