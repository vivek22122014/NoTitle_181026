"""Authorization/effect boundary for the synchronous Phase 4 conversation actor."""
import asyncio,hashlib,hmac,time
from dataclasses import dataclass,field
from collections import OrderedDict
from uuid import uuid4
from app.domain.errors import DomainError,require
from app.domain.security import canonical,token
from app.domain.conversation_contracts import Ack
from app.services.primitives import Limiter
from app.repositories.database import one
from app.coordinator.mailbox import Mailbox,MailboxFull
BACKGROUND={'heartbeat','session.resume','text.delivered','call.sdp','call.ice','call.connected','call.refresh'}

@dataclass
class Access:
    principal:object
    revisions:tuple
    deadline:float
    premium_until:float

@dataclass
class Binding:
    principal:object
    generation:int
    access:Access
    renewed:float=-1e10
    action:str|None=None
    cancelled:OrderedDict=field(default_factory=OrderedDict)

class FreeLedger:
    async def __call__(self,principal):return {'premium_until':0,'entitlement_revision':0}

class Conversation:
    def __init__(self,actor,identity,accounts=None,social=None,ledger=None,media=None):
        self.rt,self.identity,self.accounts,self.social=actor,identity,accounts,social
        self.ledger=ledger or FreeLedger();self.bindings={};self.pending={};self.effects={};self.match_tasks=set()
        self.limiter=Limiter(actor.clock);self.handshakes=0;self.available=True;self.closed=False
        self.counters={'commands':0,'rejected':0,'slow_clients':0,'pair_checks':0,'matches_rejected':0,'handshake_rejected':0}
        self.mailbox=Mailbox(actor.authority);self.dispatching=None;self.dispatch_waiters=set()
        self.feature_handlers={}
        from typing import get_args
        if social is not None:
            from app.services.conversation_social import ConversationSocial
            from app.domain.social_contracts import SOCIAL_COMMANDS
            handler=ConversationSocial(self)
            for model in SOCIAL_COMMANDS:
                for name in get_args(model.model_fields['type'].annotation):self.feature_handlers[name]=handler
        if media is not None:self.attach_media(media)

    def attach_media(self,media):
        from typing import get_args
        from app.services.conversation_audio import ConversationAudio
        from app.domain.audio_contracts import AUDIO_COMMANDS
        handler=ConversationAudio(self,media)
        for model in AUDIO_COMMANDS:
            for name in get_args(model.model_fields['type'].annotation):self.feature_handlers[name]=handler

    async def transition(self,function,*,control=False):
        """Drain at most 64 control + 64 ordinary synchronous transitions per turn."""
        require(not self.closed,'SERVICE_UNAVAILABLE',503)
        loop=asyncio.get_running_loop();future=loop.create_future();self.dispatch_waiters.add(future)
        future.add_done_callback(self.dispatch_waiters.discard)
        def apply():
            if future.done():return
            try:future.set_result(function())
            except DomainError as error:future.set_exception(error)
        try:self.mailbox.submit(apply,control=control)
        except MailboxFull:
            self.dispatch_waiters.discard(future);future.cancel()
            if control:self.abort_dispatch()
            raise DomainError('CONTROL_SATURATED' if control else 'COMMAND_CAPACITY',503) from None
        if self.dispatching is None:self.dispatching=loop.call_soon(self.drain_transitions)
        return await future

    def drain_transitions(self):
        self.dispatching=None
        try:self.mailbox.drain_tick()
        except Exception:self.abort_dispatch();return
        if self.mailbox.control or self.mailbox.ordinary:self.dispatching=asyncio.get_running_loop().call_soon(self.drain_transitions)

    def abort_dispatch(self):
        self.available=False;self.mailbox.control.clear();self.mailbox.ordinary.clear();self.rt.fence()
        for future in tuple(self.dispatch_waiters):
            if not future.done():future.set_exception(DomainError('SERVICE_UNAVAILABLE',503))

    async def authorize(self,principal,*,strict=False):
        self.rt.authority.assert_authority()
        current=await self.identity.resolve({principal.kind:principal.token})
        require(current and current.kind==principal.kind and current.ref==principal.ref,'SESSION_EXPIRED',401)
        row=current.account
        require(row.get('core_consent',True) and row.get('status','active')=='active' and current.ref not in self.identity.participation_fences and current.ref not in self.identity.fenced_subjects,'PARTICIPATION_UNAVAILABLE',403)
        if current.kind=='account':
            require(self.accounts is not None,'POLICY_UNAVAILABLE',503)
            async with self.identity.db.transaction() as connection:
                row=await self.identity.lock_account(connection,current);current.account=row
                require(row.get('core_consent') and row.get('status')=='active','PARTICIPATION_UNAVAILABLE',403)
                require(await self.accounts.current_policy(connection,current.account_id),'POLICY_ACCEPTANCE_REQUIRED',409)
                restriction=await one(connection,"SELECT 1 FROM nt.restrictions WHERE subject_ref=%s AND starts_at<=now() AND (ends_at IS NULL OR ends_at>now()) LIMIT 1",(current.ref,))
                require(not restriction,'PARTICIPATION_RESTRICTED',403)
            expiry=min(row['session_expires_at'].timestamp(),row['session_absolute_expires'].timestamp())
            deadline=self.rt.clock()+max(0,expiry-self.rt.wall())
        else:
            guest=self.identity.guests.get(self.identity.security.digest('guest',current.token));require(guest,'SESSION_EXPIRED',401)
            row=await self.identity.guest_access(current);current.account=row
            deadline=min(guest['until'],guest['absolute'])
        entitlement=await self.ledger(current) if current.kind=='account' else {'premium_until':0,'entitlement_revision':0}
        return Access(current,tuple(row.get(k,1) for k in ('auth_generation','profile_revision','preference_revision','consent_revision','safety_revision'))+(entitlement.get('entitlement_revision',0),),deadline,float(entitlement['premium_until']))

    async def prepare(self,principal,dto):
        require(not self.closed and not self.rt.maintenance,'ADMISSION_CLOSED',503)
        require(principal.kind in {'account','guest'},'AUTHENTICATION_REQUIRED',401)
        self.limiter.take(('ticket',principal.ref),5,60)
        old=self.rt.people.get(principal.ref);stamp=(old.revision,old.generation) if old else None
        access=await self.authorize(principal,strict=True)
        require(not self.closed,'ADMISSION_CLOSED',503)
        # Only explicit, fully reauthorized reconnects recover admission after an outage.
        self.available=True
        person=self.rt.people.get(principal.ref)
        require((person is None and stamp is None) or person is not None and stamp==(person.revision,person.generation),'AUTHORITY_CHANGED')
        require(not person or not person.connected or dto.takeover and dto.known_socket_generation==person.generation,'SOCKET_EXISTS')
        profile={key:access.principal.account[key] for key in ('display_name','gender','topic_id','bio')}
        profile['professional']=access.principal.account.get('professional',{}) if access.principal.account.get('professional_consent') else {}
        self.rt.enter(principal.ref,profile,principal.kind=='account',access.premium_until)
        self.identity.prune();require(len(self.identity.tickets)<400,'TICKET_CAPACITY',503)
        require(sum(v['ref']==principal.ref for v in self.identity.tickets.values())<2,'TICKET_CAPACITY',429)
        secret=token();person=self.rt.people[principal.ref]
        self.identity.tickets[self.identity.security.digest('ticket',secret)]={'principal':principal,'ref':principal.ref,'until':self.rt.clock()+60,
            'stamp':(person.revision,person.generation),'access':access,'takeover':dto.takeover,'generation':dto.known_socket_generation}
        return {'ticket':secret,'expires_in':60,'owner_epoch':self.rt.authority.epoch,'protocol_version':2}

    async def connect(self,ticket,cookies):
        record=self.identity.tickets.pop(self.identity.security.digest('ticket',ticket),None)
        require(record and record['until']>self.rt.clock(),'TICKET_EXPIRED',401)
        principal=record['principal'];require(hmac.compare_digest(cookies.get(principal.kind) or '',principal.token),'TICKET_BINDING',401)
        access=await self.authorize(principal,strict=True)
        person=self.rt.person(principal.ref)
        require(record['stamp']==(person.revision,person.generation) and access.revisions==record['access'].revisions,'TICKET_STALE',409)
        generation=self.rt.connect(principal.ref,record['takeover'],record['generation'])
        binding=Binding(access.principal,generation,access);self.bindings[principal.ref]=binding;return binding

    def check(self,binding,command,*,disconnected=False):
        self.rt.authority.assert_authority();person=self.rt.person(binding.principal.ref)
        require(self.bindings.get(person.id) is binding and person.generation==binding.generation and (person.connected or disconnected),'SOCKET_REPLACED',401)
        require(command.owner_epoch==self.rt.authority.epoch and command.socket_generation==person.generation,'STALE_SOCKET')
        require(binding.access.deadline>self.rt.clock() or command.type in {'interaction.end','queue.cancel','call.end','call.cancel'},'SESSION_EXPIRED',401)
        return person

    def digest(self,command):return hashlib.sha256(canonical(command.model_dump())).hexdigest()

    def previous(self,person,command):
        old=person.commands.get(command.command_id)
        if old and old[2]>self.rt.clock():
            require(old[0]==self.digest(command),'COMMAND_NONCE_CONFLICT');return old[1]

    def acknowledge(self,binding,command,result=None,*,emit=True):
        person=self.rt.person(binding.principal.ref);result=Ack(command_id=command.command_id,**(result or {})).model_dump(mode='json',exclude_none=True)
        require(len(canonical(result))<=512,'ACK_LIMIT')
        person.commands[command.command_id]=(self.digest(command),result,self.rt.clock()+120)
        person.commands.move_to_end(command.command_id)
        while len(person.commands)>128:person.commands.popitem(last=False)
        if emit:self.rt.emit(person.id,'command.ack',result)
        return result

    def cancel_effects(self,ref,except_id=None):
        try:current=asyncio.current_task()
        except RuntimeError:current=None
        for key,task in list(self.effects.items()):
            if key[0]==ref and key[2]!=except_id and task is not current:task.cancel()
        for key in list(self.pending):
            if key[0]==ref and key[2]!=except_id:self.pending.pop(key,None)

    def begin(self,binding,command):
        person=self.check(binding,command);previous=self.previous(person,command)
        if previous:self.rt.emit(person.id,'command.ack',previous);return None
        key=(person.id,person.generation,command.command_id);digest=self.digest(command)
        if key in self.pending:
            require(self.pending[key][0]==digest,'COMMAND_NONCE_CONFLICT');return None
        require(len(self.pending)<2048,'COMMAND_CAPACITY',429)
        if command.type=='interaction.next':
            require(command.payload.interaction_handle==person.interaction,'STALE_INTERACTION')
            self.cancel_effects(person.id);self.rt.end(person.id,'next');binding.action=command.command_id
        else:require(command.interaction_epoch==person.revision or command.type in {'session.resume','heartbeat','call.end','call.cancel'},'STALE_INTERACTION')
        if command.type=='queue.join':
            require(not person.interaction,'NOT_AVAILABLE');require(binding.action is None,'SEARCH_PENDING')
            binding.action=command.command_id
        self.pending[key]=(digest,person.revision)
        return key

    def control(self,binding,command,*,http=False):
        person=self.check(binding,command,disconnected=http);previous=self.previous(person,command)
        if previous:
            if not http:self.rt.emit(person.id,'command.ack',previous)
            return previous
        if command.type=='interaction.end':
            handle=command.payload.interaction_handle
            if person.interaction!=handle:
                ended=self.rt.ended.get(handle);require(ended and person.id in ended[:2] and ended[2]>self.rt.clock(),'STALE_INTERACTION')
                return self.acknowledge(binding,command,{'status':'already_ended'},emit=not http)
            self.cancel_effects(person.id);binding.action=None;self.rt.end(person.id)
        else:
            require(command.type=='queue.cancel','COMMAND_TYPE',422);target=command.payload.search_command_id
            queue=self.rt.searches.get(person.id)
            current=binding.action==target or queue and queue['search_command_id']==target
            interaction=self.rt.interactions.get(person.interaction)
            if interaction and interaction.searches.get(person.id)==target:
                self.cancel_effects(person.id);binding.action=None;self.rt.end(person.id,'search_cancelled');current=False
            if current:
                binding.cancelled[target]=self.rt.clock()+120
                while len(binding.cancelled)>128:binding.cancelled.popitem(last=False)
                self.cancel_effects(person.id);binding.action=None;self.rt.cancel(person.id)
        return self.acknowledge(binding,command,{'status':'ended' if command.type=='interaction.end' else 'cancelled'},emit=not http)

    async def execute(self,binding,command,key):
        if key is None:return
        ref=binding.principal.ref;task=asyncio.current_task();self.effects[key]=task
        try:
            person=self.check(binding,command);pending=self.pending.get(key)
            require(pending is not None,'COMMAND_CANCELLED')
            revision=pending[1]
            access=await self.authorize(binding.principal)
            person=self.check(binding,command)
            require(person.revision==revision and key in self.pending,'STALE_INTERACTION')
            binding.access=access;binding.principal=access.principal;row=access.principal.account
            require(command.type not in {'queue.join','interaction.next'} or binding.action==command.command_id and command.command_id not in binding.cancelled,'COMMAND_CANCELLED')
            if command.type not in BACKGROUND and self.rt.clock()-binding.renewed>=60:
                await self.identity.foreground(access.principal);binding.renewed=self.rt.clock()
                person=self.check(binding,command);require(person.revision==revision and key in self.pending,'STALE_INTERACTION')
                if binding.access.deadline-self.rt.clock()<20:binding.access=await self.authorize(binding.principal)
            if command.type in self.feature_handlers:
                self.limiter.take(('ordinary',ref),20,2)
                result=await self.feature_handlers[command.type].execute(binding,command,revision)
                def finish():
                    current=self.check(binding,command);require(key in self.pending,'COMMAND_CANCELLED')
                    if command.type not in BACKGROUND:current.last_action=self.rt.clock()
                    self.counters['commands']+=1
                    return self.acknowledge(binding,command,result)
                return await self.transition(finish)
            def commit():
                person=self.check(binding,command)
                require(person.revision==revision and key in self.pending,'STALE_INTERACTION')
                result={}
                if command.type not in {'heartbeat','session.resume'}:self.limiter.take(('ordinary',ref),20,2)
                if command.type in {'queue.join','interaction.next'}:
                    require(binding.action==command.command_id,'COMMAND_CANCELLED')
                    self.limiter.take(('search',ref),3,3)
                    require(not self.rt.maintenance,'ADMISSION_CLOSED',503)
                    require(command.payload.profile_revision==row.get('profile_revision',1) and command.payload.preference_revision==row.get('preference_revision',1),'REVISION_CONFLICT')
                    person.premium_until=access.premium_until
                    prefs=row.get('preferences',{})
                    professional={k:prefs.get(k,[]) for k in ('industry','role','experience','interests','topics')} if prefs.get('professional_enabled') and row.get('professional_consent') else {}
                    self.rt.join(ref,command.payload.gender,professional,general_talk=command.payload.general_talk,command_id=command.command_id)
                elif command.type=='text.send':
                    require(person.interaction==command.payload.interaction_handle,'STALE_INTERACTION')
                    self.limiter.take(('text',ref),10,2);result=self.rt.text(ref,command.payload.text,command.command_id)
                elif command.type=='text.delivered':
                    require(person.interaction==command.payload.interaction_handle,'STALE_INTERACTION')
                    self.rt.delivered(ref,command.payload.message_id,command.payload.sequence)
                elif command.type=='session.resume':self.rt.emit(ref,'state.snapshot',self.rt.snapshot(ref))
                elif command.type=='heartbeat':
                    self.limiter.take(('heartbeat',ref),2,2);self.rt.emit(ref,'heartbeat.ack',{'client_time':command.payload.client_time})
                else:require(False,'FEATURE_UNAVAILABLE',503)
                person.last_action=self.rt.clock() if command.type not in BACKGROUND else person.last_action
                self.counters['commands']+=1;return self.acknowledge(binding,command,result)
            return await self.transition(commit)
        except DomainError as error:
            self.counters['rejected']+=1
            if error.status==401 or error.code in {'PARTICIPATION_UNAVAILABLE','PARTICIPATION_RESTRICTED','POLICY_ACCEPTANCE_REQUIRED'}:self.deny(ref,error.code)
            raise
        except asyncio.CancelledError:raise
        except Exception:
            self.degrade();raise DomainError('SERVICE_UNAVAILABLE',503) from None
        finally:
            self.pending.pop(key,None);self.effects.pop(key,None)
            if command.type in {'queue.join','interaction.next'} and binding.action==command.command_id:binding.action=None

    async def stop_audio(self,binding,command,key):
        """Scoped stop authority survives stalled normal authorization and expired idle time."""
        if key is None:return
        try:
            require(command.type in {'call.end','call.cancel'},'COMMAND_TYPE',422)
            self.check(binding,command);handler=self.feature_handlers.get(command.type)
            require(handler,'AUDIO_UNAVAILABLE',503)
            result=await handler.execute(binding,command,self.pending[key][1])
            def finish():
                self.check(binding,command);require(key in self.pending,'COMMAND_CANCELLED')
                return self.acknowledge(binding,command,result)
            return await self.transition(finish,control=True)
        finally:self.pending.pop(key,None)

    def deny(self,ref,code):
        if ref in self.rt.people:
            self.cancel_effects(ref);self.rt.end(ref,code);self.rt.emit(ref,'service.unavailable',{'code':code});self.rt.disconnect(ref)

    def degrade(self):
        self.available=False
        for ref in tuple(self.bindings):self.deny(ref,'SERVICE_UNAVAILABLE')

    async def validate_pair(self,reservation):
        try:
            async with asyncio.timeout(2):
                accesses=[]
                for ref in reservation.members:
                    binding=self.bindings.get(ref);require(binding,'MATCH_STALE')
                    accesses.append(await self.authorize(binding.principal,strict=True))
                    if self.social:await self.social.hydrate(binding.principal)
                def publish():
                    for ref,access in zip(reservation.members,accesses):
                        binding=self.bindings.get(ref);require(binding and binding.access.revisions==access.revisions,'MATCH_STALE')
                        person=self.rt.person(ref);person.premium_until=access.premium_until
                        require(access.deadline>self.rt.clock(),'SESSION_EXPIRED',401)
                    return self.rt.publish(reservation)
                await self.transition(publish)
        except DomainError as error:
            self.counters['matches_rejected']+=1
            if error.status==401 or error.code in {'PARTICIPATION_UNAVAILABLE','PARTICIPATION_RESTRICTED','POLICY_ACCEPTANCE_REQUIRED'}:
                for ref in reservation.members:self.deny(ref,error.code)
        except asyncio.CancelledError:raise
        except Exception:self.degrade()
        finally:self.rt.release(reservation.id)

    def step(self):
        if self.closed:return
        self.rt.authority.assert_authority();self.rt.tick()
        for ref,binding in tuple(self.bindings.items()):
            if ref not in self.rt.people:
                self.cancel_effects(ref);self.bindings.pop(ref,None)
            else:
                binding.cancelled=OrderedDict((key,until) for key,until in binding.cancelled.items() if until>self.rt.clock())
        if not self.available or self.rt.maintenance:return
        deadline=time.perf_counter()+.1;checks=0
        while len(self.match_tasks)<4 and checks<10000 and time.perf_counter()<deadline:
            reservation=self.rt.reserve_match(10000-checks,deadline);checks+=self.rt.scan_checks
            if not reservation:break
            task=asyncio.create_task(self.validate_pair(reservation));self.match_tasks.add(task)
            def done(value):
                self.match_tasks.discard(value)
                if not value.cancelled():value.exception()
            task.add_done_callback(done)
        self.counters['pair_checks']+=checks

    def maintenance(self,closed):
        if closed and not self.rt.maintenance:
            for ref in tuple(self.bindings):
                if ref in self.rt.people:self.rt.end(ref,'maintenance');self.rt.emit(ref,'service.draining',{'code':'MAINTENANCE'})
        self.rt.maintenance=closed

    async def close(self):
        # Teardown must be queued before closed dispatch rejects late effects.
        for interaction in tuple(self.rt.interactions.values()):
            if interaction.call:self.rt.end_call(interaction,'shutdown')
        self.rt.fence()
        self.closed=True
        if self.dispatching:self.dispatching.cancel();self.dispatching=None
        self.mailbox.control.clear();self.mailbox.ordinary.clear()
        for future in tuple(self.dispatch_waiters):
            if not future.done():future.cancel()
        tasks=set(self.match_tasks)|set(self.effects.values())
        for task in tasks:task.cancel()
        await asyncio.gather(*tasks,return_exceptions=True)
        self.identity.tickets.clear();self.bindings.clear();self.pending.clear();self.effects.clear();self.rt.fence()
