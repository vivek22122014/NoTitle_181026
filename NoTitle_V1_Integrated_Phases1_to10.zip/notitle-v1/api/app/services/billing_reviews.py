"""Private, provider-verified disposition of externally frozen entitlement."""
import asyncio
from datetime import timedelta
from decimal import Decimal
from uuid import UUID,uuid4
from app.domain.errors import require
from app.domain.security import canonical
from app.integrations.cashfree import verified_refunds,verified_disputes,external_disposition,ProviderUnknown,ProviderRejected
from app.repositories.database import one,many
from .identity import now


class BillingReviews:
    def __init__(self,billing):
        self.billing=billing;self.db=billing.db;self.identity=billing.identity;self.security=billing.security

    async def staff(self,connection,principal,role=None):
        principal.permission('billing.remedies')
        row=await one(connection,'''SELECT a.role_version,s.mfa_at FROM nt.staff_accounts a JOIN nt.staff_sessions s
            ON s.staff_id=a.id AND s.role_version=a.role_version WHERE a.id=%s AND s.token_hmac=%s
            AND s.key_version=%s AND a.status='active' AND s.expires_at>now() AND s.absolute_expires>now() FOR UPDATE OF a,s''',
            (principal.account_id,self.security.digest('staff_session',principal.token),self.security.key_version))
        require(row and row['mfa_at'] and timedelta(0)<=now()-row['mfa_at']<=timedelta(minutes=5),'FRESH_MFA_REQUIRED',401)
        granted=await one(connection,"SELECT permission FROM nt.staff_roles WHERE staff_id=%s AND permission='billing.remedies'",(principal.account_id,))
        require(granted and (role is None or row['role_version']==role),'FORBIDDEN',403)
        return row['role_version']

    async def audit(self,connection,p,ref,action,request_id):
        await connection.execute("INSERT INTO nt.access_audit(id,actor_ref,purpose_code,object_type,object_ref,action,request_id) VALUES(%s,%s,'billing_review','purchase',%s,%s,%s)",(uuid4(),p.ref,ref,action,request_id))

    async def list(self,p,request_id,cursor=None):
        require(cursor is None or isinstance(cursor,str) and len(cursor)==32,'INVALID_CURSOR',422)
        async with self.db.transaction('private') as c:
            await self.staff(c,p)
            rows=await many(c,'''SELECT p.public_ref AS purchase_ref,p.public_ref AS review_id,'external_financial_review' AS kind,
                r.held_seconds,r.created_at,r.revision,r.event_refs AS origin_ref FROM nt.external_financial_reviews r
                JOIN nt.purchases p ON p.id=r.purchase_id WHERE r.state='open' AND (%s::text IS NULL OR p.public_ref>%s)
                ORDER BY p.public_ref LIMIT 21''',(cursor,cursor))
            await self.audit(c,p,'queue','list_external_reviews',request_id)
        return {'items':rows[:20],'next_cursor':rows[19]['purchase_ref'] if len(rows)>20 else None}

    async def provider_state(self,purchase,payment_id=None,order=None):
        try:
            async with asyncio.timeout(12):return await self._provider_state(purchase,payment_id,order)
        except (ProviderUnknown,ProviderRejected,TimeoutError):require(False,'PROVIDER_VERIFICATION_UNAVAILABLE',503)

    async def _provider_state(self,purchase,payment_id=None,order=None):
        provider=self.billing.provider;require(provider,'PAYMENTS_UNAVAILABLE',503)
        require(purchase['environment']==self.billing.environment,'PAYMENT_ENVIRONMENT_MISMATCH',409)
        async with self.db.transaction('jobs') as c:
            if payment_id is None:
                capture=await one(c,"SELECT provider_payment_id FROM nt.payment_attempts WHERE purchase_id=%s AND status='SUCCESS' AND environment=%s AND currency='INR' AND amount_paise=%s",(purchase['id'],purchase['environment'],purchase['amount_paise']))
                require(capture,'CAPTURE_PENDING');payment_id=capture['provider_payment_id']
            review=await one(c,'SELECT event_refs FROM nt.external_financial_reviews WHERE purchase_id=%s',(purchase['id'],))
        if order is None:
            order,raw_refunds,raw_disputes=await asyncio.gather(provider.fetch_order(purchase['merchant_order_id']),provider.fetch_refunds(purchase['merchant_order_id']),provider.fetch_disputes(purchase['merchant_order_id']))
        else:raw_refunds,raw_disputes=await asyncio.gather(provider.fetch_refunds(purchase['merchant_order_id']),provider.fetch_disputes(purchase['merchant_order_id']))
        try:valid=order['order_id']==purchase['merchant_order_id'] and order['order_currency']=='INR' and Decimal(str(order['order_amount']))*100==purchase['amount_paise']
        except Exception:valid=False
        require(valid,'PROVIDER_ASSOCIATION_INVALID',502)
        refunds=verified_refunds(raw_refunds,purchase['merchant_order_id'],payment_id,purchase['amount_paise'])
        disputes=verified_disputes(raw_disputes,purchase['merchant_order_id'],payment_id,purchase['amount_paise'])
        known_refunds={ref.split(':')[2] for ref in (review['event_refs'] if review else []) if ref.startswith('external-refund:') and len(ref.split(':'))>=3}
        require(len(known_refunds)<=128,'REVIEW_REFERENCE_LIMIT',503)
        missing_refunds=known_refunds-{row['provider_id'] for row in refunds}
        if missing_refunds:
            async with self.db.transaction('jobs') as c:
                receipts=await many(c,"SELECT facts FROM nt.receipts WHERE purchase_id=%s AND facts->>'document_kind'='provider_financial_review' ORDER BY receipt_number DESC LIMIT 256",(purchase['id'],))
            for identifier in sorted(missing_refunds):
                recorded=next((row['facts'] for row in receipts if str(row['facts'].get('provider_refund_id',row['facts'].get('provider_id','')))==identifier and (row['facts'].get('merchant_refund_id') or row['facts'].get('merchant_id'))),None)
                require(recorded,'PROVIDER_ASSOCIATION_UNRESOLVED',503)
                merchant=recorded.get('merchant_refund_id',recorded.get('merchant_id'))
                raw=await provider.fetch_refund(purchase['merchant_order_id'],merchant)
                verified=verified_refunds([raw],purchase['merchant_order_id'],payment_id,purchase['amount_paise'])
                require(verified[0]['provider_id']==identifier,'PROVIDER_ASSOCIATION_INVALID',502);refunds+=verified
        known={ref.split(':')[2] for ref in (review['event_refs'] if review else []) if ref.startswith('external-dispute:') and len(ref.split(':'))>=3}
        present={row['provider_id'] for row in disputes}
        require(len(known)<=128,'REVIEW_REFERENCE_LIMIT',503)
        for identifier in sorted(known-present):
            raw=await provider.fetch_dispute(identifier)
            verified=verified_disputes([raw],purchase['merchant_order_id'],payment_id,purchase['amount_paise'])
            require(verified[0]['provider_id']==identifier,'PROVIDER_ASSOCIATION_INVALID',502);disputes+=verified
        facts={'environment':purchase['environment'],'order_id':purchase['merchant_order_id'],'payment_id':str(payment_id),
               'refunds':sorted(refunds,key=lambda r:r['provider_id']),'disputes':sorted(disputes,key=lambda r:r['provider_id'])}
        return facts,self.security.digest('external_provider_facts',canonical(facts).decode())

    @staticmethod
    def disposition(facts,purchase,review,action,requested,already_revoked=0):
        try:return external_disposition(facts['refunds'],facts['disputes'],purchase['amount_paise'],purchase['duration_seconds'],review['held_seconds'],action,requested,already_revoked)
        except ProviderUnknown as exc:require(False,str(exc),409)

    async def sync(self,c,purchase,subject,facts,digest):
        review=await one(c,'SELECT * FROM nt.external_financial_reviews WHERE purchase_id=%s FOR UPDATE',(purchase['id'],))
        if review and review['state']!='open' and review['provider_digest']==digest:return
        # Internal remedies retain their own originating holds and stable jobs.
        for refund in facts['refunds']:
            internal=await one(c,'SELECT public_ref FROM nt.refunds WHERE provider_ref=%s AND purchase_id=%s',(refund['merchant_id'],purchase['id']))
            if internal:
                await c.execute("INSERT INTO nt.durable_jobs(id,kind,dedupe_key,object_ref) VALUES(%s,'refund',%s,%s) ON CONFLICT(dedupe_key) DO UPDATE SET state='ready',available_at=now() WHERE nt.durable_jobs.state<>'running'",(uuid4(),'refund:'+internal['public_ref'],internal['public_ref']));continue
            if refund['status'] in {'CANCELLED','REJECTED'}:continue
            origin='external-refund:'+purchase['environment']+':'+refund['provider_id']+':'+digest[:16]
            await self.billing.hold_external(c,purchase,subject,origin,'external_refund_hold',{'verification':'independent_provider_lookup',**refund})
        for dispute in facts['disputes']:
            if dispute['status'].endswith('_MERCHANT_WON'):continue
            origin='external-dispute:'+purchase['environment']+':'+dispute['provider_id']+':'+digest[:16]
            await self.billing.hold_external(c,purchase,subject,origin,'external_dispute_hold',{'verification':'independent_provider_lookup',**dispute})
        await self.absorb_available(c,purchase)

    async def absorb_available(self,c,purchase):
        """Capture after a notice, or failed internal refunds, cannot escape a freeze."""
        review=await one(c,"SELECT * FROM nt.external_financial_reviews WHERE purchase_id=%s AND state='open' FOR UPDATE",(purchase['id'],))
        if not review:return
        lot=await one(c,'SELECT available_seconds FROM nt.entitlement_lots WHERE purchase_id=%s FOR UPDATE',(purchase['id'],))
        if not lot or not lot['available_seconds']:return
        seconds=lot['available_seconds']
        await c.execute('UPDATE nt.entitlement_lots SET available_seconds=0,held_seconds=held_seconds+%s,revision=revision+1 WHERE purchase_id=%s',(seconds,purchase['id']))
        await c.execute('UPDATE nt.external_financial_reviews SET held_seconds=held_seconds+%s,revision=revision+1,updated_at=now() WHERE purchase_id=%s',(seconds,purchase['id']))
        await c.execute('UPDATE nt.financial_subjects SET ledger_revision=ledger_revision+1 WHERE id=%s',(purchase['financial_subject_id'],))
        await c.execute('INSERT INTO nt.ledger_adjustments(id,subject_id,lot_id,kind,seconds,origin_ref,reason) VALUES(%s,%s,%s,\'external_hold_catchup\',%s,%s,%s)',(uuid4(),purchase['financial_subject_id'],purchase['id'],seconds,'external-catchup:'+str(purchase['id'])+':'+str(review['revision']),'Preserve external freeze across capture/internal settlement'))

    async def refresh(self,p,ref,request_id):
        async with self.db.transaction('private') as c:
            role=await self.staff(c,p);purchase=await one(c,'SELECT * FROM nt.purchases WHERE public_ref=%s',(ref,));require(purchase,'NOT_FOUND',404)
            await self.audit(c,p,ref,'refresh_external_provider',request_id)
        facts,digest=await self.provider_state(purchase)
        async with self.db.transaction('private') as c:
            await self.staff(c,p,role)
            await one(c,'SELECT * FROM nt.subject_controls WHERE financial_subject_id=%s FOR UPDATE',(purchase['financial_subject_id'],))
            subject=await one(c,'SELECT * FROM nt.financial_subjects WHERE id=%s FOR UPDATE',(purchase['financial_subject_id'],))
            purchase=await one(c,'SELECT * FROM nt.purchases WHERE id=%s FOR UPDATE',(purchase['id'],))
            await self.sync(c,purchase,subject,facts,digest)
        await self.billing.publish_available(subject,None)
        return {'purchase_ref':ref,'provider_digest':digest,'provider_state_summary':facts,'state':'checked'}

    async def preview(self,p,ref,dto,request_id):
        from psycopg.types.json import Jsonb
        async with self.db.transaction('private') as c:
            role=await self.staff(c,p);purchase=await one(c,'SELECT * FROM nt.purchases WHERE public_ref=%s',(ref,));require(purchase,'NOT_FOUND',404)
            await self.audit(c,p,ref,'preview_external_resolution',request_id)
        facts,digest=await self.provider_state(purchase)
        async with self.db.transaction('private') as c:
            await self.staff(c,p,role)
            await one(c,'SELECT * FROM nt.subject_controls WHERE financial_subject_id=%s FOR UPDATE',(purchase['financial_subject_id'],))
            subject=await one(c,'SELECT * FROM nt.financial_subjects WHERE id=%s FOR UPDATE',(purchase['financial_subject_id'],))
            purchase=await one(c,'SELECT * FROM nt.purchases WHERE id=%s FOR UPDATE',(purchase['id'],))
            await self.absorb_available(c,purchase)
            subject=await one(c,'SELECT * FROM nt.financial_subjects WHERE id=%s',(subject['id'],))
            review=await one(c,"SELECT * FROM nt.external_financial_reviews WHERE purchase_id=%s AND state='open' FOR UPDATE",(purchase['id'],));require(review,'NOT_FOUND',404)
            lot=await one(c,'SELECT revoked_seconds,revision FROM nt.entitlement_lots WHERE purchase_id=%s FOR UPDATE',(purchase['id'],));require(lot,'CAPTURE_PENDING')
            decision=self.disposition(facts,purchase,review,dto.action,dto.seconds_to_revoke,lot['revoked_seconds'])
            payload={'kind':'external_financial_resolution','purchase_ref':ref,'action':dto.action,'held_seconds':review['held_seconds'],
                     'reason':dto.reason,'client_nonce':dto.client_nonce,'provider_digest':digest,'provider_state_summary':facts,**decision}
            preview=uuid4().hex
            await c.execute("INSERT INTO nt.sensitive_previews(nonce,actor_id,object_ref,payload_digest,payload,revisions,expires_at) VALUES(%s,%s,%s,%s,%s,%s,now()+interval '2 minutes')",(preview,p.account_id,ref,self.security.digest('preview',canonical(payload).decode()),Jsonb(payload),Jsonb({'role':role,'ledger':subject['ledger_revision'],'review':review['revision'],'lot':lot['revision']})))
        return {'preview':preview,'payload':payload,'expires_in':120}

    async def confirm(self,p,reference,request_id):
        try:operation_nonce=UUID(reference)
        except (ValueError,TypeError,AttributeError):require(False,'INVALID_PREVIEW',422)
        async with self.db.transaction('private') as c:
            await self.staff(c,p)
            committed=await one(c,"SELECT result FROM nt.operation_results WHERE scope_ref=%s AND kind='external_financial_confirm' AND client_nonce=%s AND expires_at>now()",(p.ref,operation_nonce))
            if committed:return committed['result']
            receipt=await one(c,"SELECT facts FROM nt.receipts WHERE facts->>'document_kind'='external_financial_resolution' AND facts->>'preview_ref'=%s ORDER BY receipt_number DESC LIMIT 1",(reference,))
            if receipt:
                facts=receipt['facts'];keys=('purchase_ref','state','verified_lost_paise','minimum_revoke_seconds','seconds_to_revoke','seconds_to_restore')
                require(all(key in facts for key in keys) and facts['state'] in {'restored','revoked'} and all(type(facts[key]) is int and facts[key]>=0 for key in keys[2:]),'FINANCIAL_RECORD_INVALID',503)
                await self.audit(c,p,facts['purchase_ref'],'recover_external_resolution',request_id)
                return {key:facts[key] for key in keys}
            preview=await one(c,'SELECT * FROM nt.sensitive_previews WHERE nonce=%s',(reference,))
            require(preview and preview['actor_id']==p.account_id and preview['payload'].get('kind')=='external_financial_resolution','NOT_FOUND',404)
            if preview['consumed_at']:
                saved=await one(c,"SELECT result FROM nt.operation_results WHERE scope_ref=%s AND kind='external_financial_confirm' AND client_nonce=%s",(p.ref,UUID(reference)))
                require(saved,'PREVIEW_CONSUMED');return saved['result']
            require(preview['expires_at']>now(),'PREVIEW_EXPIRED')
            purchase=await one(c,'SELECT * FROM nt.purchases WHERE public_ref=%s',(preview['object_ref'],))
        facts,digest=await self.provider_state(purchase)
        from psycopg.types.json import Jsonb
        async with self.db.transaction('private') as c:
            await self.staff(c,p,preview['revisions']['role'])
            await one(c,'SELECT * FROM nt.subject_controls WHERE financial_subject_id=%s FOR UPDATE',(purchase['financial_subject_id'],))
            subject=await one(c,'SELECT * FROM nt.financial_subjects WHERE id=%s FOR UPDATE',(purchase['financial_subject_id'],))
            purchase=await one(c,'SELECT * FROM nt.purchases WHERE id=%s FOR UPDATE',(purchase['id'],))
            review=await one(c,'SELECT * FROM nt.external_financial_reviews WHERE purchase_id=%s FOR UPDATE',(purchase['id'],))
            preview=await one(c,'SELECT * FROM nt.sensitive_previews WHERE nonce=%s FOR UPDATE',(reference,))
            require(not preview['consumed_at'] and preview['expires_at']>now() and review['state']=='open','PREVIEW_STALE')
            payload=preview['payload']
            require(self.security.verify('preview',canonical(payload).decode(),preview['payload_digest']),'PREVIEW_INVALID')
            require(subject['ledger_revision']==preview['revisions']['ledger'] and review['revision']==preview['revisions']['review'] and digest==payload['provider_digest'],'PREVIEW_STALE')
            current_lot=await one(c,'SELECT revoked_seconds,revision FROM nt.entitlement_lots WHERE purchase_id=%s FOR UPDATE',(purchase['id'],))
            require(current_lot and current_lot['revision']==preview['revisions']['lot'],'PREVIEW_STALE')
            decision=self.disposition(facts,purchase,review,payload['action'],payload['seconds_to_revoke'],current_lot['revoked_seconds'])
            require(all(decision[key]==payload[key] for key in decision),'PREVIEW_STALE')
            lots=await self.billing.account_lots(c,subject);lot=next((row for row in lots if row.purchase==str(purchase['id'])),None)
            require(lot and review['held_seconds']<=lot.held,'EXTERNAL_HOLD_INVARIANT')
            from app.domain.ledger import settle
            settle(lot,decision['seconds_to_revoke'],True);settle(lot,decision['seconds_to_restore'],False)
            await c.execute('UPDATE nt.entitlement_lots SET available_seconds=%s,held_seconds=%s,revoked_seconds=%s,revision=revision+1 WHERE purchase_id=%s',(lot.available,lot.held,lot.revoked,purchase['id']))
            state='revoked' if payload['action']=='revoke' else 'restored'
            await c.execute('UPDATE nt.external_financial_reviews SET state=%s,held_seconds=0,provider_digest=%s,resolved_preview=%s,revision=revision+1,updated_at=now() WHERE purchase_id=%s',(state,digest,reference,purchase['id']))
            await c.execute("UPDATE nt.purchases SET state='captured' WHERE id=%s",(purchase['id'],))
            await c.execute("UPDATE nt.durable_jobs SET state='done',last_error_code=NULL WHERE object_ref=%s AND kind='billing_external_review'",(purchase['public_ref'],))
            await c.execute('INSERT INTO nt.ledger_adjustments(id,subject_id,lot_id,kind,seconds,origin_ref,reason) VALUES(%s,%s,%s,%s,%s,%s,%s)',(uuid4(),subject['id'],purchase['id'],'external_review_'+state,review['held_seconds'],'external-resolution:'+reference,payload['reason']))
            result={'purchase_ref':purchase['public_ref'],'state':state,**decision}
            receipt={'document_kind':'external_financial_resolution','preview_ref':reference,'provider_digest':digest,**result,'resolved_at':now().isoformat()}
            await c.execute('INSERT INTO nt.receipts(public_ref,subject_id,purchase_id,facts) VALUES(%s,%s,%s,%s)',(uuid4().hex,subject['id'],purchase['id'],Jsonb(receipt)))
            await c.execute('UPDATE nt.sensitive_previews SET consumed_at=now() WHERE nonce=%s',(reference,))
            await self.identity.save_operation(c,p.ref,'external_financial_confirm',str(UUID(reference)),preview['payload_digest'],result)
            await self.audit(c,p,purchase['public_ref'],'confirm_external_'+state,request_id)
        await self.billing.publish_available(subject,None)
        return result
