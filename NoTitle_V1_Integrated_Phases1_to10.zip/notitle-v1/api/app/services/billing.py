from datetime import timedelta
import hashlib
import time
from uuid import UUID, uuid4
from app.domain.errors import require, DomainError
from app.domain.ledger import Lot, advance, hold, settle
from app.domain.security import canonical
from app.integrations.cashfree import verified_capture, verified_refunds, verify_webhook, ProviderUnknown, ProviderRejected
from app.repositories.database import one, many
from .identity import now


class Billing:
    def __init__(self,db,security,provider,identity,enabled=False,environment='sandbox'):
        self.db,self.security,self.provider,self.identity=db,security,provider,identity
        self.enabled,self.environment=enabled,environment
        self.receipt_configuration=None
        self.public_origin=None
        self.admission=lambda:True
        # Live or sandbox sales must not silently bypass unresolved externally
        # initiated refunds/disputes. Runtime injects reviewed release evidence.
        self.external_adjustments_ready=lambda:False
        from .billing_reviews import BillingReviews
        self.reviews=BillingReviews(self)

    async def subject(self,connection,principal,lock=False):
        require(principal.kind in {'account','financial'},'ACCOUNT_REQUIRED',401)
        if principal.kind=='account':
            subject=await one(connection,'SELECT * FROM nt.financial_subjects WHERE account_id=%s',(principal.account_id,))
        else:
            subject=await one(connection,'SELECT * FROM nt.financial_subjects WHERE id=%s',(UUID(principal.scope),))
        require(subject,'NOT_FOUND',404)
        if lock:
            await one(connection,'SELECT * FROM nt.subject_controls WHERE financial_subject_id=%s FOR UPDATE',(subject['id'],))
            subject=await one(connection,'SELECT * FROM nt.financial_subjects WHERE id=%s FOR UPDATE',(subject['id'],))
        return subject

    async def account_lots(self,connection,subject):
        rows=await many(connection,'''SELECT l.*,p.state AS purchase_state FROM nt.entitlement_lots l
            JOIN nt.purchases p ON p.id=l.purchase_id WHERE l.subject_id=%s ORDER BY l.grant_seq FOR UPDATE OF l''',(subject['id'],))
        lots=[Lot(str(r['purchase_id']),r['grant_seq'],r['granted_seconds'],r['consumed_seconds'],r['available_seconds'],r['held_seconds'],r['revoked_seconds']) for r in rows]
        # Frozen origins cannot consume elapsed time intended for other passes,
        # even if a failed internal remedy later restores their available bucket.
        running=[lot for lot,row in zip(lots,rows) if row['purchase_state']!='financial_review']
        timestamp=advance(running,subject['last_accounted_at'].timestamp(),now().timestamp())
        for lot in lots:
            await connection.execute('UPDATE nt.entitlement_lots SET consumed_seconds=%s,available_seconds=%s,held_seconds=%s,revoked_seconds=%s,revision=revision+1 WHERE purchase_id=%s',
                (lot.consumed,lot.available,lot.held,lot.revoked,UUID(lot.purchase)))
        await connection.execute('UPDATE nt.financial_subjects SET last_accounted_at=to_timestamp(%s),ledger_revision=ledger_revision+1 WHERE id=%s',(timestamp,subject['id']))
        return lots

    async def entitlement(self,principal):
        return await self.matching_entitlement(principal)

    async def matching_entitlement(self,principal):
        """Read one MVCC snapshot without consuming time or changing its revision.

        Holds/revocations are reflected in available_seconds. Wall-clock expiry is
        projected from the last durable accounting boundary; mutations retain the
        existing subject-control -> subject -> FIFO-lot lock order.
        """
        if principal.kind!='account': return {'available_seconds':0,'premium_until':0,'entitlement_revision':0}
        async with self.db.transaction() as connection:
            row=await one(connection,'''SELECT s.ledger_revision,
                floor(extract(epoch FROM s.last_accounted_at))::bigint AS accounted,
                floor(extract(epoch FROM statement_timestamp()))::bigint AS observed,
                COALESCE((SELECT sum(l.available_seconds) FROM nt.entitlement_lots l JOIN nt.purchases p ON p.id=l.purchase_id
                  WHERE l.subject_id=s.id AND p.state<>'financial_review'),0)::bigint AS available
                FROM nt.financial_subjects s WHERE s.account_id=%s''',(principal.account_id,))
        require(row,'NOT_FOUND',404)
        available=max(0,row['available']-max(0,row['observed']-row['accounted']))
        return {'available_seconds':available,'premium_until':row['accounted']+row['available'] if available else 0,
                'entitlement_revision':row['ledger_revision']}

    async def plans(self):
        async with self.db.transaction() as connection:
            rows=await many(connection,'SELECT DISTINCT ON(code) code,version,gross_paise,duration_seconds,currency,enabled,tax_rule,policy_version FROM nt.plan_versions ORDER BY code,enabled DESC,version DESC')
        items=[]
        for row in rows:
            snapshot=None
            if self.receipt_configuration and row['code']!='Annual365':
                try:snapshot=self.receipt_configuration.snapshot(row['code'],row['version'],row['tax_rule'],row['gross_paise'])
                except DomainError:pass
            enabled=bool(row['enabled'] and self.enabled and self.admission() and self.external_adjustments_ready() and self.provider and snapshot and self.public_origin and row['tax_rule']!='unreviewed' and row['policy_version']==self.identity.policy_version and row['code']!='Annual365')
            items.append({**row,'enabled':enabled,'receipt_preview':snapshot if enabled else None})
        return {'items':items,
                'renewal':'none','refund_policy':'No voluntary refunds. Required legal and payment remedies remain available.'}

    async def purchase(self,principal,dto):
        require(self.enabled and self.provider and self.admission(),'PAYMENTS_UNAVAILABLE',503)
        require(self.external_adjustments_ready(),'PAYMENT_EXCEPTION_REVIEW_REQUIRED',503)
        require(self.public_origin,'PAYMENT_RETURN_CONFIGURATION_REQUIRED',503)
        require(principal.kind=='account' and principal.account['status']=='active','ACCOUNT_REQUIRED',401)
        require(dto.policy_accepted and dto.policy_version==self.identity.policy_version,'POLICY_ACCEPTANCE_REQUIRED',422)
        require(dto.plan_code!='Annual365','ANNUAL_REMEDY_GATE',503)
        try:nonce=UUID(dto.client_nonce)
        except (ValueError,TypeError,AttributeError):require(False,'INVALID_NONCE',422)
        from psycopg.types.json import Jsonb
        async with self.db.transaction() as connection:
            current=await self.identity.lock_account(connection,principal)
            require(current['status']=='active','ACCOUNT_REQUIRED',401)
            subject=await self.subject(connection,principal,True)
            purchase=await one(connection,'SELECT * FROM nt.purchases WHERE idempotency_key=%s',(nonce,))
            if purchase:
                require(purchase['financial_subject_id']==subject['id'] and purchase['plan_code']==dto.plan_code and purchase['plan_version']==dto.plan_version,'NONCE_CONFLICT')
                require(purchase['environment']==self.environment,'PAYMENT_ENVIRONMENT_MISMATCH',409)
            else:
                unresolved=await one(connection,"SELECT public_ref FROM nt.purchases WHERE financial_subject_id=%s AND state IN ('created','checkout','unknown') ORDER BY created_at LIMIT 1",(subject['id'],))
                require(not unresolved,'PURCHASE_PENDING',409)
                plan=await one(connection,'SELECT * FROM nt.plan_versions WHERE code=%s AND version=%s AND enabled=true',(dto.plan_code,dto.plan_version))
                require(plan and plan['tax_rule']!='unreviewed' and plan['policy_version']==dto.policy_version,'PLAN_UNAVAILABLE',503)
                require(self.receipt_configuration,'RECEIPT_CONFIGURATION_REQUIRED',503)
                snapshot=self.receipt_configuration.snapshot(plan['code'],plan['version'],plan['tax_rule'],plan['gross_paise'])
                pid,ref=uuid4(),uuid4().hex
                purchase=await one(connection,'''INSERT INTO nt.purchases(id,public_ref,financial_subject_id,plan_code,plan_version,
                    amount_paise,duration_seconds,merchant_order_id,idempotency_key,environment,policy_version,policy_digest,policy_accepted_at,tax_rule,receipt_snapshot)
                    VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,now(),%s,%s) RETURNING *''',
                    (pid,ref,subject['id'],plan['code'],plan['version'],plan['gross_paise'],plan['duration_seconds'],'nt_'+ref,
                     nonce,self.environment,dto.policy_version,self.identity.policy_digest,plan['tax_rule'],Jsonb(snapshot)))
                await connection.execute("INSERT INTO nt.durable_jobs(id,kind,dedupe_key,object_ref,available_at) VALUES(%s,'payment',%s,%s,now()+interval '1 minute')",(uuid4(),'payment:'+ref,ref))
        if purchase['state'] in {'captured','financial_review'}:
            return {'purchase_ref':purchase['public_ref'],'state':purchase['state']}
        if purchase['state'] in {'expired','cancelled','failed'}:
            return {'purchase_ref':purchase['public_ref'],'state':purchase['state']}
        if purchase['payment_session_ciphertext']:
            return {'purchase_ref':purchase['public_ref'],'state':purchase['state'],'payment_session_id':self.security.decrypt('checkout:'+purchase['public_ref'],purchase['payment_session_ciphertext'])}
        # Reuse merchant ID. Unknown outcomes are reconciled; do not automatically re-create.
        try:
            if purchase['state']=='unknown':
                order=await self.provider.fetch_order(purchase['merchant_order_id'])
            else:
                order=await self.provider.create_order(purchase['merchant_order_id'],purchase['amount_paise'],str(subject['id']).replace('-',''),dto.payment_phone,purchase['idempotency_key'],
                    return_url=self.public_origin+'/billing/status/?purchase_ref='+purchase['public_ref'])
            require(order.get('order_id')==purchase['merchant_order_id'] and isinstance(order.get('payment_session_id'),str),'PROVIDER_RESPONSE_INVALID',502)
            session=order['payment_session_id']
            require(len(session)<8192,'PROVIDER_RESPONSE_INVALID',502)
            async with self.db.transaction() as connection:
                current=await self.identity.lock_account(connection,principal)
                require(current['status']=='active','ACCOUNT_REQUIRED',401)
                await connection.execute("UPDATE nt.purchases SET state=CASE WHEN state IN ('captured','financial_review') THEN state ELSE 'checkout' END,provider_order_id=%s,payment_session_ciphertext=CASE WHEN state IN ('captured','financial_review') THEN NULL ELSE %s END WHERE id=%s",(str(order['cf_order_id']),self.security.encrypt('checkout:'+purchase['public_ref'],session),purchase['id']))
            # Capture may race the provider request. Return durable state, never
            # overwrite a verified capture with browser-checkout status.
            async with self.db.transaction() as connection:
                current=await one(connection,'SELECT state FROM nt.purchases WHERE id=%s',(purchase['id'],))
            return {'purchase_ref':purchase['public_ref'],'state':current['state'],**({'payment_session_id':session} if current['state']=='checkout' else {})}
        except (ProviderUnknown,ProviderRejected):
            async with self.db.transaction() as connection:
                await connection.execute("UPDATE nt.purchases SET state='unknown' WHERE id=%s AND state NOT IN ('captured','financial_review')",(purchase['id'],))
            return {'purchase_ref':purchase['public_ref'],'state':'pending','retry_advice':'Check this purchase before paying again.'}

    async def get_purchase(self,principal,ref):
        async with self.db.transaction() as connection:
            subject=await self.subject(connection,principal)
            row=await one(connection,'SELECT public_ref,plan_code,amount_paise,state,created_at,captured_at FROM nt.purchases WHERE public_ref=%s AND financial_subject_id=%s',(ref,subject['id']))
            require(row,'NOT_FOUND',404)
            remedies=await many(connection,'''SELECT r.public_ref,r.amount_paise,r.state,r.remedy_basis,r.created_at,r.verified_at
                FROM nt.refunds r JOIN nt.purchases p ON p.id=r.purchase_id
                WHERE p.public_ref=%s AND p.financial_subject_id=%s ORDER BY r.created_at DESC LIMIT 20''',(ref,subject['id']))
            return {**row,'remedies':remedies}

    async def purchases(self,principal):
        async with self.db.transaction() as connection:
            subject=await self.subject(connection,principal)
            rows=await many(connection,'''SELECT public_ref,plan_code,amount_paise,state,created_at,captured_at
                FROM nt.purchases WHERE financial_subject_id=%s ORDER BY created_at DESC LIMIT 20''',(subject['id'],))
        return {'items':rows}

    async def resume_purchase(self,principal,ref):
        """Reopen only the owned existing hosted order; never create a replacement."""
        require(self.enabled and self.provider and self.admission() and self.receipt_configuration and self.public_origin,'PAYMENTS_UNAVAILABLE',503)
        require(self.external_adjustments_ready(),'PAYMENT_EXCEPTION_REVIEW_REQUIRED',503)
        require(principal.kind=='account' and principal.account['status']=='active','ACCOUNT_REQUIRED',401)
        async with self.db.transaction() as connection:
            current=await self.identity.lock_account(connection,principal)
            require(current['status']=='active','ACCOUNT_REQUIRED',401)
            subject=await self.subject(connection,principal)
            purchase=await one(connection,'SELECT * FROM nt.purchases WHERE public_ref=%s AND financial_subject_id=%s',(ref,subject['id']))
        require(purchase,'NOT_FOUND',404)
        require(purchase['environment']==self.environment,'PAYMENT_ENVIRONMENT_MISMATCH',409)
        if purchase['state'] in {'captured','financial_review'}:return {'purchase_ref':ref,'state':purchase['state']}
        try:order=await self.provider.fetch_order(purchase['merchant_order_id'])
        except (ProviderUnknown,ProviderRejected):return {'purchase_ref':ref,'state':'pending'}
        from decimal import Decimal,InvalidOperation
        try:
            valid=isinstance(order,dict) and order.get('order_id')==purchase['merchant_order_id'] and order.get('order_currency')=='INR' and Decimal(str(order.get('order_amount')))*100==purchase['amount_paise']
        except (InvalidOperation,ValueError,TypeError):valid=False
        require(valid,'PROVIDER_RESPONSE_INVALID',502)
        state=order.get('order_status')
        async with self.db.transaction() as connection:
            current_account=await self.identity.lock_account(connection,principal)
            require(current_account['status']=='active','ACCOUNT_REQUIRED',401)
            current=await one(connection,'SELECT state FROM nt.purchases WHERE id=%s FOR UPDATE',(purchase['id'],))
            if current['state'] in {'captured','financial_review'}:return {'purchase_ref':ref,'state':current['state']}
            if state in {'EXPIRED','TERMINATED'}:
                final='expired' if state=='EXPIRED' else 'cancelled'
                await connection.execute('UPDATE nt.purchases SET state=%s,payment_session_ciphertext=NULL WHERE id=%s',(final,purchase['id']))
                return {'purchase_ref':ref,'state':final}
            session=order.get('payment_session_id')
            if state=='ACTIVE' and isinstance(session,str) and 0<len(session)<8192:
                await connection.execute("UPDATE nt.purchases SET state='checkout',payment_session_ciphertext=%s WHERE id=%s",(self.security.encrypt('checkout:'+ref,session),purchase['id']))
                return {'purchase_ref':ref,'state':'checkout','payment_session_id':session}
            if state=='PAID':
                await connection.execute("INSERT INTO nt.durable_jobs(id,kind,dedupe_key,object_ref) VALUES(%s,'payment',%s,%s) ON CONFLICT(dedupe_key) DO UPDATE SET state='ready',available_at=now() WHERE nt.durable_jobs.state<>'running'",(uuid4(),'payment:'+ref,ref))
        # PAID still needs independent order+payments verification by the job.
        return {'purchase_ref':ref,'state':'pending'}

    async def reconcile(self,ref):
        from psycopg.types.json import Jsonb
        require(self.provider,'PAYMENTS_UNAVAILABLE',503)
        async with self.db.transaction('jobs') as connection:
            purchase=await one(connection,'SELECT * FROM nt.purchases WHERE public_ref=%s',(ref,))
        require(purchase,'NOT_FOUND',404)
        require(purchase['environment']==self.environment,'PAYMENT_ENVIRONMENT_MISMATCH',409)
        order=await self.provider.fetch_order(purchase['merchant_order_id'])
        payments=await self.provider.fetch_payments(purchase['merchant_order_id'])
        payment_id=verified_capture(order,payments,purchase['merchant_order_id'],purchase['amount_paise'])
        require(payment_id,'CAPTURE_PENDING',409)
        facts,digest=await self.reviews.provider_state(purchase,payment_id,order)
        async with self.db.transaction('jobs') as connection:
            await one(connection,'SELECT * FROM nt.subject_controls WHERE financial_subject_id=%s FOR UPDATE',(purchase['financial_subject_id'],))
            subject=await one(connection,'SELECT * FROM nt.financial_subjects WHERE id=%s FOR UPDATE',(purchase['financial_subject_id'],))
            purchase=await one(connection,'SELECT * FROM nt.purchases WHERE id=%s FOR UPDATE',(purchase['id'],))
            previous=await one(connection,'SELECT * FROM nt.payment_attempts WHERE provider_payment_id=%s',(payment_id,))
            if previous:
                require(previous['purchase_id']==purchase['id'],'PAYMENT_ASSOCIATION_CONFLICT')
            else:
                existing=await one(connection,'SELECT * FROM nt.entitlement_lots WHERE purchase_id=%s',(purchase['id'],))
                require(not existing,'DUPLICATE_CAPTURE_REVIEW')
                require(purchase['receipt_snapshot'],'RECEIPT_REVIEW_REQUIRED')
                lots=await self.account_lots(connection,subject)
                await connection.execute("INSERT INTO nt.payment_attempts(provider_payment_id,purchase_id,amount_paise,currency,environment,status) VALUES(%s,%s,%s,'INR',%s,'SUCCESS')",(payment_id,purchase['id'],purchase['amount_paise'],purchase['environment']))
                sequence=max((l.seq for l in lots),default=0)+1
                await connection.execute('INSERT INTO nt.entitlement_lots(purchase_id,subject_id,grant_seq,granted_seconds,available_seconds) VALUES(%s,%s,%s,%s,%s)',(purchase['id'],subject['id'],sequence,purchase['duration_seconds'],purchase['duration_seconds']))
                await connection.execute("UPDATE nt.purchases SET state=CASE WHEN state='financial_review' THEN state ELSE 'captured' END,captured_at=now(),payment_session_ciphertext=NULL WHERE id=%s",(purchase['id'],))
                facts={**purchase['receipt_snapshot'],'purchase_ref':ref,'gross_paise':purchase['amount_paise'],'currency':'INR','plan':purchase['plan_code'],'duration_seconds':purchase['duration_seconds'],'tax_rule':purchase['tax_rule'],'provider_payment_id':payment_id,'verified_at':now().isoformat()}
                await connection.execute('INSERT INTO nt.receipts(public_ref,subject_id,purchase_id,facts) VALUES(%s,%s,%s,%s)',(uuid4().hex,subject['id'],purchase['id'],Jsonb(facts)))
            await self.reviews.sync(connection,purchase,subject,facts,digest)
        await self.publish_available(subject,None)

    async def hold_external_refunds(self,connection,purchase,subject,refunds):
        for refund in refunds:
            internal=await one(connection,'SELECT public_ref FROM nt.refunds WHERE provider_ref=%s AND purchase_id=%s',(refund['merchant_id'],purchase['id']))
            if internal:
                await connection.execute("INSERT INTO nt.durable_jobs(id,kind,dedupe_key,object_ref) VALUES(%s,'refund',%s,%s) ON CONFLICT(dedupe_key) DO UPDATE SET state='ready',available_at=now() WHERE nt.durable_jobs.state<>'running'",(uuid4(),'refund:'+internal['public_ref'],internal['public_ref']))
                continue
            if refund['status'] in {'CANCELLED','REJECTED'}:continue
            origin='external-refund:'+self.environment+':'+refund['provider_id']
            await self.hold_external(connection,purchase,subject,origin,'external_refund_hold',
                {'provider_refund_id':refund['provider_id'],'merchant_refund_id':refund['merchant_id'],'amount_paise':refund['amount_paise'],'provider_status':refund['status'],'verification':'independent_provider_lookup'})

    async def hold_external(self,connection,purchase,subject,origin,kind,facts):
        """Conservative origin-lot freeze, not a refund or adjudication command."""
        previous=await one(connection,'SELECT id FROM nt.ledger_adjustments WHERE origin_ref=%s',(origin,))
        queued=await one(connection,'SELECT id FROM nt.durable_jobs WHERE dedupe_key=%s',(origin,))
        if previous or queued:return
        from psycopg.types.json import Jsonb
        subject=await one(connection,'SELECT * FROM nt.financial_subjects WHERE id=%s',(subject['id'],))
        lots=await self.account_lots(connection,subject)
        lot=next((item for item in lots if item.purchase==str(purchase['id'])),None)
        seconds=lot.available if lot else 0
        if lot:hold(lot,seconds,'provider_bank_direction')
        if lot:await connection.execute('UPDATE nt.entitlement_lots SET available_seconds=%s,held_seconds=%s,revision=revision+1 WHERE purchase_id=%s',(lot.available,lot.held,purchase['id']))
        if lot:await connection.execute('INSERT INTO nt.ledger_adjustments(id,subject_id,lot_id,kind,seconds,origin_ref,reason) VALUES(%s,%s,%s,%s,%s,%s,%s)',(uuid4(),subject['id'],purchase['id'],kind,seconds,origin,'External provider event; held pending authorized financial review'))
        await connection.execute("UPDATE nt.purchases SET state='financial_review',payment_session_ciphertext=NULL WHERE id=%s",(purchase['id'],))
        receipt={'document_kind':'provider_financial_review','purchase_ref':purchase['public_ref'],'currency':'INR','held_seconds':seconds,'review_required':True,**facts,'observed_at':now().isoformat()}
        await connection.execute('INSERT INTO nt.receipts(public_ref,subject_id,purchase_id,facts) VALUES(%s,%s,%s,%s)',(uuid4().hex,subject['id'],purchase['id'],Jsonb(receipt)))
        await connection.execute("INSERT INTO nt.durable_jobs(id,kind,dedupe_key,object_ref,state,last_error_code) VALUES(%s,'billing_external_review',%s,%s,'review','EXTERNAL_FINANCIAL_REVIEW_REQUIRED') ON CONFLICT(dedupe_key) DO NOTHING",(uuid4(),origin,purchase['public_ref']))
        review=await one(connection,'SELECT * FROM nt.external_financial_reviews WHERE purchase_id=%s FOR UPDATE',(purchase['id'],))
        refs=list(review['event_refs']) if review and review['state']=='open' else []
        if origin not in refs:refs.append(origin)
        require(len(refs)<=128,'REVIEW_REFERENCE_LIMIT',503)
        held=(review['held_seconds'] if review and review['state']=='open' else 0)+seconds
        await connection.execute("INSERT INTO nt.external_financial_reviews(purchase_id,held_seconds,event_refs) VALUES(%s,%s,%s) ON CONFLICT(purchase_id) DO UPDATE SET state='open',held_seconds=%s,event_refs=%s,revision=nt.external_financial_reviews.revision+1,updated_at=now()",(purchase['id'],held,Jsonb(refs),held,Jsonb(refs)))

    async def enqueue_backfill(self):
        """Schedule at most one oldest checked order per worker minute, fairly."""
        if not self.provider:return
        async with self.db.transaction('jobs') as c:
            purchase=await one(c,"""SELECT p.public_ref FROM nt.purchases p LEFT JOIN nt.durable_jobs j
                ON j.dedupe_key='payment:'||p.public_ref WHERE p.environment=%s AND p.state IN ('captured','financial_review')
                AND (j.id IS NULL OR j.state='done' AND j.available_at<now()-interval '1 hour')
                ORDER BY COALESCE(j.available_at,p.created_at),p.public_ref LIMIT 1 FOR UPDATE OF p SKIP LOCKED""",(self.environment,))
            if purchase:
                await c.execute("INSERT INTO nt.durable_jobs(id,kind,dedupe_key,object_ref) VALUES(%s,'payment',%s,%s) ON CONFLICT(dedupe_key) DO UPDATE SET state='ready',available_at=now() WHERE nt.durable_jobs.state='done'",(uuid4(),'payment:'+purchase['public_ref'],purchase['public_ref']))

    async def webhook(self,body,timestamp,signature,secret):
        try:payload=verify_webhook(body,timestamp,signature,secret)
        except (ProviderRejected,ValueError,TypeError,UnicodeDecodeError):
            require(False,'WEBHOOK_INVALID',400)
        require(int(timestamp)<=int(time.time()*1000)+300000,'WEBHOOK_FUTURE_TIMESTAMP',400)
        require(isinstance(payload,dict) and isinstance(payload.get('data'),dict),'WEBHOOK_INVALID',400)
        event_type=payload.get('type','unknown')
        disputes={'DISPUTE_CREATED','DISPUTE_UPDATED','DISPUTE_CLOSED'}
        require(event_type in {'PAYMENT_SUCCESS_WEBHOOK','PAYMENT_FAILED_WEBHOOK','PAYMENT_USER_DROPPED_WEBHOOK','REFUND_STATUS_WEBHOOK'}|disputes,'WEBHOOK_TYPE',400)
        details=payload['data'].get('refund' if event_type=='REFUND_STATUS_WEBHOOK' else 'order_details' if event_type in disputes else 'order')
        require(isinstance(details,dict),'WEBHOOK_INVALID',400)
        order_ref=details.get('order_id')
        import re
        require(isinstance(order_ref,str) and re.fullmatch(r'[A-Za-z0-9_-]{3,45}',order_ref),'WEBHOOK_INVALID',400)
        dispute=payload['data'].get('dispute') if event_type in disputes else None
        if event_type in disputes:
            require(isinstance(dispute,dict) and re.fullmatch(r'[0-9]{1,40}',str(dispute.get('dispute_id',''))),'WEBHOOK_INVALID',400)
        refund_notice=details if event_type=='REFUND_STATUS_WEBHOOK' else None
        if refund_notice:
            require(re.fullmatch(r'[A-Za-z0-9_-]{1,64}',str(refund_notice.get('cf_refund_id',''))) and re.fullmatch(r'[A-Za-z0-9_-]{3,45}',str(refund_notice.get('refund_id',''))),'WEBHOOK_INVALID',400)
        digest=hashlib.sha256(body).hexdigest()
        async with self.db.transaction('jobs') as connection:
            inserted=await one(connection,'INSERT INTO nt.webhook_inbox(dedupe_digest,event_type,merchant_order_id) VALUES(%s,%s,%s) ON CONFLICT DO NOTHING RETURNING dedupe_digest',(digest,event_type,order_ref))
            if not inserted:return {'received':True}
            purchase=await one(connection,'SELECT * FROM nt.purchases WHERE merchant_order_id=%s',(order_ref,))
            if purchase:
                require(purchase['environment']==self.environment,'PAYMENT_ENVIRONMENT_MISMATCH',409)
                if dispute or refund_notice:
                    await one(connection,'SELECT * FROM nt.subject_controls WHERE financial_subject_id=%s FOR UPDATE',(purchase['financial_subject_id'],))
                    subject=await one(connection,'SELECT * FROM nt.financial_subjects WHERE id=%s FOR UPDATE',(purchase['financial_subject_id'],))
                    purchase=await one(connection,'SELECT * FROM nt.purchases WHERE id=%s FOR UPDATE',(purchase['id'],))
                    # Fresh signed financial notices fence an in-flight preview
                    # even if provider listing is briefly eventually consistent.
                    await connection.execute('UPDATE nt.financial_subjects SET ledger_revision=ledger_revision+1 WHERE id=%s',(subject['id'],))
                    # A signed event is sufficient only for a protective hold.
                    # It is never authority to send money or settle a dispute.
                    if dispute:
                        await self.hold_external(connection,purchase,subject,'external-dispute:'+self.environment+':'+str(dispute['dispute_id'])+':notice:'+digest[:16],'external_dispute_hold',
                            {'provider_dispute_id':str(dispute['dispute_id']),'provider_event':event_type,'verification':'signed_notice_pending_independent_review'})
                    if refund_notice:
                        internal=await one(connection,'SELECT public_ref FROM nt.refunds WHERE purchase_id=%s AND provider_ref=%s',(purchase['id'],str(refund_notice['refund_id'])))
                        if not internal:
                            await self.hold_external(connection,purchase,subject,'external-refund:'+self.environment+':'+str(refund_notice['cf_refund_id'])+':notice:'+digest[:16],'external_refund_hold',
                                {'provider_refund_id':str(refund_notice['cf_refund_id']),'merchant_refund_id':str(refund_notice['refund_id']),'provider_event':event_type,'verification':'signed_notice_pending_independent_review'})
                await connection.execute("INSERT INTO nt.durable_jobs(id,kind,dedupe_key,object_ref) VALUES(%s,'payment',%s,%s) ON CONFLICT(dedupe_key) DO UPDATE SET state='ready',available_at=now() WHERE nt.durable_jobs.state<>'running'",(uuid4(),'payment:'+purchase['public_ref'],purchase['public_ref']))
        if (dispute or refund_notice) and purchase:await self.publish_available(subject,None)
        return {'received':True}

    async def receipts(self,principal,reference=None,cursor=None):
        require(cursor is None or type(cursor) is int and 0<cursor<2**63,'INVALID_CURSOR',422)
        async with self.db.transaction() as connection:
            subject=await self.subject(connection,principal)
            rows=await many(connection,'''SELECT public_ref,receipt_number,facts,created_at FROM nt.receipts
                WHERE subject_id=%s AND (%s::text IS NULL OR public_ref=%s)
                AND (%s::bigint IS NULL OR receipt_number<%s) ORDER BY receipt_number DESC LIMIT 21''',(subject['id'],reference,reference,cursor,cursor))
        if reference: require(rows,'NOT_FOUND',404)
        return {'items':rows[:20],'next_cursor':rows[19]['receipt_number'] if len(rows)>20 else None}

    async def preview(self,principal,dto):
        from psycopg.types.json import Jsonb
        principal.permission('billing.remedies')
        require(now()-principal.mfa_at<timedelta(minutes=5),'FRESH_MFA_REQUIRED',401)
        async with self.db.transaction('private') as connection:
            purchase=await one(connection,'SELECT p.*,s.ledger_revision FROM nt.purchases p JOIN nt.financial_subjects s ON s.id=p.financial_subject_id WHERE p.public_ref=%s',(dto.purchase_ref,))
            require(purchase and purchase['state']=='captured','NOT_FOUND',404)
            require(dto.amount_paise<=purchase['amount_paise'],'REFUND_RANGE',422)
            preview=uuid4().hex;payload=dto.model_dump()
            await connection.execute("INSERT INTO nt.sensitive_previews(nonce,actor_id,object_ref,payload_digest,payload,revisions,expires_at) VALUES(%s,%s,%s,%s,%s,%s,now()+interval '2 minutes')",(preview,principal.account_id,dto.purchase_ref,self.security.digest('preview',canonical(payload).decode()),Jsonb(payload),Jsonb({'ledger':purchase['ledger_revision']})))
        return {'preview':preview,'expires_in':120,'payload':payload}

    async def confirm(self,principal,preview_ref):
        principal.permission('billing.remedies')
        require(now()-principal.mfa_at<timedelta(minutes=5),'FRESH_MFA_REQUIRED',401)
        async with self.db.transaction('private') as connection:
            preview=await one(connection,'SELECT * FROM nt.sensitive_previews WHERE nonce=%s',(preview_ref,))
            require(preview and preview['actor_id']==principal.account_id and preview['expires_at']>now(),'PREVIEW_EXPIRED')
            purchase=await one(connection,'SELECT * FROM nt.purchases WHERE public_ref=%s',(preview['object_ref'],))
            await one(connection,'SELECT * FROM nt.subject_controls WHERE financial_subject_id=%s FOR UPDATE',(purchase['financial_subject_id'],))
            subject=await one(connection,'SELECT * FROM nt.financial_subjects WHERE id=%s FOR UPDATE',(purchase['financial_subject_id'],))
            purchase=await one(connection,'SELECT * FROM nt.purchases WHERE id=%s FOR UPDATE',(purchase['id'],))
            preview=await one(connection,'SELECT * FROM nt.sensitive_previews WHERE nonce=%s FOR UPDATE',(preview_ref,))
            require(not preview['consumed_at'] and subject['ledger_revision']==preview['revisions']['ledger'],'PREVIEW_STALE')
            dto=preview['payload']
            require(self.security.verify('preview',canonical(dto).decode(),preview['payload_digest']),'PREVIEW_INVALID')
            lots=await self.account_lots(connection,subject)
            lot=next((l for l in lots if l.purchase==str(purchase['id'])),None)
            require(lot,'LOT_NOT_FOUND')
            reserved=await one(connection,"SELECT COALESCE(sum(amount_paise),0) AS amount FROM nt.refunds WHERE purchase_id=%s AND state NOT IN ('failed','cancelled')",(purchase['id'],))
            require(reserved['amount']+dto['amount_paise']<=purchase['amount_paise'],'REFUND_RANGE')
            hold(lot,dto['seconds'],dto['remedy_basis'])
            await connection.execute('UPDATE nt.entitlement_lots SET available_seconds=%s,held_seconds=%s,revision=revision+1 WHERE purchase_id=%s',(lot.available,lot.held,purchase['id']))
            refund_id,ref=uuid4(),uuid4().hex
            await connection.execute("INSERT INTO nt.refunds(id,public_ref,purchase_id,origin_lot,amount_paise,held_seconds,state,remedy_basis,evidence_ref,decision_reason,preview_nonce,provider_ref,idempotency_key) VALUES(%s,%s,%s,%s,%s,%s,'held',%s,%s,%s,%s,%s,%s)",(refund_id,ref,purchase['id'],purchase['id'],dto['amount_paise'],dto['seconds'],dto['remedy_basis'],dto['evidence_ref'],dto['reason'],preview_ref,'nr_'+ref,uuid4()))
            await connection.execute('UPDATE nt.sensitive_previews SET consumed_at=now() WHERE nonce=%s',(preview_ref,))
            await connection.execute("INSERT INTO nt.durable_jobs(id,kind,dedupe_key,object_ref) VALUES(%s,'refund',%s,%s)",(uuid4(),'refund:'+ref,ref))
        await self.publish_available(subject, sum(item.available for item in lots))
        return {'refund_ref':ref,'state':'held'}

    async def refund(self,ref):
        from psycopg.types.json import Jsonb
        require(self.provider,'PAYMENTS_UNAVAILABLE',503)
        async with self.db.transaction('jobs') as connection:
            refund=await one(connection,'SELECT r.*,p.merchant_order_id,p.financial_subject_id,p.public_ref AS purchase_ref FROM nt.refunds r JOIN nt.purchases p ON p.id=r.purchase_id WHERE r.public_ref=%s',(ref,))
            require(refund,'NOT_FOUND',404)
            if refund['state'] in {'succeeded','failed','cancelled'}: return
            if refund['state']=='held':
                await connection.execute("UPDATE nt.refunds SET state='submitting' WHERE id=%s",(refund['id'],))
        if refund['state']=='held':
            basis={'payment_error':'verified_payment_error','statutory_remedy':'statutory','provider_bank_direction':'binding_provider_decision'}[refund['remedy_basis']]
            await self.provider.create_required_refund(refund['merchant_order_id'],refund['provider_ref'],refund['amount_paise'],basis,refund['idempotency_key'])
        result=await self.provider.fetch_refund(refund['merchant_order_id'],refund['provider_ref'])
        require(result.get('refund_id')==refund['provider_ref'],'REFUND_REFERENCE_MISMATCH')
        from decimal import Decimal
        require(Decimal(str(result.get('refund_amount','-1')))*100==refund['amount_paise'],'REFUND_AMOUNT_MISMATCH')
        status=result.get('refund_status')
        state={'SUCCESS':'succeeded','PENDING':'pending','PENDING_APPROVAL':'pending','ONHOLD':'pending','CANCELLED':'cancelled','REJECTED':'failed'}.get(status,'needs_review')
        async with self.db.transaction('jobs') as connection:
            await one(connection,'SELECT * FROM nt.subject_controls WHERE financial_subject_id=%s FOR UPDATE',(refund['financial_subject_id'],))
            subject=await one(connection,'SELECT * FROM nt.financial_subjects WHERE id=%s FOR UPDATE',(refund['financial_subject_id'],))
            await one(connection,'SELECT * FROM nt.purchases WHERE id=%s FOR UPDATE',(refund['purchase_id'],))
            lots=await self.account_lots(connection,subject)
            current=await one(connection,'SELECT * FROM nt.refunds WHERE id=%s FOR UPDATE',(refund['id'],))
            if current['state'] in {'succeeded','failed','cancelled'}: return
            if state in {'succeeded','failed','cancelled'}:
                lot=next(l for l in lots if l.purchase==str(refund['origin_lot']))
                settle(lot,refund['held_seconds'],state=='succeeded')
                await connection.execute('UPDATE nt.entitlement_lots SET available_seconds=%s,held_seconds=%s,revoked_seconds=%s,revision=revision+1 WHERE purchase_id=%s',(lot.available,lot.held,lot.revoked,refund['origin_lot']))
                await connection.execute('INSERT INTO nt.ledger_adjustments(id,subject_id,lot_id,kind,seconds,origin_ref,reason) VALUES(%s,%s,%s,%s,%s,%s,%s)',(uuid4(),subject['id'],refund['origin_lot'],state,refund['held_seconds'],ref,refund['remedy_basis']))
                facts={'document_kind':'required_remedy_outcome','purchase_ref':refund['purchase_ref'],'refund_ref':ref,'outcome':state,'requested_paise':refund['amount_paise'],'settled_paise':refund['amount_paise'] if state=='succeeded' else 0,'currency':'INR','remedy_basis':refund['remedy_basis'],'verified_at':now().isoformat()}
                await connection.execute('INSERT INTO nt.receipts(public_ref,subject_id,purchase_id,refund_id,facts) VALUES(%s,%s,%s,%s,%s)',(uuid4().hex,subject['id'],refund['purchase_id'],refund['id'],Jsonb(facts)))
            await connection.execute('UPDATE nt.refunds SET state=%s,verified_at=now() WHERE id=%s',(state,refund['id']))
        await self.publish_available(subject,sum(item.available for item in lots))
        require(state in {'succeeded','failed','cancelled'},'REFUND_PENDING')

    async def publish_available(self,subject,seconds):
        if not subject['account_id']:return
        async with self.db.transaction('jobs') as connection:
            account=await one(connection,'SELECT public_ref FROM nt.accounts WHERE id=%s',(subject['account_id'],))
        person=self.identity.realtime.people.get(account['public_ref']) if account else None
        if person:
            from types import SimpleNamespace
            projection=await self.matching_entitlement(SimpleNamespace(kind='account',account_id=subject['account_id']))
            person.premium_until=projection['premium_until']
            waiter=self.identity.realtime.waiters.get(account['public_ref'])
            if person.premium_until<=self.identity.realtime.wall() and waiter and waiter.gender!='everyone' and hasattr(self.identity.realtime,'pause_preferences'):
                self.identity.realtime.pause_preferences(account['public_ref'])
