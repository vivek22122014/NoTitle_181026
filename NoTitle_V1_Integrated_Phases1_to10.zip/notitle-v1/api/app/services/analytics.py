import hashlib
import json
from datetime import timedelta
from uuid import uuid4
from app.domain.errors import require
from app.domain.metrics import IDS, HISTOGRAMS, NAMES, BINS, suppress
from app.repositories.database import one, many
from .identity import now


class Analytics:
    def __init__(self,db,metrics,realtime):
        self.db,self.metrics,self.realtime=db,metrics,realtime
        self.pending=None
        self.cache={}
        self.complete=True
        self.started_at=now()

    async def flush(self):
        # Retain one bounded batch on failure; retries use exactly its original digest.
        if not self.pending:
            self.pending=(uuid4(),now().replace(second=0,microsecond=0),self.metrics.drain())
        import copy
        batch_id,bucket,pending_values=self.pending
        values=copy.deepcopy(pending_values)
        digest=hashlib.sha256(json.dumps(values,sort_keys=True).encode()).hexdigest()
        async with self.db.transaction('jobs') as connection:
            await connection.execute("SET LOCAL TIME ZONE 'UTC'")
            existing=await one(connection,'SELECT digest FROM nt.aggregate_batches WHERE id=%s',(batch_id,))
            if existing:
                require(existing['digest']==digest,'BATCH_CONFLICT')
            else:
                await connection.execute('INSERT INTO nt.aggregate_batches(id,digest) VALUES(%s,%s)',(batch_id,digest))
                exact=await many(connection,"SELECT * FROM nt.outbox WHERE kind='metric' AND processed_at IS NULL ORDER BY created_at LIMIT 1000 FOR UPDATE SKIP LOCKED")
                contributions={}
                current=now()
                def include(timestamp,metric,value):
                    resolution=retained_resolution(timestamp,current)
                    if resolution is None:
                        metric=IDS['metric_samples_dropped'];value=[1,1,[0]*13];resolution='minute';timestamp=current
                    key=(resolution,truncate_bucket(timestamp,resolution))
                    item=contributions.setdefault(key,{}).setdefault(metric,[0,0,[0]*13])
                    item[0]+=value[0];item[1]+=value[1]
                    item[2]=[a+b for a,b in zip(item[2],value[2])]
                for metric,value in values.items():include(bucket,metric,value)
                for row in exact:
                    include(row['created_at'],row['metric_id'],[1,1,[0]*13])
                    await connection.execute('UPDATE nt.outbox SET processed_at=now() WHERE id=%s',(row['id'],))
                for (resolution,event_bucket),metrics in contributions.items():
                    for metric,(count,total,bins) in metrics.items():
                        await connection.execute('''INSERT INTO nt.aggregate_buckets(resolution,bucket,metric_id,sample_count,total,bins,complete)
                            VALUES(%s,%s,%s,%s,%s,%s,%s) ON CONFLICT(resolution,bucket,metric_id) DO UPDATE SET
                            sample_count=nt.aggregate_buckets.sample_count+EXCLUDED.sample_count,
                            total=nt.aggregate_buckets.total+EXCLUDED.total,
                            bins=ARRAY(SELECT a+b FROM unnest(nt.aggregate_buckets.bins,EXCLUDED.bins) AS x(a,b)),
                            complete=nt.aggregate_buckets.complete AND EXCLUDED.complete''',(resolution,event_bucket,metric,count,total,bins,self.complete))
                        # Late exact events amend already-materialized coarser buckets too.
                        # A later deterministic rollup then replaces them from full retained sources.
                        for target in ('hour','day','month')[('minute','hour','day','month').index(resolution):]:
                            await connection.execute('''UPDATE nt.aggregate_buckets SET sample_count=sample_count+%s,total=total+%s,
                                bins=ARRAY(SELECT a+b FROM unnest(bins,%s::bigint[]) AS x(a,b)),complete=complete AND %s
                                WHERE resolution=%s AND bucket=%s AND metric_id=%s''',
                                (count,total,bins,self.complete,target,truncate_bucket(event_bucket,target),metric))
        self.pending=None

    async def rollup(self):
        # Recompute each closed target bucket from complete, still-retained finer data.
        # The upsert replaces totals; it never adds the same source twice.
        async with self.db.transaction('jobs') as connection:
            await connection.execute("SET LOCAL TIME ZONE 'UTC'")
            for source,target,age in [('minute','hour',7),('hour','day',30),('day','month',90)]:
                rows=await many(connection,'''SELECT DISTINCT date_trunc(%s,bucket) AS bucket FROM nt.aggregate_buckets
                    WHERE resolution=%s AND bucket<date_trunc(%s,now()) AND bucket>=date_trunc(%s,now()-(%s*interval '1 day'))
                    ORDER BY bucket LIMIT 1000''',(target,source,target,target,age))
                for item in rows:
                    # One bounded SQL statement handles all 26 metrics in this bucket.
                    # Avoid a separate round trip for every histogram and metric.
                    await connection.execute('''WITH source AS MATERIALIZED (
                        SELECT metric_id,sample_count,total,bins,complete FROM nt.aggregate_buckets
                        WHERE resolution=%s AND date_trunc(%s,bucket)=%s),
                        totals AS (SELECT metric_id,sum(sample_count)::bigint n,sum(total) total,bool_and(complete) complete
                            FROM source GROUP BY metric_id),
                        histogram AS (SELECT metric_id,array_agg(n ORDER BY i)::bigint[] bins FROM
                            (SELECT metric_id,i,sum(bins[i])::bigint n FROM source,generate_series(1,13) i GROUP BY metric_id,i) h GROUP BY metric_id)
                        INSERT INTO nt.aggregate_buckets(resolution,bucket,metric_id,sample_count,total,bins,complete)
                        SELECT %s,%s,t.metric_id,t.n,t.total,h.bins,t.complete FROM totals t JOIN histogram h USING(metric_id)
                        ON CONFLICT(resolution,bucket,metric_id) DO UPDATE SET sample_count=EXCLUDED.sample_count,
                        total=EXCLUDED.total,bins=EXCLUDED.bins,complete=EXCLUDED.complete''',
                        (source,target,item['bucket'],target,item['bucket']))
                    await connection.execute('INSERT INTO nt.aggregate_rollups(resolution,bucket) VALUES(%s,%s) ON CONFLICT DO NOTHING',(target,item['bucket']))
                await connection.execute('''DELETE FROM nt.aggregate_buckets b WHERE resolution=%s AND bucket<date_trunc(%s,now()-(%s*interval '1 day'))
                    AND EXISTS(SELECT 1 FROM nt.aggregate_rollups r WHERE r.resolution=%s AND r.bucket=date_trunc(%s,b.bucket))''',(source,target,age,target,target))
            await connection.execute("DELETE FROM nt.aggregate_buckets WHERE resolution='month' AND bucket<date_trunc('month',now())-interval '12 months'")
            await connection.execute("DELETE FROM nt.aggregate_batches WHERE created_at<now()-interval '7 days'")
            await connection.execute("DELETE FROM nt.aggregate_rollups WHERE bucket<date_trunc('month',now())-interval '13 months'")
            size=await one(connection,"SELECT pg_total_relation_size('nt.aggregate_buckets') AS size")
            require(size['size']<200*1024*1024,'ANALYTICS_STORAGE_BUDGET',503)

    async def summary(self,principal):
        principal.permission('analytics.read')
        key='summary';cached=self.cache.get(key)
        if cached and (now()-cached[0]).total_seconds()<60: return cached[1]
        async with self.db.transaction('analytics') as connection:
            await connection.execute("SET LOCAL statement_timeout='500ms'")
            await connection.execute("SET LOCAL TIME ZONE 'UTC'")
            counts=await one(connection,'SELECT current_accounts,open_cases,total_accounts FROM nt.analytics_operational')
            rows=await many(connection,"SELECT metric_id,sum(sample_count)::bigint AS samples,sum(total) AS total,bool_and(complete) AS complete FROM nt.aggregate_buckets WHERE resolution='minute' AND bucket>=now()-interval '24 hours' GROUP BY metric_id")
        active=sum(p.connected and (self.realtime.clock()-p.last_action<300 or p.interaction is not None) for p in self.realtime.people.values())
        result={'current_accounts':counts['current_accounts'],'total_accounts':counts['total_accounts'],
                'total_accounts_definition':'Retained registered accounts with active or restricted status; excludes guests and deleting/deleted accounts.',
                'current_accounts_definition':'Retained registered accounts with active account status; this is not a recent-activity metric.',
                'open_cases':counts['open_cases'],'active_now':active,
                'active_definition':'Admitted identities active within five minutes or in a live interaction; includes guests.',
                'series':summary_metrics(rows),
                'as_of':now().isoformat(),'complete':self.complete,
                'collection_started_at':self.started_at.isoformat(),
                'window_hours':24,'timezone':'UTC',
                'history_note':'RAM counters are best effort; process loss can create gaps. Registration and support counters use the durable outbox. No daily unique user tracking is collected.',
                'retention':{'minute_days':7,'hour_days':30,'day_days':90,'month_months':12,'raw_activity_logs':False}}
        self.cache[key]=(now(),result)
        return result

    async def series(self,principal,metric,start,end,resolution):
        principal.permission('analytics.read')
        require(metric in IDS.values() and resolution in {'hour','day'} and start.tzinfo and end.tzinfo and start<end<=now(), 'QUERY_INVALID',422)
        require(end-start<=timedelta(days=31 if resolution=='hour' else 90),'RANGE_LIMIT',422)
        async with self.db.transaction('analytics') as connection:
            await connection.execute("SET LOCAL statement_timeout='500ms'")
            await connection.execute("SET LOCAL TIME ZONE 'UTC'")
            rows=await many(connection,'SELECT bucket,sample_count,total,bins,complete FROM nt.aggregate_buckets WHERE resolution=%s AND metric_id=%s AND bucket>=%s AND bucket<%s ORDER BY bucket LIMIT 2000',(resolution,metric,start,end))
        result=[]
        for row in rows:
            cohort=row['sample_count'] if metric in HISTOGRAMS else row['total']
            count=suppress(cohort)
            result.append({'bucket':row['bucket'],'count':count,'complete':row['complete'],
                           'mean':None if count['suppressed'] or metric not in HISTOGRAMS or not row['sample_count'] else float(row['total'])/row['sample_count'],
                           'p95_upper_ms':None if count['suppressed'] or metric not in HISTOGRAMS else percentile_bound(row['bins'],.95),
                           'total':None if count['suppressed'] else row['total'],
                           'bins':None if count['suppressed'] else row['bins']})
        return {'items':result,'metric':metric_definition(metric),'timezone':'UTC','resolution':resolution}


def metric_definition(metric):
    require(type(metric) is int and metric in IDS.values(),'QUERY_INVALID',422)
    name=NAMES[metric-1]
    return {'metric_id':metric,'name':name,'kind':'histogram' if metric in HISTOGRAMS else 'counter',
            'unit':'milliseconds' if metric in HISTOGRAMS else ('seconds' if name.endswith('_seconds') else 'events')}

def percentile_bound(bins,quantile):
    """Histogram upper bound, never a fabricated exact percentile or infinity in JSON."""
    if not bins or not sum(bins):return None
    target=sum(bins)*quantile;seen=0
    for count,bound in zip(bins,BINS):
        seen+=count
        if seen>=target:return '>30000' if bound==float('inf') else bound
    return None

def summary_metrics(rows):
    indexed={row['metric_id']:row for row in rows}
    result=[]
    for metric in IDS.values():
        row=indexed.get(metric);definition=metric_definition(metric)
        total=0 if row is None else row['total'];samples=0 if row is None else row['samples']
        count=suppress(samples if metric in HISTOGRAMS else total)
        result.append(definition|{'count':count,'complete':row is not None and row['complete'],
             'mean':None if metric not in HISTOGRAMS or not samples or count['suppressed'] else float(total)/samples,
             'observed':row is not None})
    return result


def truncate_bucket(timestamp,resolution):
    from datetime import timezone
    timestamp=timestamp.astimezone(timezone.utc)
    if resolution=='month':return timestamp.replace(day=1,hour=0,minute=0,second=0,microsecond=0)
    if resolution=='day':return timestamp.replace(hour=0,minute=0,second=0,microsecond=0)
    if resolution=='hour':return timestamp.replace(minute=0,second=0,microsecond=0)
    return timestamp.replace(second=0,microsecond=0)

def retained_resolution(timestamp,current):
    """Route delayed exact events into complete retained sources, never partial history."""
    for resolution,target,days in [('minute','hour',7),('hour','day',30),('day','month',90)]:
        if timestamp>=truncate_bucket(current-timedelta(days=days),target):return resolution
    cutoff=truncate_bucket(current,'month')
    cutoff=cutoff.replace(year=cutoff.year-1)
    return 'month' if timestamp>=cutoff else None
