"""Owner-only profile, consent and session mutations with explicit revisions."""
from uuid import UUID,uuid4
from app.domain.errors import require
from app.repositories.database import one,many
from .identity import now

class AccountControls:
    def __init__(self,identity,catalogs):self.identity,self.db,self.rt,self.catalogs=identity,identity.db,identity.realtime,catalogs

    async def current_policy(self,connection,account_id):
        rows=await many(connection,"""SELECT DISTINCT ON(purpose) purpose,choice,publication_digest,proof_format
            FROM nt.consent_records WHERE account_id=%s AND purpose IN ('adult','terms') ORDER BY purpose,decision_revision DESC NULLS LAST,recorded_at DESC,id DESC""",(account_id,))
        return len(rows)==2 and all(r['choice'] and r['proof_format']==2 and r['publication_digest']==self.identity.policy_digest for r in rows)

    def fence_choices(self,ref,core=False):
        if not core and hasattr(self.rt,'pause_preferences'):
            self.rt.pause_preferences(ref)
            for key in [k for k,v in self.identity.tickets.items() if v['ref']==ref]:self.identity.tickets.pop(key,None)
            return
        self.rt.waiters.pop(ref,None)
        for key in [k for k,v in self.identity.tickets.items() if v['ref']==ref]:self.identity.tickets.pop(key,None)
        if core:
            self.identity.participation_fences.add(ref);self.identity.fence(ref,'consent_withdrawn')
        elif ref in self.rt.people:
            self.rt.people[ref].revision+=1
            self.rt.emit(ref,'queue.paused',{'reason':'preferences_changed'})

    async def consent(self,principal,dto):
        policy=self.identity.policy;policy.validate(dto,withdrawal=True)
        purpose=policy.purposes[dto.purpose]
        expected=purpose['text_digest'] if dto.choice else purpose['withdrawal_digest']
        label=purpose['label'] if dto.choice else purpose['withdrawal_label']
        require(dto.text_digest==expected,'CONSENT_TEXT_CHANGED',409)
        self.identity.limiter.take(('consent',principal.ref),10,60)
        if principal.kind=='guest':return self.guest_consent(principal,dto,label,expected)
        require(principal.kind=='account','ACCOUNT_REQUIRED',401)
        payload=self.identity.request_digest('consent',dto)
        async with self.db.transaction() as connection:
            row=await self.identity.lock_account(connection,principal)
            previous=await self.identity.previous(connection,principal.ref,'consent',dto.client_nonce,payload)
            if previous:return previous
            require(dto.expected_revision==row['consent_revision'],'REVISION_CONFLICT',409)
            if dto.purpose=='core' and dto.choice:require(await self.current_policy(connection,principal.account_id),'POLICY_ACCEPTANCE_REQUIRED',409)
            self.fence_choices(principal.ref,core=dto.purpose=='core' and not dto.choice)
            if dto.purpose=='professional':
                await connection.execute("""UPDATE nt.accounts SET professional_consent=%s,consent_revision=consent_revision+1,
                  preference_revision=preference_revision+1,professional=CASE WHEN %s THEN professional ELSE '{}'::jsonb END,
                  preferences=CASE WHEN %s THEN preferences ELSE preferences || '{"professional_enabled":false,"industry":[],"role":[],"experience":[],"interests":[],"topics":[]}'::jsonb END WHERE id=%s""",(dto.choice,dto.choice,dto.choice,principal.account_id))
            else:await connection.execute('UPDATE nt.accounts SET core_consent=%s,consent_revision=consent_revision+1 WHERE id=%s',(dto.choice,principal.account_id))
            await connection.execute("""INSERT INTO nt.consent_records(id,account_id,retained_subject_ref,purpose,choice,policy_version,text_digest,publication_digest,proof_format,decision_text,decision_revision)
              VALUES(%s,%s,%s,%s,%s,%s,%s,%s,2,%s,%s)""",(uuid4(),principal.account_id,principal.ref,dto.purpose,dto.choice,policy.version,expected,policy.publication_digest,label,row['consent_revision']+1))
            result={'saved':True,'purpose':dto.purpose,'choice':dto.choice,'consent_revision':row['consent_revision']+1}
            await self.identity.save_operation(connection,principal.ref,'consent',dto.client_nonce,payload,result)
        if dto.purpose=='core' and dto.choice:self.identity.participation_fences.discard(principal.ref)
        person=self.rt.people.get(principal.ref)
        if person:
            person.profile[dto.purpose+'_consent']=dto.choice
            if dto.purpose=='professional' and not dto.choice:person.profile['professional']={};person.profile['preferences']={}
        return result

    async def accept_policy(self,principal,dto):
        self.identity.policy.validate(dto);require(dto.adult and dto.terms,'CURRENT_CONSENTS_REQUIRED',422)
        payload=self.identity.request_digest('policy_acceptance',dto)
        async with self.db.transaction() as connection:
            row=await self.identity.lock_account(connection,principal)
            previous=await self.identity.previous(connection,principal.ref,'policy_acceptance',dto.client_nonce,payload)
            if previous:return previous
            require(row['consent_revision']==dto.expected_revision,'REVISION_CONFLICT',409)
            self.fence_choices(principal.ref,core=not dto.core)
            await connection.execute("""UPDATE nt.accounts SET core_consent=%s,professional_consent=%s,consent_revision=consent_revision+1,
                preference_revision=preference_revision+1,professional=CASE WHEN %s THEN professional ELSE '{}'::jsonb END,
                preferences=CASE WHEN %s THEN preferences ELSE preferences || '{"professional_enabled":false,"industry":[],"role":[],"experience":[],"interests":[],"topics":[]}'::jsonb END WHERE id=%s""",(dto.core,dto.professional,dto.professional,dto.professional,principal.account_id))
            await self.identity.record_consents(connection,principal.account_id,principal.ref,{p:getattr(dto,p) for p in self.identity.policy.purposes},row['consent_revision']+1)
            result={'saved':True,'consent_revision':row['consent_revision']+1}
            await self.identity.save_operation(connection,principal.ref,'policy_acceptance',dto.client_nonce,payload,result)
        if dto.core:self.identity.participation_fences.discard(principal.ref)
        person=self.rt.people.get(principal.ref)
        if person:
            person.profile.update(core_consent=dto.core,professional_consent=dto.professional)
            if not dto.professional:person.profile.update(professional={},preferences={})
        return result

    def guest_consent(self,principal,dto,label,text_digest):
        guest=self.identity.guests.get(self.identity.security.digest('guest',principal.token))
        require(guest,'SESSION_EXPIRED',401);profile=guest['profile']
        operations=guest.setdefault('operations',{});payload=self.identity.request_digest('consent',dto)
        previous=operations.get(dto.client_nonce)
        if previous:
            require(previous[0]==payload,'NONCE_CONFLICT',409)
            return previous[1]
        require(profile['consent_revision']==dto.expected_revision,'REVISION_CONFLICT',409)
        require(len(operations)<128 or not dto.choice and profile[dto.purpose+'_consent'],'CONSENT_CAPACITY',429)
        if profile[dto.purpose+'_consent']==dto.choice:
            result={'saved':True,'consent_revision':profile['consent_revision'],'choice':dto.choice,'purpose':dto.purpose}
            operations[dto.client_nonce]=(payload,result)
            return result
        require(not dto.choice or len(guest['proof'])<128,'CONSENT_CAPACITY',429)
        self.fence_choices(principal.ref,core=dto.purpose=='core' and not dto.choice)
        if dto.purpose=='core' and dto.choice:self.identity.participation_fences.discard(principal.ref)
        profile[dto.purpose+'_consent']=dto.choice;profile['consent_revision']+=1
        if dto.purpose=='professional' and not dto.choice:profile['professional']={};profile['preferences']={};profile['preference_revision']+=1
        person=self.rt.people.get(principal.ref)
        if person:
            person.profile[dto.purpose+'_consent']=dto.choice
            if dto.purpose=='professional' and not dto.choice:person.profile.update(professional={},preferences={})
        guest['proof'].append({'purpose':dto.purpose,'choice':dto.choice,'decision_text':label,'text_digest':text_digest,
                               'policy_version':self.identity.policy_version,'publication_digest':self.identity.policy_digest,'proof_format':2,'decision_revision':profile['consent_revision'],'recorded_at':now().isoformat()})
        result={'saved':True,'consent_revision':profile['consent_revision'],'choice':dto.choice,'purpose':dto.purpose}
        operations[dto.client_nonce]=(payload,result)
        return result

    async def proof(self,principal):
        if principal.kind=='guest':
            guest=self.identity.guests.get(self.identity.security.digest('guest',principal.token));require(guest,'SESSION_EXPIRED',401)
            return {'identity_kind':'guest','temporary':True,'items':guest['proof']}
        require(principal.kind=='account','ACCOUNT_REQUIRED',401)
        async with self.db.transaction() as connection:
            await self.identity.lock_account(connection,principal)
            rows=await many(connection,"SELECT purpose,choice,policy_version,text_digest,publication_digest,proof_format,decision_text,decision_revision,recorded_at FROM nt.consent_records WHERE account_id=%s ORDER BY decision_revision NULLS FIRST,recorded_at,id LIMIT 500",(principal.account_id,))
        return {'identity_kind':'account','temporary':False,'items':rows,'bounded_to':500}

    async def profile(self,principal,dto):
        require(principal.kind in ('guest','account'),'ACCOUNT_REQUIRED',401)
        values=dto.model_dump(exclude={'expected_revision'})
        if principal.kind=='guest':
            guest=self.identity.guests.get(self.identity.security.digest('guest',principal.token));require(guest,'SESSION_EXPIRED',401)
            require(guest['profile']['profile_revision']==dto.expected_revision,'REVISION_CONFLICT',409)
            require(values['display_name']==guest['profile']['display_name'],'GUEST_NAME_FIXED',422)
            guest['profile'].update(values);guest['profile']['profile_revision']+=1
        else:
            async with self.db.transaction() as connection:
                row=await self.identity.lock_account(connection,principal)
                require(row['profile_revision']==dto.expected_revision,'REVISION_CONFLICT',409)
                await connection.execute('UPDATE nt.accounts SET display_name=%s,gender=%s,topic_id=%s,bio=%s,profile_revision=profile_revision+1 WHERE id=%s',
                                         (dto.display_name,dto.gender,dto.topic_id,dto.bio,principal.account_id))
        self.fence_choices(principal.ref)
        person=self.rt.people.get(principal.ref)
        if person:
            if person.interaction:person.pending_profile=values
            else:person.profile.update(values)
        return {'profile':values,'profile_revision':dto.expected_revision+1}

    async def preferences(self,principal,dto):
        require(principal.kind in {'account','guest'},'ACCOUNT_REQUIRED',401)
        keys=('industry','role','experience','interests','topics')
        for key in keys:require(all(v in self.catalogs[key] for v in getattr(dto,key)) and len(getattr(dto,key))==len(set(getattr(dto,key))),'CATALOG_VALUE_INVALID',422)
        if principal.kind=='guest':
            guest=self.identity.guests.get(self.identity.security.digest('guest',principal.token));require(guest,'SESSION_EXPIRED',401)
            row=guest['profile'];require(row['preference_revision']==dto.expected_revision,'REVISION_CONFLICT',409)
            require(dto.gender=='everyone','PREMIUM_REQUIRED',403)
            require(row['professional_consent'] or not dto.professional_enabled and not any(getattr(dto,key) for key in keys),'PROFESSIONAL_CONSENT_REQUIRED',422)
            values=dto.model_dump(exclude={'expected_revision'});professional={key:getattr(dto,key) for key in keys} if row['professional_consent'] else {}
            self.fence_choices(principal.ref);row['preferences']=values;row['professional']=professional;row['preference_revision']+=1
            person=self.rt.people.get(principal.ref)
            if person:person.profile['professional']=professional
            return {'saved':values,'preference_revision':row['preference_revision'],'scope':'current_identity'}
        from psycopg.types.json import Jsonb
        async with self.db.transaction() as connection:
            row=await self.identity.lock_account(connection,principal)
            require(row['preference_revision']==dto.expected_revision,'REVISION_CONFLICT',409)
            require(row['professional_consent'] or not dto.professional_enabled and not any(getattr(dto,key) for key in keys),'PROFESSIONAL_CONSENT_REQUIRED',422)
            values=dto.model_dump(exclude={'expected_revision'});professional={k:getattr(dto,k) for k in keys} if row['professional_consent'] else {}
            self.fence_choices(principal.ref)
            await connection.execute('UPDATE nt.accounts SET preferences=%s,professional=%s,preference_revision=preference_revision+1 WHERE id=%s',(Jsonb(values),Jsonb(professional),principal.account_id))
        person=self.rt.people.get(principal.ref)
        if person:person.profile['professional']=professional
        return {'saved':values,'preference_revision':dto.expected_revision+1}

    async def sessions(self,principal):
        require(principal.kind=='account','ACCOUNT_REQUIRED',401)
        async with self.db.transaction() as connection:
            await self.identity.lock_account(connection,principal)
            rows=await many(connection,"SELECT id,created_at,last_active,expires_at FROM nt.account_sessions WHERE account_id=%s AND revoked_at IS NULL AND expires_at>now() AND absolute_expires>now() ORDER BY created_at",(principal.account_id,))
        return {'items':rows,'current_session':str(principal.session_id)}

    async def revoke(self,principal,ref):
        async with self.db.transaction() as connection:
            await self.identity.lock_account(connection,principal,fresh=True)
            row=await one(connection,'UPDATE nt.account_sessions SET revoked_at=COALESCE(revoked_at,now()) WHERE account_id=%s AND id=%s RETURNING id',(principal.account_id,UUID(ref)))
            require(row,'NOT_FOUND',404)
        self.identity.fence(principal.ref,'session_revoked')
        return {'revoked':True,'current':str(principal.session_id)==ref}
