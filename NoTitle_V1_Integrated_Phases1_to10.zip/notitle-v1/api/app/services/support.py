from datetime import timedelta
import asyncio
from contextlib import asynccontextmanager
from uuid import UUID, uuid4
from app.domain.errors import require
from app.domain.security import canonical, safe_staff_reply
from app.repositories.database import one, many
from .identity import now
from app.domain.legal import LegalRules


class Support:
    def __init__(self,db,security,identity):
        self.db,self.security,self.identity=db,security,identity
        self.writes={};self.normal=0;self.urgent=0;self.legal=LegalRules()

    @asynccontextmanager
    async def capacity(self,principal,urgent=False):
        pool='urgent' if urgent else 'normal'
        require(self.writes.get(principal.ref,0)<2 and getattr(self,pool)<8,'SUPPORT_BUSY',429)
        self.writes[principal.ref]=self.writes.get(principal.ref,0)+1
        setattr(self,pool,getattr(self,pool)+1)
        try:yield
        finally:
            self.writes[principal.ref]-=1
            if not self.writes[principal.ref]:del self.writes[principal.ref]
            setattr(self,pool,getattr(self,pool)-1)

    def digest(self,body):
        return self.security.digest('payload',canonical(body).decode())

    async def lock_account_authority(self,connection,principal):
        if principal.kind!='account':return
        authorized=await one(connection,'SELECT nt.lock_case_account(%s,%s,%s) AS authorized',
            (principal.account_id,self.security.digest('account_session',principal.token),principal.account['auth_generation']))
        require(authorized and authorized['authorized'] and principal.ref not in self.identity.fenced_subjects,'AUTHENTICATION_REQUIRED',401)

    async def lock_staff_authority(self,connection,principal):
        if principal.kind!='staff':return
        row=await one(connection,"""SELECT s.staff_id FROM nt.staff_sessions s
            JOIN nt.staff_accounts a ON a.id=s.staff_id AND a.role_version=s.role_version
            WHERE s.token_hmac=%s AND s.key_version=%s AND a.status='active'
              AND s.expires_at>now() AND s.absolute_expires>now() FOR SHARE OF a,s""",
            (self.security.digest('staff_session',principal.token),self.security.key_version))
        require(row and row['staff_id']==principal.account_id,'AUTHENTICATION_REQUIRED',401)
        grants=await many(connection,'SELECT permission FROM nt.staff_roles WHERE staff_id=%s',(principal.account_id,))
        require(principal.grants<=frozenset(item['permission'] for item in grants),'AUTHENTICATION_REQUIRED',401)

    def prepare_report(self,principal,peer_handle=None,interaction_handle=None,block=False):
        """Freeze the bounded ring before End; public projections never expose account refs."""
        rt=self.identity.realtime;person=rt.person(principal.ref)
        interaction=rt.interactions.get(person.interaction)
        if interaction and (interaction_handle is None or interaction.id==interaction_handle):
            other=interaction.right if interaction.left==principal.ref else interaction.left
            if peer_handle is not None:require(rt.resolve_peer(principal.ref,peer_handle)==other,'NOT_FOUND',404)
            prepared=rt.prepare_report(principal.ref);reference=prepared['snapshot_ref']
        else:
            require(peer_handle and interaction_handle,'NOT_FOUND',404)
            other=rt.resolve_peer(principal.ref,peer_handle)
            ended=rt.ended.get(interaction_handle)
            require(ended and principal.ref in ended[:2] and other in ended[:2] and ended[2]>rt.clock(),'NOT_FOUND',404)
            existing=[key for key,value in rt.snapshots.items() if value['identity']==principal.ref]
            for key in existing:del rt.snapshots[key]
            reference=uuid4().hex
            rt.snapshots[reference]={'identity':principal.ref,'other':other,'interaction':interaction_handle,
                'until':rt.clock()+120,'bytes':0,'messages':[],'attribution_only':True}
        snapshot=rt.snapshots[reference]
        # Synchronous safety change precedes all database work and receipt preparation.
        if block:rt.block(principal.ref,other,reference)
        return {'snapshot_ref':reference,'expires_in':120,'attribution_only':bool(snapshot.get('attribution_only')),
            'locally_blocked':block,'messages':[{'id':item['id'],'sender':'me' if item['sender']==principal.ref else 'peer',
                'text':item['text'],'sent_at':item['sent_at']} for item in snapshot['messages']]}

    async def audit(self,principal,case_ref,purpose,action,request_id):
        require(purpose in {'triage','reply','safety_review','privacy_review','billing_review','appeal_review'},'PURPOSE_REQUIRED',422)
        # Independent transaction must commit BEFORE decrypting any content.
        async with self.db.transaction('private') as connection:
            await connection.execute('''INSERT INTO nt.access_audit(id,actor_ref,purpose_code,object_type,object_ref,action,request_id)
                VALUES(%s,%s,%s,'case',%s,%s,%s)''',(uuid4(),principal.ref,purpose,case_ref,action,request_id))

    @staticmethod
    def authorize(principal,case,grant='cases.read'):
        require(case is not None,'NOT_FOUND',404)
        if principal.kind=='staff':
            principal.permission(grant)
            require(case['assigned_staff_id']==principal.account_id or 'cases.triage' in principal.grants,'NOT_FOUND',404)
        else:
            require((principal.kind=='account' and case['account_id']==principal.account_id) or
                    (principal.kind=='case' and principal.scope==case['public_ref']),'NOT_FOUND',404)

    async def revalidate_read(self,principal,case_id,grant):
        # Recheck the actual session and current grants AFTER the audit commit.
        current_principal=await self.identity.resolve({'admin':principal.token},private=True)
        require(current_principal is not None,'AUTHENTICATION_REQUIRED',401)
        async with self.db.transaction('private') as connection:
            await self.lock_staff_authority(connection,principal)
            case=await one(connection,'SELECT * FROM nt.support_cases WHERE id=%s',(case_id,))
            self.authorize(current_principal,case,grant)

    async def report_retry(self,principal,dto):
        """Recover a committed nonce even after the ephemeral evidence has expired."""
        payload=dto.model_dump(exclude={'proof','snapshot_ref','selected_ids','reason','block','attribution_only_accepted'})
        payload['report']={'snapshot_ref':dto.snapshot_ref,'reason':dto.reason,'selected_ids':sorted(dto.selected_ids)}
        digest=self.digest(payload)
        async with self.db.transaction('support') as connection:
            await self.lock_account_authority(connection,principal)
            previous=await one(connection,"SELECT keyed_digest,result FROM nt.operation_results WHERE scope_ref=%s AND kind='case' AND client_nonce=%s",(principal.ref,UUID(dto.client_nonce)))
            if not previous:return None
            require(previous['keyed_digest']==digest,'NONCE_CONFLICT')
            return previous['result']

    async def create(self,principal,dto,request_id,report=None,parent_ref=None):
        async with self.capacity(principal,dto.category in {'safety','privacy','security','appeal'}):
            return await self._create(principal,dto,request_id,report,parent_ref)

    async def _create(self,principal,dto,request_id,report=None,parent_ref=None):
        from psycopg.types.json import Jsonb
        payload=dto.model_dump(exclude={'proof'})
        if parent_ref:payload['parent_ref']=parent_ref
        if report:payload['report']={'snapshot_ref':report['snapshot_ref'],'reason':report['reason'],'selected_ids':sorted(m['id'] for m in report['messages'])}
        digest=self.digest(payload)
        async with self.db.transaction('support') as connection:
            await self.lock_account_authority(connection,principal)
            await self.lock_staff_authority(connection,principal)
            # Serialize same nonce across concurrent submissions without exposing secret content.
            await connection.execute('SELECT pg_advisory_xact_lock(hashtextextended(%s,0))',(principal.ref+dto.client_nonce,))
            previous=await one(connection,"SELECT * FROM nt.operation_results WHERE scope_ref=%s AND kind='case' AND client_nonce=%s",(principal.ref,UUID(dto.client_nonce)))
            if previous:
                require(previous['keyed_digest']==digest,'NONCE_CONFLICT')
                return previous['result']
            self.identity.limiter.take(('case',principal.ref),5,86400)
            proof=None
            if principal.kind!='account':
                require(dto.proof is not None,'PREPARATION_REQUIRED',422)
                proof=self.identity.reservations.proof(principal.ref,'case',**dto.proof.model_dump())
            parent_id=None
            if parent_ref:
                parent=await one(connection,'SELECT * FROM nt.support_cases WHERE public_ref=%s FOR UPDATE',(parent_ref,))
                self.authorize(principal,parent)
                parent_id=parent['parent_case_id'] or parent['id']
            case_id,ref=uuid4(),uuid4().hex
            await connection.execute('''INSERT INTO nt.support_cases(id,public_ref,account_id,category,subject_ciphertext,last_sequence)
                VALUES(%s,%s,%s,%s,%s,1)''',(case_id,ref,principal.account_id if principal.kind=='account' else None,dto.category,
                self.security.encrypt('case:'+ref+':subject',dto.subject)))
            if parent_id:await connection.execute('UPDATE nt.support_cases SET parent_case_id=%s,legal_state=%s WHERE id=%s',(parent_id,parent['legal_state'],case_id))
            elif self.legal.reviewed:
                created=await one(connection,'SELECT created_at FROM nt.support_cases WHERE id=%s',(case_id,))
                for rule in self.legal.applicable(dto.category,created['created_at']):
                    await self.attach_rule(connection,case_id,rule,created['created_at'])
                await connection.execute("UPDATE nt.support_cases SET legal_state='classified' WHERE id=%s",(case_id,))
            await connection.execute('''INSERT INTO nt.case_messages(case_id,sequence,sender_kind,sender_ref,body_ciphertext,client_nonce,keyed_digest)
                VALUES(%s,1,'user',%s,%s,%s,%s)''',(case_id,principal.ref,self.security.encrypt('case:'+ref+':1',dto.body),UUID(dto.client_nonce),self.digest({'body':dto.body})))
            if proof:
                await connection.execute("INSERT INTO nt.scoped_receipts(public_ref,kind,subject_ref,verifier) VALUES(%s,'case',%s,%s)",(dto.proof.reservation_id,ref,proof['verifier']))
            if report:
                report_id=uuid4()
                await connection.execute("INSERT INTO nt.reports(id,public_ref,reporter_ref,subject_ref,interaction_ref,reason,allegation_ciphertext,case_id,attribution_kind) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)",(report_id,uuid4().hex,principal.ref,report['other'],report['interaction'],report['reason'],self.security.encrypt('report:'+str(report_id),dto.body),case_id,'server_snapshot' if report['messages'] else 'attribution_only'))
                for message in report['messages']:
                    await connection.execute("INSERT INTO nt.report_evidence(report_id,server_message_id,sender_scoped_ref,sent_at,body_ciphertext,source) VALUES(%s,%s,%s,to_timestamp(%s),%s,'server_snapshot')",(report_id,message['id'],'reporter' if message['sender']==principal.ref else 'subject',message['sent_at'],self.security.encrypt('evidence:'+str(report_id)+':'+message['id'],message['text'])))
            result={'case_ref':ref,'sequence':1,'version':1,'status':'open','receipt_ref':dto.proof.reservation_id if proof else None}
            await connection.execute("INSERT INTO nt.operation_results(scope_ref,kind,client_nonce,keyed_digest,result) VALUES(%s,'case',%s,%s,%s)",(principal.ref,UUID(dto.client_nonce),digest,Jsonb(result)))
            await connection.execute("INSERT INTO nt.outbox(id,kind,object_ref,metric_id) VALUES(%s,'metric',%s,12)",(uuid4(),ref))
        # Keep reservation verifier until expiry for safe retries; plaintext secret was never stored.
        return result

    async def list(self,principal,cursor=None,limit=20,status=None,category=None):
        require(1<=limit<=(50 if principal.kind=='staff' else 20),'LIMIT_INVALID',422)
        scope='cases:'+principal.ref+':'+str(status)+':'+str(category)
        after=self.security.open_cursor(scope,cursor) if cursor else ['0001-01-01T00:00:00+00:00','']
        async with self.db.transaction('private' if principal.kind=='staff' else 'support') as connection:
            await self.lock_account_authority(connection,principal)
            await self.lock_staff_authority(connection,principal)
            if principal.kind=='staff':
                principal.permission('cases.queue')
                rows=await many(connection,'''SELECT public_ref,category,status,version,last_sequence,seen_user_sequence,seen_staff_sequence,
                    updated_at,assigned_staff_id FROM nt.support_cases WHERE (updated_at,public_ref)>(%s,%s)
                    AND (%s::text IS NULL OR status=%s) AND (%s::text IS NULL OR category=%s) ORDER BY updated_at,public_ref LIMIT %s''',
                    (after[0],after[1],status,status,category,category,limit+1))
            else:
                require(principal.kind=='account','ACCOUNT_REQUIRED',401)
                rows=await many(connection,'''SELECT public_ref,category,status,version,last_sequence,seen_user_sequence,seen_staff_sequence,updated_at
                    FROM nt.support_cases WHERE account_id=%s AND (updated_at,public_ref)>(%s,%s) ORDER BY updated_at,public_ref LIMIT %s''',(principal.account_id,after[0],after[1],limit+1))
        next_cursor=self.security.cursor(scope,[rows[limit-1]['updated_at'].isoformat(),rows[limit-1]['public_ref']],now().timestamp()+3600) if len(rows)>limit else None
        return {'items':rows[:limit],'next_cursor':next_cursor}

    async def get(self,principal,ref):
        async with self.db.transaction('private' if principal.kind=='staff' else 'support') as connection:
            await self.lock_account_authority(connection,principal)
            await self.lock_staff_authority(connection,principal)
            row=await one(connection,'SELECT * FROM nt.support_cases WHERE public_ref=%s',(ref,))
            self.authorize(principal,row)
            obligations=await many(connection,'SELECT id,acknowledge_by,act_by,status,escalation FROM nt.case_obligations WHERE case_id=%s OR case_id=%s ORDER BY act_by',(row['id'],row['parent_case_id']))
        result={key:row[key] for key in ('public_ref','category','status','version','last_sequence','seen_user_sequence','seen_staff_sequence','created_at','updated_at','legal_state')}
        result['obligations']=obligations
        if principal.kind=='staff':
            async with self.db.transaction('private') as connection:
                result['reports']=await many(connection,'SELECT public_ref,reason FROM nt.reports WHERE case_id=%s ORDER BY submitted_at LIMIT 50',(row['id'],))
        if principal.kind!='staff': result['subject']=self.security.decrypt('case:'+ref+':subject',row['subject_ciphertext'])
        return result

    async def messages(self,principal,ref,after=0,before=None,limit=50,purpose='triage',request_id=''):
        require(0<=after and 1<=limit<=50 and not(after and before),'CURSOR_INVALID',422)
        async with self.db.transaction('private' if principal.kind=='staff' else 'support') as connection:
            await self.lock_account_authority(connection,principal)
            await self.lock_staff_authority(connection,principal)
            case=await one(connection,'SELECT * FROM nt.support_cases WHERE public_ref=%s',(ref,))
            self.authorize(principal,case)
            if before:
                rows=await many(connection,'''SELECT * FROM nt.case_messages WHERE case_id=%s AND sequence<%s ORDER BY sequence DESC LIMIT %s''',(case['id'],before,limit))
                rows.reverse()
            else:
                rows=await many(connection,'SELECT * FROM nt.case_messages WHERE case_id=%s AND sequence>%s ORDER BY sequence LIMIT %s',(case['id'],after,limit))
        if principal.kind=='staff' and rows:
            await self.audit(principal,ref,purpose,'read_messages',request_id)
        # Revalidate grant/scope after audit and before releasing fetched plaintext.
        if principal.kind=='staff':
            await self.revalidate_read(principal,case['id'],'cases.read')
        return {'items':[{'sequence':r['sequence'],'sender_kind':r['sender_kind'],'display_role':'Moderator' if r['sender_kind']=='staff' else 'You',
                'body':self.security.decrypt('case:'+ref+':'+str(r['sequence']),r['body_ciphertext']),'created_at':r['created_at']} for r in rows],
                'high_water_sequence':case['last_sequence'],'next_after':rows[-1]['sequence'] if rows else after}

    async def message(self,principal,ref,dto,request_id):
        async with self.capacity(principal):
            return await self._message(principal,ref,dto,request_id)

    async def _message(self,principal,ref,dto,request_id):
        if principal.kind=='staff': safe_staff_reply(dto.body)
        sender='staff' if principal.kind=='staff' else 'user'
        digest=self.digest({'body':dto.body})
        async with self.db.transaction('private' if sender=='staff' else 'support') as connection:
            await self.lock_account_authority(connection,principal)
            await self.lock_staff_authority(connection,principal)
            case=await one(connection,'SELECT * FROM nt.support_cases WHERE public_ref=%s FOR UPDATE',(ref,))
            self.authorize(principal,case,'cases.reply')
            existing=await one(connection,'SELECT sequence,keyed_digest,created_at FROM nt.case_messages WHERE case_id=%s AND sender_kind=%s AND client_nonce=%s',(case['id'],sender,UUID(dto.client_nonce)))
            if existing:
                require(existing['keyed_digest']==digest,'NONCE_CONFLICT')
                return {'sequence':existing['sequence'],'created_at':existing['created_at'],'status':'sent'}
            self.identity.limiter.take(('message',principal.ref),3,18)
            require(case['status']!='closed','CASE_CLOSED')
            require(case['last_sequence']<1000,'CONTINUATION_REQUIRED')
            sequence=case['last_sequence']+1
            await connection.execute('UPDATE nt.support_cases SET last_sequence=%s,version=version+1,updated_at=now() WHERE id=%s',(sequence,case['id']))
            row=await one(connection,'''INSERT INTO nt.case_messages(case_id,sequence,sender_kind,sender_ref,body_ciphertext,client_nonce,keyed_digest)
                VALUES(%s,%s,%s,%s,%s,%s,%s) RETURNING created_at''',(case['id'],sequence,sender,principal.ref,self.security.encrypt('case:'+ref+':'+str(sequence),dto.body),UUID(dto.client_nonce),digest))
            if sender=='staff':
                await connection.execute("UPDATE nt.case_obligations SET status='acknowledged',acknowledged_at=now() WHERE (case_id=%s OR case_id=%s) AND status='open'",(case['id'],case['parent_case_id']))
                await connection.execute("INSERT INTO nt.outbox(id,kind,object_ref,metric_id) VALUES(%s,'metric',%s,13)",(uuid4(),ref))
                await connection.execute("INSERT INTO nt.case_events(id,case_id,actor_ref,kind,reason_code,request_id) VALUES(%s,%s,%s,'reply','reply',%s)",(uuid4(),case['id'],principal.ref,request_id))
            return {'sequence':sequence,'created_at':row['created_at'],'status':'sent'}

    async def seen(self,principal,ref,through,request_id):
        async with self.db.transaction('private' if principal.kind=='staff' else 'support') as connection:
            await self.lock_account_authority(connection,principal)
            await self.lock_staff_authority(connection,principal)
            case=await one(connection,'SELECT * FROM nt.support_cases WHERE public_ref=%s FOR UPDATE',(ref,))
            self.authorize(principal,case)
            require(0<=through<=case['last_sequence'],'FUTURE_SEQUENCE',422)
            if principal.kind=='staff':
                await connection.execute('UPDATE nt.support_cases SET seen_staff_sequence=GREATEST(seen_staff_sequence,%s) WHERE id=%s',(through,case['id']))
                await connection.execute("INSERT INTO nt.case_events(id,case_id,actor_ref,kind,reason_code,request_id) VALUES(%s,%s,%s,'seen','seen',%s)",(uuid4(),case['id'],principal.ref,request_id))
            else:
                await connection.execute('UPDATE nt.support_cases SET seen_user_sequence=GREATEST(seen_user_sequence,%s) WHERE id=%s',(through,case['id']))
        return {'seen_through':through}

    async def transition(self,principal,ref,dto,action,request_id):
        from psycopg.types.json import Jsonb
        digest=self.digest(dto.model_dump())
        async with self.db.transaction('private' if principal.kind=='staff' else 'support') as connection:
            await self.lock_account_authority(connection,principal)
            await self.lock_staff_authority(connection,principal)
            case=await one(connection,'SELECT * FROM nt.support_cases WHERE public_ref=%s FOR UPDATE',(ref,))
            grant={'claim':'cases.claim','assignment':'cases.assign','status':'cases.manage','reopen':'cases.read'}[action]
            if action in {'claim','assignment'}:
                principal.permission(grant); require(case,'NOT_FOUND',404)
            else: self.authorize(principal,case,grant)
            scope=principal.ref+':'+ref
            previous=await one(connection,'SELECT * FROM nt.operation_results WHERE scope_ref=%s AND kind=%s AND client_nonce=%s',(scope,action,UUID(dto.client_nonce)))
            if previous:
                require(previous['keyed_digest']==digest,'NONCE_CONFLICT'); return previous['result']
            require(case['version']==dto.expected_version,'VERSION_CONFLICT')
            if action=='claim':
                require(case['assigned_staff_id'] in (None,principal.account_id),'ALREADY_ASSIGNED')
                await connection.execute("UPDATE nt.support_cases SET assigned_staff_id=%s,version=version+1,updated_at=now() WHERE id=%s",(principal.account_id,case['id']))
            elif action=='assignment':
                if dto.staff_ref:
                    assignee=await one(connection,"SELECT a.id FROM nt.staff_accounts a JOIN nt.staff_roles r ON r.staff_id=a.id WHERE a.id=%s AND a.status='active' AND r.permission='cases.read' FOR SHARE OF a",(UUID(dto.staff_ref),))
                    require(assignee,'ASSIGNEE_UNAVAILABLE',422)
                await connection.execute('UPDATE nt.support_cases SET assigned_staff_id=%s,version=version+1,updated_at=now() WHERE id=%s',(UUID(dto.staff_ref) if dto.staff_ref else None,case['id']))
            else:
                status='open' if action=='reopen' else dto.target_status
                if action=='reopen': require(case['closed_at'] and now()-case['closed_at']<=timedelta(days=30),'CONTINUATION_REQUIRED')
                if status in {'closed','resolved'}:
                    root=await one(connection,'SELECT legal_state FROM nt.support_cases WHERE id=%s',(case['parent_case_id'] or case['id'],))
                    require(root['legal_state']=='classified','LEGAL_CLASSIFICATION_REQUIRED')
                    obligation=await one(connection,"SELECT 1 FROM nt.case_obligations WHERE (case_id=%s OR case_id=%s) AND status<>'completed' LIMIT 1",(case['id'],case['parent_case_id']))
                    require(not obligation,'OPEN_LEGAL_OBLIGATION')
                await connection.execute("UPDATE nt.support_cases SET status=%s,closed_at=CASE WHEN %s='closed' THEN now() ELSE NULL END,version=version+1,updated_at=now() WHERE id=%s",(status,status,case['id']))
            event_id=uuid4()
            await connection.execute('INSERT INTO nt.case_events(id,case_id,actor_ref,kind,reason_code,request_id,reason_ciphertext) VALUES(%s,%s,%s,%s,%s,%s,%s)',(event_id,case['id'],principal.ref,action,'staff_action' if principal.kind=='staff' else 'user_reopen',request_id,self.security.encrypt('case_event:'+str(event_id),dto.reason)))
            result={'version':case['version']+1}
            await connection.execute('INSERT INTO nt.operation_results(scope_ref,kind,client_nonce,keyed_digest,result) VALUES(%s,%s,%s,%s,%s)',(scope,action,UUID(dto.client_nonce),digest,Jsonb(result)))
            return result

    async def notes(self,principal,ref,request_id,body=None,nonce=None):
        principal.permission('cases.notes')
        async with self.db.transaction('private') as connection:
            await self.lock_staff_authority(connection,principal)
            case=await one(connection,'SELECT * FROM nt.support_cases WHERE public_ref=%s FOR UPDATE',(ref,))
            self.authorize(principal,case,'cases.notes')
            if body:
                require(nonce is not None,'NONCE_REQUIRED',422)
                digest=self.digest({'body':body})
                previous=await one(connection,'SELECT id,keyed_digest FROM nt.case_internal_notes WHERE case_id=%s AND staff_id=%s AND client_nonce=%s',(case['id'],principal.account_id,UUID(nonce)))
                if previous:
                    require(previous['keyed_digest']==digest,'NONCE_CONFLICT');return {'id':str(previous['id'])}
                note_id=uuid4()
                await connection.execute("INSERT INTO nt.case_internal_notes(id,case_id,staff_id,purpose,body_ciphertext,client_nonce,keyed_digest) VALUES(%s,%s,%s,'triage',%s,%s,%s)",(note_id,case['id'],principal.account_id,self.security.encrypt('note:'+str(note_id),body),UUID(nonce),digest))
                return {'id':str(note_id)}
            rows=await many(connection,'SELECT * FROM nt.case_internal_notes WHERE case_id=%s ORDER BY created_at DESC LIMIT 50',(case['id'],))
        if rows:
            await self.audit(principal,ref,'triage','read_notes',request_id)
            await self.revalidate_read(principal,case['id'],'cases.notes')
        return {'items':[{'id':r['id'],'body':self.security.decrypt('note:'+str(r['id']),r['body_ciphertext']),'created_at':r['created_at']} for r in rows]}

    async def attach_rule(self,connection,case_id,rule,received_at):
        acknowledge,act=self.legal.deadlines(rule,received_at)
        await connection.execute("INSERT INTO nt.case_obligations(id,case_id,rule_version,received_at,acknowledge_by,act_by) VALUES(%s,%s,%s,%s,%s,%s) ON CONFLICT(case_id,rule_version) DO NOTHING",(uuid4(),case_id,rule['id']+':'+rule['version'],received_at,acknowledge,act))

    async def classify(self,principal,ref,dto,request_id):
        principal.permission('cases.legal')
        require(self.legal.reviewed,'LEGAL_REVIEW_REQUIRED')
        async with self.db.transaction('private') as connection:
            await self.lock_staff_authority(connection,principal)
            case=await one(connection,'SELECT * FROM nt.support_cases WHERE public_ref=%s FOR UPDATE',(ref,))
            self.authorize(principal,case,'cases.legal')
            require(case['version']==dto.expected_version,'VERSION_CONFLICT')
            require(case['parent_case_id'] is None,'CLASSIFY_ROOT_CASE')
            rows=self.legal.applicable(case['category'],case['created_at'])
            if dto.rule_id:rows.append(self.legal.select(dto.rule_id,case['category'],case['created_at']))
            for row in rows:await self.attach_rule(connection,case['id'],row,case['created_at'])
            await connection.execute("UPDATE nt.support_cases SET legal_state='classified',version=version+1 WHERE id=%s",(case['id'],))
            await connection.execute("INSERT INTO nt.access_audit(id,actor_ref,purpose_code,object_type,object_ref,action,request_id) VALUES(%s,%s,'triage','case',%s,'legal_classification',%s)",(uuid4(),principal.ref,ref,request_id))
        return {'legal_state':'classified','version':case['version']+1}
