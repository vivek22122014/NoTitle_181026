from datetime import timedelta
import time
from uuid import UUID,uuid4
from app.domain.errors import require
from app.domain.security import canonical
from app.repositories.database import one,many
from .identity import now


class Moderation:
    def __init__(self,db,security,identity,support,privacy):
        self.db,self.security,self.identity,self.support,self.privacy=db,security,identity,support,privacy

    @staticmethod
    def independent_reviewer(principal,case,account,previous):
        if case['category']!='appeal':return
        owned=case['account_id']==account.get('id') if account.get('target_kind','account')=='account' else case.get('guest_ref')==account.get('public_ref')
        require(owned,'APPEAL_SUBJECT_MISMATCH',403)
        require(previous and previous['staff_id']!=principal.account_id,'INDEPENDENT_REVIEW_REQUIRED',403)

    def guest_target(self,ref):
        # O(200) bounded identity table; no device identifier or client-supplied identity.
        guest=next((value for value in self.identity.guests.values() if value['ref']==ref),None)
        require(guest is not None and guest.get('until',0)>time.monotonic() and guest.get('absolute',0)>time.monotonic(),'NOT_FOUND',404)
        return {'target_kind':'guest','public_ref':ref,'safety_revision':int(guest['profile'].get('safety_revision',0))},guest

    async def appeal_owner(self,connection,case):
        if case['category']!='appeal' or case['account_id'] is not None:return
        root=case['parent_case_id'] or case['id']
        source=await one(connection,"SELECT sender_ref FROM nt.case_messages WHERE case_id=%s AND sequence=1 AND sender_kind='user'",(root,))
        case['guest_ref']=source['sender_ref'] if source else None

    async def latest_decision(self,connection,subject):
        return await one(connection,'SELECT id,staff_id FROM nt.moderation_decisions WHERE subject_ref=%s ORDER BY starts_at DESC,id DESC LIMIT 1',(subject,))

    async def report(self,principal,ref,purpose,request_id):
        principal.permission('reports.read')
        async with self.db.transaction('private') as connection:
            report=await one(connection,'SELECT r.*,c.public_ref AS case_ref,c.assigned_staff_id FROM nt.reports r JOIN nt.support_cases c ON c.id=r.case_id WHERE r.public_ref=%s',(ref,))
            require(report and (report['assigned_staff_id']==principal.account_id or 'cases.triage' in principal.grants),'NOT_FOUND',404)
            rows=await many(connection,'SELECT * FROM nt.report_evidence WHERE report_id=%s',(report['id'],))
        await self.support.audit(principal,report['case_ref'],purpose,'read_report',request_id)
        await self.support.revalidate_read(principal,report['case_id'],'reports.read')
        return {'report_ref':ref,'reason':report['reason'],'subject_ref':report['subject_ref'],
                'allegation':self.security.decrypt('report:'+str(report['id']),report['allegation_ciphertext']),
                'evidence':[{'message_id':r['server_message_id'],'sender':r['sender_scoped_ref'],'sent_at':r['sent_at'],
                    'body':self.security.decrypt('evidence:'+str(report['id'])+':'+r['server_message_id'],r['body_ciphertext'])} for r in rows]}

    async def preview(self,principal,dto):
        from psycopg.types.json import Jsonb
        principal.permission('safety.decide')
        require(principal.mfa_at is not None and timedelta(0)<=now()-principal.mfa_at<timedelta(minutes=5),'FRESH_MFA_REQUIRED',401)
        async with self.db.transaction('private') as connection:
            await self.support.lock_staff_authority(connection,principal)
            case=await one(connection,'SELECT * FROM nt.support_cases WHERE public_ref=%s',(dto.case_ref,))
            self.support.authorize(principal,case,'safety.decide')
            await connection.execute('SELECT pg_advisory_xact_lock(hashtextextended(%s,0))',('subject:'+dto.subject_ref,))
            account=await one(connection,'SELECT id,safety_revision FROM nt.accounts WHERE public_ref=%s',(dto.subject_ref,))
            if account:account['target_kind']='account'
            else:account,_=self.guest_target(dto.subject_ref)
            await self.appeal_owner(connection,case)
            previous=await self.latest_decision(connection,dto.subject_ref)
            self.independent_reviewer(principal,case,account,previous)
            ref=uuid4().hex;payload=dto.model_dump()
            await connection.execute("INSERT INTO nt.sensitive_previews(nonce,actor_id,object_ref,payload_digest,payload,revisions,expires_at) VALUES(%s,%s,%s,%s,%s,%s,now()+interval '2 minutes')",(ref,principal.account_id,dto.subject_ref,self.security.digest('preview',canonical(payload).decode()),Jsonb(payload),Jsonb({'safety':account['safety_revision'],'case':case['version'],'target_kind':account['target_kind'],'last_decision':str(previous['id']) if previous else None})))
        return {'preview':ref,'payload':payload,'expires_in':120,'target_kind':account['target_kind']}

    async def confirm(self,principal,ref,request_id):
        from psycopg.types.json import Jsonb
        principal.permission('safety.decide')
        require(principal.mfa_at is not None and timedelta(0)<=now()-principal.mfa_at<timedelta(minutes=5),'FRESH_MFA_REQUIRED',401)
        async with self.db.transaction('private') as connection:
            await self.support.lock_staff_authority(connection,principal)
            preview=await one(connection,'SELECT * FROM nt.sensitive_previews WHERE nonce=%s FOR UPDATE',(ref,))
            require(preview and preview['actor_id']==principal.account_id and not preview['consumed_at'] and preview['expires_at']>now(),'PREVIEW_EXPIRED')
            payload=preview['payload'];require('case_ref' in payload,'PREVIEW_KIND')
            case=await one(connection,'SELECT * FROM nt.support_cases WHERE public_ref=%s FOR UPDATE',(payload['case_ref'],))
            self.support.authorize(principal,case,'safety.decide')
            await connection.execute('SELECT pg_advisory_xact_lock(hashtextextended(%s,0))',('subject:'+payload['subject_ref'],))
            account=await one(connection,'SELECT * FROM nt.accounts WHERE public_ref=%s FOR UPDATE',(payload['subject_ref'],))
            expected_kind=preview['revisions'].get('target_kind','account')
            guest=None
            if account:
                require(expected_kind=='account','PREVIEW_STALE')
                account['target_kind']='account'
            else:
                require(expected_kind=='guest','PREVIEW_STALE')
                account,guest=self.guest_target(payload['subject_ref'])
            previous=await self.latest_decision(connection,payload['subject_ref'])
            if expected_kind=='guest':require((str(previous['id']) if previous else None)==preview['revisions'].get('last_decision'),'PREVIEW_STALE')
            await self.appeal_owner(connection,case)
            self.independent_reviewer(principal,case,account,previous)
            require(case['version']==preview['revisions']['case'] and account['safety_revision']==preview['revisions']['safety'],'PREVIEW_STALE')
            require(self.security.verify('preview',canonical(payload).decode(),preview['payload_digest']),'PREVIEW_INVALID')
            decision=uuid4();ends=now()+timedelta(hours=payload['duration_hours']) if payload['duration_hours'] else None
            await connection.execute('''INSERT INTO nt.moderation_decisions(id,case_id,subject_ref,action,reason_code,authority,starts_at,ends_at,staff_id)
                VALUES(%s,%s,%s,%s,%s,'community_rules',clock_timestamp(),%s,%s)''',(decision,case['id'],payload['subject_ref'],payload['action'],payload['reason_code'],ends,principal.account_id))
            if payload['action']=='restrict':
                await connection.execute("INSERT INTO nt.restrictions(id,subject_ref,kind,starts_at,ends_at,reason_code,decision_id) VALUES(%s,%s,'participation',now(),%s,%s,%s)",(uuid4(),payload['subject_ref'],ends,payload['reason_code'],decision))
            else:
                await connection.execute('UPDATE nt.restrictions SET ends_at=now(),revision=revision+1 WHERE subject_ref=%s AND (ends_at IS NULL OR ends_at>now())',(payload['subject_ref'],))
            if account['target_kind']=='account':
                await connection.execute('UPDATE nt.accounts SET safety_revision=safety_revision+1 WHERE id=%s',(account['id'],))
                await connection.execute("INSERT INTO nt.account_notices(id,account_id,kind,safe_payload,expires_at) VALUES(%s,%s,'safety_decision',%s,now()+interval '180 days')",(uuid4(),account['id'],Jsonb({'action':payload['action'],'reason':payload['reason_code'],'appeal':'Chat with Moderator → Appeal','decision_ref':str(decision)})))
            event_id=uuid4()
            await connection.execute("INSERT INTO nt.case_events(id,case_id,actor_ref,kind,reason_code,request_id,reason_ciphertext) VALUES(%s,%s,%s,'safety_decision',%s,%s,%s)",(event_id,case['id'],principal.ref,payload['reason_code'],request_id,self.security.encrypt('case_event:'+str(event_id),payload['reason'])))
            await connection.execute('UPDATE nt.sensitive_previews SET consumed_at=now() WHERE nonce=%s',(ref,))
            await connection.execute("INSERT INTO nt.access_audit(id,actor_ref,purpose_code,object_type,object_ref,action,request_id) VALUES(%s,%s,'safety_review','subject',%s,%s,%s)",(uuid4(),principal.ref,payload['subject_ref'],payload['action'],request_id))
        if guest is not None:guest['profile']['safety_revision']=int(guest['profile'].get('safety_revision',0))+1
        self.identity.fence(payload['subject_ref'],'safety_decision')
        return {'decision_ref':str(decision),'action':payload['action']}

    async def obligations(self,principal,case_ref,dto):
        principal.permission('cases.legal')
        async with self.db.transaction('private') as connection:
            await self.support.lock_staff_authority(connection,principal)
            case=await one(connection,'SELECT * FROM nt.support_cases WHERE public_ref=%s FOR UPDATE',(case_ref,))
            self.support.authorize(principal,case,'cases.legal')
            require(case['version']==dto.expected_version,'VERSION_CONFLICT')
            row=await one(connection,"UPDATE nt.case_obligations SET status='completed',completed_at=now(),evidence_ref=%s WHERE id=%s AND case_id=%s AND status<>'completed' RETURNING id",(dto.evidence_ref,UUID(dto.obligation_ref),case['id']))
            require(row,'NOT_FOUND',404)
            await connection.execute('UPDATE nt.support_cases SET version=version+1 WHERE id=%s',(case['id'],))
        return {'completed':True}
