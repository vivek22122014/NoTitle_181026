"""Mutual consent and external relay effects behind the conversation mailbox."""
from app.domain.errors import require

class ConversationAudio:
    def __init__(self,service,media):self.service,self.media=service,media

    async def execute(self,binding,command,captured_revision):
        service,media=self.service,self.media;ref=binding.principal.ref
        def validate():
            person=service.check(binding,command)
            require(person.revision==captured_revision and person.interaction==command.payload.interaction_handle,'STALE_INTERACTION')
            interaction=service.rt.current(ref)
            if command.type not in {'call.end','call.cancel'}:require(all(service.rt.people[member].connected for member in (interaction.left,interaction.right)),'PARTNER_INTERRUPTED')
            if command.type!='call.request':
                call=interaction.call
                require(call and call['id']==command.payload.call_id,'CALL_EXPIRED')
                if hasattr(command.payload,'negotiation_revision'):
                    require(call['revision']==command.payload.negotiation_revision,'STALE_NEGOTIATION')
            return interaction
        def commit():
            interaction=validate();kind=command.type
            # Local teardown remains available during relay failure.
            if kind in {'call.end','call.cancel'}:
                if kind=='call.cancel':require(interaction.call['from']==ref and interaction.call['state']=='ringing','CALL_EXPIRED')
                service.rt.end_call(interaction,'cancelled' if kind=='call.cancel' else 'ended');return None
            require(not media.unavailable and media.controller,'AUDIO_UNAVAILABLE',503)
            if kind=='call.request':
                require(len(media.reserved)<25,'CALL_CAPACITY',503)
                result=service.rt.call_request(ref)
                service.rt.emit(ref,'call.ringing',{'interaction_handle':interaction.id,'call_id':result['call_id'],'expires_in':30})
            elif kind=='call.respond':
                # Reserve synchronously before leaving the mailbox for relay I/O.
                return media.reserve_accept(ref,command.payload.accept)
            elif kind=='call.connected':media.connected(ref,command.payload.call_id)
            elif kind in {'call.sdp','call.ice'}:
                service.limiter.take(('audio_signal',ref),64,2)
                return ('signal',command.payload.model_dump())
            elif kind=='call.refresh':return media.reserve_refresh(ref,command.payload.call_id)
            return None
        effect=await service.transition(commit,control=command.type in {'call.end','call.cancel'})
        if isinstance(effect,tuple) and effect[0]=='signal':
            await media.forward_signal(ref,command.type,effect[1],service.transition,validate)
            return {}
        if effect:
            # The captured call object/revision is checked again inside publish.
            def binding_current():
                person=service.check(binding,command)
                require(person.revision==captured_revision and person.interaction==command.payload.interaction_handle,'STALE_INTERACTION')
            await media.provision(effect,transition=service.transition,validate=binding_current)
        return {}
