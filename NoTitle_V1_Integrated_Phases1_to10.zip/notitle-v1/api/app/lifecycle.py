"""Own the lease from acquisition through the last cleanup, including failed startup."""
import asyncio
from contextlib import asynccontextmanager
from dataclasses import dataclass

from app.coordinator.core import Coordinator


@dataclass(frozen=True)
class OwnedProcess:
    lease: object
    coordinator: Coordinator
    heartbeat: asyncio.Task


async def heartbeat(lease, coordinator):
    try:
        while True:
            await lease.prove()
            coordinator.heartbeat()
            await asyncio.sleep(1)
    except BaseException:
        # A failed proof fences immediately, including while services are opening.
        coordinator.fence()
        raise


@asynccontextmanager
async def ownership(dsn, acquire):
    lease = await acquire(dsn)
    coordinator = Coordinator(lease.epoch)
    task = asyncio.create_task(heartbeat(lease, coordinator), name="owner-proof")
    try:
        yield OwnedProcess(lease, coordinator, task)
    finally:
        coordinator.fence()
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)
        await lease.close()
