"""Forward-only, checksummed transactional SQL migrations, run by the migrator."""
from pathlib import Path
import hashlib
import re
import psycopg
from .ownership import OWNER_LOCK
MIGRATION_LOCK = 72401302

async def migrate(dsn: str, directory: Path, *, through: int | None = None):
    files = sorted(directory.glob("*.sql"))
    if not files or any(not re.fullmatch(r"[0-9]{4}_[a-z_]+\.sql", p.name) for p in files):
        raise ValueError("Invalid migration inventory")
    if through is not None and (type(through) is not int or through < 1):
        raise ValueError("Invalid migration target")
    ids = [p.name[:4] for p in files]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate migration number")
    async with await psycopg.AsyncConnection.connect(dsn, autocommit=True) as conn:
        async with conn.cursor() as cur:
            await cur.execute("SELECT pg_try_advisory_lock(%s)", (MIGRATION_LOCK,))
            if not (await cur.fetchone())[0]:
                raise RuntimeError("MIGRATION_BUSY")
            # Same lock as runner: no migration may overlap a live owner.
            await cur.execute("SELECT pg_try_advisory_lock(%s)", (OWNER_LOCK,))
            if not (await cur.fetchone())[0]:
                raise RuntimeError("STOP_OWNER_BEFORE_MIGRATION")
            await cur.execute("CREATE SCHEMA IF NOT EXISTS nt_system")
            await cur.execute("""CREATE TABLE IF NOT EXISTS nt_system.schema_migrations (
                name text PRIMARY KEY, sha256 text NOT NULL,
                applied_at timestamptz NOT NULL DEFAULT now())""")
            await cur.execute("SELECT name, sha256 FROM nt_system.schema_migrations ORDER BY name")
            applied = dict(await cur.fetchall())
            known = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
            if any(name not in known or known[name] != digest for name, digest in applied.items()):
                raise RuntimeError("MIGRATION_HISTORY_MISMATCH")
            if list(applied) != [p.name for p in files[:len(applied)]]:
                raise RuntimeError("MIGRATION_HISTORY_NOT_PREFIX")
            for path in files:
                if through is not None and int(path.name[:4]) > through:
                    break
                if path.name in applied:
                    continue
                async with conn.transaction():
                    await cur.execute(path.read_text(), prepare=False)
                    await cur.execute("INSERT INTO nt_system.schema_migrations(name,sha256) VALUES(%s,%s)",
                                      (path.name, known[path.name]))
