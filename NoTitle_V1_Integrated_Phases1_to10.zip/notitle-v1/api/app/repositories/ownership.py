import asyncio
import psycopg

OWNER_LOCK = 72401301

class OwnerBusy(RuntimeError):
    pass

class OwnerLease:
    def __init__(self, conn, epoch: int):
        self.conn, self.epoch = conn, epoch

    @classmethod
    async def acquire(cls, dsn: str):
        conn = await psycopg.AsyncConnection.connect(
            dsn, autocommit=True, connect_timeout=5,
            options="-c statement_timeout=1500 -c lock_timeout=500",
            application_name="notitle-owner")
        try:
            async with conn.cursor() as cur:
                await cur.execute("SELECT pg_try_advisory_lock(%s)", (OWNER_LOCK,))
                if not (await cur.fetchone())[0]:
                    raise OwnerBusy("OWNER_ALREADY_RUNNING")
                await cur.execute("SELECT nextval('nt_system.owner_epoch_seq')")
                epoch = (await cur.fetchone())[0]
            return cls(conn, epoch)
        except BaseException:
            await conn.close()
            raise

    async def prove(self):
        async with asyncio.timeout(1.5):
            async with self.conn.cursor() as cur:
                # Detect session lock loss as well as connectivity loss.
                await cur.execute("""SELECT EXISTS (
                    SELECT 1 FROM pg_locks WHERE locktype='advisory'
                    AND pid=pg_backend_pid() AND classid=0 AND objid=%s
                    AND objsubid=1 AND granted)""", (OWNER_LOCK,))
                if not (await cur.fetchone())[0]:
                    raise OwnerBusy("OWNER_LOCK_LOST")

    async def close(self):
        await self.conn.close()  # PostgreSQL releases this session's lock.
