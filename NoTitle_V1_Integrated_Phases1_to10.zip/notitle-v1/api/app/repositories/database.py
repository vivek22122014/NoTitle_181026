"""Fixed role pools with bounded acquisition and repair; never reconnect the owner."""
import asyncio
from contextlib import asynccontextmanager


class PoolUnavailable(RuntimeError):
    pass


async def connect(dsn):
    import psycopg
    from psycopg.rows import dict_row
    return await psycopg.AsyncConnection.connect(
        dsn, autocommit=True, row_factory=dict_row, connect_timeout=3,
        options="-c statement_timeout=2000 -c lock_timeout=500 -c idle_in_transaction_session_timeout=5000",
    )


class Pool:
    def __init__(self, dsn, size, *, connector=connect, acquire_timeout=2, connect_timeout=3):
        if type(size) is not int or size < 1:
            raise ValueError("Positive fixed pool size required")
        self.dsn, self.size, self.connector = dsn, size, connector
        self.acquire_timeout, self.connect_timeout = acquire_timeout, connect_timeout
        self.queue = asyncio.Queue(maxsize=size)
        self.connections = []
        self.closed = True

    async def new_connection(self):
        async with asyncio.timeout(self.connect_timeout):
            return await self.connector(self.dsn)

    async def open(self):
        if not self.closed or self.connections:
            raise PoolUnavailable("POOL_ALREADY_OPEN")
        self.closed = False
        try:
            for _ in range(self.size):
                connection = await self.new_connection()
                self.connections.append(connection)
                self.queue.put_nowait(connection)
        except BaseException:
            await self.close()
            raise

    @asynccontextmanager
    async def transaction(self):
        if self.closed:
            raise PoolUnavailable("POOL_CLOSED")
        async with asyncio.timeout(self.acquire_timeout):
            connection = await self.queue.get()
        try:
            if self.closed:
                raise PoolUnavailable("POOL_CLOSED")
            if connection.closed:
                # This slot remains borrowed while it reconnects. The old connection
                # is closed first, preserving the fixed budget even during a repair.
                index = self.connections.index(connection)
                await connection.close()
                replacement = await self.new_connection()
                if self.closed:
                    await replacement.close()
                    raise PoolUnavailable("POOL_CLOSED")
                self.connections[index] = replacement
                connection = replacement
            async with connection.transaction():
                yield connection
        finally:
            if not self.closed:
                self.queue.put_nowait(connection)

    async def close(self):
        self.closed = True
        results = await asyncio.gather(*(connection.close() for connection in self.connections), return_exceptions=True)
        self.connections.clear()
        while not self.queue.empty():
            self.queue.get_nowait()
        if any(isinstance(result, BaseException) for result in results):
            raise PoolUnavailable("POOL_CLOSE_FAILED")


class Database:
    SIZES = {"public": 6, "support": 2, "private": 2, "jobs": 2, "analytics": 2}

    def __init__(self, dsns):
        self.pools = {name: Pool(dsns[name], size) for name, size in self.SIZES.items()}

    async def open(self):
        try:
            for pool in self.pools.values():
                await pool.open()
        except BaseException:
            await self.close()
            raise

    def transaction(self, role="public"):
        return self.pools[role].transaction()

    async def close(self):
        results = await asyncio.gather(*(pool.close() for pool in self.pools.values()), return_exceptions=True)
        if any(isinstance(result, BaseException) for result in results):
            raise PoolUnavailable("DATABASE_CLOSE_FAILED")


async def one(connection, sql, params=()):
    cursor = await connection.execute(sql, params)
    return await cursor.fetchone()


async def many(connection, sql, params=()):
    cursor = await connection.execute(sql, params)
    return await cursor.fetchall()
