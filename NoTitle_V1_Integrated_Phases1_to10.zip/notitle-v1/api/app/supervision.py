import asyncio

async def supervise(lease, coordinator, listener_tasks, stop, heartbeat_task=None):
    async def heartbeat():
        while True:
            await lease.prove()
            coordinator.heartbeat()
            await asyncio.sleep(1)
    beat=heartbeat_task or asyncio.create_task(heartbeat())
    stopped=asyncio.create_task(stop.wait())
    try:
        done,_=await asyncio.wait([*listener_tasks,beat,stopped],return_when=asyncio.FIRST_COMPLETED)
        coordinator.fence()
        if stopped not in done:
            raise RuntimeError("OWNER_OR_LISTENER_LOST")
    finally:
        coordinator.fence()
        for task in (beat,stopped):task.cancel()
        await asyncio.gather(beat,stopped,return_exceptions=True)
