"""Explicit local Phase 3 surface. This is not production feature authorization."""
PUBLIC_PREFIXES=('/api/v1/auth/','/api/v1/me','/api/v1/privacy/','/api/v1/support/')
PUBLIC_EXACT={'/health/live','/health/ready','/api/v1/bootstrap','/api/v1/catalogs','/api/v1/operations/prepare',
              '/api/v1/billing/receipts/access/prepare','/api/v1/billing/receipts/access/confirm','/api/v1/billing/receipts/access'}
PRIVATE_PREFIXES=('/internal/v1/auth/','/internal/v1/privacy/')
PRIVATE_EXACT={'/internal/v1/bootstrap'}

def allowed(path,private=False):
    return path in (PRIVATE_EXACT if private else PUBLIC_EXACT) or any(path.startswith(p) for p in (PRIVATE_PREFIXES if private else PUBLIC_PREFIXES))

def filter_identity_routes(public,private,extra=None):
    for app,is_private in ((public,False),(private,True)):
        app.router.routes[:]=[route for route in app.router.routes if allowed(route.path,is_private) or not is_private and route.path in (extra or set())]
