"""Wire v2 transport; domain transitions and async authorization live in services."""
import asyncio,hmac,json
from urllib.parse import urlsplit
from fastapi import Request,WebSocket,WebSocketDisconnect
from fastapi.responses import JSONResponse
from pydantic import TypeAdapter,ValidationError
from app.domain.conversation_contracts import Hello,HTTPControl,decode,strict_json
from app.domain.errors import DomainError,require
from .models import Ticket

CONTROL=TypeAdapter(HTTPControl)

def install_realtime(app,runtime,principal,data):
    service,rt=runtime.conversation,runtime.realtime
    @app.post('/api/v1/ws/ticket')
    async def ticket(dto:Ticket,request:Request):
        require(runtime.settings.admission,'ADMISSION_CLOSED',503)
        p=await principal(request)
        try:return data(request,await service.prepare(p,dto))
        except DomainError as error:
            if error.code!='SOCKET_EXISTS':raise
            person=rt.people.get(p.ref)
            return JSONResponse({'data':{'socket_generation':person.generation if person else 0},'error':{'code':'SOCKET_EXISTS','message':'Another tab owns chat. Takeover must be explicit.','retryable':False},'request_id':request.state.request_id},409)

    @app.post('/api/v1/interactions/end')
    async def end(request:Request):
        p=await principal(request)
        try:command=CONTROL.validate_python(strict_json((await request.body()).decode()))
        except (ValueError,TypeError,ValidationError,RecursionError):raise DomainError('INVALID_INPUT',422) from None
        binding=service.bindings.get(p.ref)
        require(binding and binding.principal.kind==p.kind and hmac.compare_digest(binding.principal.token,p.token),'SOCKET_AUTHORITY_REQUIRED',401)
        return data(request,await service.transition(lambda:service.control(binding,command,http=True),control=True))

    @app.websocket('/api/v1/ws')
    async def socket(ws:WebSocket):
        headers=ws.scope['headers'];unique={b'host',b'origin',b'cookie'}
        names=[key for key,_ in headers if key in unique]
        if len(names)!=len(set(names)) or ws.headers.get('origin')!=runtime.settings.public_origin or ws.headers.get('host')!=urlsplit(runtime.settings.public_origin).netloc or ws.scope.get('query_string'):
            await ws.close(code=1008);return
        if service.handshakes>=32 or not runtime.settings.admission:
            service.counters['handshake_rejected']+=1;await ws.close(code=1013);return
        service.handshakes+=1;binding=None;generation=None;owned=[];close_code=1008
        async def receive_text():
            event=await asyncio.wait_for(ws.receive(),45)
            if event['type']=='websocket.disconnect':raise WebSocketDisconnect(event.get('code',1000))
            require(event.get('text') is not None,'BINARY_NOT_SUPPORTED',422)
            return event['text']
        try:
            await ws.accept()
            raw=await asyncio.wait_for(receive_text(),5);hello=Hello.model_validate(strict_json(raw,1024))
            cookie_names=[part.split('=',1)[0].strip() for part in ws.headers.get('cookie','').split(';') if '=' in part]
            require(len(cookie_names)==len(set(cookie_names)),'DUPLICATE_COOKIE',400)
            values={kind:ws.cookies.get(runtime.cookie_name(kind)) for kind in ('account','guest')}
            binding=await asyncio.wait_for(service.connect(hello.ticket,values),5);generation=binding.generation
        except asyncio.CancelledError:
            try:await ws.close(code=1001)
            except Exception:pass
            raise
        except Exception:
            try:await ws.close(code=1008)
            except Exception:pass
            return
        finally:
            service.handshakes-=1
        # A separate reader handles teardown even while ordinary authorization waits.
        async def write():
            while True:
                runtime.coordinator.assert_authority();person=rt.people.get(binding.principal.ref)
                if not person or person.generation!=generation:
                    raise DomainError('SOCKET_REPLACED',401)
                if not person.connected:raise DomainError('SERVICE_UNAVAILABLE',503)
                if binding.access.deadline<=rt.clock():service.deny(person.id,'SESSION_EXPIRED');raise DomainError('SESSION_EXPIRED',401)
                for _ in range(64):
                    if not person.events:break
                    event,size=person.events.popleft();person.event_bytes-=size
                    try:
                        if event['socket_generation']!=generation:continue
                        if event['type'] in {'text.message','interaction.started'} and event['data'].get('interaction_handle')!=person.interaction:continue
                        if event['type'] in {'session.ready','state.snapshot'} and event['data'].get('interaction') and event['data']['interaction']['interaction_handle']!=person.interaction:continue
                        await asyncio.wait_for(ws.send_json(event),3)
                    finally:event=None
                await asyncio.sleep(.02)
        queue=asyncio.Queue(maxsize=2)
        async def work():
            while True:
                command,key=await queue.get();task=asyncio.create_task(service.execute(binding,command,key))
                try:await task
                except asyncio.CancelledError:
                    if asyncio.current_task().cancelling():task.cancel();await asyncio.gather(task,return_exceptions=True);raise
                except (DomainError,ValidationError,ValueError,KeyError,TypeError) as error:
                    person=rt.people.get(binding.principal.ref)
                    if person and person.generation==generation:rt.emit(person.id,'command.error',{'command_id':command.command_id,'code':getattr(error,'code','INVALID_COMMAND')})
                finally:command=None;key=None;task=None
        async def read():
            processed=0
            while True:
                raw=await receive_text();command=None
                try:
                    command=decode(raw)
                    if command.type in {'interaction.end','queue.cancel'}:
                        revision=rt.person(binding.principal.ref).revision
                        await service.transition(lambda command=command:service.control(binding,command),control=True)
                        # Drop ordinary plaintext queued before the teardown boundary.
                        if rt.person(binding.principal.ref).revision!=revision:
                            while not queue.empty():
                                old_key=queue.get_nowait()[1];service.pending.pop(old_key,None)
                    elif command.type in {'call.end','call.cancel'}:
                        key=await service.transition(lambda command=command:service.begin(binding,command),control=True)
                        if key is not None:await service.stop_audio(binding,command,key)
                    elif command.type=='interaction.next':
                        key=await service.transition(lambda command=command:service.begin(binding,command),control=True)
                        if key is not None:
                            while not queue.empty():
                                old_key=queue.get_nowait()[1];service.pending.pop(old_key,None)
                            queue.put_nowait((command,key))
                    else:
                        require(not queue.full(),'COMMAND_CAPACITY',429)
                        key=await service.transition(lambda command=command:service.begin(binding,command))
                        if key is not None:queue.put_nowait((command,key))
                except (DomainError,ValidationError,ValueError,KeyError,TypeError,RecursionError) as error:
                    person=rt.people.get(binding.principal.ref)
                    if person and person.generation==generation:rt.emit(person.id,'command.error',{'command_id':command.command_id if command else None,'code':getattr(error,'code','INVALID_COMMAND')})
                finally:raw='';command=None
                processed+=1
                if processed%64==0:await asyncio.sleep(0)
        try:
            owned=[asyncio.create_task(write()),asyncio.create_task(read()),asyncio.create_task(work())]
            done,_=await asyncio.wait(owned,return_when=asyncio.FIRST_COMPLETED)
            for task in done:task.result()
        except DomainError as error:close_code=4009 if error.code=='SOCKET_REPLACED' else 4001 if error.status==401 else 1013
        except WebSocketDisconnect:return
        except Exception:close_code=1013
        finally:
            for task in owned:task.cancel()
            await asyncio.gather(*owned,return_exceptions=True)
            if binding:
                person=rt.people.get(binding.principal.ref)
                if person and person.generation==generation:
                    service.cancel_effects(person.id);rt.disconnect(person.id)
            while not queue.empty():queue.get_nowait()
            try:await ws.close(code=close_code)
            except Exception:pass
