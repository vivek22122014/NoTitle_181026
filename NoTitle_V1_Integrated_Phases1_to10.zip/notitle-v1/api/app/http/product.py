import asyncio
import hashlib
import json
import time
from datetime import datetime
from uuid import UUID, uuid4
from urllib.parse import urlsplit,parse_qsl
from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, Response
from starlette.exceptions import HTTPException
from app.domain.errors import DomainError, require
from app.coordinator.core import Fenced
from app.domain.security import canonical,token
from app.repositories.database import one,many
from . import models as m


class Boundary:
    def __init__(self,app,origin):self.app,self.origin=app,origin
    async def __call__(self,scope,receive,send):
        if scope['type']!='http':return await self.app(scope,receive,send)
        path=scope['path'];headers=dict(scope['headers'])
        async def reject(code,status):
            return await JSONResponse({'error':{'code':code,'message':code.replace('_',' ').capitalize(),'retryable':False},'request_id':scope.get('state',{}).get('request_id',uuid4().hex)},status)(scope,receive,send)
        unique={b'host',b'origin',b'cookie',b'x-csrf-token',b'x-nt-authority',b'content-type'}
        names=[name.lower() for name,_ in scope['headers'] if name.lower() in unique]
        if len(names)!=len(set(names)):return await reject('DUPLICATE_HEADER',400)
        # Loopback container/CLI probes use the API port, not the public edge Host.
        # These two status-only routes carry no identity or scoped authority.
        if path not in {'/health/live','/health/ready'} and headers.get(b'host',b'').decode('latin1')!=urlsplit(self.origin).netloc:return await reject('HOST_INVALID',400)
        if any(k.lower() in {'secret','token','password','code','recovery_secret','csrf'} for k,_ in parse_qsl(scope.get('query_string',b'').decode('latin1'))):
            return await reject('CREDENTIALS_IN_URL',400)
        limit=262144 if path.endswith('/webhooks/cashfree') else 12288 if '/support/' in path or '/cases' in path or path.endswith('/reports') else 8192
        # Read bounded ASGI frames before FastAPI parses JSON; ignore advertised length.
        body=bytearray()
        while True:
            event=await receive()
            if event['type']=='http.disconnect':return
            body.extend(event.get('body',b''))
            if len(body)>limit:
                return await JSONResponse({'error':{'code':'BODY_LIMIT','message':'Request too large','retryable':False}},413)(scope,receive,send)
            if not event.get('more_body',False):break
        delivered=False
        async def replay():
            nonlocal delivered
            if not delivered:delivered=True;return {'type':'http.request','body':bytes(body),'more_body':False}
            return await receive()
        if scope['method'] not in {'GET','HEAD','OPTIONS'} and body and headers.get(b'content-type',b'').split(b';')[0]!=b'application/json':
            return await JSONResponse({'error':{'code':'CONTENT_TYPE','message':'JSON required','retryable':False}},415)(scope,replay,send)
        await self.app(scope,replay,send)


def create_product_apps(runtime):
    identity,db,security=runtime.identity,runtime.db,runtime.security
    rt,support,billing,privacy,social=runtime.realtime,runtime.support,runtime.billing,runtime.privacy,runtime.social
    apps=[]
    for private in (False,True):
        app=FastAPI(title='NoTitle private' if private else 'NoTitle public',docs_url=None,redoc_url=None,openapi_url=None)
        app.add_middleware(Boundary,origin=runtime.settings.private_origin if private else runtime.settings.public_origin)
        @app.middleware('http')
        async def headers(request,call_next):
            request.state.request_id=uuid4().hex
            started=time.monotonic()
            try:
                response=await call_next(request)
            except Exception:
                response=JSONResponse({'error':{'code':'INTERNAL_ERROR','message':'Request could not be completed','retryable':True},'request_id':request.state.request_id},500)
            response.headers.update({'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','X-Request-ID':request.state.request_id,'Referrer-Policy':'no-referrer'})
            runtime.metrics.add('requests_total');runtime.metrics.add('api_latency_ms',(time.monotonic()-started)*1000)
            if response.status_code>=500:runtime.metrics.add('server_errors')
            return response
        @app.exception_handler(DomainError)
        async def domain_error(request,exc):return fail(request,exc.code,exc.status)
        @app.exception_handler(RequestValidationError)
        async def validation_error(request,exc):
            fields=[{'path':'.'.join(str(v) for v in item['loc'] if v!='body'),'message':'Review this field.'} for item in exc.errors()[:12]]
            return JSONResponse({'error':{'code':'INVALID_INPUT','message':'Review the highlighted fields.','fields':fields,'retryable':False},'request_id':request.state.request_id},422)
        @app.exception_handler(HTTPException)
        async def http_error(request,exc):return fail(request,'NOT_FOUND' if exc.status_code==404 else 'REQUEST_DENIED',exc.status_code)
        @app.exception_handler(Fenced)
        async def fenced_error(request,exc):return fail(request,'OWNER_UNAVAILABLE',503)
        apps.append(app)
    public,private=apps

    def fail(request,code,status):
        headers={'Retry-After':'30'} if status==429 else {}
        return JSONResponse({'error':{'code':code,'message':code.replace('_',' ').capitalize(),'retryable':status>=500 or status==429},'request_id':getattr(request.state,'request_id','')},status,headers=headers)
    def data(request,result,status=200):
        from fastapi.encoders import jsonable_encoder
        return JSONResponse(jsonable_encoder({'data':result,'request_id':request.state.request_id}),status)
    def cookie(response,kind,secret):
        response.set_cookie(runtime.cookie_name(kind),secret,secure=runtime.settings.secure_cookies,httponly=True,samesite='lax',path='/',max_age={'account':2592000,'guest':86400,'bootstrap':1800,'admin_bootstrap':1800,'admin':14400}.get(kind,86400))
    def clear_cookie(response,kind):
        response.delete_cookie(runtime.cookie_name(kind),path='/',secure=runtime.settings.secure_cookies,httponly=True,samesite='lax')
    def cookies(request):
        raw=request.headers.get('cookie','')
        names=[part.split('=',1)[0].strip() for part in raw.split(';') if '=' in part]
        require(len(names)==len(set(names)),'DUPLICATE_COOKIE',400)
        return {name:request.cookies.get(runtime.cookie_name(name)) for name in ('account','guest','bootstrap','admin_bootstrap','admin','case','financial','deletion')}
    async def principal(request,*,staff=False,allow_bootstrap=False,scope=None,mutating=None):
        runtime.coordinator.assert_authority()
        expected=runtime.settings.private_origin if staff else runtime.settings.public_origin
        require(request.headers.get('host')==expected.split('://',1)[1],'HOST_INVALID',400)
        requested=request.headers.get('x-nt-authority') if scope else None
        require(requested is None or requested in {'account',scope},'AUTHORITY_INVALID',400)
        p=await identity.resolve(cookies(request),private=staff,scope=None if requested=='account' else scope)
        if requested:require(p is not None and p.kind==requested,'AUTHENTICATION_REQUIRED',401)
        require(p is not None and (allow_bootstrap or p.kind!='bootstrap'),'AUTHENTICATION_REQUIRED',401)
        if mutating is None:mutating=request.method not in {'GET','HEAD'}
        if mutating:
            require(request.headers.get('origin')==expected,'ORIGIN_INVALID',403)
            require(security.verify('csrf',p.token,request.headers.get('x-csrf-token','')),'CSRF_INVALID',403)
        if mutating:await identity.foreground(p)
        return p
    async def credential_principal(request):
        # A spent account cookie can prove only an exact recorded credential retry.
        # It is never resolved as an account or used for any other route.
        from app.services.primitives import Principal
        runtime.coordinator.assert_authority();values=cookies(request)
        require(request.headers.get('origin')==runtime.settings.public_origin,'ORIGIN_INVALID',403)
        secret=values.get('account');require(secret and security.verify('csrf',secret,request.headers.get('x-csrf-token','')),'CSRF_INVALID',403)
        current=await identity.resolve(values)
        if current and current.kind=='account':return current
        return Principal('credential_retry','',secret)
    async def account(request,fresh=False):
        p=await principal(request);require(p.kind=='account','ACCOUNT_REQUIRED',401)
        if fresh:identity.fresh(p)
        return p

    @public.get('/health/live')
    async def live(request:Request):return data(request,{'status':'live'})
    @public.get('/health/ready')
    async def ready(request:Request):
        runtime.coordinator.assert_authority()
        return data(request,{'status':'ready' if runtime.settings.admission else 'maintenance','mode':runtime.scope,'admission':runtime.scope in {'product','realtime'} and runtime.settings.admission,'identity_ready':runtime.settings.admission,'audio':not runtime.media.unavailable,'payments':billing.enabled and runtime.settings.admission and billing.external_adjustments_ready()})
    def network_limit(request,kind,capacity,seconds):
        address=request.headers.get('x-nt-client-ip') or (request.client.host if request.client else 'unknown')
        key=security.digest('network_rate',address+':'+str(int(time.time()//3600)))
        identity.limiter.take((kind,key),capacity,seconds)

    @public.get('/api/v1/bootstrap')
    async def bootstrap(request:Request):
        from app.domain.projections import BootstrapView
        network_limit(request,'bootstrap',200,60)
        p=await identity.resolve(cookies(request))
        if not p:p=identity.new_bootstrap()
        preauth=identity.bootstrap_principal(cookies(request).get('bootstrap'))
        if not preauth:preauth=p if p.kind=='bootstrap' else identity.new_bootstrap()
        scoped_csrf={};scoped_subjects={}
        for scope_kind in ('case','financial','deletion'):
            scoped=await identity.resolve(cookies(request),scope=scope_kind)
            if scoped and scoped.kind==scope_kind:
                scoped_csrf[scope_kind]=security.csrf(scoped.token);scoped_subjects[scope_kind]=scoped.scope
        result=data(request,BootstrapView.model_validate({'csrf':security.csrf(p.token),'scoped_csrf':scoped_csrf,'scoped_subjects':scoped_subjects,'identity_kind':p.kind,'policy_version':identity.policy_version,'policy_digest':identity.policy_digest,'policy':runtime.policy.public(),
                             'gates':{'identity':runtime.settings.admission,'admission':runtime.settings.admission and runtime.scope in {'product','realtime'},'audio':not runtime.media.unavailable,'payments':billing.enabled and runtime.settings.admission and billing.external_adjustments_ready(),'payment_mode':'production' if runtime.settings.environment=='production' else 'sandbox'},
                             'owner_epoch':runtime.coordinator.epoch,'server_time':datetime.now().astimezone().isoformat()}).model_dump())
        cookie(result,'bootstrap',preauth.token)
        return result
    @private.get('/internal/v1/bootstrap')
    async def staff_bootstrap(request:Request):
        p=await identity.resolve(cookies(request),private=True)
        if not p:p=identity.new_bootstrap('private')
        result=data(request,{'csrf':security.csrf(p.token),'identity_kind':p.kind,'grants':sorted(p.grants)})
        if p.kind=='bootstrap':cookie(result,'admin_bootstrap',p.token)
        return result
    @public.post('/api/v1/operations/prepare')
    async def prepare(dto:m.Prepare,request:Request):
        p=await principal(request,allow_bootstrap=True)
        return data(request,identity.reservations.prepare(p.ref,dto.kind,dto.client_nonce))
    @public.post('/api/v1/auth/guest')
    async def guest(dto:m.Guest,request:Request):
        require(runtime.settings.admission,'ADMISSION_CLOSED',503)
        p=await principal(request,allow_bootstrap=True)
        result=identity.guest(p,dto);response=data(request,{'csrf':security.csrf(result.token),'identity_kind':'guest'},201)
        cookie(response,'guest',result.token);clear_cookie(response,'account');return response
    @public.post('/api/v1/auth/register')
    async def register(dto:m.Register,request:Request):
        network_limit(request,'register',10,60)
        require(runtime.settings.admission,'ADMISSION_CLOSED',503)
        p=await principal(request,allow_bootstrap=True)
        secret=await identity.registration(p,dto)
        response=data(request,{'csrf':security.csrf(secret),'identity_kind':'account'},201);cookie(response,'account',secret);clear_cookie(response,'guest');return response
    @public.post('/api/v1/auth/login')
    async def login(dto:m.Login,request:Request):
        network_limit(request,'login',20,60)
        p=await principal(request,allow_bootstrap=True)
        result=await identity.login(p,dto)
        if 'secret' not in result:return JSONResponse({'data':result,'error':{'code':'SESSION_LIMIT','message':'Choose one owned session to revoke.','retryable':False},'request_id':request.state.request_id},409)
        response=data(request,{'csrf':security.csrf(result['secret']),'identity_kind':'account'});cookie(response,'account',result['secret']);clear_cookie(response,'guest');return response
    @public.get('/api/v1/auth/session-limit')
    async def session_limit_list(request:Request):return data(request,await identity.session_limit(await principal(request,allow_bootstrap=True)))
    @public.post('/api/v1/auth/session-limit/{session_ref}')
    async def session_limit_resolve(session_ref:UUID,request:Request):
        p=await principal(request,allow_bootstrap=True)
        result=await identity.session_limit(p,str(session_ref))
        response=data(request,{'csrf':security.csrf(result['secret']),'identity_kind':'account'});cookie(response,'account',result['secret']);clear_cookie(response,'guest');return response
    @public.post('/api/v1/auth/reauth')
    async def reauth(dto:m.Reauth,request:Request):
        await identity.reauthenticate(await account(request),dto.password);return data(request,{'reauthenticated':True})
    @public.post('/api/v1/auth/recover')
    async def recover(dto:m.Recover,request:Request):
        await identity.recover(await principal(request,allow_bootstrap=True),dto);return data(request,{'recovered':True,'next':'login'})
    @public.post('/api/v1/auth/logout')
    @public.post('/api/v1/auth/logout-all')
    async def logout(request:Request):
        p=await principal(request,allow_bootstrap=True)
        if request.url.path.endswith('logout-all'):require(p.kind=='account','ACCOUNT_REQUIRED',401)
        await identity.logout(p,request.url.path.endswith('logout-all'))
        values=cookies(request)
        async with db.transaction('support') as connection:
            for kind in ('case','financial','deletion'):
                if values.get(kind):await connection.execute('DELETE FROM nt.scoped_status_sessions WHERE token_hmac=%s',(security.digest('scope_session',values[kind]),))
        response=data(request,{'logged_out':True})
        for kind in ('account','guest','case','financial','deletion'):clear_cookie(response,kind)
        return response
    @public.post('/api/v1/me/recovery/rotate')
    async def recovery_rotate(dto:m.RotateRecovery,request:Request):
        secret=await identity.credential_change(await credential_principal(request),dto,'rotate_recovery')
        response=data(request,{'rotated':True,'csrf':security.csrf(secret)});cookie(response,'account',secret);return response
    @public.post('/api/v1/me/password')
    async def password_change(dto:m.PasswordChange,request:Request):
        secret=await identity.credential_change(await credential_principal(request),dto,'password_change')
        response=data(request,{'csrf':security.csrf(secret),'changed':True});cookie(response,'account',secret);return response
    @public.get('/api/v1/me')
    async def me(request:Request):
        p=await principal(request);require(p.kind in {'account','guest'},'ACCOUNT_REQUIRED',401)
        from app.domain.projections import owner,OwnerResponse
        current=True
        entitlement=await billing.entitlement(p) if runtime.scope=='product' else {'available_seconds':0,'premium_until':0,'entitlement_revision':0}
        if p.kind=='account':
            async with db.transaction() as connection:
                p.account=await identity.lock_account(connection,p)
                current=await runtime.accounts.current_policy(connection,p.account_id)
        return data(request,OwnerResponse.model_validate(owner(p)|{'policy_current':current,'entitlement':entitlement}).model_dump())
    @public.patch('/api/v1/me/profile')
    async def profile(dto:m.ProfileUpdate,request:Request):return data(request,await runtime.accounts.profile(await principal(request),dto))
    @public.patch('/api/v1/me/preferences')
    async def preferences(dto:m.Preferences,request:Request):
        return data(request,await runtime.accounts.preferences(await principal(request),dto))
    @public.post('/api/v1/me/consents')
    async def consent(dto:m.ConsentChange,request:Request):return data(request,await runtime.accounts.consent(await principal(request),dto))
    @public.get('/api/v1/me/consent-proof')
    async def consent_proof(request:Request):return data(request,await runtime.accounts.proof(await principal(request)))
    @public.post('/api/v1/me/policy-acceptance')
    async def policy_acceptance(dto:m.PolicyAcceptance,request:Request):return data(request,await runtime.accounts.accept_policy(await account(request),dto))
    @public.get('/api/v1/me/sessions')
    async def sessions(request:Request):
        return data(request,await runtime.accounts.sessions(await account(request)))
    @public.delete('/api/v1/me/sessions/{ref}')
    async def revoke_session(ref:UUID,request:Request):
        result=await runtime.accounts.revoke(await account(request,True),str(ref));response=data(request,result)
        if result['current']:clear_cookie(response,'account')
        return response
    @public.get('/api/v1/me/notices')
    async def notices(request:Request):
        p=await account(request)
        async with db.transaction() as connection:rows=await many(connection,'SELECT id,kind,safe_payload,issued_at,seen_at FROM nt.account_notices WHERE account_id=%s AND expires_at>now() ORDER BY issued_at DESC LIMIT 50',(p.account_id,))
        return data(request,{'items':rows})
    @public.post('/api/v1/me/notices/{ref}/seen')
    async def notice_seen(ref:str,request:Request):
        p=await account(request)
        async with db.transaction() as connection:await connection.execute('UPDATE nt.account_notices SET seen_at=COALESCE(seen_at,now()) WHERE account_id=%s AND id=%s',(p.account_id,UUID(ref)))
        return data(request,{'seen':True})
    @public.get('/api/v1/catalogs')
    async def catalogs(request:Request):return data(request,runtime.catalogs)
    @public.get('/api/v1/friends')
    async def friends(request:Request):return data(request,await social.friends(await principal(request)))
    @public.delete('/api/v1/friends/{ref}')
    async def remove_friend(ref:str,request:Request,expected_relationship_revision:int):return data(request,await social.remove(await principal(request),ref,expected_relationship_revision))
    @public.post('/api/v1/blocks')
    async def block(dto:m.Block,request:Request):
        p=await principal(request)
        other=social.target(p.ref,dto.peer_handle) if dto.peer_handle in getattr(social,'relationship_handles',{}) else rt.resolve_peer(p.ref,dto.peer_handle) if hasattr(rt,'resolve_peer') else dto.peer_handle
        return data(request,await social.block(p,other))
    @public.get('/api/v1/blocks')
    async def blocks(request:Request,cursor:str|None=None):return data(request,await social.blocks(await account(request),cursor=cursor))
    @public.delete('/api/v1/blocks/{ref}')
    async def unblock(ref:str,request:Request):return data(request,await social.blocks(await account(request),ref))
    @public.post('/api/v1/reports/prepare')
    async def report_prepare(dto:m.ReportPrepare,request:Request):
        return data(request,support.prepare_report(await principal(request),dto.peer_handle,dto.interaction_handle,dto.block))
    @public.post('/api/v1/reports')
    async def report(dto:m.Report,request:Request):
        require(dto.category=='safety','CATEGORY_INVALID',422)
        require(dto.reason!='other' or len(dto.body.strip())>=10,'EXPLANATION_REQUIRED',422)
        p=await principal(request)
        snapshot=rt.snapshots.get(dto.snapshot_ref)
        if dto.block and snapshot and snapshot['identity']==p.ref and snapshot['until']>rt.clock():rt.block(p.ref,snapshot['other'],dto.snapshot_ref)
        previous=await support.report_retry(p,dto)
        if previous:return data(request,previous,201)
        snapshot=rt.snapshots.get(dto.snapshot_ref)
        require(snapshot and snapshot['identity']==p.ref and snapshot['until']>rt.clock(),'EVIDENCE_EXPIRED')
        require(not snapshot.get('attribution_only') or dto.attribution_only_accepted,'ATTRIBUTION_CONFIRMATION_REQUIRED',422)
        messages=[item for item in snapshot['messages'] if item['id'] in dto.selected_ids]
        require(len(messages)==len(set(dto.selected_ids)),'EVIDENCE_SELECTION_INVALID',422)
        if dto.block:await social.block(p,snapshot['other'],dto.snapshot_ref)
        result=await support.create(p,m.CaseCreate(**dto.model_dump(exclude={'snapshot_ref','selected_ids','reason','block','attribution_only_accepted'})),request.state.request_id,
            report={'snapshot_ref':dto.snapshot_ref,'reason':dto.reason,'other':snapshot['other'],'interaction':snapshot['interaction'],'messages':messages})
        return data(request,result,201)
    @public.post('/api/v1/support/cases')
    async def create_case(dto:m.CaseCreate,request:Request):return data(request,await support.create(await principal(request,allow_bootstrap=True),dto,request.state.request_id),201)
    @public.post('/api/v1/support/access')
    async def case_access(dto:m.Access,request:Request):
        await principal(request,allow_bootstrap=True)
        secret=await identity.scoped_access('case',dto.receipt_ref,dto.secret)
        scope_principal=await identity.resolve({'case':secret},scope='case')
        response=data(request,{'csrf':security.csrf(secret),'csrf_scope':'case','access_granted':True,'case_ref':scope_principal.scope});cookie(response,'case',secret);return response
    @public.get('/api/v1/support/cases')
    async def cases(request:Request,cursor:str|None=None,limit:int=20):return data(request,await support.list(await account(request),cursor,limit))
    @public.get('/api/v1/support/cases/{ref}')
    async def get_case(ref:str,request:Request):return data(request,await support.get(await principal(request,scope='case'),ref))
    @public.get('/api/v1/support/cases/{ref}/messages')
    async def messages(ref:str,request:Request,after_sequence:int=0,before_sequence:int|None=None,limit:int=50):return data(request,await support.messages(await principal(request,scope='case'),ref,after_sequence,before_sequence,limit))
    @public.post('/api/v1/support/cases/{ref}/messages')
    async def message(ref:str,dto:m.CaseMessage,request:Request):return data(request,await support.message(await principal(request,scope='case'),ref,dto,request.state.request_id),201)
    @public.post('/api/v1/support/cases/{ref}/seen')
    async def seen(ref:str,dto:m.Seen,request:Request):return data(request,await support.seen(await principal(request,scope='case'),ref,dto.seen_through,request.state.request_id))
    @public.post('/api/v1/support/cases/{ref}/continuations/prepare')
    async def continuation_prepare(ref:str,dto:m.Prepare,request:Request):
        p=await principal(request,scope='case');await support.get(p,ref)
        require(dto.kind=='case','OPERATION_KIND',422)
        return data(request,identity.reservations.prepare(p.ref,'case',dto.client_nonce))
    @public.post('/api/v1/support/cases/{ref}/continuations')
    async def continuation(ref:str,dto:m.CaseCreate,request:Request):
        return data(request,await support.create(await principal(request,scope='case'),dto,request.state.request_id,parent_ref=ref),201)
    @public.post('/api/v1/support/cases/{ref}/reopen')
    async def reopen(ref:str,dto:m.Versioned,request:Request):return data(request,await support.transition(await principal(request,scope='case'),ref,dto,'reopen',request.state.request_id))
    @public.post('/api/v1/privacy/requests')
    async def rights(dto:m.PrivacyRequest,request:Request):
        return data(request,await privacy.request_rights(await account(request),dto,support,request.state.request_id),201)
    @public.post('/api/v1/privacy/exports')
    async def export_create(dto:m.ExportRequest,request:Request):return data(request,await privacy.request_export(await account(request,True),dto),202)
    @public.get('/api/v1/privacy/exports/{ref}')
    async def export_status(ref:str,request:Request):return data(request,await privacy.export(await account(request),ref))
    @public.get('/api/v1/privacy/exports/{ref}/download')
    async def export_download(ref:str,request:Request):return Response(await privacy.export(await account(request),ref,True),media_type='application/json',headers={'Content-Disposition':'attachment; filename="notitle-export.json"','Cache-Control':'no-store'})
    @public.post('/api/v1/privacy/delete')
    async def delete(dto:m.Delete,request:Request):return data(request,await privacy.delete(await account(request,True),dto),202)
    @public.post('/api/v1/privacy/status/access')
    async def deletion_access(dto:m.Access,request:Request):
        await principal(request,allow_bootstrap=True)
        secret=await identity.scoped_access('deletion',dto.receipt_ref,dto.secret)
        response=data(request,{'csrf':security.csrf(secret),'csrf_scope':'deletion'});cookie(response,'deletion',secret);return response
    @public.get('/api/v1/privacy/status')
    async def deletion_status(request:Request):return data(request,await privacy.status(await principal(request,scope='deletion')))
    @public.get('/api/v1/privacy/retention')
    async def retention(request:Request):
        from app.domain.retention import public_registry
        return data(request,{'categories':public_registry(),'policy_version':identity.policy_version})
    @public.get('/api/v1/billing/plans')
    async def plans(request:Request):return data(request,await billing.plans())
    @public.get('/api/v1/billing/entitlement')
    async def entitlement(request:Request):return data(request,await billing.entitlement(await principal(request)))
    @public.post('/api/v1/billing/purchases')
    async def purchase(dto:m.Purchase,request:Request):return data(request,await billing.purchase(await account(request),dto))
    @public.get('/api/v1/billing/purchases')
    async def purchases(request:Request):return data(request,await billing.purchases(await principal(request,scope='financial')))
    @public.get('/api/v1/billing/purchases/{ref}')
    async def get_purchase(ref:str,request:Request):return data(request,await billing.get_purchase(await principal(request,scope='financial'),ref))
    @public.post('/api/v1/billing/purchases/{ref}/resume')
    async def resume_purchase(ref:str,request:Request):return data(request,await billing.resume_purchase(await account(request),ref))
    @public.get('/api/v1/billing/receipts')
    async def receipts(request:Request,cursor:int|None=None):
        require(cursor is None or cursor>0,'INVALID_CURSOR',422)
        return data(request,await billing.receipts(await principal(request,scope='financial'),cursor=cursor))
    @public.get('/api/v1/billing/receipts/{ref}')
    async def receipt(ref:str,request:Request):return data(request,await billing.receipts(await principal(request,scope='financial'),ref))
    @public.post('/api/v1/billing/receipts/access/prepare')
    async def financial_prepare(dto:m.Prepare,request:Request):
        p=await account(request,True);require(dto.kind=='financial','OPERATION_KIND',422)
        return data(request,identity.reservations.prepare(p.ref,'financial',dto.client_nonce))
    @public.post('/api/v1/billing/receipts/access/confirm')
    async def financial_confirm(dto:m.Proof,request:Request):return data(request,await privacy.bind_receipt(await account(request,True),'financial',dto))
    @public.post('/api/v1/billing/receipts/access')
    async def financial_access(dto:m.Access,request:Request):
        await principal(request,allow_bootstrap=True);secret=await identity.scoped_access('financial',dto.receipt_ref,dto.secret)
        response=data(request,{'csrf':security.csrf(secret),'csrf_scope':'financial'});cookie(response,'financial',secret);return response
    @public.post('/api/v1/billing/refund-requests')
    async def remedy_request(dto:m.CaseCreate,request:Request):
        p=await account(request);require(dto.category=='payment','CATEGORY_INVALID',422)
        return data(request,await support.create(p,dto,request.state.request_id),201)
    @public.post('/api/v1/webhooks/cashfree')
    async def webhook(request:Request):
        require(billing.provider,'PAYMENTS_UNAVAILABLE',503)
        return data(request,await billing.webhook(await request.body(),request.headers.get('x-webhook-timestamp',''),request.headers.get('x-webhook-signature',''),runtime.webhook_secret))
    @private.post('/internal/v1/auth/login')
    async def staff_login(dto:m.Mfa,request:Request):
        await principal(request,staff=True,allow_bootstrap=True)
        secret=await identity.staff_login(dto);response=data(request,{'csrf':security.csrf(secret),'identity_kind':'staff'});cookie(response,'admin',secret);return response
    @private.post('/internal/v1/auth/step-up')
    async def staff_step_up(dto:m.StaffStepUp,request:Request):
        return data(request,await identity.staff_step_up(await principal(request,staff=True),dto))
    @private.post('/internal/v1/auth/logout')
    async def staff_logout(request:Request):
        p=await principal(request,staff=True)
        async with db.transaction('private') as connection:await connection.execute('DELETE FROM nt.staff_sessions WHERE token_hmac=%s',(security.digest('staff_session',p.token),))
        response=data(request,{'logged_out':True});response.delete_cookie(runtime.cookie_name('admin'),path='/');return response
    @private.get('/internal/v1/cases')
    async def staff_cases(request:Request,cursor:str|None=None,limit:int=50,status:str|None=None,category:str|None=None):
        require(status in {None,'open','in_progress','waiting_user','resolved','closed'} and category in {None,'general','payment','safety','privacy','appeal','security'},'FILTER_INVALID',422)
        return data(request,await support.list(await principal(request,staff=True),cursor,limit,status,category))
    @private.get('/internal/v1/cases/{ref}')
    async def staff_case(ref:str,request:Request):return data(request,await support.get(await principal(request,staff=True),ref))
    @private.get('/internal/v1/cases/{ref}/messages')
    async def staff_messages(ref:str,request:Request,purpose:str,after_sequence:int=0,before_sequence:int|None=None,limit:int=50):return data(request,await support.messages(await principal(request,staff=True),ref,after_sequence,before_sequence,limit,purpose,request.state.request_id))
    @private.post('/internal/v1/cases/{ref}/messages')
    async def staff_message(ref:str,dto:m.CaseMessage,request:Request):return data(request,await support.message(await principal(request,staff=True),ref,dto,request.state.request_id),201)
    @private.post('/internal/v1/cases/{ref}/seen')
    async def staff_seen(ref:str,dto:m.Seen,request:Request):return data(request,await support.seen(await principal(request,staff=True),ref,dto.seen_through,request.state.request_id))
    @private.post('/internal/v1/cases/{ref}/claim')
    async def claim(ref:str,dto:m.Versioned,request:Request):return data(request,await support.transition(await principal(request,staff=True),ref,dto,'claim',request.state.request_id))
    @private.post('/internal/v1/cases/{ref}/assignment')
    async def assignment(ref:str,dto:m.Assignment,request:Request):return data(request,await support.transition(await principal(request,staff=True),ref,dto,'assignment',request.state.request_id))
    @private.post('/internal/v1/cases/{ref}/status')
    async def status(ref:str,dto:m.CaseStatus,request:Request):return data(request,await support.transition(await principal(request,staff=True),ref,dto,'status',request.state.request_id))
    @private.get('/internal/v1/cases/{ref}/notes')
    async def notes(ref:str,request:Request):return data(request,await support.notes(await principal(request,staff=True),ref,request.state.request_id))
    @private.post('/internal/v1/cases/{ref}/notes')
    async def note(ref:str,dto:m.CaseMessage,request:Request):return data(request,await support.notes(await principal(request,staff=True),ref,request.state.request_id,dto.body,dto.client_nonce),201)
    @private.post('/internal/v1/billing/refunds/preview')
    async def refund_preview(dto:m.RefundPreview,request:Request):return data(request,await billing.preview(await principal(request,staff=True),dto))
    @private.post('/internal/v1/billing/refunds/confirm')
    async def refund_confirm(dto:m.Confirm,request:Request):return data(request,await billing.confirm(await principal(request,staff=True),dto.preview))
    @private.get('/internal/v1/billing/reviews')
    async def financial_reviews(request:Request,cursor:str|None=None):
        return data(request,await billing.reviews.list(await principal(request,staff=True),request.state.request_id,cursor=cursor))
    @private.post('/internal/v1/billing/reviews/{ref}/refresh')
    async def financial_review_refresh(ref:str,request:Request):
        return data(request,await billing.reviews.refresh(await principal(request,staff=True),ref,request.state.request_id))
    @private.post('/internal/v1/billing/reviews/{ref}/preview')
    async def financial_review_preview(ref:str,dto:m.ExternalResolution,request:Request):
        return data(request,await billing.reviews.preview(await principal(request,staff=True),ref,dto,request.state.request_id))
    @private.post('/internal/v1/billing/reviews/confirm')
    async def financial_review_confirm(dto:m.Confirm,request:Request):
        return data(request,await billing.reviews.confirm(await principal(request,staff=True),dto.preview,request.state.request_id))
    @private.get('/internal/v1/analytics/summary')
    async def analytics_summary(request:Request):return data(request,await runtime.analytics.summary(await principal(request,staff=True)))
    @private.get('/internal/v1/analytics/series')
    async def analytics_series(request:Request,metric_id:int,start:datetime,end:datetime,resolution:str='hour'):return data(request,await runtime.analytics.series(await principal(request,staff=True),metric_id,start,end,resolution))
    @private.get('/internal/v1/health')
    async def private_health(request:Request):
        p=await principal(request,staff=True);p.permission('operations.read')
        return data(request,{'owner_epoch':runtime.coordinator.epoch,'worker_error':runtime.worker.last_error,'relay_available':not runtime.media.unavailable,'admission':runtime.settings.admission})
    @private.get('/internal/v1/audit')
    async def audit(request:Request):
        p=await principal(request,staff=True);p.permission('audit.read')
        async with db.transaction('private') as connection:rows=await many(connection,'SELECT actor_ref,purpose_code,object_type,object_ref,action,created_at FROM nt.access_audit ORDER BY created_at DESC LIMIT 50')
        return data(request,{'items':rows})
    @private.get('/internal/v1/release/evidence')
    async def evidence(request:Request):
        p=await principal(request,staff=True);p.permission('operations.read');return data(request,runtime.settings.release_evidence)

    @private.get('/internal/v1/reports/{ref}')
    async def report_read(ref:str,request:Request,purpose:str='safety_review'):
        return data(request,await runtime.moderation.report(await principal(request,staff=True),ref,purpose,request.state.request_id))
    @private.post('/internal/v1/decisions/preview')
    async def decision_preview(dto:m.Decision,request:Request):
        return data(request,await runtime.moderation.preview(await principal(request,staff=True),dto))
    @private.post('/internal/v1/decisions/confirm')
    async def decision_confirm(dto:m.Confirm,request:Request):
        return data(request,await runtime.moderation.confirm(await principal(request,staff=True),dto.preview,request.state.request_id))
    @private.get('/internal/v1/legal/rules')
    async def legal_rules(request:Request):
        p=await principal(request,staff=True);p.permission('cases.legal')
        return data(request,{'reviewed':support.legal.reviewed,'rules':support.legal.pack.get('rules',[])})
    @private.post('/internal/v1/cases/{ref}/classification')
    async def classification(ref:str,dto:m.ObligationCreate,request:Request):
        return data(request,await support.classify(await principal(request,staff=True),ref,dto,request.state.request_id))
    @private.post('/internal/v1/cases/{ref}/obligations/complete')
    async def obligation_complete(ref:str,dto:m.ObligationComplete,request:Request):
        return data(request,await runtime.moderation.obligations(await principal(request,staff=True),ref,dto))
    @private.get('/internal/v1/privacy/requests')
    async def privacy_queue(request:Request):
        p=await principal(request,staff=True);p.permission('privacy.read')
        async with db.transaction('private') as connection:
            rows=await many(connection,'SELECT id,kind,verification_state,deadline,status FROM nt.privacy_requests ORDER BY deadline NULLS LAST LIMIT 50')
        return data(request,{'items':rows})

    @private.post('/internal/v1/auth/recovery')
    async def staff_recovery(dto:m.StaffRecovery,request:Request):
        await principal(request,staff=True,allow_bootstrap=True)
        secret=await identity.staff_recovery(dto)
        response=data(request,{'csrf':security.csrf(secret),'identity_kind':'staff'});cookie(response,'admin',secret);return response
    @private.post('/internal/v1/privacy/holds/preview')
    async def hold_preview(dto:m.HoldPreview,request:Request):
        return data(request,await privacy.hold_preview(await principal(request,staff=True),dto))
    @private.post('/internal/v1/privacy/holds/confirm')
    async def hold_confirm(dto:m.Confirm,request:Request):
        return data(request,await privacy.hold_confirm(await principal(request,staff=True),dto.preview))
    @private.post('/internal/v1/privacy/holds/{ref}/release/preview')
    async def release_hold_preview(ref:str,dto:m.Reason,request:Request):
        return data(request,await privacy.release_preview(await principal(request,staff=True),ref,dto.reason))
    @private.post('/internal/v1/privacy/holds/release/confirm')
    async def release_hold_confirm(dto:m.Confirm,request:Request):
        return data(request,await privacy.release_confirm(await principal(request,staff=True),dto.preview))
    @private.get('/internal/v1/privacy/holds')
    async def privacy_holds(request:Request):
        p=await principal(request,staff=True);p.permission('privacy.holds')
        async with db.transaction('private') as connection:
            rows=await many(connection,'SELECT id,subject_ref,scope,review_at,expires_at,state FROM nt.legal_holds ORDER BY review_at LIMIT 50')
        return data(request,{'items':rows})
    if runtime.scope=='identity':
        from .identity_scope import filter_identity_routes
        filter_identity_routes(public,private)
    else:
        from .realtime import install_realtime
        install_realtime(public,runtime,principal,data)
        if runtime.scope=='realtime':
            from .identity_scope import filter_identity_routes
            extra={'/api/v1/ws','/api/v1/ws/ticket','/api/v1/interactions/end','/api/v1/blocks','/api/v1/blocks/{ref}','/api/v1/friends','/api/v1/friends/{ref}','/api/v1/reports','/api/v1/reports/prepare'}
            filter_identity_routes(public,private,extra)
    return public,private
