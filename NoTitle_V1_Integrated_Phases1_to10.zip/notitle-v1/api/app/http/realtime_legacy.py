import asyncio
import hashlib
import json
import time
from uuid import UUID,uuid4
from fastapi import Request,WebSocket,WebSocketDisconnect
from app.domain.errors import DomainError,require
from app.domain.security import canonical,token
from app.repositories.database import one
from .models import Ticket

from app.domain.protocol import validate


def install_realtime(app,runtime,principal,data):
    identity,rt=runtime.identity,runtime.realtime
    @app.post('/api/v1/ws/ticket')
    async def ticket(dto:Ticket,request:Request):
        require(runtime.settings.admission,'ADMISSION_CLOSED',503)
        p=await principal(request);require(p.kind in {'account','guest'},'AUTHENTICATION_REQUIRED',401)
        original=rt.people.get(p.ref)
        stamp=(original.revision,original.generation) if original else None
        revisions=tuple(p.account.get(k,1) for k in ('consent_revision','profile_revision','preference_revision','auth_generation'))
        require(p.account.get('core_consent',True) and p.account.get('status','active')=='active','PARTICIPATION_UNAVAILABLE',403)
        require(p.ref not in identity.participation_fences,'PARTICIPATION_UNAVAILABLE',403)
        if p.kind=='account':
            async with runtime.db.transaction() as connection:
                require(await runtime.accounts.current_policy(connection,p.account_id),'POLICY_ACCEPTANCE_REQUIRED',409)
        if p.kind=='account':
            async with runtime.db.transaction() as connection:
                restricted=await one(connection,"SELECT 1 FROM nt.restrictions WHERE subject_ref=%s AND starts_at<=now() AND (ends_at IS NULL OR ends_at>now()) LIMIT 1",(p.ref,))
            require(not restricted,'PARTICIPATION_RESTRICTED',403)
        identity.limiter.take(('ticket',p.ref),5,60)
        entitlement=await runtime.billing.entitlement(p)
        await runtime.social.hydrate(p)
        current=await identity.resolve({p.kind:p.token})
        require(current and current.ref==p.ref and current.account.get('core_consent',True) and current.account.get('status','active')=='active' and p.ref not in identity.participation_fences,'PARTICIPATION_UNAVAILABLE',403)
        require(revisions==tuple(current.account.get(k,1) for k in ('consent_revision','profile_revision','preference_revision','auth_generation')),'AUTHORITY_CHANGED',409)
        person=rt.people.get(p.ref)
        require(stamp is None and person is None or person is not None and stamp==(person.revision,person.generation),'AUTHORITY_CHANGED',409)
        rt.enter(p.ref,{k:current.account[k] for k in ('display_name','gender','topic_id','bio')}|{'professional':current.account.get('professional',{})},p.kind=='account',entitlement['premium_until'])
        identity.prune();require(len(identity.tickets)<400,'TICKET_CAPACITY',503)
        secret=token()
        identity.tickets[runtime.security.digest('ticket',secret)]={'principal':p,'takeover':dto.takeover,'generation':dto.known_socket_generation,'until':time.monotonic()+60,'ref':p.ref}
        return data(request,{'ticket':secret,'expires_in':60,'owner_epoch':runtime.coordinator.epoch})

    @app.websocket('/api/v1/ws')
    async def socket(ws:WebSocket):
        if ws.headers.get('origin')!=runtime.settings.public_origin or ws.query_params:
            await ws.close(code=1008);return
        await ws.accept()
        p=None;generation=None
        try:
            hello=json.loads(await asyncio.wait_for(ws.receive_text(),5))
            require(isinstance(hello,dict) and set(hello)=={'type','ticket'} and hello['type']=='hello' and isinstance(hello['ticket'],str) and len(hello['ticket'])==43,'HELLO_INVALID',401)
            ticket=identity.tickets.pop(runtime.security.digest('ticket',hello['ticket']),None)
            require(ticket and ticket['until']>time.monotonic(),'TICKET_EXPIRED',401)
            p=ticket['principal']
            current=await identity.resolve({p.kind:p.token})
            require(current and current.ref==p.ref,'SESSION_EXPIRED',401)
            generation=rt.connect(p.ref,ticket['takeover'],ticket['generation'])
            person=rt.people[p.ref]
            async def write():
                while True:
                    runtime.coordinator.assert_authority()
                    require(person.connected and person.generation==generation,'SOCKET_REPLACED',401)
                    for event in rt.drain(p.ref):await asyncio.wait_for(ws.send_json(event),3)
                    await asyncio.sleep(.05)
            ordinary=asyncio.Queue(maxsize=2)
            async def process():
                nonlocal p
                while True:
                    raw=await ordinary.get()
                    command=None
                    try:
                        command=validate(raw)
                        current=await identity.resolve({p.kind:p.token})
                        require(current and current.ref==p.ref,'SESSION_EXPIRED',401);p=current
                        require(person.connected and person.generation==generation,'SOCKET_REPLACED',401)
                        require(command['owner_epoch']==runtime.coordinator.epoch and command['socket_generation']==generation,'STALE_SOCKET')
                        kind,payload=command['type'],command['payload']
                        digest=hashlib.sha256(canonical(command)).hexdigest()
                        previous=person.commands.get(command['command_id'])
                        if previous and previous[2]>rt.clock():
                            require(previous[0]==digest,'COMMAND_NONCE_CONFLICT')
                            rt.emit(p.ref,'command.ack',previous[1]);continue
                        require(command['interaction_epoch']==person.revision,'STALE_INTERACTION')
                        if kind not in {'interaction.end','queue.cancel','call.end','call.cancel','heartbeat'}:identity.limiter.take(('ws',p.ref),30,10)
                        if kind not in {'heartbeat','session.resume','interaction.end','queue.cancel','call.end','call.cancel'}:
                            require(p.account.get('core_consent',True) and p.account.get('status','active')=='active','PARTICIPATION_UNAVAILABLE',403)
                        result={}
                        if kind in {'queue.join','interaction.next'}:
                            revision=person.revision
                            entitlement=await runtime.billing.entitlement(p)
                            require(person.revision==revision and person.generation==generation and person.connected,'STALE_INTERACTION')
                            person.premium_until=entitlement['premium_until']
                            if kind=='interaction.next':rt.end(p.ref,'next')
                            prefs=p.account.get('preferences',{})
                            professional={key:prefs.get(key,[]) for key in ('industry','role','experience','interests','topics')} if prefs.get('professional_enabled') and p.account.get('professional_consent') else {}
                            rt.join(p.ref,payload['gender'],professional)
                        elif kind=='queue.cancel':
                            if rt.waiters.pop(p.ref,None):runtime.metrics.add('searches_cancelled')
                            rt.emit(p.ref,'queue.cancelled',{})
                        elif kind=='interaction.end':rt.end(p.ref)
                        elif kind=='text.send':result=rt.text(p.ref,payload['text'])
                        elif kind=='text.delivered':rt.delivered(p.ref,payload['message_id'])
                        elif kind in {'friend.request','friend.respond'}:
                            interaction=rt.current(p.ref);members=(interaction.left,interaction.right)
                            revisions={member:rt.people[member].revision for member in members}
                            durable=all(rt.people[member].registered for member in members)
                            result=rt.friend_request(p.ref,durable) if kind=='friend.request' else rt.friend_respond(p.ref,payload['accept'],durable)
                            if result.get('status')=='accepted' and durable:
                                await runtime.social.save_friend(*members,revisions)
                                rt.finish_friend(rt.pair(*members))
                            result.pop('pair',None)
                        elif kind=='friend.invite':rt.invite(p.ref,payload['peer_handle'])
                        elif kind=='friend.invite.respond':rt.invite_respond(p.ref,payload['peer_handle'],payload['accept'])
                        elif kind=='call.request':
                            require(not runtime.media.unavailable,'AUDIO_UNAVAILABLE',503)
                            result=rt.call_request(p.ref)
                        elif kind=='call.respond':await runtime.media.accept(p.ref,payload['accept'])
                        elif kind in {'call.end','call.cancel'}:rt.end_call(rt.current(p.ref),'ended')
                        elif kind in {'call.sdp','call.ice'}:runtime.media.signal(p.ref,kind,payload)
                        elif kind=='call.connected':runtime.media.connected(p.ref,payload['call_id'])
                        elif kind=='call.refresh':
                            identity.limiter.take(('call_refresh',p.ref),1,240)
                            await runtime.media.refresh(p.ref,payload['call_id'])
                        elif kind=='session.resume':rt.emit(p.ref,'interaction.resumed',rt.describe(p.ref))
                        elif kind=='heartbeat':result={'server_time':time.time()}
                        if kind!='heartbeat':person.last_action=rt.clock();await identity.foreground(p)
                        acknowledgment={'command_id':command['command_id'],'ok':True,**result}
                        require(len(canonical(acknowledgment))<=512,'ACK_LIMIT')
                        person.commands[command['command_id']]=(digest,acknowledgment,rt.clock()+120)
                        while len(person.commands)>128:person.commands.popitem(last=False)
                        rt.emit(p.ref,'command.ack',acknowledgment)
                    except (DomainError,ValueError,KeyError,TypeError) as exc:
                        rt.emit(p.ref,'command.error',{'command_id':command.get('command_id') if command else None,'code':getattr(exc,'code','INVALID_COMMAND')})
            async def read():
                # Safety controls execute synchronously, even while ordinary effects await IO.
                while True:
                    raw=await asyncio.wait_for(ws.receive_text(),45)
                    command=None
                    try:
                        command=validate(raw)
                        require(person.connected and person.generation==generation,'SOCKET_REPLACED',401)
                        if command['type'] not in {'interaction.end','queue.cancel','call.end','call.cancel'}:
                            require(not ordinary.full(),'COMMAND_CAPACITY',429)
                            ordinary.put_nowait(raw);continue
                        require(command['owner_epoch']==runtime.coordinator.epoch and command['socket_generation']==generation,'STALE_SOCKET')
                        digest=hashlib.sha256(canonical(command)).hexdigest()
                        previous=person.commands.get(command['command_id'])
                        if previous and previous[2]>rt.clock():
                            require(previous[0]==digest,'COMMAND_NONCE_CONFLICT')
                            rt.emit(p.ref,'command.ack',previous[1]);continue
                        require(command['interaction_epoch']==person.revision,'STALE_INTERACTION')
                        kind=command['type']
                        if kind=='interaction.end':rt.end(p.ref)
                        elif kind=='queue.cancel':
                            if rt.waiters.pop(p.ref,None):runtime.metrics.add('searches_cancelled')
                            rt.emit(p.ref,'queue.cancelled',{})
                            person.revision+=1
                        else:rt.end_call(rt.current(p.ref),'ended')
                        result={'command_id':command['command_id'],'ok':True}
                        person.commands[command['command_id']]=(digest,result,rt.clock()+120)
                        while len(person.commands)>128:person.commands.popitem(last=False)
                        rt.emit(p.ref,'command.ack',result)
                    except (DomainError,ValueError,KeyError,TypeError) as exc:
                        rt.emit(p.ref,'command.error',{'command_id':command.get('command_id') if command else None,'code':getattr(exc,'code','INVALID_COMMAND')})
            tasks=[asyncio.create_task(write()),asyncio.create_task(read()),asyncio.create_task(process())]
            try:
                done,pending=await asyncio.wait(tasks,return_when=asyncio.FIRST_COMPLETED)
                for task in done:task.result()
            finally:
                for task in tasks:task.cancel()
                await asyncio.gather(*tasks,return_exceptions=True)
        except (WebSocketDisconnect,Exception):
            try:await ws.close(code=1008)
            except Exception:pass
        finally:
            if p and p.ref in rt.people and rt.people[p.ref].generation==generation:rt.disconnect(p.ref)
