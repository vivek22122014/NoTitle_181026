from uuid import uuid4
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException
from app.coordinator.core import Fenced

def create_apps(coordinator):
    def app(title):
        api = FastAPI(title=title, docs_url=None, redoc_url=None, openapi_url=None)
        @api.middleware("http")
        async def security(request: Request, call_next):
            request.state.request_id = str(uuid4())
            response = await call_next(request)
            response.headers.update({"Cache-Control":"no-store", "X-Content-Type-Options":"nosniff",
                                     "X-Request-ID":request.state.request_id})
            return response
        @api.exception_handler(HTTPException)
        async def http_error(request, exc):
            return error(request, exc.status_code, "NOT_FOUND" if exc.status_code==404 else "UNAVAILABLE")
        @api.exception_handler(RequestValidationError)
        async def invalid(request, exc):
            return error(request, 422, "INVALID_INPUT")
        @api.exception_handler(Exception)
        async def unexpected(request, exc):
            return error(request, 500, "INTERNAL_ERROR")
        return api
    def error(request, status, code):
        return JSONResponse({"error":{"code":code,"message":"Request cannot be completed",
                            "retryable":status>=500},"request_id":request.state.request_id},status_code=status)
    public, private = app("NoTitle public foundation"), app("NoTitle private foundation")
    @public.get("/health/live")
    async def live(request: Request):
        return {"data":{"status":"live"},"request_id":request.state.request_id}
    @public.get("/health/ready")
    async def ready(request: Request):
        try:
            coordinator.assert_authority()
        except Fenced:
            return error(request, 503, "OWNER_UNAVAILABLE")
        # This separately selected foundation application never mounts product APIs.
        return {"data":{"status":"maintenance","mode":"foundation","admission":False},
                "request_id":request.state.request_id}
    @private.get("/internal/v1/health")
    async def private_health(request: Request):
        # Loopback alone does not authorize staff. Phase 3/5 add MFA and grant checks.
        return error(request, 401, "AUTHENTICATION_REQUIRED")
    return public, private
