from typing import Literal
from uuid import UUID
import unicodedata
from pydantic import BaseModel, ConfigDict, Field, field_validator


class DTO(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    @field_validator('client_nonce',check_fields=False)
    @classmethod
    def canonical_nonce(cls,value):
        if str(UUID(value))!=value:raise ValueError('Canonical UUID required')
        return value

    @field_validator('password',check_fields=False)
    @classmethod
    def password_bytes(cls,value):
        if len(value.encode())>512:raise ValueError('Password exceeds byte limit')
        return value


class Profile(DTO):
    display_name: str = Field(min_length=2, max_length=24)
    gender: Literal["male", "female", "other"]
    topic_id: Literal["general", "career", "technology", "wellbeing", "leadership", "creativity"] = "general"
    bio: str = Field(default="", max_length=160)

    @field_validator('display_name','bio')
    @classmethod
    def safe_profile_text(cls,value,info):
        if any(unicodedata.category(c) in {'Cc','Cf','Cs'} for c in value):raise ValueError('Controls are not allowed')
        if info.field_name=='display_name':
            normalized=unicodedata.normalize('NFKC',value).casefold().strip()
            if len(normalized)<2 or normalized in {'admin','administrator','moderator','support','system','official','notitle'}:
                raise ValueError('Choose a non-staff display name')
        return value


class Consents(DTO):
    adult: bool
    terms: bool
    core: bool
    professional: bool = False
    policy_version: str = Field(max_length=40)
    policy_digest: str = Field(pattern=r'^[0-9a-f]{64}$')

class PolicyAcceptance(Consents):
    expected_revision: int = Field(ge=1)
    client_nonce: str = Field(pattern=r'^[0-9a-f-]{36}$')

class ConsentChange(DTO):
    purpose: Literal['core','professional']
    choice: bool
    policy_version: str = Field(max_length=40)
    policy_digest: str = Field(pattern=r'^[0-9a-f]{64}$')
    expected_revision: int = Field(ge=1)
    client_nonce: str = Field(pattern=r'^[0-9a-f-]{36}$')
    text_digest: str = Field(pattern=r'^[0-9a-f]{64}$')

class ProfileUpdate(Profile):
    expected_revision: int = Field(ge=1)


class Guest(Profile):
    consents: Consents


class Proof(DTO):
    reservation_id: str = Field(pattern=r'^[0-9a-f]{32}$')
    secret: str = Field(pattern=r'^[A-Za-z0-9_-]{43}$')
    saved: bool


class Register(Guest):
    username: str = Field(min_length=4, max_length=24)
    password: str = Field(min_length=12, max_length=128)
    proof: Proof
    client_nonce: str = Field(pattern=r"^[0-9a-f-]{36}$")


class Credentials(DTO):
    username: str = Field(min_length=4, max_length=24)
    password: str = Field(min_length=12, max_length=128)

class Login(Credentials):
    end_guest: bool = False


class Reauth(DTO):
    password: str = Field(min_length=12, max_length=128)


class Recover(DTO):
    username: str = Field(min_length=4, max_length=24)
    recovery_secret: str = Field(min_length=43, max_length=43)
    password: str = Field(min_length=12, max_length=128)
    proof: Proof
    client_nonce: str = Field(pattern=r'^[0-9a-f-]{36}$')


class Prepare(DTO):
    kind: Literal["recovery", "case", "financial", "deletion"]
    client_nonce: str = Field(pattern=r"^[0-9a-f-]{36}$")


class CaseMessage(DTO):
    body: str = Field(min_length=1, max_length=4000)
    client_nonce: str = Field(pattern=r"^[0-9a-f-]{36}$")
    @field_validator("body")
    @classmethod
    def bytes_limit(cls, value):
        if len(value.encode()) > 8192:
            raise ValueError("Message exceeds byte limit")
        return value


class CaseCreate(CaseMessage):
    category: Literal["general", "payment", "safety", "privacy", "appeal", "security"]
    subject: str = Field(min_length=1, max_length=120)
    proof: Proof | None = None


class Access(DTO):
    receipt_ref: str = Field(pattern=r'^[0-9a-f]{32}$')
    secret: str = Field(pattern=r'^[A-Za-z0-9_-]{43}$')


class Seen(DTO):
    seen_through: int = Field(ge=0)


class Versioned(DTO):
    expected_version: int = Field(ge=1)
    reason: str = Field(min_length=2, max_length=300)
    client_nonce: str = Field(pattern=r"^[0-9a-f-]{36}$")


class CaseStatus(Versioned):
    target_status: Literal["open", "in_progress", "waiting_user", "resolved", "closed"]


class Assignment(Versioned):
    staff_ref: str | None = Field(default=None, max_length=36)


class Ticket(DTO):
    takeover: bool = False
    known_socket_generation: int = Field(default=0, ge=0)


class Purchase(DTO):
    plan_code: Literal["Short3", "Week7", "Month30", "Annual365"]
    plan_version: str = Field(max_length=40)
    policy_version: str = Field(max_length=40)
    policy_accepted: bool
    client_nonce: str = Field(pattern=r"^[0-9a-f-]{36}$")
    payment_phone: str = Field(pattern=r"^[0-9]{10}$")


class RefundPreview(DTO):
    purchase_ref: str = Field(max_length=32)
    amount_paise: int = Field(gt=0)
    seconds: int = Field(ge=0)
    remedy_basis: Literal["payment_error", "statutory_remedy", "provider_bank_direction"]
    evidence_ref: str = Field(min_length=4, max_length=100)
    reason: str = Field(min_length=10, max_length=300)


class Confirm(DTO):
    preview: str = Field(min_length=32, max_length=32)


class ExternalResolution(DTO):
    action: Literal['restore','revoke']
    seconds_to_revoke: int | None = Field(default=None, ge=0)
    reason: str = Field(min_length=10, max_length=500)
    client_nonce: str = Field(pattern=r'^[0-9a-f-]{36}$')


class Mfa(Credentials):
    code: str = Field(pattern=r"^[0-9]{6}$")


class PrivacyRequest(CaseMessage):
    kind: Literal["access", "correction", "withdrawal", "complaint", "appeal"]


class Delete(DTO):
    proof: Proof
    confirmation: Literal["DELETE MY ACCOUNT"]


class Block(DTO):
    peer_handle: str = Field(min_length=32, max_length=32)


class ReportPrepare(DTO):
    peer_handle: str | None = Field(default=None,pattern=r'^[0-9a-f]{32}$')
    interaction_handle: str | None = Field(default=None,pattern=r'^[0-9a-f]{32}$')
    block: bool = True


class Report(CaseCreate):
    snapshot_ref: str = Field(pattern=r'^[0-9a-f]{32}$')
    selected_ids: list[str] = Field(default_factory=list,max_length=30)
    attribution_only_accepted: bool = False
    @field_validator('selected_ids')
    @classmethod
    def selected_message_ids(cls,value):
        import re
        if len(value)!=len(set(value)) or any(not re.fullmatch(r'[0-9a-f]{32}',item) for item in value):raise ValueError('Unique server message IDs required')
        return value

    reason: Literal["harassment", "threats", "doxxing", "confidentiality", "false_accusations", "scams", "impersonation", "underage", "sexual_misconduct", "spam", "other"]
    block: bool = True


class Preferences(DTO):
    expected_revision: int = Field(ge=1)
    gender: Literal["everyone", "male", "female", "other"] = "everyone"
    professional_enabled: bool = False
    industry: list[str] = Field(default_factory=list, max_length=5)
    role: list[str] = Field(default_factory=list, max_length=5)
    experience: list[str] = Field(default_factory=list, max_length=5)
    interests: list[str] = Field(default_factory=list, max_length=10)
    topics: list[str] = Field(default_factory=list, max_length=5)

class ExportRequest(DTO):
    client_nonce: str = Field(pattern=r'^[0-9a-f-]{36}$')

class Decision(DTO):
    case_ref: str = Field(min_length=32,max_length=32)
    subject_ref: str = Field(min_length=32,max_length=32)
    action: Literal['restrict','release']
    reason_code: Literal['harassment','threats','doxxing','underage','scam','impersonation','appeal_upheld','other']
    duration_hours: int = Field(ge=1,le=8760)
    reason: str = Field(min_length=10,max_length=300)

class ObligationComplete(DTO):
    obligation_ref: str = Field(max_length=36)
    evidence_ref: str = Field(min_length=4,max_length=100)
    expected_version: int = Field(ge=1)

class RotateRecovery(DTO):
    proof: Proof
    client_nonce: str = Field(pattern=r'^[0-9a-f-]{36}$')

class PasswordChange(DTO):
    password: str = Field(min_length=12,max_length=128)
    client_nonce: str = Field(pattern=r'^[0-9a-f-]{36}$')

class StaffRecovery(Credentials):
    recovery_code: str = Field(min_length=24,max_length=100)

class HoldPreview(DTO):
    subject_ref: str = Field(min_length=36,max_length=36)
    scope: str = Field(min_length=4,max_length=100)
    basis: str = Field(min_length=10,max_length=500)
    review_days: int = Field(ge=1,le=180)
    expires_days: int = Field(ge=1,le=365)

class Reason(DTO):
    reason: str = Field(min_length=10,max_length=300)

class ObligationCreate(DTO):
    rule_id: str | None = Field(default=None,min_length=1,max_length=80)
    expected_version: int = Field(ge=1)

class StaffStepUp(DTO):
    password: str = Field(min_length=12,max_length=128)
    code: str = Field(pattern=r'^[0-9]{6}$')
