from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, field_validator

class StrictDTO(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True, frozen=True)

class Peer(StrictDTO):
    peer_handle: UUID
    display_name: str = Field(min_length=2, max_length=24)
    gender: Literal["male", "female", "other"]
    topic_id: str = Field(min_length=1, max_length=40)
    bio: str = Field(max_length=160)

class TextPayload(StrictDTO):
    text: str = Field(min_length=1, max_length=2000)
    @field_validator("text")
    @classmethod
    def byte_limit(cls, text: str) -> str:
        if len(text.encode("utf-8")) > 6144:
            raise ValueError("UTF-8 limit exceeded")
        return text

class EndPayload(StrictDTO):
    interaction_handle: UUID

class CommandBase(StrictDTO):
    protocol_version: Literal[1]
    command_id: UUID
    owner_epoch: int = Field(ge=1)
    socket_generation: int = Field(ge=1)
    interaction_epoch: int = Field(ge=1)

class TextCommand(CommandBase):
    type: Literal["text.send"]
    payload: TextPayload

class EndCommand(CommandBase):
    type: Literal["interaction.end"]
    payload: EndPayload

Command = Annotated[TextCommand | EndCommand, Field(discriminator="type")]
