"""One owner, two loopback listeners and one signal supervisor in either mode."""
import asyncio
from contextlib import contextmanager
import signal
import socket
import sys
import resource

import uvicorn

from app.lifecycle import ownership
from app.repositories.ownership import OwnerLease
from app.settings import Settings
from app.supervision import supervise


class SupervisedServer(uvicorn.Server):
    @contextmanager
    def capture_signals(self):
        yield  # The runner owns signals for both listeners.


def bind(port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("127.0.0.1", port))
        sock.listen(128)
        sock.setblocking(False)
        return sock
    except BaseException:
        sock.close()
        raise


async def run(settings):
    # Ordinary conversations must never enter a process core dump.
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    # The lease is always released, even if configuration or a constructor fails.
    async with ownership(settings.dsn, OwnerLease.acquire) as owned:
        coordinator = owned.coordinator
        sockets, servers, tasks, installed_signals = [], [], [], []
        runtime = None
        stop = asyncio.Event()
        loop = asyncio.get_running_loop()
        try:
            for sig in (signal.SIGINT, signal.SIGTERM):
                loop.add_signal_handler(sig, stop.set)
                installed_signals.append(sig)
            async with owned.lease.conn.cursor() as cur:
                await cur.execute("SELECT protocol_version,schema_version FROM nt_system.foundation_metadata WHERE singleton")
                metadata = await cur.fetchone()
            supported = {(1, 1), (1, 2), (1, 3)} if settings.mode == "foundation" else {(1, 3)}
            if metadata not in supported:
                raise RuntimeError("SCHEMA_INCOMPATIBLE")
            if settings.mode != 'foundation':
                from app.domain.migration_contract import packaged_inventory,verify_applied
                async with owned.lease.conn.cursor() as cur:
                    await cur.execute('SELECT name,sha256 FROM nt_system.schema_migrations ORDER BY name')
                    applied=await cur.fetchall()
                verify_applied(packaged_inventory(),applied)
            if settings.mode == "foundation":
                from app.http.factory import create_apps
                apps = create_apps(coordinator)
            else:
                # Later-phase construction and integrations are absent in foundation mode.
                from app.http.product import create_product_apps
                from app.runtime import Runtime, ProductSettings
                runtime = Runtime(ProductSettings.load(settings.dsn), coordinator,scope=settings.mode)
                await runtime.open()
                apps = create_product_apps(runtime)
            coordinator.assert_authority()
            if stop.is_set():
                return
            # Reserve BOTH ports before scheduling either server; partial startup cannot admit.
            for port in (settings.public_port, settings.private_port):
                sockets.append(bind(port))
            for app, port, sock in zip(apps, (settings.public_port, settings.private_port), sockets):
                config = uvicorn.Config(
                    app, host="127.0.0.1", port=port, lifespan="off", workers=1,
                    access_log=False, log_level="warning", proxy_headers=False,
                    timeout_graceful_shutdown=3, limit_concurrency=256,
                    ws_max_size=65536, ws_max_queue=8, ws_per_message_deflate=False,
                )
                server = SupervisedServer(config)
                servers.append(server)
                tasks.append(asyncio.create_task(server.serve(sockets=[sock])))
            supervised = [*tasks, *(runtime.tasks if runtime else [])]
            await supervise(owned.lease, coordinator, supervised, stop, heartbeat_task=owned.heartbeat)
        finally:
            coordinator.fence()
            for server in servers:
                server.should_exit = True
            try:
                if tasks:
                    _, pending = await asyncio.wait(tasks, timeout=4)
                    for task in pending:
                        task.cancel()
                    await asyncio.gather(*tasks, return_exceptions=True)
            finally:
                for sock in sockets:
                    sock.close()
                try:
                    if runtime is not None:
                        await runtime.close()
                finally:
                    for sig in installed_signals:
                        loop.remove_signal_handler(sig)


def main():
    try:
        asyncio.run(run(Settings.load()))
    except KeyboardInterrupt:
        return
    except Exception:
        # No DSN, provider body or secret-bearing exception reaches logs.
        print("RUNNER_STOPPED: configuration, listener, schema or owner failure", file=sys.stderr)
        raise SystemExit(4)


if __name__ == "__main__":
    main()
