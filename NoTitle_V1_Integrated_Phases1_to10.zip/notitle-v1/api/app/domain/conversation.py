"""Bounded Phase 4 actor. Persistent effects are authorized outside these transitions."""
from collections import OrderedDict,deque
import copy,json,math,secrets,time
from dataclasses import dataclass
from uuid import uuid4
from .realtime import Realtime,Waiter,Interaction
from .conversation_contracts import EVENT,LIMITS,SendPayload
from .errors import require

@dataclass(frozen=True)
class PairReservation:
    id:str
    members:tuple[str,str]
    stamps:tuple
    until:float

class ConversationActor(Realtime):
    def __init__(self,*args,rng=None,**kwargs):
        super().__init__(*args,**kwargs);self.rng=rng or secrets.SystemRandom()
        self.reservations={};self.reserved=set();self.searches={};self.paused_ages={}
        self.maintenance=False;self.scan_checks=0;self.scan_seconds=0
        self.ended_handles=OrderedDict()

    def enter(self,identity,profile,registered=False,premium_until=0):
        previous=self.people.get(identity)
        if previous and previous.interaction:
            previous.pending_profile={k:profile[k] for k in ('display_name','gender','topic_id','bio')}
            previous.premium_until=premium_until;previous.registered=registered;return previous
        person=super().enter(identity,profile,registered,premium_until);person.registered=registered;return person

    def emit(self,identity,kind,data):
        person=self.people.get(identity)
        if not person:return
        if kind.startswith('call.') and 'interaction_handle' not in data:
            data=dict(data,interaction_handle=person.interaction)
        person.sequence+=1
        event=EVENT.validate_python({'type':kind,'data':data,'protocol_version':2,'server_sequence':person.sequence,
            'server_time':float(self.wall()),'owner_epoch':self.authority.epoch,'socket_generation':max(1,person.generation),'interaction_epoch':person.revision}).model_dump(mode='json',exclude_none=False)
        size=len(json.dumps(event,ensure_ascii=False).encode())
        if len(person.events)>=64 or person.event_bytes+size>262144:
            self.erase_events(identity);self.disconnect(identity);return
        person.events.append((event,size));person.event_bytes+=size

    def erase_events(self,identity,content_only=False):
        person=self.people.get(identity)
        if not person:return
        if content_only:
            person.events=deque((event,size) for event,size in person.events if event['type'] not in {'text.message','interaction.started','session.ready','state.snapshot'})
            person.event_bytes=sum(size for _,size in person.events)
        else:person.events.clear();person.event_bytes=0

    def connect(self,identity,takeover=False,known_generation=0):
        person=self.person(identity)
        require(not person.connected or takeover and known_generation==person.generation,'SOCKET_EXISTS')
        if person.connected:self.disconnect(identity)
        self.expire_grace()
        self.erase_events(identity);person.commands.clear();person.generation+=1
        person.connected=True;person.disconnected_at=None;person.last_action=self.clock()
        self.emit(identity,'session.ready',self.snapshot(identity))
        interaction=self.interactions.get(person.interaction)
        if interaction:
            other=interaction.right if interaction.left==identity else interaction.left
            if self.people[other].connected:self.emit(other,'state.snapshot',self.snapshot(other))
        return person.generation

    def disconnect(self,identity):
        person=self.people.get(identity)
        if not person or not person.connected:return
        super().disconnect(identity);self.searches.pop(identity,None);self.paused_ages.pop(identity,None)
        self.invalidate(identity)
        interaction=self.interactions.get(person.interaction)
        if interaction:
            other=interaction.right if interaction.left==identity else interaction.left
            self.emit(other,'interaction.interrupted',{'interaction_handle':interaction.id,'grace_expires_at':self.wall()+25})

    def peer(self,identity,viewer=None):
        if viewer is None:return super().peer(identity) # Retained later-phase relationship adapter, never Phase 4 wire.
        interaction=self.current(viewer)
        require(identity in (interaction.left,interaction.right) and identity!=viewer,'NOT_FOUND',404)
        return {'peer_handle':interaction.handles[identity],**{k:interaction.profiles[identity][k] for k in ('display_name','gender','topic_id','bio')}}

    def resolve_peer(self,viewer,handle):
        person=self.person(viewer);interaction=self.interactions.get(person.interaction)
        if interaction:
            other=interaction.right if interaction.left==viewer else interaction.left
            if interaction.handles[other]==handle:return other
        known=self.ended_handles.get((viewer,handle));require(known and known[1]>self.clock(),'NOT_FOUND',404);return known[0]

    def message_view(self,message,viewer):
        return {'id':message['id'],'sequence':message['sequence'],'sender':'me' if message['sender']==viewer else 'peer',
            'text':message['text'],'sent_at':float(message['sent_at']),'delivered':message['delivered'],
            'command_id':message.get('command_id') if message['sender']==viewer else None}

    def describe(self,identity):
        person=self.people[identity];interaction=self.interactions.get(person.interaction)
        if not interaction:return None
        other=interaction.right if interaction.left==identity else interaction.left
        deadlines=[p.disconnected_at+25 for p in (self.people[identity],self.people[other]) if not p.connected and p.disconnected_at is not None]
        return {'interaction_handle':interaction.id,'search_command_id':interaction.searches.get(identity),'peer':self.peer(other,identity),
            'messages':[self.message_view(m,identity) for m in interaction.messages],
            'interrupted':bool(deadlines),'grace_expires_at':float(self.wall()+max(0,min(deadlines)-self.clock())) if deadlines else None}

    def snapshot(self,identity):
        interaction=self.describe(identity);queue=self.searches.get(identity) if identity in self.waiters else None
        return {'state':'maintenance' if self.maintenance else 'interrupted' if interaction and interaction['interrupted'] else 'matched' if interaction else 'searching' if queue else 'idle',
            'queue':copy.deepcopy(queue),'interaction':interaction,'limits':dict(LIMITS)}

    def join(self,identity,preference='everyone',professional=None,*,general_talk=True,command_id=None):
        require(not self.maintenance,'ADMISSION_CLOSED',503)
        person=self.person(identity);old=self.waiters.get(identity);age=old.since if old else self.paused_ages.get(identity,self.clock())
        require(person.connected and not person.interaction,'NOT_AVAILABLE')
        require(preference in {'everyone','male','female','other'},'PREFERENCE_INVALID',422)
        require(preference=='everyone' or person.premium_until>self.wall(),'PREMIUM_REQUIRED',403)
        require(old or len(self.waiters)<100,'QUEUE_CAPACITY',503)
        self.paused_ages.pop(identity,None)
        if person.pending_profile:person.profile.update(person.pending_profile);person.pending_profile=None
        self.invalidate(identity);person.revision+=1
        relevance=professional if person.premium_until>self.wall() else {}
        self.waiters[identity]=Waiter(identity,age,preference,relevance or {},person.revision)
        self.waiters[identity].general_talk=general_talk or person.profile['topic_id']=='general'
        self.searches[identity]={'search_command_id':command_id or str(uuid4()),'joined_at':float(self.wall()-(self.clock()-age)),
            'gender':preference,'general_talk':self.waiters[identity].general_talk}
        if not old:self.metrics.add('searches_started');self.metrics.add('professional_enabled' if relevance else 'professional_disabled')
        self.emit(identity,'queue.waiting',self.searches[identity])

    def pause_preferences(self,identity):
        waiter=self.waiters.pop(identity,None)
        if waiter:self.paused_ages[identity]=waiter.since
        self.searches.pop(identity,None);self.invalidate(identity)
        if identity in self.people:
            self.people[identity].revision+=1
            if self.people[identity].interaction:self.emit(identity,'state.snapshot',self.snapshot(identity))
            else:self.emit(identity,'queue.paused',{'reason':'preferences_changed'})

    def score(self,anchor,candidate):
        now=self.clock();a,b=self.people[anchor.person],self.people[candidate.person]
        pair_time=self.recent.get(self.pair(anchor.person,candidate.person));wait=now-candidate.since
        penalty=60*math.exp(-(now-pair_time-4)/10) if pair_time is not None and now-pair_time<300 else 0
        topic=.5 if a.profile['topic_id']!='general' and a.profile['topic_id']==b.profile['topic_id'] else 0
        def relevance(waiter,other):
            if not waiter.professional or self.people[waiter.person].premium_until<=self.wall():return 0
            score=0
            for key,values in waiter.professional.items():
                if not values:continue
                overlap=set(values)&set(other.get(key,[]))
                score+=.1*len(overlap)/len(set(values)) if key=='interests' else .1*bool(overlap)
            return min(.5,score)
        general=getattr(anchor,'general_talk',True) or getattr(candidate,'general_talk',True)
        professional=0 if general else (relevance(anchor,b.profile.get('professional',{}))+relevance(candidate,a.profile.get('professional',{})))/2
        fade=max(0,1-max(now-anchor.since,wait)/5)
        return wait-penalty+fade*(topic+professional)

    def compatible(self,a,b):
        if a.person in self.reserved or b.person in self.reserved:return False
        if self.people[a.person].interaction or self.people[b.person].interaction:return False
        if any(w.gender!='everyone' and self.people[w.person].premium_until<=self.wall() for w in (a,b)):return False
        return super().compatible(a,b)

    def stamp(self,identity):
        p=self.person(identity);waiter=self.waiters.get(identity)
        return (p.revision,p.generation,id(waiter),p.premium_until>self.wall())

    def reserve_match(self,max_checks=10000,deadline=None):
        self.authority.assert_authority();started=time.perf_counter();checks=0
        deadline=min(deadline or started+.1,started+.1)
        for key,value in list(self.reservations.items()):
            if value.until<=self.clock():self.release(key)
        for anchor in sorted(tuple(self.waiters.values()),key=lambda w:w.since):
            if anchor.person in self.reserved:continue
            candidates=[]
            for candidate in tuple(self.waiters.values()):
                checks+=1
                if checks>max_checks or time.perf_counter()>deadline:self.scan_checks=checks-1;self.scan_seconds=time.perf_counter()-started;return None
                if self.compatible(anchor,candidate):candidates.append(candidate)
            if candidates:
                ranked=[(self.score(anchor,w),-w.since,w) for w in candidates];best=max((score,age) for score,age,_ in ranked)
                chosen=self.rng.choice([w for score,age,w in ranked if (score,age)==best])
                members=(anchor.person,chosen.person);reservation=PairReservation(uuid4().hex,members,tuple(self.stamp(p) for p in members),self.clock()+2)
                self.reservations[reservation.id]=reservation;self.reserved.update(members)
                self.scan_checks=checks;self.scan_seconds=time.perf_counter()-started;return reservation
        self.scan_checks=checks;self.scan_seconds=time.perf_counter()-started;return None

    def release(self,reference):
        reservation=self.reservations.pop(reference,None)
        if reservation:self.reserved.difference_update(reservation.members)

    def invalidate(self,identity):
        for key,value in list(self.reservations.items()):
            if identity in value.members:self.release(key)

    def publish(self,reservation):
        current=self.reservations.get(reservation.id)
        require(current is reservation and reservation.until>self.clock(),'MATCH_STALE')
        require(all(p in self.people and self.stamp(p)==stamp for p,stamp in zip(reservation.members,reservation.stamps)),'MATCH_STALE')
        left,right=reservation.members;self.release(reservation.id)
        require(self.compatible(self.waiters[left],self.waiters[right]),'MATCH_STALE')
        return self.start(left,right)

    def match(self):
        # Runtime uses reserve -> async authorization -> publish instead.
        reservation=self.reserve_match()
        while reservation:self.publish(reservation);reservation=self.reserve_match()

    def start(self,left,right):
        require(self.people[left].connected and self.people[right].connected,'NOT_AVAILABLE')
        self.next_epoch+=1;interaction=Interaction(uuid4().hex,left,right,self.next_epoch,self.clock())
        require(not self.blocked(left,right) and not self.people[left].interaction and not self.people[right].interaction,'NOT_AVAILABLE')
        interaction.handles={left:uuid4().hex,right:uuid4().hex};interaction.profiles={p:copy.deepcopy(self.people[p].profile) for p in (left,right)};interaction.next_sequence=0
        interaction.searches={p:self.searches.get(p,{}).get('search_command_id') for p in (left,right)}
        self.interactions[interaction.id]=interaction
        if self.pair(left,right) in self.recent:self.metrics.add('repeat_matches')
        for member in (left,right):
            waiter=self.waiters.pop(member,None);self.searches.pop(member,None);self.paused_ages.pop(member,None)
            if waiter:self.metrics.add('match_wait_ms',(self.clock()-waiter.since)*1000)
            self.people[member].interaction=interaction.id;self.people[member].revision+=1
        for member in (left,right):self.emit(member,'interaction.started',self.describe(member))
        self.metrics.add('matches');return interaction

    def cancel(self,identity):
        person=self.person(identity);self.invalidate(identity)
        if self.waiters.pop(identity,None):self.metrics.add('searches_cancelled')
        self.searches.pop(identity,None);self.paused_ages.pop(identity,None);person.revision+=1
        self.emit(identity,'queue.cancelled',{})

    def text(self,identity,body,command_id=None):
        interaction=self.current(identity)
        require(all(self.people[p].connected for p in (interaction.left,interaction.right)),'PEER_INTERRUPTED')
        SendPayload(interaction_handle=interaction.id,text=body)
        interaction.next_sequence+=1
        message={'id':uuid4().hex,'sender':identity,'sequence':interaction.next_sequence,'text':body,'sent_at':float(self.wall()),'delivered':False,'command_id':command_id}
        interaction.messages.append(message);interaction.bytes+=len(body.encode())
        while len(interaction.messages)>30 or interaction.bytes>65536:interaction.bytes-=len(interaction.messages.popleft()['text'].encode())
        for member in (interaction.left,interaction.right):self.emit(member,'text.message',{'interaction_handle':interaction.id,'message':self.message_view(message,member)})
        self.metrics.add('text_accepted');return {'message_id':message['id'],'sequence':message['sequence'],'status':'accepted'}

    def delivered(self,identity,message_id,sequence=None):
        interaction=self.current(identity)
        message=next((m for m in interaction.messages if m['id']==message_id and m['sender']!=identity and m['sequence']==sequence),None)
        require(message is not None,'MESSAGE_NOT_FOUND',404)
        if not message['delivered']:
            message['delivered']=True;self.emit(message['sender'],'text.delivered',{'interaction_handle':interaction.id,'message_id':message_id,'sequence':sequence})

    def end(self,identity,reason='ended'):
        person=self.person(identity);self.invalidate(identity);self.searches.pop(identity,None);self.paused_ages.pop(identity,None)
        interaction=self.interactions.get(person.interaction)
        if not interaction:
            self.waiters.pop(identity,None);person.revision+=1;self.emit(identity,'interaction.ended',{'reason':reason,'interaction_handle':None});return
        handle=interaction.id
        for viewer,other in ((interaction.left,interaction.right),(interaction.right,interaction.left)):
            self.ended_handles[(viewer,interaction.handles[other])]=(other,self.clock()+600)
        while len(self.ended_handles)>10000:self.ended_handles.popitem(last=False)
        for member in (interaction.left,interaction.right):self.erase_events(member,True);self.searches.pop(member,None);self.invalidate(member)
        # Base End erases the only ordinary text ring, requests and both memberships.
        # Its legacy ended event is adapted here to include the interaction handle.
        original=self.emit
        def adapted(member,kind,data):original(member,kind,data|{'interaction_handle':handle} if kind=='interaction.ended' else data)
        self.emit=adapted
        try:super().end(identity,reason)
        finally:self.emit=original

    def block(self,identity,other,snapshot_ref=None):
        person=self.person(identity);peer=self.people.get(other)
        known=any(viewer==identity and value[0]==other and value[1]>self.clock() for (viewer,_),value in self.ended_handles.items())
        current=peer and person.interaction and person.interaction==peer.interaction
        if not known:return super().block(identity,other,snapshot_ref)
        require(identity!=other,'NOT_FOUND',404);self.blocks.add((identity,other));self.friends.discard(self.pair(identity,other));self.invalidate(identity);self.invalidate(other)
        if current:self.end(identity,'blocked')

    def expire_grace(self):
        for identity,person in tuple(self.people.items()):
            if person.interaction and not person.connected and person.disconnected_at is not None and self.clock()-person.disconnected_at>=25:self.end(identity,'reconnect_expired')

    def tick(self):
        self.authority.assert_authority();self.expire_grace();now=self.clock()
        for interaction in tuple(self.interactions.values()):
            if interaction.call and interaction.call['state'] in {'ringing','connecting'} and now>=interaction.call['until']:self.end_call(interaction,'timeout')
        for identity,waiter in list(self.waiters.items()):
            person=self.people[identity]
            if person.premium_until<=self.wall():
                if waiter.gender!='everyone':
                    self.invalidate(identity);self.waiters.pop(identity,None);self.searches.pop(identity,None);self.paused_ages[identity]=waiter.since;person.revision+=1
                    self.emit(identity,'queue.paused',{'reason':'premium_expired'})
                else:waiter.professional={}
        self.recent={pair:stamp for pair,stamp in self.recent.items() if now-stamp<300}
        self.ended={key:value for key,value in self.ended.items() if value[2]>now}
        self.snapshots={key:value for key,value in self.snapshots.items() if value['until']>now}
        self.invites={key:value for key,value in self.invites.items() if value['until']>now}
        self.ended_handles=OrderedDict((key,value) for key,value in self.ended_handles.items() if value[1]>now)
        while len(self.ended)>10000:self.ended.pop(next(iter(self.ended)))
        for key,value in list(self.reservations.items()):
            if value.until<=now:self.release(key)
        for identity,person in tuple(self.people.items()):
            while person.commands and next(iter(person.commands.values()))[2]<=now:person.commands.popitem(last=False)
            if not person.connected and not person.interaction and now-person.last_action>1800:self.retire(identity)

    def fence(self):
        for person in self.people.values():person.events.clear();person.event_bytes=0;person.commands.clear()
        self.reservations.clear();self.reserved.clear();self.searches.clear();self.paused_ages.clear();self.ended_handles.clear()
        self.recent.clear();self.ended.clear();self.requests.clear();self.invites.clear();self.friends.clear();self.blocks.clear();super().fence()
