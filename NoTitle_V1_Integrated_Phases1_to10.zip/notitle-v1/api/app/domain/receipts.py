"""Immutable reviewed receipt facts; no guessed tax rates or merchant details."""
from .errors import require
from .ledger import PLANS
from copy import deepcopy

class ReceiptConfiguration:
    def __init__(self,pack):
        pack=deepcopy(pack)
        require(isinstance(pack,dict) and pack.get('state')=='reviewed' and pack.get('review_evidence_ref'),'RECEIPT_REVIEW_REQUIRED')
        merchant=pack.get('merchant',{})
        require(all(isinstance(merchant.get(k),str) and merchant[k].strip() for k in ('legal_name','postal_address','contact_route')),'MERCHANT_FACTS_REQUIRED')
        require('@' not in merchant['contact_route'],'SUPPORT_EMAIL_NOT_ALLOWED')
        self.pack=pack
        require(isinstance(pack.get('plans'),dict) and pack['plans'],'RECEIPT_PLANS_REQUIRED')
        for code,plan in pack['plans'].items():
            require(code in PLANS and code!='Annual365','RECEIPT_PLAN_INVALID')
            gross=PLANS[code][0]
            require(isinstance(plan,dict) and isinstance(plan.get('version'),str) and isinstance(plan.get('tax_rule'),str) and plan['tax_rule']!='unreviewed','RECEIPT_RULE_REQUIRED')
            require(type(plan.get('net_paise')) is int and 0<=plan['net_paise']<=gross and isinstance(plan.get('taxes'),list) and len(plan['taxes'])<=5,'RECEIPT_AMOUNT_INVALID')
            for tax in plan['taxes']:
                require(isinstance(tax,dict) and isinstance(tax.get('name'),str) and 0<len(tax['name'])<=80 and type(tax.get('paise')) is int and tax['paise']>=0,'RECEIPT_TAX_INVALID')
            require(plan['net_paise']+sum(row['paise'] for row in plan['taxes'])==gross,'RECEIPT_CONSERVATION')

    def snapshot(self,code,version,tax_rule,gross):
        row=self.pack['plans'].get(code)
        require(row and row['version']==version and row['tax_rule']==tax_rule and PLANS[code][0]==gross,'RECEIPT_RULE_MISMATCH')
        return deepcopy({'document_kind':'payment_receipt','merchant':self.pack['merchant'],'net_paise':row['net_paise'],
                'taxes':row['taxes'],'tax_rule':tax_rule,'configuration_evidence':self.pack['review_evidence_ref']})
