class DomainError(Exception):
    def __init__(self, code, status=409):
        self.code, self.status = code, status
        super().__init__(code)


def require(condition, code, status=409):
    if not condition:
        raise DomainError(code, status)
