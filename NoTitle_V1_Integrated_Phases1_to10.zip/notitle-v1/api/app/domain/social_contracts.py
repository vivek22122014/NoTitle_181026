"""Free mutual friends and online invitations. No public identity search."""
from typing import Literal
from pydantic import Field
from app.contracts import StrictDTO
from .protocol_common import Ref,CommandBase,EventBase

class InteractionTarget(StrictDTO):interaction_handle:Ref
class RequestResponse(StrictDTO):request_handle:Ref;accept:bool
class RelationshipTarget(StrictDTO):relationship_handle:Ref
class InvitationResponse(StrictDTO):invite_handle:Ref;accept:bool
class FriendRequest(CommandBase):type:Literal['friend.request'];payload:InteractionTarget
class FriendRespond(CommandBase):type:Literal['friend.respond'];payload:RequestResponse
class FriendInvite(CommandBase):type:Literal['friend.invite'];payload:RelationshipTarget
class FriendInviteRespond(CommandBase):type:Literal['friend.invite.respond'];payload:InvitationResponse

class FriendPeer(StrictDTO):
    peer_handle:Ref
    display_name:str=Field(min_length=2,max_length=24)
    gender:Literal['male','female','other']
    topic_id:str
    bio:str=Field(max_length=160)
class FriendItem(StrictDTO):
    relationship_handle:Ref
    peer:FriendPeer
    revision:int=Field(ge=1)
    persistence:Literal['temporary','saving','saved']
    presence:Literal['available','busy','offline']
class FriendPending(StrictDTO):
    request_handle:Ref
    interaction_handle:Ref
    peer:FriendPeer
    incoming:bool
class FriendRequestClosed(StrictDTO):request_handle:Ref
class FriendStatus(StrictDTO):relationship:FriendItem
class FriendRemoved(StrictDTO):relationship_handle:Ref
class Invitation(StrictDTO):
    invite_handle:Ref
    relationship_handle:Ref
    peer:FriendPeer
    expires_at:float=Field(allow_inf_nan=False)
    incoming:bool
class InvitationClosed(StrictDTO):invite_handle:Ref;reason:Literal['closed','expired','unavailable','accepted']
class FriendPendingEvent(EventBase):type:Literal['friend.pending'];data:FriendPending
class FriendClosedEvent(EventBase):type:Literal['friend.request_closed'];data:FriendRequestClosed
class FriendStatusEvent(EventBase):type:Literal['friend.accepted','friend.saving','friend.persisted'];data:FriendStatus
class FriendRemovedEvent(EventBase):type:Literal['friend.removed','friend.expired'];data:FriendRemoved
class InvitationEvent(EventBase):type:Literal['friend.invite.sent','friend.invite.received'];data:Invitation
class InvitationClosedEvent(EventBase):type:Literal['friend.invite.closed'];data:InvitationClosed
SOCIAL_COMMANDS=(FriendRequest,FriendRespond,FriendInvite,FriendInviteRespond)
SOCIAL_EVENTS=(FriendPendingEvent,FriendClosedEvent,FriendStatusEvent,FriendRemovedEvent,InvitationEvent,InvitationClosedEvent)
