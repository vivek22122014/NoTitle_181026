"""Single-owner synchronous transitions. No database/network await inside this actor.

The transport drains bounded event queues. End/Block fences are applied before any
durable effect; delayed effects must revalidate the revision they reserved.
"""
from collections import OrderedDict, deque
from dataclasses import dataclass, field
import math
import time
from uuid import uuid4
from .errors import DomainError, require


@dataclass
class Person:
    id: str
    profile: dict
    registered: bool = False
    premium_until: float = 0
    generation: int = 0
    revision: int = 1
    interaction: str | None = None
    connected: bool = False
    last_action: float = 0
    disconnected_at: float | None = None
    events: deque = field(default_factory=deque)
    event_bytes: int = 0
    commands: OrderedDict = field(default_factory=OrderedDict)
    sequence: int = 0
    pending_profile: dict | None = None


@dataclass
class Waiter:
    person: str
    since: float
    gender: str
    professional: dict
    revision: int


@dataclass
class Interaction:
    id: str
    left: str
    right: str
    epoch: int
    started: float
    messages: deque = field(default_factory=deque)
    bytes: int = 0
    call: dict | None = None
    cooldown_until: float = 0


class Realtime:
    def __init__(self, authority, metrics, clock=time.monotonic, wall=time.time):
        self.authority, self.metrics, self.clock, self.wall = authority, metrics, clock, wall
        self.people, self.waiters, self.interactions = {}, {}, {}
        self.blocks, self.friends = set(), set()
        self.requests, self.invites, self.recent, self.ended, self.snapshots = {}, {}, {}, {}, {}
        self.next_epoch = 0
        self.media_ends = deque(maxlen=200)

    def enter(self, identity, profile, registered=False, premium_until=0):
        self.authority.assert_authority()
        if identity not in self.people:
            require(len(self.people) < 200, "CAPACITY", 503)
            self.people[identity] = Person(identity, dict(profile), registered, premium_until, last_action=self.clock())
        person = self.people[identity]
        person.profile = dict(profile)
        person.premium_until = premium_until
        return person

    def person(self, identity):
        self.authority.assert_authority()
        require(identity in self.people, "SESSION_EXPIRED", 401)
        return self.people[identity]

    def emit(self, identity, kind, data):
        import json
        person = self.people.get(identity)
        if not person:
            return
        person.sequence += 1
        event = {"type": kind, "data": data, "server_sequence": person.sequence,
                 "server_time": self.wall(), "owner_epoch": self.authority.epoch,
                 "socket_generation": person.generation, "interaction_epoch": person.revision}
        size = len(json.dumps(event).encode())
        if len(person.events) >= 64 or person.event_bytes + size > 262144:
            person.events.clear(); person.event_bytes = 0
            self.disconnect(identity)
            return
        person.events.append((event, size)); person.event_bytes += size

    def drain(self, identity):
        person = self.person(identity)
        events = [item[0] for item in person.events]
        person.events.clear(); person.event_bytes = 0
        return events

    def connect(self, identity, takeover=False, known_generation=0):
        person = self.person(identity)
        require(not person.connected or (takeover and known_generation == person.generation), "SOCKET_EXISTS")
        person.generation += 1
        person.connected = True; person.disconnected_at = None; person.last_action = self.clock()
        self.emit(identity, "session.ready", {"generation": person.generation, "profile": person.profile,
                  "interaction": self.describe(identity)})
        return person.generation

    def disconnect(self, identity):
        person = self.people.get(identity)
        if not person:
            return
        person.connected = False; person.disconnected_at = self.clock()
        if self.waiters.pop(identity, None):
            self.metrics.add("searches_abandoned")
        interaction = self.interactions.get(person.interaction)
        if interaction and interaction.call:
            self.end_call(interaction, "disconnected")

    @staticmethod
    def pair(left, right):
        return tuple(sorted((left, right)))

    def blocked(self, left, right):
        return (left, right) in self.blocks or (right, left) in self.blocks

    def peer(self, identity):
        p = self.people[identity]
        return {"peer_handle": identity, **{k: p.profile[k] for k in ("display_name", "gender", "topic_id", "bio")}}

    def describe(self, identity):
        p = self.people[identity]
        interaction = self.interactions.get(p.interaction)
        if not interaction:
            return None
        other = interaction.right if interaction.left == identity else interaction.left
        return {"interaction_handle": interaction.id, "peer": self.peer(other),
                "interaction_epoch": p.revision, "messages": list(interaction.messages),
                "call": {"id": interaction.call["id"], "state": interaction.call["state"]} if interaction.call else None}

    def join(self, identity, preference="everyone", professional=None):
        p = self.person(identity)
        require(p.connected and not p.interaction, "NOT_AVAILABLE")
        if p.pending_profile:p.profile.update(p.pending_profile);p.pending_profile=None
        require(preference in {"everyone", "male", "female", "other"}, "PREFERENCE_INVALID", 422)
        require(preference == "everyone" or p.premium_until > self.wall(), "PREMIUM_REQUIRED", 403)
        require(identity in self.waiters or len(self.waiters) < 100, "QUEUE_CAPACITY", 503)
        old = self.waiters.get(identity)
        relevance = professional if p.premium_until > self.wall() else {}
        self.waiters[identity] = Waiter(identity, old.since if old else self.clock(), preference, relevance or {}, p.revision)
        if not old:
            self.metrics.add("searches_started")
            self.metrics.add("professional_enabled" if relevance else "professional_disabled")
        self.emit(identity, "queue.waiting", {"since": self.wall(), "gender": preference})

    def compatible(self, a, b):
        left, right = self.people[a.person], self.people[b.person]
        since = self.recent.get(self.pair(a.person, b.person))
        return (a.person != b.person and not self.blocked(a.person, b.person)
                and left.connected and right.connected and a.revision == left.revision and b.revision == right.revision
                and (a.gender == "everyone" or a.gender == right.profile["gender"])
                and (b.gender == "everyone" or b.gender == left.profile["gender"])
                and (since is None or self.clock() - since >= 4))

    def score(self, anchor, candidate):
        now = self.clock()
        wait = now - candidate.since
        pair_time = self.recent.get(self.pair(anchor.person, candidate.person))
        penalty = 60 * math.exp(-(now - pair_time - 4) / 10) if pair_time is not None and now - pair_time < 300 else 0
        a, b = self.people[anchor.person], self.people[candidate.person]
        topic = .5 if a.profile["topic_id"] != "general" and a.profile["topic_id"] == b.profile["topic_id"] else 0
        def relevance(w, other):
            if not w.professional:
                return 0
            return min(.5, .1 * sum(bool(set(values) & set(other.get(key, [])))
                                   for key, values in w.professional.items()))
        professional = (relevance(anchor, b.profile.get("professional", {})) + relevance(candidate, a.profile.get("professional", {}))) / 2
        fade = max(0, 1 - max(now - anchor.since, wait) / 5)
        return wait - penalty + fade * (topic + professional)

    def match(self):
        self.authority.assert_authority()
        checks = 0
        for anchor in sorted(tuple(self.waiters.values()), key=lambda w: (w.since, w.person)):
            if anchor.person not in self.waiters:
                continue
            candidates = []
            for candidate in tuple(self.waiters.values()):
                checks += 1
                if checks > 10000:
                    return
                if self.compatible(anchor, candidate):
                    candidates.append(candidate)
            if candidates:
                chosen = max(candidates, key=lambda w: (self.score(anchor, w), -w.since, w.person))
                self.start(anchor.person, chosen.person)

    def start(self, left, right):
        require(not self.blocked(left, right) and not self.people[left].interaction and not self.people[right].interaction, "NOT_AVAILABLE")
        self.next_epoch += 1
        interaction = Interaction(uuid4().hex, left, right, self.next_epoch, self.clock())
        self.interactions[interaction.id] = interaction
        if self.pair(left, right) in self.recent:
            self.metrics.add("repeat_matches")
        for identity in (left, right):
            waiter = self.waiters.pop(identity, None)
            if waiter:
                self.metrics.add("match_wait_ms", (self.clock() - waiter.since) * 1000)
            self.people[identity].interaction = interaction.id
            self.people[identity].revision += 1
            self.emit(identity, "interaction.started", self.describe(identity))
        self.metrics.add("matches")
        return interaction

    def current(self, identity):
        p = self.person(identity)
        require(p.interaction in self.interactions, "NO_INTERACTION")
        return self.interactions[p.interaction]

    def end(self, identity, reason="ended"):
        p = self.person(identity)
        self.waiters.pop(identity, None)
        interaction = self.interactions.get(p.interaction)
        if not interaction:
            p.revision += 1
            return
        if interaction.call:
            self.end_call(interaction, reason)
        self.recent[self.pair(interaction.left, interaction.right)] = self.clock()
        self.ended[interaction.id] = (interaction.left, interaction.right, self.clock() + 600)
        interaction.messages.clear(); interaction.bytes = 0
        self.interactions.pop(interaction.id)
        for member in (interaction.left, interaction.right):
            self.people[member].interaction = None
            self.people[member].revision += 1
            self.emit(member, "interaction.ended", {"reason": reason})
        for key in list(self.requests):
            if self.requests[key]["interaction"] == interaction.id:
                del self.requests[key]

    def block(self, identity, other, snapshot_ref=None):
        person=self.person(identity)
        snapshot=self.snapshots.get(snapshot_ref) if snapshot_ref else None
        scoped_snapshot=bool(snapshot and snapshot['identity']==identity and snapshot['other']==other and snapshot['until']>self.clock())
        peer=self.people.get(other)
        known_friend=self.pair(identity, other) in self.friends
        require(identity != other and (peer or scoped_snapshot or known_friend), "NOT_FOUND", 404)
        require(scoped_snapshot or known_friend or
                (peer and person.interaction and person.interaction == peer.interaction), "NOT_FOUND", 404)
        self.blocks.add((identity, other))
        self.friends.discard(self.pair(identity, other))
        if peer and person.interaction and person.interaction == peer.interaction:
            self.end(identity, "blocked")

    def text(self, identity, body):
        interaction = self.current(identity)
        require(isinstance(body, str) and 0 < len(body) <= 2000 and len(body.encode()) <= 6144, "TEXT_LIMIT", 422)
        message = {"id": uuid4().hex, "sender": identity, "text": body, "sent_at": self.wall()}
        interaction.messages.append(message); interaction.bytes += len(body.encode())
        while len(interaction.messages) > 30 or interaction.bytes > 65536:
            interaction.bytes -= len(interaction.messages.popleft()["text"].encode())
        for member in (interaction.left, interaction.right):
            self.emit(member, "text.message", message)
        self.metrics.add("text_accepted")
        return {"message_id": message["id"], "status": "accepted"}

    def delivered(self, identity, message_id):
        interaction = self.current(identity)
        message = next((m for m in interaction.messages if m["id"] == message_id and m["sender"] != identity), None)
        require(message is not None, "MESSAGE_NOT_FOUND", 404)
        self.emit(message["sender"], "text.delivered", {"message_id": message_id})

    def friend_request(self, identity, defer=False):
        interaction = self.current(identity)
        other = interaction.right if identity == interaction.left else interaction.left
        pair = self.pair(identity, other)
        require(pair not in self.friends, "ALREADY_FRIENDS")
        require(sum(identity in p for p in self.friends) < 100 and sum(other in p for p in self.friends) < 100, "FRIEND_LIMIT")
        existing = self.requests.get(pair)
        if existing and existing["from"] != identity:
            return self.friend_respond(identity, True, defer)
        self.requests[pair] = {"from": identity, "interaction": interaction.id, "revision": self.people[identity].revision}
        self.emit(other, "friend.request", {"from": self.peer(identity)})
        return {"status": "requested"}

    def friend_respond(self, identity, accept, defer=False):
        interaction = self.current(identity)
        other = interaction.right if identity == interaction.left else interaction.left
        pair = self.pair(identity, other)
        request = self.requests.get(pair)
        require(request and request["from"] == other and request["interaction"] == interaction.id, "REQUEST_EXPIRED")
        del self.requests[pair]
        if accept and not defer:
            self.finish_friend(pair)
        elif not accept:
            for member in pair:self.emit(member, 'friend.updated', {'accepted':False})
        return {"status": "accepted" if accept else "declined", "pair": pair}

    def finish_friend(self,pair):
        require(not self.blocked(*pair),'FRIEND_UNAVAILABLE')
        self.friends.add(pair);self.metrics.add('friend_acceptances')
        for member in pair:self.emit(member,'friend.updated',{'accepted':True})

    def invite(self, identity, other):
        require(self.pair(identity, other) in self.friends and not self.blocked(identity, other), "NOT_FOUND", 404)
        require(all(p in self.people and self.people[p].connected and not self.people[p].interaction for p in (identity, other)), "FRIEND_UNAVAILABLE")
        pair = self.pair(identity, other)
        existing = self.invites.get(pair)
        if existing and existing["from"] == other and existing["until"] > self.clock():
            self.invites.pop(pair); self.start(identity, other)
            return
        self.invites[pair] = {"from": identity, "until": self.clock() + 30}
        self.emit(other, "friend.invitation", {"from": self.peer(identity), "expires_in": 30})

    def invite_respond(self, identity, other, accept):
        pair = self.pair(identity, other); invite = self.invites.pop(pair, None)
        require(invite and invite["from"] == other and invite["until"] > self.clock(), "INVITE_EXPIRED")
        if accept:
            self.start(identity, other)

    def call_request(self, identity):
        interaction = self.current(identity)
        require(interaction.call is None and self.clock() >= interaction.cooldown_until, "CALL_BUSY")
        require(sum(i.call is not None for i in self.interactions.values()) < 25, "CALL_CAPACITY", 503)
        other = interaction.right if identity == interaction.left else interaction.left
        call = {"id": uuid4().hex, "from": identity, "state": "ringing", "until": self.clock() + 30, "revision": 1}
        interaction.call = call
        self.metrics.add("calls_attempted")
        self.emit(other, "call.request", {"call_id": call["id"], "expires_in": 30})
        return {"call_id": call["id"], "state": "ringing"}

    def call_respond(self, identity, accept):
        interaction = self.current(identity); call = interaction.call
        require(call and call["from"] != identity and call["state"] == "ringing" and self.clock() < call["until"], "CALL_EXPIRED")
        if not accept:
            self.end_call(interaction, "declined"); return None
        call.update(state="connecting", until=self.clock() + 20, revision=call["revision"] + 1, connecting_at=self.clock(), client_ready=set(), relay_ready=False)
        return dict(call)

    def end_call(self, interaction, reason):
        call = interaction.call
        if not call:
            return
        # Capacity remains reserved until the controller confirms allocations absent.
        if call["state"] != "teardown":
            if call["state"] != "connected": self.metrics.add("calls_failed")
            call.update(state="teardown", revision=call["revision"] + 1)
            self.media_ends.append(call["id"])
        interaction.cooldown_until = self.clock() + 15
        for member in (interaction.left, interaction.right):
            self.emit(member, "call.ended", {"reason": reason, "call_id": call["id"]})

    def prepare_report(self, identity):
        interaction = self.current(identity)
        existing = next((key for key, v in self.snapshots.items() if v["identity"] == identity), None)
        if existing:
            del self.snapshots[existing]
        require(sum(v["bytes"] for v in self.snapshots.values()) + interaction.bytes <= 16 * 1024 * 1024, "SNAPSHOT_CAPACITY", 503)
        reference = uuid4().hex
        other = interaction.right if identity == interaction.left else interaction.left
        self.snapshots[reference] = {"identity": identity, "other": other, "interaction": interaction.id,
            "until": self.clock() + 120, "bytes": interaction.bytes, "messages": [dict(m) for m in interaction.messages]}
        return {"snapshot_ref": reference, "messages": list(interaction.messages), "expires_in": 120}

    def tick(self):
        self.authority.assert_authority()
        now = self.clock()
        for identity, p in tuple(self.people.items()):
            if not p.connected and p.disconnected_at is not None and now - p.disconnected_at >= 25 and p.interaction:
                self.end(identity, "reconnect_expired")
            waiter = self.waiters.get(identity)
            if waiter and p.premium_until <= self.wall():
                if waiter.gender != "everyone":
                    del self.waiters[identity]; self.emit(identity, "queue.paused", {"reason": "premium_expired"})
                else:
                    waiter.professional = {}
        for interaction in tuple(self.interactions.values()):
            if interaction.call and interaction.call["state"] in {"ringing", "connecting"} and now >= interaction.call["until"]:
                self.end_call(interaction, "timeout")
        for identity,p in tuple(self.people.items()):
            if not p.connected and not p.interaction and now-p.last_action>1800:self.retire(identity)
        self.recent = {p: t for p, t in self.recent.items() if now - t < 300}
        self.ended = {r: v for r, v in self.ended.items() if v[2] > now}
        self.snapshots = {r: v for r, v in self.snapshots.items() if v["until"] > now}
        self.invites = {p: v for p, v in self.invites.items() if v["until"] > now}
        self.match()

    def retire(self,identity):
        if identity not in self.people:return
        self.end(identity,'session_expired')
        self.people.pop(identity,None)
        self.friends={pair for pair in self.friends if identity not in pair or any(p in self.people for p in pair if p!=identity)}
        self.blocks={pair for pair in self.blocks if identity not in pair or any(p in self.people for p in pair if p!=identity)}

    def fence(self):
        self.waiters.clear(); self.snapshots.clear()
        for interaction in tuple(self.interactions.values()):
            interaction.messages.clear()
        self.interactions.clear(); self.people.clear()
