"""Startup checks for required additive migrations within a schema contract.
Extra forward migrations remain allowed for explicitly compatible rollback images.
"""
import hashlib
import re
from pathlib import Path


def inventory(directory):
    directory=Path(directory);files=sorted(directory.glob('*.sql'))
    if not files or len(files)>512:raise RuntimeError('MIGRATION_INVENTORY_INVALID')
    names=[p.name for p in files]
    if any(not re.fullmatch(r'[0-9]{4}_[a-z_]+\.sql',name) for name in names) or len({name[:4] for name in names})!=len(names):
        raise RuntimeError('MIGRATION_INVENTORY_INVALID')
    if [int(name[:4]) for name in names]!=list(range(1,len(names)+1)):
        raise RuntimeError('MIGRATION_INVENTORY_INVALID')
    if any(p.is_symlink() or not p.is_file() for p in files):raise RuntimeError('MIGRATION_INVENTORY_INVALID')
    return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}


def packaged_inventory():
    # Exact supported layouts: API Docker image and source checkout.
    here=Path(__file__).resolve()
    for root in (here.parents[2],here.parents[3]):
        directory=root/'db/migrations'
        if directory.is_dir():return inventory(directory)
    raise RuntimeError('MIGRATION_INVENTORY_MISSING')


def verify_applied(required,rows):
    applied=dict(rows)
    if len(applied)!=len(rows):raise RuntimeError('MIGRATION_HISTORY_INVALID')
    if any(applied.get(name)!=digest for name,digest in required.items()):
        raise RuntimeError('REQUIRED_MIGRATIONS_NOT_APPLIED')
    return True
