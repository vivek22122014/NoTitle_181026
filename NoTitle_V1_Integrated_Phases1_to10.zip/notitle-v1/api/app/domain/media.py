import ipaddress
import re
from .errors import require


def candidate(value,relay_ip):
    require(isinstance(value,str) and len(value)<=1024,'ICE_INVALID',422)
    parts=value.removeprefix('a=').split()
    require(len(parts)>=8 and parts[0].startswith('candidate:') and parts[1]=='1' and parts[2].lower()=='udp'
            and parts[4]==str(ipaddress.IPv4Address(relay_ip)) and parts[6:8]==['typ','relay'],'RELAY_ONLY',422)
    require(parts[5].isdigit() and 49152<=int(parts[5])<=50175,'RELAY_PORT',422)
    # Related addresses are never forwarded. Only known numeric extension fields survive.
    clean=parts[:8]
    tail=parts[8:]
    require(len(tail)%2==0,'ICE_INVALID',422)
    for key,val in zip(tail[::2],tail[1::2]):
        if key in {'raddr','rport'}:continue
        if key in {'generation','network-id','network-cost'} and val.isdigit():clean.extend((key,val))
        elif key=='ufrag' and re.fullmatch(r'[A-Za-z0-9+/]{1,256}',val):clean.extend((key,val))
        else:require(False,'ICE_EXTENSION',422)
    return ' '.join(clean)


def sdp(value,relay_ip):
    require(isinstance(value,str) and len(value.encode())<=65536,'SDP_LIMIT',422)
    lines=value.replace('\r\n','\n').splitlines()
    media=[line for line in lines if line.startswith('m=')]
    require(len(media)==1 and re.fullmatch(r'm=audio [0-9]+ UDP/TLS/RTP/SAVPF [0-9 ]+',media[0]),'AUDIO_ONLY',422)
    require(any(line=='a=rtcp-mux' for line in lines) and any(line.startswith('a=group:BUNDLE ') for line in lines),'BUNDLE_REQUIRED',422)
    require(any(re.fullmatch(r'a=fingerprint:sha-256 (?:[0-9A-Fa-f]{2}:){31}[0-9A-Fa-f]{2}',line) for line in lines),'DTLS_REQUIRED',422)
    require(any(re.fullmatch(r'a=rtpmap:\d+ opus/48000/2',line,re.I) for line in lines),'OPUS_REQUIRED',422)
    output=[]
    for line in lines:
        require('\x00' not in line and len(line)<=2048,'SDP_INVALID',422)
        if line.startswith('a=candidate:'):line='a='+candidate(line,relay_ip)
        if line.startswith('c='):line='c=IN IP4 0.0.0.0'
        if line.startswith('o='):line='o=- 0 0 IN IP4 0.0.0.0'
        if line.startswith('a=rtcp:'):continue
        require(not any(line.startswith(prefix) for prefix in ('a=sctp','a=crypto:','a=remote-candidates:')),'SDP_UNSUPPORTED',422)
        output.append(line)
    return '\r\n'.join(output)+'\r\n'
