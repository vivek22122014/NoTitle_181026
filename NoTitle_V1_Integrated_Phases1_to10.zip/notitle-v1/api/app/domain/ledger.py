"""Integer, FIFO wall-clock entitlement accounting. Persistence locks live in Billing."""
from dataclasses import dataclass
from .errors import require

PLANS = {
    "Short3": (9900, 259200), "Week7": (19900, 604800),
    "Month30": (49900, 2592000), "Annual365": (149900, 31536000),
}
REMEDIES = {"payment_error", "statutory_remedy", "provider_bank_direction"}


@dataclass
class Lot:
    purchase: str
    seq: int
    granted: int
    consumed: int = 0
    available: int = 0
    held: int = 0
    revoked: int = 0

    def check(self):
        require(self.granted > 0 and min(self.consumed, self.available, self.held, self.revoked) >= 0
                and self.granted == self.consumed + self.available + self.held + self.revoked, "LOT_INVARIANT")


def advance(lots, last_accounted, now):
    elapsed = max(0, int(now) - int(last_accounted))
    for lot in sorted(lots, key=lambda item: item.seq):
        lot.check()
        used = min(lot.available, elapsed)
        lot.available -= used
        lot.consumed += used
        elapsed -= used
        lot.check()
    return max(int(last_accounted), int(now))


def hold(lot, seconds, basis):
    require(basis in REMEDIES, "VOLUNTARY_REFUND_PROHIBITED", 422)
    require(type(seconds) is int and 0 <= seconds <= lot.available, "HOLD_RANGE")
    lot.available -= seconds
    lot.held += seconds
    lot.check()


def settle(lot, seconds, succeeded):
    require(type(seconds) is int and 0 <= seconds <= lot.held, "HOLD_RANGE")
    lot.held -= seconds
    if succeeded:
        lot.revoked += seconds
    else:
        lot.available += seconds
    lot.check()
