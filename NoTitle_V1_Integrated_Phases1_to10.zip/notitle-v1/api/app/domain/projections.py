"""Explicit trust-boundary projections. Never serialize a database account row."""
from typing import Literal
from pydantic import Field
from app.contracts import StrictDTO

class ProfileView(StrictDTO):
    display_name:str
    gender:Literal['male','female','other']
    topic_id:str
    bio:str

class OwnerView(StrictDTO):
    identity_kind:Literal['account','guest']
    ref:str
    username:str|None
    profile:ProfileView
    preferences:dict
    professional:dict
    core_consent:bool
    professional_consent:bool
    profile_revision:int=Field(ge=1)
    preference_revision:int=Field(ge=1)
    consent_revision:int=Field(ge=1)
    account_status:Literal['active','restricted']

class StaffView(StrictDTO):
    identity_kind:Literal['staff']
    grants:list[str]

class PurposeView(StrictDTO):
    label:str
    text_digest:str=Field(pattern=r'^[0-9a-f]{64}$')
    documents:list[str]
    withdrawal_label:str|None=None
    withdrawal_digest:str|None=None

class PolicyView(StrictDTO):
    version:str
    publication_digest:str=Field(pattern=r'^[0-9a-f]{64}$')
    state:Literal['draft','reviewed']
    effective_at:str|None
    purposes:dict[str,PurposeView]

class GatesView(StrictDTO):
    identity:bool
    admission:bool
    audio:bool
    payments:bool
    payment_mode:Literal['sandbox','production']

class BootstrapView(StrictDTO):
    csrf:str
    scoped_csrf:dict[str,str]
    scoped_subjects:dict[str,str]
    identity_kind:Literal['bootstrap','guest','account']
    policy_version:str
    policy_digest:str
    policy:PolicyView
    gates:GatesView
    owner_epoch:int
    server_time:str

class EntitlementView(StrictDTO):
    available_seconds:int
    premium_until:int
    entitlement_revision:int

class OwnerResponse(OwnerView):
    policy_current:bool
    entitlement:EntitlementView

class PreparedView(StrictDTO):
    reservation_id:str=Field(pattern=r'^[0-9a-f]{32}$')
    secret:str=Field(pattern=r'^[A-Za-z0-9_-]{43}$')
    expires_in:int=Field(ge=1,le=600)

def owner(principal):
    row=principal.account
    return OwnerView(identity_kind=principal.kind,ref=principal.ref,username=row.get('username') if principal.kind=='account' else None,
        profile=ProfileView(**{k:row[k] for k in ProfileView.model_fields}),
        preferences=row.get('preferences',{}),professional=row.get('professional',{}),
        core_consent=row.get('core_consent',True),professional_consent=row.get('professional_consent',False),
        profile_revision=row.get('profile_revision',1),preference_revision=row.get('preference_revision',1),
        consent_revision=row.get('consent_revision',1),account_status=row.get('status','active')).model_dump()

