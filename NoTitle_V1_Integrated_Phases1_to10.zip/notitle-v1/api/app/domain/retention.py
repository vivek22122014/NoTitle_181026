"""V1 retention registry; a software target is not a legal determination."""
from dataclasses import dataclass

@dataclass(frozen=True)
class RetentionRule:
    category:str
    trigger:str
    duration_seconds:int|None
    holds_apply:bool
    authority:str

RULES=(
 RetentionRule('account_sessions','idle_or_absolute_expiry',30*86400,False,'identity'),
 RetentionRule('scoped_sessions','idle_or_absolute_expiry',86400,False,'identity'),
 RetentionRule('operation_results','created_at',86400,False,'identity'),
 RetentionRule('exports','created_at',86400,False,'privacy'),
 RetentionRule('profile','deletion_disabled_at',30*86400,True,'privacy'),
 RetentionRule('support','closed_at',90*86400,True,'support'),
 RetentionRule('safety','closed_at',180*86400,True,'safety'),
 RetentionRule('consent','closure_or_withdrawal',180*86400,True,'privacy'),
 RetentionRule('finance','reviewed_statutory_trigger',None,True,'finance'),
)
def public_registry():
    return [{'category':r.category,'trigger':r.trigger,'duration_seconds':r.duration_seconds,
             'lawful_holds_apply':r.holds_apply,'status':'requires_operator_schedule' if r.duration_seconds is None else 'V1 engineering target'} for r in RULES]
