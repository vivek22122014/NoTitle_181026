"""Phase 4 wire v2. Strict, generated contracts; v1 candidate source is retained.

The database foundation protocol number is independent of this browser wire version.
"""
import json,math,unicodedata
from typing import Annotated,Literal,Union
from uuid import UUID
from pydantic import Field,TypeAdapter,field_validator
from app.contracts import StrictDTO
from .errors import require
from .protocol_common import Ref,Nonce,Positive,CommandBase,EventBase


class Hello(StrictDTO):
    protocol_version:Literal[2]
    type:Literal['session.hello']
    ticket:Annotated[str,Field(pattern=r'^[A-Za-z0-9_-]{43}$')]

class SearchPayload(StrictDTO):
    gender:Literal['everyone','male','female','other']='everyone'
    general_talk:bool=True
    profile_revision:Positive
    preference_revision:Positive

class CancelPayload(StrictDTO):
    search_command_id:Nonce

class EndPayload(StrictDTO):
    interaction_handle:Ref

class NextPayload(SearchPayload,EndPayload):pass

class SendPayload(EndPayload):
    text:str=Field(min_length=1,max_length=2000)
    @field_validator('text')
    @classmethod
    def text_bytes(cls,value):
        if len(value.encode())>6144 or any(unicodedata.category(c)=='Cs' or unicodedata.category(c)=='Cc' and c not in '\t\r\n' for c in value):
            raise ValueError('Text byte or control limit')
        return value

class DeliveredPayload(EndPayload):
    message_id:Ref
    sequence:Positive

class ResumePayload(StrictDTO):
    last_server_sequence:int=Field(ge=0)

class HeartbeatPayload(StrictDTO):
    client_time:float=Field(ge=0,le=1e15,allow_inf_nan=False)


class SearchCommand(CommandBase):type:Literal['queue.join'];payload:SearchPayload
class CancelCommand(CommandBase):type:Literal['queue.cancel'];payload:CancelPayload
class EndCommand(CommandBase):type:Literal['interaction.end'];payload:EndPayload
class NextCommand(CommandBase):type:Literal['interaction.next'];payload:NextPayload
class SendCommand(CommandBase):type:Literal['text.send'];payload:SendPayload
class DeliveredCommand(CommandBase):type:Literal['text.delivered'];payload:DeliveredPayload
class ResumeCommand(CommandBase):type:Literal['session.resume'];payload:ResumePayload
class HeartbeatCommand(CommandBase):type:Literal['heartbeat'];payload:HeartbeatPayload
from .social_contracts import SOCIAL_COMMANDS,SOCIAL_EVENTS
from .audio_contracts import AUDIO_COMMANDS,AUDIO_EVENTS
CORE_COMMANDS=(SearchCommand,CancelCommand,EndCommand,NextCommand,SendCommand,DeliveredCommand,ResumeCommand,HeartbeatCommand)
Command=Annotated[Union[CORE_COMMANDS+SOCIAL_COMMANDS+AUDIO_COMMANDS],Field(discriminator='type')]
HTTPControl=Annotated[Union[EndCommand,CancelCommand],Field(discriminator='type')]
COMMAND=TypeAdapter(Command)

class TicketView(StrictDTO):
    ticket:Annotated[str,Field(pattern=r'^[A-Za-z0-9_-]{43}$')]
    expires_in:int=Field(ge=1,le=60)
    owner_epoch:Positive
    protocol_version:Literal[2]=2

class PeerView(StrictDTO):
    peer_handle:Ref
    display_name:str=Field(min_length=2,max_length=24)
    gender:Literal['male','female','other']
    topic_id:str
    bio:str=Field(max_length=160)

class MessageView(StrictDTO):
    id:Ref
    sequence:Positive
    sender:Literal['me','peer']
    text:str=Field(min_length=1,max_length=2000)
    sent_at:float=Field(allow_inf_nan=False)
    delivered:bool
    command_id:Nonce|None=None

class InteractionView(StrictDTO):
    interaction_handle:Ref
    search_command_id:Nonce|None=None
    peer:PeerView
    messages:list[MessageView]=Field(max_length=30)
    interrupted:bool
    grace_expires_at:float|None

class QueueView(StrictDTO):
    search_command_id:Nonce
    joined_at:float
    gender:Literal['everyone','male','female','other']
    general_talk:bool

class Snapshot(StrictDTO):
    state:Literal['idle','searching','matched','interrupted','maintenance']
    queue:QueueView|None=None
    interaction:InteractionView|None=None
    limits:dict[str,int]

class Ack(StrictDTO):
    command_id:Nonce
    ok:Literal[True]=True
    status:str|None=None
    message_id:Ref|None=None
    sequence:Positive|None=None

class Error(StrictDTO):command_id:Nonce|None=None;code:str
class Ended(StrictDTO):interaction_handle:Ref|None=None;reason:str
class Paused(StrictDTO):reason:str
class TextData(StrictDTO):interaction_handle:Ref;message:MessageView
class DeliveryData(StrictDTO):interaction_handle:Ref;message_id:Ref;sequence:Positive
class Interrupted(StrictDTO):interaction_handle:Ref;grace_expires_at:float
class HeartbeatData(StrictDTO):client_time:float
class Empty(StrictDTO):pass
class ServiceData(StrictDTO):code:str

class SnapshotEvent(EventBase):type:Literal['session.ready','state.snapshot'];data:Snapshot
class WaitingEvent(EventBase):type:Literal['queue.waiting'];data:QueueView
class CancelledEvent(EventBase):type:Literal['queue.cancelled'];data:Empty
class PausedEvent(EventBase):type:Literal['queue.paused'];data:Paused
class StartedEvent(EventBase):type:Literal['interaction.started'];data:InteractionView
class EndedEvent(EventBase):type:Literal['interaction.ended'];data:Ended
class InterruptedEvent(EventBase):type:Literal['interaction.interrupted'];data:Interrupted
class TextEvent(EventBase):type:Literal['text.message'];data:TextData
class DeliveryEvent(EventBase):type:Literal['text.delivered'];data:DeliveryData
class AckEvent(EventBase):type:Literal['command.ack'];data:Ack
class ErrorEvent(EventBase):type:Literal['command.error'];data:Error
class ServiceEvent(EventBase):type:Literal['service.draining','service.unavailable'];data:ServiceData
class HeartbeatEvent(EventBase):type:Literal['heartbeat.ack'];data:HeartbeatData
CORE_EVENTS=(SnapshotEvent,WaitingEvent,CancelledEvent,PausedEvent,StartedEvent,EndedEvent,InterruptedEvent,TextEvent,DeliveryEvent,AckEvent,ErrorEvent,ServiceEvent,HeartbeatEvent)
Event=Annotated[Union[CORE_EVENTS+SOCIAL_EVENTS+AUDIO_EVENTS],Field(discriminator='type')]
EVENT=TypeAdapter(Event)

def strict_json(raw,limit=8192):
    require(isinstance(raw,str) and len(raw.encode())<=limit,'FRAME_LIMIT',422)
    def pairs(items):
        result={}
        for key,value in items:
            require(key not in result,'DUPLICATE_FIELD',422);result[key]=value
        return result
    def constant(_):raise ValueError('Nonfinite JSON')
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=constant)

def decode(raw):
    # Parse the globally bounded frame, then enforce its command-specific ceiling.
    value=strict_json(raw,65536)
    require(len(raw.encode())<= (65536 if isinstance(value,dict) and value.get('type')=='call.sdp' else 8192),'FRAME_LIMIT',422)
    return COMMAND.validate_python(value)

LIMITS={'text_codepoints':2000,'text_bytes':6144,'messages':30,'ring_bytes':65536,'reconnect_seconds':25,'heartbeat_seconds':20,'command_results':128}
