"""Fixed aggregate-only metric catalog. Never accepts a user or route label."""
import math
from collections import defaultdict
from datetime import datetime, timezone
from .errors import require

NAMES = ('registrations matches searches_started searches_cancelled text_accepted friend_acceptances '
         'calls_attempted calls_connected calls_failed call_seconds participant_seconds support_created '
         'support_replies match_wait_ms api_latency_ms call_setup_ms requests_total server_errors '
         'auth_denials loop_lag_ms db_latency_ms professional_enabled professional_disabled repeat_matches '
         'searches_abandoned metric_samples_dropped').split()
IDS = {name: i + 1 for i, name in enumerate(NAMES)}
BINS = (5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000, 30000, math.inf)
HISTOGRAMS = {IDS[n] for n in ('match_wait_ms', 'api_latency_ms', 'call_setup_ms', 'loop_lag_ms', 'db_latency_ms')}


class Metrics:
    def __init__(self):
        self.values = defaultdict(lambda: [0, 0, [0] * 13])
        self.dropped = 0

    def add(self, name, value=1):
        require(name in IDS and type(value) in (int, float) and math.isfinite(value) and 0 <= value <= 1e12, "METRIC_INVALID")
        metric = IDS[name]
        count, total, bins = self.values[metric]
        self.values[metric][0] = count + 1
        self.values[metric][1] = total + value
        if metric in HISTOGRAMS:
            bins[next(i for i, bound in enumerate(BINS) if value <= bound)] += 1

    def drain(self):
        values = dict(self.values)
        self.values.clear()
        return values


def suppress(value):
    return {"value": None, "display": "<10", "suppressed": True} if 0 < value < 10 else {"value": value, "display": str(value), "suppressed": False}
