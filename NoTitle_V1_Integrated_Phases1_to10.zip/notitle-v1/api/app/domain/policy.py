"""Exact deployed policy and consent-prompt snapshots; no legal approval inference."""
from dataclasses import dataclass
from datetime import datetime,timezone
import hashlib,json
from copy import deepcopy
from pathlib import Path
from .errors import require

LABELS={
 'adult':'I confirm I am at least 18 years old.',
 'terms':'I accept the Terms of Service.',
 'core':'I agree to the described core processing for participation.',
 'professional':'Optional: use my private professional categories for matching relevance.',
}
REFERENCES={'adult':['terms'],'terms':['terms','community'],'core':['privacy','retention','cookies'],'professional':['privacy']}
WITHDRAWALS={'core':'Withdraw my participation consent.','professional':'Withdraw my optional professional processing.'}

def digest(value):
    return hashlib.sha256((json.dumps(value,indent=2,ensure_ascii=False,sort_keys=True)+'\n').encode()).hexdigest()

@dataclass(frozen=True)
class PolicySnapshot:
    version:str
    publication_digest:str
    state:str
    effective_at:str|None
    purposes:dict

    @classmethod
    def load(cls,path,version,publication_digest,*,production=False):
        raw=Path(path).read_bytes();value=json.loads(raw)
        require(hashlib.sha256(raw).hexdigest()==publication_digest and value['version']==version,'POLICY_ARTIFACT_MISMATCH',503)
        require(value.get('schema')==2 and value['state'] in ('draft','reviewed'),'POLICY_ARTIFACT_INVALID',503)
        public={k:value[k] for k in ('version','state','effective_at','operator','processors','policies')}
        require(value['content_sha256']==digest(public),'POLICY_CONTENT_MISMATCH',503)
        if production:
            require(value['state']=='reviewed' and not value['publication_blockers'],'POLICY_UNREVIEWED',503)
            effective=datetime.fromisoformat(value['effective_at'].replace('Z','+00:00'))
            require(effective.tzinfo is not None and effective<=datetime.now(timezone.utc),'POLICY_NOT_EFFECTIVE',503)
        purposes={}
        for purpose,label in LABELS.items():
            body={'purpose':purpose,'label':label,'policy_version':version,
                  'documents':{key:value['policies'][key] for key in REFERENCES[purpose]}}
            purposes[purpose]={'label':label,'text_digest':digest(body),'documents':REFERENCES[purpose]}
            if purpose in WITHDRAWALS:
                purposes[purpose].update(withdrawal_label=WITHDRAWALS[purpose],withdrawal_digest=digest({'purpose':purpose,'choice':False,'label':WITHDRAWALS[purpose],'control_version':1}))
        return cls(version,publication_digest,value['state'],value['effective_at'],purposes)

    def public(self):
        return {'version':self.version,'publication_digest':self.publication_digest,'state':self.state,
                'effective_at':self.effective_at,'purposes':deepcopy(self.purposes)}

    def validate(self,value,*,withdrawal=False):
        if withdrawal and value.choice is False:return
        require(value.policy_version==self.version and value.policy_digest==self.publication_digest,'POLICY_CHANGED',409)

