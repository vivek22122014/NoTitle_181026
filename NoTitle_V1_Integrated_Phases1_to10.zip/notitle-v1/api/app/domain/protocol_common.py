"""Shared strict browser wire-2 envelopes for text, social and audio."""
from typing import Annotated,Literal
from pydantic import Field
from app.contracts import StrictDTO
Ref=Annotated[str,Field(pattern=r'^[0-9a-f]{32}$')]
Nonce=Annotated[str,Field(pattern=r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')]
Positive=Annotated[int,Field(ge=1)]
class CommandBase(StrictDTO):
    protocol_version:Literal[2]
    command_id:Nonce
    owner_epoch:Positive
    socket_generation:Positive
    interaction_epoch:Positive
class EventBase(StrictDTO):
    protocol_version:Literal[2]=2
    server_sequence:Positive
    server_time:float=Field(allow_inf_nan=False)
    owner_epoch:Positive
    socket_generation:Positive
    interaction_epoch:Positive
