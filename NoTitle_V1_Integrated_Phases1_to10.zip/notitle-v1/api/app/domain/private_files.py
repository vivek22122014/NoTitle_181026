"""Private local files and the explicitly group-readable production mount profile."""
import os
import errno
from pathlib import Path
import stat

def read_private(path):
    path=Path(path)
    try:descriptor=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
    except OSError as exc:
        if exc.errno==errno.ELOOP:raise ValueError('Regular private file required') from None
        raise
    with os.fdopen(descriptor) as stream:
        info=os.fstat(stream.fileno());mode=stat.S_IMODE(info.st_mode)
        if not stat.S_ISREG(info.st_mode):raise ValueError('Regular private file required')
        private=mode in (0o400,0o600) and info.st_uid in (os.geteuid(),0)
        mounted=os.environ.get('APP_ENV')=='production' and mode==0o440 and info.st_uid==0 and info.st_gid==os.getegid()
        if not private and not mounted:raise ValueError('Private file permissions required')
        return stream.read().strip()
