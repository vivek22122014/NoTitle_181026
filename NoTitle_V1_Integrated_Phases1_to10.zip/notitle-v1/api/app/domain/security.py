"""Purpose-bound verifiers, encrypted records and replay-resistant MFA primitives."""
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import struct
import time
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from .errors import require


def token():
    return secrets.token_urlsafe(32)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()


class Security:
    def __init__(self, hmac_key: bytes, wrapping_key: bytes, *, key_version=1, wrapping_version=1, previous_wrapping_keys=None):
        require(len(hmac_key) == len(wrapping_key) == 32, "KEY_LENGTH")
        require(type(key_version) is int and key_version>=1 and type(wrapping_version) is int and 1<=wrapping_version<2**32,'KEY_VERSION')
        require(all(type(version) is int and 1<=version<2**32 and isinstance(key,bytes) and len(key)==32 for version,key in (previous_wrapping_keys or {}).items()),'KEY_VERSION')
        self.key,self.key_version,self.wrapping_version=hmac_key,key_version,wrapping_version
        self.wrappers={version:AESGCM(key) for version,key in (previous_wrapping_keys or {}).items()}
        self.wrappers[wrapping_version]=AESGCM(wrapping_key)
        self.wrapper=self.wrappers[wrapping_version]

    def digest(self, purpose, value):
        return hmac.new(self.key, purpose.encode() + b"\0" + value.encode(), hashlib.sha256).hexdigest()

    def verify(self, purpose, value, digest):
        if not isinstance(value,str) or not isinstance(digest,str):return False
        if digest.startswith('h'):
            prefix,separator,digest=digest.partition(':')
            if not separator or prefix!='h'+str(self.key_version):return False
        if not re.fullmatch(r'[0-9a-f]{64}',digest):return False
        return hmac.compare_digest(self.digest(purpose, value), digest)

    def verifier(self,purpose,value):
        return 'h'+str(self.key_version)+':'+self.digest(purpose,value)

    def derived_token(self,purpose,proof,nonce,subject):
        return base64.urlsafe_b64encode(hmac.new(self.key,canonical([purpose,proof,nonce,subject]),hashlib.sha256).digest()).decode().rstrip('=')

    def csrf(self, cookie):
        return self.digest("csrf", cookie)

    def encrypt(self, scope, body):
        # A unique data key per field allows targeted retirement; the envelope includes
        # its version and wrapped key, never a plaintext data key in PostgreSQL.
        key, nonce, wrap_nonce = os.urandom(32), os.urandom(12), os.urandom(12)
        header=b'\x02'+struct.pack('>I',self.wrapping_version)
        aad=header+("nt:"+scope).encode()
        return header+wrap_nonce+self.wrapper.encrypt(wrap_nonce,key,aad)+nonce+AESGCM(key).encrypt(nonce,body.encode(),aad)

    def decrypt(self, scope, envelope):
        envelope = bytes(envelope)
        if envelope[:1]==b'\x01':
            require(len(envelope)>=89 and 1 in self.wrappers,'ENVELOPE_INVALID')
            aad=("nt:v1:"+scope).encode();wrapper=self.wrappers[1];offset=1
        else:
            require(envelope[:1]==b'\x02' and len(envelope)>=93,'ENVELOPE_INVALID')
            version=struct.unpack('>I',envelope[1:5])[0]
            require(version in self.wrappers,'ENVELOPE_KEY_UNAVAILABLE',503)
            aad=envelope[:5]+('nt:'+scope).encode();wrapper=self.wrappers[version];offset=5
        key=wrapper.decrypt(envelope[offset:offset+12],envelope[offset+12:offset+60],aad)
        return AESGCM(key).decrypt(envelope[offset+60:offset+72],envelope[offset+72:],aad).decode()

    def cursor(self, scope, value, expiry):
        body = base64.urlsafe_b64encode(canonical([scope, value, expiry])).decode().rstrip("=")
        return body + "." + self.digest("cursor", body)

    def open_cursor(self, scope, value, now=None):
        require(isinstance(value, str) and len(value) <= 1024, "CURSOR_INVALID", 400)
        try:
            body, signature = value.split(".")
            require(self.verify("cursor", body, signature), "CURSOR_INVALID", 400)
            actual, result, expiry = json.loads(base64.urlsafe_b64decode(body + "=" * (-len(body) % 4)))
            require(actual == scope and expiry > (now or time.time()), "CURSOR_EXPIRED", 400)
            return result
        except (ValueError, TypeError, KeyError):
            require(False, "CURSOR_INVALID", 400)


def normalize_username(username):
    require(isinstance(username, str), "USERNAME_INVALID", 422)
    value = username.lower()
    require(re.fullmatch(r"[a-z0-9_-]{4,24}", value) is not None and value not in {
        "admin", "moderator", "support", "notitle", "system", "administrator", "official"}, "USERNAME_INVALID", 422)
    return value


def validate_password(password):
    require(isinstance(password, str) and 12 <= len(password) <= 128 and len(password.encode()) <= 512,
            "PASSWORD_LENGTH", 422)
    return password  # Do not strip, lowercase or normalize secrets.


def totp_counter(secret, code, last_counter, now=None):
    require(re.fullmatch(r"\d{6}", code) is not None, "MFA_INVALID", 401)
    key = base64.b32decode(secret, casefold=True)
    counter = int((time.time() if now is None else now) // 30)
    for candidate in (counter, counter - 1, counter + 1):
        if candidate <= last_counter:
            continue
        digest = hmac.new(key, struct.pack(">Q", candidate), hashlib.sha1).digest()
        offset = digest[-1] & 15
        expected = str((struct.unpack(">I", digest[offset:offset + 4])[0] & 0x7fffffff) % 1000000).zfill(6)
        if hmac.compare_digest(code, expected):
            return candidate
    require(False, "MFA_INVALID", 401)


def safe_staff_reply(body):
    require(not re.search(r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}", body), "EMAIL_NOT_ALLOWED", 422)
    require(not re.search(r"(?i)(send|share|provide|give).{0,45}(password|recovery code|otp|cvv|card number|bank login)", body),
            "SECRET_REQUEST_NOT_ALLOWED", 422)
