"""Strict call-scoped contracts. No generic media credentials endpoint exists."""
from typing import Annotated,Literal
from pydantic import Field
from app.contracts import StrictDTO
from .protocol_common import Ref,Positive,CommandBase,EventBase

class Scope(StrictDTO):interaction_handle:Ref
class CallScope(Scope):call_id:Ref
class Negotiation(CallScope):negotiation_revision:Positive
class Respond(CallScope):accept:bool
class Description(Negotiation):
    description_type:Literal['offer','answer']
    sdp:str=Field(min_length=1,max_length=65536)
class Candidate(Negotiation):candidate:str=Field(min_length=1,max_length=1024)
class RequestCommand(CommandBase):type:Literal['call.request'];payload:Scope
class RespondCommand(CommandBase):type:Literal['call.respond'];payload:Respond
class AudioCancelCommand(CommandBase):type:Literal['call.cancel'];payload:CallScope
class AudioEndCommand(CommandBase):type:Literal['call.end'];payload:CallScope
class SDPCommand(CommandBase):type:Literal['call.sdp'];payload:Description
class ICECommand(CommandBase):type:Literal['call.ice'];payload:Candidate
class ConnectedCommand(CommandBase):type:Literal['call.connected'];payload:Negotiation
class RefreshCommand(CommandBase):type:Literal['call.refresh'];payload:Negotiation
AUDIO_COMMANDS=(RequestCommand,RespondCommand,AudioCancelCommand,AudioEndCommand,SDPCommand,ICECommand,ConnectedCommand,RefreshCommand)

class Ringing(CallScope):expires_in:int=Field(ge=1,le=30)
class IceServer(StrictDTO):
    urls:list[str]=Field(min_length=1,max_length=4)
    username:str=Field(min_length=1,max_length=512)
    credential:str=Field(min_length=1,max_length=512)
class Authorized(Negotiation):
    offerer:bool
    ice_servers:list[IceServer]=Field(min_length=1,max_length=4)
class Signal(Description):pass
class Trickle(Candidate):sdpMid:Literal['0']='0';sdpMLineIndex:Literal[0]=0
class AudioEnded(CallScope):reason:str=Field(max_length=64)
class RingingEvent(EventBase):type:Literal['call.request','call.ringing'];data:Ringing
class AuthorizedEvent(EventBase):type:Literal['call.connect','call.refresh'];data:Authorized
class SDPEvent(EventBase):type:Literal['call.sdp'];data:Signal
class ICEEvent(EventBase):type:Literal['call.ice'];data:Trickle
class ConnectedEvent(EventBase):type:Literal['call.connected'];data:Negotiation
class AudioEndedEvent(EventBase):type:Literal['call.ended'];data:AudioEnded
AUDIO_EVENTS=(RingingEvent,AuthorizedEvent,SDPEvent,ICEEvent,ConnectedEvent,AudioEndedEvent)
