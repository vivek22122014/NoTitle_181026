import json
from uuid import UUID
from .errors import require

# Exact payload keys; values receive command-specific validation below.
PAYLOADS={
 'queue.join':({'gender'},set()),'queue.cancel':(set(),set()),'interaction.end':(set(),set()),
 'interaction.next':({'gender'},set()),'text.send':({'text'},set()),'text.delivered':({'message_id'},set()),
 'friend.request':(set(),set()),'friend.respond':({'accept'},set()),'friend.invite':({'peer_handle'},set()),
 'friend.invite.respond':({'peer_handle','accept'},set()),'call.request':(set(),set()),
 'call.respond':({'accept'},set()),'call.cancel':(set(),set()),'call.end':(set(),set()),
 'call.sdp':({'call_id','description_type','sdp'},set()),'call.ice':({'call_id','candidate'},set()),
 'call.connected':({'call_id'},set()),'call.refresh':({'call_id'},set()),'session.resume':(set(),set()),'heartbeat':(set(),set())}


def validate(raw):
    require(isinstance(raw,str) and len(raw.encode())<=65536,'FRAME_LIMIT',422)
    command=json.loads(raw)
    require(isinstance(command,dict) and set(command)=={'protocol_version','command_id','type','owner_epoch','socket_generation','interaction_epoch','payload'},'COMMAND_SCHEMA',422)
    require(command['protocol_version']==1 and type(command['protocol_version']) is int,'PROTOCOL_VERSION',422)
    UUID(command['command_id'])
    for field in ('owner_epoch','socket_generation','interaction_epoch'):
        require(type(command[field]) is int and command[field]>=1,'COMMAND_SCHEMA',422)
    kind=command['type'];require(kind in PAYLOADS,'COMMAND_TYPE',422)
    require(kind=='call.sdp' or len(raw.encode())<=8192,'FRAME_LIMIT',422)
    required,optional=PAYLOADS[kind];payload=command['payload']
    require(isinstance(payload,dict) and required<=set(payload)<=required|optional,'PAYLOAD_SCHEMA',422)
    if 'accept' in payload:require(type(payload['accept']) is bool,'PAYLOAD_SCHEMA',422)
    for key,value in payload.items():
        if key!='accept':require(isinstance(value,str),'PAYLOAD_SCHEMA',422)
    return command



def command_schema():
    variants=[]
    boolean={'accept'}
    for name,(required,optional) in PAYLOADS.items():
        properties={key:{'type':'boolean' if key in boolean else 'string'} for key in sorted(required|optional)}
        if 'gender' in properties:properties['gender']['enum']=['everyone','male','female','other']
        if 'text' in properties:properties['text'].update(minLength=1,maxLength=2000,description='Additionally limited to 6144 UTF-8 bytes.')
        variants.append({'type':'object','additionalProperties':False,'required':['protocol_version','command_id','type','owner_epoch','socket_generation','interaction_epoch','payload'],
            'properties':{'protocol_version':{'const':1,'type':'integer'},'command_id':{'type':'string','format':'uuid'},'type':{'const':name},
                **{key:{'type':'integer','minimum':1} for key in ('owner_epoch','socket_generation','interaction_epoch')},
                'payload':{'type':'object','additionalProperties':False,'required':sorted(required),'properties':properties}}})
    return {'$schema':'https://json-schema.org/draft/2020-12/schema','title':'NoTitle V1 WebSocket command','oneOf':variants}
