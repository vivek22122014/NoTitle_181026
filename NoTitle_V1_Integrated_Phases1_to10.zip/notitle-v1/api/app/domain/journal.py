"""Encrypted append-only feasibility journal. POSIX local replica, NOT cloud proof.
Caller supplies an independently retained anchor; rolling back both replicas and
that anchor is outside this adapter's trust boundary. Keys must live elsewhere.
"""
from pathlib import Path
import base64
import fcntl
import hashlib
import hmac
import json
import os
import re
from uuid import UUID
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

ZERO = "0" * 64

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()

def exclusive(path: Path, data: bytes):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(fd, "wb", closefd=False) as stream:
            stream.write(data)
            stream.flush()
            os.fsync(fd)
    finally:
        os.close(fd)
    parent = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(parent)
    finally:
        os.close(parent)

class JournalCorrupt(RuntimeError):
    pass

class Journal:
    def __init__(self, local: Path, replica: Path, encryption_key: bytes, signing_key: bytes):
        if local.resolve() == replica.resolve() or len(encryption_key)!=32 or len(signing_key)!=32:
            raise ValueError("Distinct stores and two 256-bit keys required")
        self.local, self.replica = local, replica
        self.aead, self.signing = AESGCM(encryption_key), signing_key
        for path in (local, replica):
            path.mkdir(parents=True, mode=0o700, exist_ok=True)
        self.lock = local / "writer.lock"

    def anchor(self, seq, tip):
        data = {"seq":seq,"tip":tip}
        return {**data,"mac":hmac.new(self.signing,canonical(data),hashlib.sha256).hexdigest()}

    def check_anchor(self, anchor):
        if set(anchor) != {"seq","tip","mac"} or type(anchor["seq"]) is not int or anchor["seq"]<0:
            raise JournalCorrupt("ANCHOR_SCHEMA")
        expected = self.anchor(anchor["seq"], anchor["tip"])
        if not hmac.compare_digest(expected["mac"], anchor["mac"]):
            raise JournalCorrupt("ANCHOR_MAC")

    def read(self, directory):
        records, tip = [], ZERO
        paths = sorted(directory.glob("*.record"))
        if len(paths)>10000:
            raise JournalCorrupt("SPIKE_LIMIT_REACHED")
        try:
            for seq,path in enumerate(paths,1):
                if path.name != f"{seq:020d}.record" or path.is_symlink() or path.stat().st_size>4096:
                    raise JournalCorrupt("JOURNAL_SEQUENCE")
                envelope = json.loads(path.read_bytes())
                if set(envelope)!={"seq","prev","nonce","ciphertext"} or envelope["seq"]!=seq or envelope["prev"]!=tip:
                    raise JournalCorrupt("JOURNAL_CHAIN")
                aad=canonical({"seq":seq,"prev":tip})
                payload=json.loads(self.aead.decrypt(base64.b64decode(envelope["nonce"],validate=True),
                                    base64.b64decode(envelope["ciphertext"],validate=True),aad))
                self.validate(payload)
                records.append(payload)
                tip=hashlib.sha256(canonical(envelope)).hexdigest()
        except JournalCorrupt:
            raise
        except Exception as exc:
            raise JournalCorrupt("JOURNAL_AUTHENTICATION") from exc
        return records, self.anchor(len(records),tip)

    @staticmethod
    def validate(payload):
        required={'operation_id','subject_ref','action'}
        optional={'receipt_ref','receipt_verifier'}
        if not required<=set(payload)<=required|optional:
            raise ValueError('Only scoped references and optional receipt verifiers in journal')
        if optional & set(payload):
            if not optional<=set(payload) or payload['action']!='delete' or not re.fullmatch(r'[a-f0-9]{32}',payload['receipt_ref']) or not re.fullmatch(r'[a-f0-9]{64}',payload['receipt_verifier']):
                raise ValueError('Receipt metadata invalid')
        UUID(payload["operation_id"]); UUID(payload["subject_ref"])
        if payload["action"] not in {"delete","hold","release_hold"}:
            raise ValueError("Unknown journal action")

    def replay(self, expected_anchor):
        self.check_anchor(expected_anchor)
        records, actual = self.read(self.replica)
        # Exact independently retained high-water mark prevents truncation/rollback.
        if actual != expected_anchor:
            raise JournalCorrupt("LATEST_CHECKPOINT_MISMATCH")
        state={}
        for record in records:
            subject=state.setdefault(record["subject_ref"],{"deleted":False,"held":False})
            if record["action"]=="delete":
                subject["deleted"]=True
                if "receipt_ref" in record:subject.setdefault("receipts",{})[record["receipt_ref"]]=record["receipt_verifier"]
            if record["action"]=="hold": subject["held"]=True
            if record["action"]=="release_hold": subject["held"]=False
        return state

    def append(self, payload):
        self.validate(payload)
        with self.lock.open("a+b") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            local_records, head=self.read(self.local)
            remote_records, _=self.read(self.replica)
            if remote_records!=local_records[:len(remote_records)]:
                raise JournalCorrupt("REPLICA_DIVERGED")
            if len(remote_records)>len(local_records):
                raise JournalCorrupt("RESTORE_LOCAL_BEFORE_APPEND")
            previous=next((r for r in local_records if r["operation_id"]==payload["operation_id"]),None)
            if previous is not None and previous!=payload:
                raise JournalCorrupt("NONCE_CONFLICT")
            if previous is None:
                if head["seq"]>=10000: raise JournalCorrupt("SPIKE_LIMIT_REACHED")
                seq=head["seq"]+1
                aad={"seq":seq,"prev":head["tip"]}
                nonce=os.urandom(12)
                envelope={**aad,"nonce":base64.b64encode(nonce).decode(),
                          "ciphertext":base64.b64encode(self.aead.encrypt(nonce,canonical(payload),canonical(aad))).decode()}
                exclusive(self.local/f"{seq:020d}.record", canonical(envelope))
            # A failed replica write leaves a locally fenced pending instruction.
            # Retrying SAME operation fills missing immutable records and verifies.
            for path in sorted(self.local.glob("*.record")):
                target=self.replica/path.name
                if target.exists():
                    if target.read_bytes()!=path.read_bytes(): raise JournalCorrupt("REPLICA_BYTES")
                else:
                    exclusive(target,path.read_bytes())
            _, local_head=self.read(self.local)
            _, remote_head=self.read(self.replica)
            if local_head!=remote_head: raise JournalCorrupt("REPLICA_VERIFY")
            return remote_head
