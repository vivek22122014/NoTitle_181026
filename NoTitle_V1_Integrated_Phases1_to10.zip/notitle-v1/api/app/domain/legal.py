"""Reviewed rule configuration; the program never invents statutory deadlines."""
from datetime import datetime,timezone,timedelta
from .errors import require

CATEGORIES={'general','payment','safety','privacy','appeal','security'}

class LegalRules:
    def __init__(self,pack=None):
        self.pack=pack or {};self.rules={};self.reviewed=False
        if not pack:return
        require(pack.get('state')=='reviewed' and bool(pack.get('review_evidence_ref')),'LEGAL_REVIEW_REQUIRED')
        require(set(pack.get('reviewed_categories',[]))==CATEGORIES,'LEGAL_COVERAGE_REQUIRED')
        require(isinstance(pack.get('rules'),list) and len(pack['rules'])<=100,'LEGAL_RULES_INVALID')
        for row in pack['rules']:
            require(isinstance(row,dict) and isinstance(row.get('id'),str) and 1<=len(row['id'])<=80 and row['id'] not in self.rules,'LEGAL_RULE_INVALID')
            require(isinstance(row.get('version'),str) and 1<=len(row['version'])<=80 and bool(row.get('authority_ref')),'LEGAL_RULE_INVALID')
            require(set(row.get('categories',[]))<=CATEGORIES and bool(row.get('categories')),'LEGAL_CATEGORY_INVALID')
            for name in ('acknowledge_seconds','act_seconds'):
                require(type(row.get(name)) is int and 0<row[name]<=366*86400,'LEGAL_DEADLINE_INVALID')
            require(row['acknowledge_seconds']<=row['act_seconds'],'LEGAL_DEADLINE_INVALID')
            start=datetime.fromisoformat(row['effective_from']);end=datetime.fromisoformat(row['effective_until']) if row.get('effective_until') else None
            require(start.tzinfo is not None and (end is None or end.tzinfo is not None and end>start),'LEGAL_EFFECTIVE_DATE_INVALID')
            self.rules[row['id']]={**row,'start':start,'end':end}
        self.reviewed=True

    def applicable(self,category,received_at):
        require(received_at.tzinfo is not None,'RECEIVED_DATE_INVALID')
        return [row for row in self.rules.values() if category in row['categories'] and row['start']<=received_at and (row['end'] is None or received_at<row['end']) and row.get('automatic',False)]

    def select(self,rule_id,category,received_at):
        row=self.rules.get(rule_id)
        require(row and category in row['categories'] and row['start']<=received_at and (row['end'] is None or received_at<row['end']),'LEGAL_RULE_NOT_APPLICABLE',422)
        return row

    @staticmethod
    def deadlines(row,received_at):
        return received_at+timedelta(seconds=row['acknowledge_seconds']),received_at+timedelta(seconds=row['act_seconds'])
