import asyncio
from dataclasses import dataclass,field
import hashlib
import json
import os
from pathlib import Path
from app.domain.security import Security
from app.domain.metrics import Metrics
from app.domain.realtime import Realtime
from app.repositories.database import Database
from app.services.identity import Identity
from app.services.support import Support
from app.services.billing import Billing
from app.services.privacy import Privacy
from app.services.social import Social
from app.services.moderation import Moderation
from app.services.analytics import Analytics
from app.services.media import Media,RelayClient
from app.jobs.worker import Worker

CATALOGS={
 'topics':['general','career','technology','wellbeing','leadership','creativity'],
 'industry':['technology','finance','education','healthcare','manufacturing','services','other'],
 'role':['individual_contributor','manager','founder','student','other'],
 'experience':['starting','early','mid','senior'],
 'interests':['learning','mentoring','hobbies','career_change','networking'],
 'genders':['male','female','other']}


def read_secret(path):
    from app.domain.private_files import read_private
    return read_private(path)


@dataclass
class ProductSettings:
    environment:str
    public_origin:str
    private_origin:str
    secure_cookies:bool
    admission:bool
    payments:bool
    audio:bool
    policy_version:str
    policy_digest:str
    dsns:dict
    hmac_key:bytes
    wrapping_key:bytes
    release_evidence:dict=field(default_factory=dict)
    secret_directory:Path=Path('.local/secrets')
    journal_directory:Path=Path('.local/journal')

    @classmethod
    def load(cls,dsn):
        directory=Path(os.environ.get('NT_SECRETS_DIR','.local/secrets'))
        environment=os.environ.get('APP_ENV','local')
        config_path=Path(os.environ.get('NT_CONFIG_FILE','.local/application.json'))
        config=json.loads(config_path.read_text())
        production=environment=='production'
        if production:
            if not all(config.get('qualification',{}).get(key) is True for key in ('dependencies','integration','browser','restore','privacy','legal','security','load')):
                raise ValueError('Unqualified production release')
            if config.get('audio') and config.get('qualification',{}).get('relay') is not True:raise ValueError('Qualified relay evidence required')
            if config.get('payments') and config.get('qualification',{}).get('merchant') is not True:raise ValueError('Qualified merchant evidence required')
            if config.get('payments') and config.get('qualification',{}).get('payment_exceptions') is not True:raise ValueError('Qualified external payment exception handling required')
            if not config['public_origin'].startswith('https://') or not config['private_origin'].startswith('https://'):
                raise ValueError('HTTPS required')
            if config['public_origin']==config['private_origin']:raise ValueError('Separate private origin required')
            if 'sslmode=verify-full' not in dsn:raise ValueError('Managed database verification required')
        roles={'public':'runtime','support':'support','private':'private','jobs':'jobs','analytics':'analytics'}
        dsns={role:read_secret(directory/(name+'_dsn')) for role,name in roles.items()}
        return cls(environment,config['public_origin'],config['private_origin'],production or config['public_origin'].startswith('https://'),
            config.get('admission',False),config.get('payments',False),config.get('audio',False),config['policy_version'],config['policy_digest'],dsns,
            bytes.fromhex(read_secret(directory/'hmac_key')),bytes.fromhex(read_secret(directory/'wrapping_key')),
            config.get('qualification',{}),directory,Path(config.get('journal_directory','.local/journal')))


class Runtime:
    def __init__(self,settings,coordinator,scope='product'):
        self.settings,self.coordinator=settings,coordinator
        self.scope=scope
        if scope in {'identity','realtime'} and (settings.payments or settings.audio):raise ValueError('Partial qualification keeps payments and media disabled')
        self.db=Database(settings.dsns)
        self.security=Security(settings.hmac_key,settings.wrapping_key)
        self.metrics=Metrics()
        from app.domain.conversation import ConversationActor
        self.realtime=(Realtime if scope=='identity' else ConversationActor)(coordinator,self.metrics)
        from app.domain.policy import PolicySnapshot
        self.policy=PolicySnapshot.load(Path(os.environ.get('NT_POLICY_FILE','policies/publication.json')),settings.policy_version,settings.policy_digest,production=settings.environment=='production')
        self.identity=Identity(self.db,self.security,self.realtime,settings.policy_version,settings.policy_digest,self.policy)
        from app.services.account_controls import AccountControls
        self.accounts=AccountControls(self.identity,CATALOGS)
        self.support=Support(self.db,self.security,self.identity)
        self.provider=None;self.webhook_secret=b''
        if settings.payments:
            from app.integrations.cashfree import CashfreeSandbox
            self.provider=CashfreeSandbox(read_secret(settings.secret_directory/'cashfree_client_id'),read_secret(settings.secret_directory/'cashfree_secret'))
            if settings.environment=='production':self.provider.BASE='https://api.cashfree.com/pg'
            self.webhook_secret=read_secret(settings.secret_directory/'cashfree_secret').encode()
        self.billing=Billing(self.db,self.security,self.provider,self.identity,settings.payments,'live' if settings.environment=='production' else 'sandbox')
        self.billing.public_origin=settings.public_origin.rstrip('/')
        self.billing.admission=lambda:self.settings.admission
        self.billing.external_adjustments_ready=lambda:self.settings.release_evidence.get('payment_exceptions') is True
        self.privacy=Privacy(self.db,self.security,self.identity)
        self.social=Social(self.db,self.realtime)
        self.moderation=Moderation(self.db,self.security,self.identity,self.support,self.privacy)
        self.analytics=Analytics(self.db,self.metrics,self.realtime)
        self.media=Media(self.realtime)
        self.catalogs=CATALOGS
        self.worker=Worker(self.db,{'payment':self.billing.reconcile,'refund':self.billing.refund,
            'delete':self.privacy.purge,'delete_confirm':self.privacy.confirm_delete,'hold_confirm':self.privacy.recover_hold,'hold_release':self.privacy.recover_hold_release,'export':self.privacy.build_export},self.analytics,self.identity,self.privacy,billing=self.billing if scope=='product' else None)
        if scope in {'identity','realtime'}:self.worker.handlers={k:v for k,v in self.worker.handlers.items() if k in {'delete','delete_confirm','hold_confirm','hold_release','export'}}
        from app.services.conversation import Conversation
        self.conversation=None if scope=='identity' else Conversation(self.realtime,self.identity,self.accounts,self.social,
            self.billing.matching_entitlement if scope=='product' else None,self.media)
        self.tasks=[]

    def cookie_name(self,kind):return ('__Host-nt_' if self.settings.secure_cookies else 'nt_local_')+kind

    async def open(self):
        from app.domain.legal import LegalRules
        rules=self.settings.secret_directory/'legal_rules'
        self.support.legal=LegalRules(json.loads(read_secret(rules))) if rules.exists() else LegalRules()
        if self.settings.environment=='production' and not self.support.legal.reviewed:raise ValueError('Reviewed legal rules required')
        if self.settings.payments:
            from app.domain.receipts import ReceiptConfiguration
            self.billing.receipt_configuration=ReceiptConfiguration(json.loads(read_secret(self.settings.secret_directory/'receipt_configuration')))
        await self.db.open()
        from app.repositories.database import one
        # Same accepted version cannot silently acquire different text or prompts.
        async with self.db.transaction('jobs') as connection:
            for purpose,proof in self.policy.purposes.items():
                await connection.execute("INSERT INTO nt.policy_versions(kind,version,content_sha256,effective_at,publication_state,prompt_text,publication_digest) VALUES(%s,%s,%s,%s,%s,%s,%s) ON CONFLICT(kind,version) DO NOTHING",(purpose,self.policy.version,proof['text_digest'],self.policy.effective_at,self.policy.state,proof['label'],self.policy.publication_digest))
                row=await one(connection,'SELECT content_sha256,publication_digest,prompt_text FROM nt.policy_versions WHERE kind=%s AND version=%s',(purpose,self.policy.version))
                if (row['content_sha256'],row['publication_digest'],row['prompt_text'])!=(proof['text_digest'],self.policy.publication_digest,proof['label']):raise ValueError('Immutable policy version changed')
        from app.integrations.journal_store import journal_from_environment
        self.privacy.journal=journal_from_environment(self.settings)
        if self.privacy.journal:
            await asyncio.to_thread(self.privacy.journal.recover_pending)
            await self.privacy.replay()
        elif self.settings.environment=='production':raise ValueError('Independent journal required')
        if self.settings.audio:
            config=json.loads(read_secret(self.settings.secret_directory/'relay_config'))
            self.media=Media(self.realtime,RelayClient(config['base'],config['certificate'],config['key'],config['ca']),config['relay_ip'])
            if self.conversation:self.conversation.attach_media(self.media)
        self.tasks=[asyncio.create_task(self.worker.run()),asyncio.create_task(self.tick()),asyncio.create_task(self.media_tick())]

    async def tick(self):
        previous=self.realtime.clock()
        while True:
            current=self.realtime.clock();elapsed=current-previous;previous=current
            self.coordinator.assert_authority()
            if self.conversation:
                self.conversation.maintenance(not self.settings.admission);self.conversation.step()
            else:self.realtime.tick()
            self.metrics.add('loop_lag_ms',max(0,elapsed-.1)*1000)
            calls=sum(i.call is not None and i.call['state']=='connected' for i in self.realtime.interactions.values())
            self.metrics.add('call_seconds',elapsed*calls)
            self.metrics.add('participant_seconds',elapsed*sum(p.interaction is not None for p in self.realtime.people.values()))
            await asyncio.sleep(.1)

    async def media_tick(self):
        # Relay IO must never stall text matching, End, or the owner heartbeat.
        while True:
            if self.media.controller:
                try:await self.media.pump()
                except asyncio.CancelledError:raise
                except Exception:
                    self.media.unavailable=True
                    for interaction in tuple(self.realtime.interactions.values()):
                        if interaction.call:self.realtime.end_call(interaction,'relay_unavailable')
            await asyncio.sleep(1)

    async def close(self):
        self.media.closing=True
        for task in self.tasks:task.cancel()
        if self.conversation:await self.conversation.close()
        if hasattr(self.social,'close'):await self.social.close()
        self.realtime.fence()
        await asyncio.gather(*self.tasks,return_exceptions=True)
        await self.media.shutdown()
        if self.provider:await self.provider.close()
        if self.media.controller:await self.media.controller.close()
        await self.db.close()
