import asyncio
import time
from uuid import uuid4
from app.repositories.database import one


class Worker:
    def __init__(self,db,handlers,analytics,identity,privacy=None,billing=None):
        self.db,self.handlers,self.analytics,self.identity=db,handlers,analytics,identity
        self.privacy=privacy
        self.billing=billing
        self.owner=uuid4().hex
        self.last_flush,self.last_retention,self.last_legal,self.last_payment_backfill=0,0,0,0
        self.last_error=None

    async def step(self):
        async with self.db.transaction('jobs') as connection:
            job=await one(connection,"""SELECT * FROM nt.durable_jobs WHERE available_at<=now() AND
                (state IN ('ready','retry') OR (state='running' AND lease_until<now()))
                AND kind=ANY(%s) ORDER BY available_at LIMIT 1 FOR UPDATE SKIP LOCKED""",(list(self.handlers),))
            if job:
                await connection.execute("UPDATE nt.durable_jobs SET state='running',lease_owner=%s,lease_until=now()+interval '60 seconds',attempts=attempts+1 WHERE id=%s",(self.owner,job['id']))
        if job:
            try:
                # Finish or cancel before the 60-second database lease can expire.
                # Durable handlers are idempotent; timed-out work retries via the same object.
                async with asyncio.timeout(45):
                    await self.handlers[job['kind']](job['object_ref'])
                state,code,delay='done',None,0
            except Exception as exc:
                code=getattr(exc,'code','JOB_RETRY')
                state='review' if job['attempts']>=27 else 'retry'
                delay=[60,300,900,3600][min(job['attempts'],3)]
                self.last_error=code
            async with self.db.transaction('jobs') as connection:
                await connection.execute("UPDATE nt.durable_jobs SET state=%s,last_error_code=%s,available_at=now()+(%s*interval '1 second'),lease_owner=NULL,lease_until=NULL WHERE id=%s AND lease_owner=%s",(state,code,delay,job['id'],self.owner))
        current=time.monotonic()
        if self.billing and current-self.last_payment_backfill>=60:
            try:await self.billing.enqueue_backfill()
            except Exception:self.last_error='PAYMENT_BACKFILL_FAILED'
            finally:self.last_payment_backfill=current
        if current-self.last_legal>=60:
            async with self.db.transaction('jobs') as connection:
                await connection.execute("WITH due AS (SELECT id,CASE WHEN act_by<now() THEN 'action_overdue' WHEN acknowledged_at IS NULL AND acknowledge_by<now() THEN 'acknowledgment_overdue' ELSE 'none' END AS next FROM nt.case_obligations WHERE status<>'completed') UPDATE nt.case_obligations o SET escalation=due.next FROM due WHERE o.id=due.id AND o.escalation IS DISTINCT FROM due.next")
            self.last_legal=current
        if current-self.last_flush>=60:
            try:
                await self.analytics.flush();self.last_flush=current
            except Exception:
                self.analytics.complete=False;self.last_error='ANALYTICS_FLUSH_FAILED';self.last_flush=current
        if current-self.last_retention>=3600:
            await self.retention();self.last_retention=current
        self.identity.prune()

    async def retention(self):
        # Expired credentials and exports are safe independent of journal authority.
        async with self.db.transaction('jobs') as connection:
            await connection.execute("""DELETE FROM nt.account_sessions s WHERE
                (expires_at<now() OR absolute_expires<now() OR revoked_at<now()-interval '1 day')
                AND NOT EXISTS(SELECT 1 FROM nt.operation_results o WHERE o.kind IN ('password_change','rotate_recovery')
                AND o.result->>'source_session'=s.id::text AND o.expires_at>now())""")
            await connection.execute('DELETE FROM nt.staff_sessions WHERE expires_at<now() OR absolute_expires<now()')
            await connection.execute('DELETE FROM nt.scoped_status_sessions WHERE expires_at<now() OR absolute_expires<now()')
            await connection.execute('DELETE FROM nt.privacy_exports WHERE expires_at<now()')
            await connection.execute('DELETE FROM nt.operation_results WHERE expires_at<now()')
            await connection.execute('DELETE FROM nt.sensitive_previews p WHERE expires_at<now() AND NOT EXISTS(SELECT 1 FROM nt.refunds r WHERE r.preview_nonce=p.nonce)')
            await connection.execute("DELETE FROM nt.outbox WHERE processed_at<now()-interval '7 days'")
            await connection.execute("DELETE FROM nt.durable_jobs WHERE state='done' AND available_at<now()-interval '30 days'")
            await connection.execute("DELETE FROM nt.webhook_inbox WHERE received_at<now()-interval '30 days'")
            await connection.execute('DELETE FROM nt.account_notices WHERE expires_at<now()')
        await self.analytics.rollup()
        if self.privacy:await self.privacy.retention_cases()

    async def run(self):
        while True:
            try:
                await self.step()
            except asyncio.CancelledError: raise
            except Exception: self.last_error='WORKER_UNAVAILABLE'
            await asyncio.sleep(1)
