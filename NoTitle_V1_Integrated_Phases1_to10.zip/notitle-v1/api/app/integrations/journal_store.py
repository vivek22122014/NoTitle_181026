"""Independent S3 checkpoint adapter; local filesystem mode is development-only.

The bucket must have versioning, retention and independent recovery custody. The
application role can create/read objects but cannot delete versions or change the
bucket policy. Production qualification must verify these provider-side controls.
"""
import json
import hashlib
import os
from pathlib import Path
from app.domain.journal import Journal,JournalCorrupt,canonical,exclusive
from app.runtime import read_secret


class LocalJournal:
    def __init__(self,root,key,signing):
        self.root=root;self.journal=Journal(root/'local',root/'replica',key,signing)
        self.anchor_path=root/'independent-anchor.json'
        if not self.anchor_path.exists():exclusive(self.anchor_path,canonical(self.journal.read(self.journal.replica)[1]))

    def append(self,payload):
        anchor=self.journal.append(payload)
        temporary=self.root/'anchor.next'
        temporary.unlink(missing_ok=True);exclusive(temporary,canonical(anchor));os.replace(temporary,self.anchor_path)
        directory=os.open(self.root,os.O_DIRECTORY)
        try:os.fsync(directory)
        finally:os.close(directory)
        return anchor

    def recover_pending(self):
        records,head=self.journal.read(self.journal.local)
        anchor=json.loads(self.anchor_path.read_bytes());self.journal.check_anchor(anchor)
        if head['seq']>anchor['seq']:self.append(records[-1])

    def verified_state(self):
        anchor=json.loads(self.anchor_path.read_bytes())
        if self.journal.read(self.journal.local)[1]!=anchor:raise JournalCorrupt('UNREPLICATED_LOCAL_INSTRUCTION')
        return self.journal.replay(anchor)


class S3Journal:
    def __init__(self,root,key,signing,bucket,prefix,region):
        import boto3
        from botocore.config import Config
        self.root,self.bucket,self.prefix=root,bucket,prefix.rstrip('/')+'/'
        self.client=boto3.client('s3',region_name=region,config=Config(connect_timeout=5,read_timeout=10,retries={'max_attempts':2,'mode':'standard'}))
        self.journal=Journal(root/'local',root/'verified-stage',key,signing)

    def read_anchor(self):
        response=self.client.get_object(Bucket=self.bucket,Key=self.prefix+'latest.json')
        data=response['Body'].read(4097)
        if len(data)>4096:raise JournalCorrupt('ANCHOR_LIMIT')
        anchor=json.loads(data);self.journal.check_anchor(anchor)
        return anchor,response['ETag']

    def recover_pending(self):
        records,head=self.journal.read(self.journal.local)
        anchor,_=self.read_anchor()
        if head['seq']>anchor['seq']:self.append(records[-1])

    def verified_state(self):
        anchor,_=self.read_anchor()
        for sequence in range(1,anchor['seq']+1):
            if sequence>10000:raise JournalCorrupt('JOURNAL_SEGMENT_LIMIT')
            name=f'{sequence:020d}.record'
            path=self.journal.replica/name
            if not path.exists():
                response=self.client.get_object(Bucket=self.bucket,Key=self.prefix+'records/'+name)
                body=response['Body'].read(4097)
                if len(body)>4096:raise JournalCorrupt('RECORD_LIMIT')
                exclusive(path,body)
            local=self.journal.local/name
            if not local.exists():exclusive(local,path.read_bytes())
            elif local.read_bytes()!=path.read_bytes():raise JournalCorrupt('LOCAL_REMOTE_DIVERGED')
        if self.journal.read(self.journal.local)[1]!=anchor:raise JournalCorrupt('UNREPLICATED_LOCAL_INSTRUCTION')
        return self.journal.replay(anchor)

    def append(self,payload):
        old,etag=self.read_anchor()
        self.journal.check_anchor(old)
        anchor=self.journal.append(payload)
        if anchor['seq']<old['seq']:raise JournalCorrupt('REMOTE_ROLLBACK_REFUSED')
        # The authenticated remote checkpoint binds the complete existing prefix.
        # Compare its exact local hash before adding anything; do not GET every old
        # object on every deletion. Startup replay separately verifies the full chain.
        if old['seq']:
            old_path=self.journal.local/f"{old['seq']:020d}.record"
            if not old_path.exists() or hashlib.sha256(old_path.read_bytes()).hexdigest()!=old['tip']:
                raise JournalCorrupt('REMOTE_PREFIX_CONFLICT')
        for sequence in range(old['seq']+1,anchor['seq']+1):
            name=f'{sequence:020d}.record';body=(self.journal.local/name).read_bytes()
            key=self.prefix+'records/'+name
            try:self.client.put_object(Bucket=self.bucket,Key=key,Body=body,ContentType='application/octet-stream',IfNoneMatch='*')
            except Exception:
                existing=self.client.get_object(Bucket=self.bucket,Key=key)['Body'].read(4097)
                if existing!=body:raise JournalCorrupt('REMOTE_RECORD_CONFLICT')
        if anchor!=old:
            self.client.put_object(Bucket=self.bucket,Key=self.prefix+'latest.json',Body=canonical(anchor),ContentType='application/json',IfMatch=etag)
        actual,_=self.read_anchor()
        if actual!=anchor:raise JournalCorrupt('REMOTE_ACK_MISMATCH')
        return anchor


def journal_from_environment(settings):
    key=bytes.fromhex(read_secret(settings.secret_directory/'journal_encryption'))
    signing=bytes.fromhex(read_secret(settings.secret_directory/'journal_signing'))
    if settings.environment=='local':return LocalJournal(settings.journal_directory,key,signing)
    config=json.loads(read_secret(settings.secret_directory/'journal_config'))
    return S3Journal(settings.journal_directory,key,signing,config['bucket'],config['prefix'],config['region'])
