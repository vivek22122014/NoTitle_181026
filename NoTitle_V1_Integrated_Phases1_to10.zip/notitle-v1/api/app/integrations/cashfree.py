"""Cashfree adapter, sandbox by default. No browser state or HTTP 200 grants entitlement.
Billing service owns durable inbox/outbox, ledger and approval authority.
"""
import asyncio
import base64
from decimal import Decimal, InvalidOperation
import hashlib
import hmac
import json
import re
from uuid import UUID

class ProviderUnknown(RuntimeError):
    pass

class ProviderRejected(RuntimeError):
    pass

def reference(value):
    if not isinstance(value,str) or not re.fullmatch(r"[A-Za-z0-9_-]{3,45}",value):
        raise ValueError("Invalid provider reference")
    return value

def amount(paise):
    if type(paise) is not int or not 1 <= paise <= 100000000:
        raise ValueError("Positive bounded integer paise required")
    return Decimal(paise)/100

def encode_payload(value):
    """Serialize provider decimal amounts as exact JSON numbers, never binary floats."""
    if isinstance(value, Decimal):
        if not value.is_finite(): raise ValueError("Non-finite provider amount")
        return format(value, 'f')
    if isinstance(value, dict):
        return '{'+','.join(json.dumps(k)+':'+encode_payload(v) for k,v in value.items())+'}'
    if isinstance(value, list): return '['+','.join(encode_payload(v) for v in value)+']'
    return json.dumps(value, allow_nan=False)

def verified_capture(order, payments, expected_id, expected_paise):
    """Use ONLY server-fetched order+payments. Preserve unknowns, never infer PAID."""
    try:
        if not isinstance(order,dict) or not isinstance(payments,list) or any(not isinstance(p,dict) for p in payments):
            return None
        def money(x):
            d=Decimal(str(x))
            if not d.is_finite() or d*100 != (d*100).to_integral_value(): raise ValueError()
            return int(d*100)
        if (order["order_id"]!=expected_id or order["order_currency"]!="INR" or
                money(order["order_amount"])!=expected_paise or order["order_status"]!="PAID"):
            return None
        matches=[p for p in payments if p.get("payment_status")=="SUCCESS" and p.get('is_captured') is not False
                 and p.get("order_id",expected_id)==expected_id and p.get("payment_currency")=="INR" and money(p.get("payment_amount"))==expected_paise]
        if len(matches)!=1: return None
        payment_id=str(matches[0]["cf_payment_id"])
        return payment_id if re.fullmatch(r"[0-9]{1,40}",payment_id) else None
    except (KeyError,ValueError,TypeError,InvalidOperation):
        return None

def verify_webhook(body: bytes, timestamp: str, signature: str, secret: bytes):
    if len(body)>262144 or not re.fullmatch(r"[0-9]{13}",timestamp):
        raise ProviderRejected("WEBHOOK_BOUNDARY")
    expected=base64.b64encode(hmac.new(secret,timestamp.encode()+body,hashlib.sha256).digest()).decode()
    if not hmac.compare_digest(expected,signature): raise ProviderRejected("WEBHOOK_SIGNATURE")
    # Timestamp freshness is not the dedupe authority; providers may deliver late.
    # Phase 8 persists event identity then independently fetches order/payment.
    return json.loads(body)

class CashfreeSandbox:
    BASE="https://sandbox.cashfree.com/pg"
    def __init__(self, client_id, secret, client=None):
        import httpx
        self.client=client or httpx.AsyncClient(timeout=httpx.Timeout(10,connect=5),follow_redirects=False)
        self.owns_client=client is None
        self.headers={"x-client-id":client_id,"x-client-secret":secret,"x-api-version":"2026-01-01"}

    async def close(self):
        if self.owns_client: await self.client.aclose()

    async def request(self, method, path, *, payload=None, nonce=None):
        import httpx
        headers=dict(self.headers)
        if payload is not None: headers['Content-Type']='application/json'
        if nonce is not None: headers["x-idempotency-key"]=str(UUID(str(nonce)))
        try:
            async with asyncio.timeout(10):
                async with self.client.stream(method,self.BASE+path,headers=headers,content=encode_payload(payload).encode() if payload is not None else None) as response:
                    if response.status_code>=500 or response.status_code in (408,409,429):
                        raise ProviderUnknown("RECONCILE_SAME_REFERENCE")
                    if response.status_code!=200: raise ProviderRejected("PROVIDER_REJECTED")
                    body=bytearray()
                    async for chunk in response.aiter_bytes():
                        if len(body)+len(chunk)>262144: raise ProviderUnknown("RESPONSE_LIMIT")
                        body.extend(chunk)
                    return json.loads(body)
        except (httpx.HTTPError,TimeoutError,ValueError) as exc:
            raise ProviderUnknown("RECONCILE_SAME_REFERENCE") from exc

    async def create_order(self, order_id, paise, customer_id, phone, nonce, *, return_url=None):
        reference(order_id); reference(customer_id)
        if not re.fullmatch(r"[0-9]{10}",phone): raise ValueError("Payment phone must contain ten digits")
        payload={
            "order_id":order_id,"order_amount":amount(paise),"order_currency":"INR",
            "customer_details":{"customer_id":customer_id,"customer_phone":phone}}
        if return_url is not None:
            from urllib.parse import urlsplit
            url=urlsplit(return_url)
            if url.scheme not in {'https','http'} or not url.hostname or url.username or url.password or url.fragment:
                raise ValueError('Invalid merchant return URL')
            if url.scheme!='https' and url.hostname not in {'localhost','127.0.0.1'}:
                raise ValueError('HTTPS merchant return URL required')
            payload['order_meta']={'return_url':return_url}
        return await self.request("POST","/orders",nonce=nonce,payload=payload)

    async def fetch_order(self, order_id):
        return await self.request("GET",f"/orders/{reference(order_id)}")

    async def fetch_payments(self, order_id):
        return await self.request("GET",f"/orders/{reference(order_id)}/payments")

    async def create_required_refund(self, order_id, refund_id, paise, basis, nonce):
        if basis not in {"statutory","verified_payment_error","binding_provider_decision"}:
            raise ValueError("Voluntary refunds prohibited")
        return await self.request("POST",f"/orders/{reference(order_id)}/refunds",nonce=nonce,
            payload={"refund_id":reference(refund_id),"refund_amount":amount(paise),
                     "refund_note":basis,"refund_speed":"STANDARD"})

    async def fetch_refund(self, order_id, refund_id):
        return await self.request("GET",f"/orders/{reference(order_id)}/refunds/{reference(refund_id)}")

    async def fetch_refunds(self, order_id):
        return await self.request("GET",f"/orders/{reference(order_id)}/refunds")

    async def fetch_disputes(self,order_id):
        return await self.request('GET',f'/orders/{reference(order_id)}/disputes')

    async def fetch_dispute(self,dispute_id):
        if not re.fullmatch(r'[0-9]{1,40}',str(dispute_id)):raise ValueError('Invalid dispute reference')
        return await self.request('GET',f'/disputes/{dispute_id}')


def verified_refunds(rows,order_id,payment_id,maximum_paise):
    """Validate independently fetched order refund records; never trust webhook amounts."""
    if not isinstance(rows,list) or len(rows)>1000:raise ProviderUnknown('REFUND_RESPONSE_INVALID')
    seen=set();verified=[]
    for row in rows:
        try:
            if not isinstance(row,dict) or row.get('order_id')!=order_id or row.get('refund_currency')!='INR' or str(row.get('cf_payment_id'))!=str(payment_id):raise ValueError()
            provider_id=str(row['cf_refund_id']);merchant_id=reference(row['refund_id'])
            if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',provider_id) or provider_id in seen:raise ValueError()
            paise=Decimal(str(row['refund_amount']))*100
            if not paise.is_finite() or paise!=paise.to_integral_value() or not 0<paise<=maximum_paise:raise ValueError()
            status=row['refund_status']
            if status not in {'SUCCESS','PENDING','PENDING_APPROVAL','ONHOLD','CANCELLED','REJECTED'}:raise ValueError()
            seen.add(provider_id);verified.append({'provider_id':provider_id,'merchant_id':merchant_id,'amount_paise':int(paise),'status':status})
        except (KeyError,ValueError,TypeError,InvalidOperation):raise ProviderUnknown('REFUND_RESPONSE_INVALID') from None
    return verified


def verified_disputes(rows,order_id,payment_id,maximum_paise):
    if not isinstance(rows,list) or len(rows)>1000:raise ProviderUnknown('DISPUTE_RESPONSE_INVALID')
    results=[];seen=set()
    statuses={'DISPUTE_CREATED','DISPUTE_DOCS_RECEIVED','DISPUTE_UNDER_REVIEW','DISPUTE_MERCHANT_WON','DISPUTE_MERCHANT_LOST','DISPUTE_MERCHANT_ACCEPTED','DISPUTE_INSUFFICIENT_EVIDENCE',
        'CHARGEBACK_CREATED','CHARGEBACK_DOCS_RECEIVED','CHARGEBACK_UNDER_REVIEW','CHARGEBACK_MERCHANT_WON','CHARGEBACK_MERCHANT_LOST','CHARGEBACK_MERCHANT_ACCEPTED','CHARGEBACK_INSUFFICIENT_EVIDENCE',
        'RETRIEVAL_CREATED','RETRIEVAL_DOCS_RECEIVED','RETRIEVAL_UNDER_REVIEW','RETRIEVAL_MERCHANT_WON','RETRIEVAL_MERCHANT_LOST','RETRIEVAL_MERCHANT_ACCEPTED','RETRIEVAL_INSUFFICIENT_EVIDENCE',
        'PRE_ARBITRATION_CREATED','PRE_ARBITRATION_DOCS_RECEIVED','PRE_ARBITRATION_UNDER_REVIEW','PRE_ARBITRATION_MERCHANT_WON','PRE_ARBITRATION_MERCHANT_LOST','PRE_ARBITRATION_MERCHANT_ACCEPTED','PRE_ARBITRATION_INSUFFICIENT_EVIDENCE',
        'ARBITRATION_CREATED','ARBITRATION_DOCS_RECEIVED','ARBITRATION_CONTEST_REQUESTED','ARBITRATION_UNDER_REVIEW','ARBITRATION_MERCHANT_WON','ARBITRATION_MERCHANT_LOST','ARBITRATION_MERCHANT_ACCEPTED','ARBITRATION_INSUFFICIENT_EVIDENCE'}
    for row in rows:
        try:
            details=row['order_details'];identifier=str(row['dispute_id']);status=row['dispute_status']
            if not re.fullmatch(r'[0-9]{1,40}',identifier) or identifier in seen or status not in statuses:raise ValueError()
            if details['order_id']!=order_id or str(details['cf_payment_id'])!=str(payment_id) or details['order_currency']!='INR' or details['payment_currency']!='INR' or row['dispute_amount_currency']!='INR':raise ValueError()
            if Decimal(str(details['order_amount']))*100!=maximum_paise or Decimal(str(details['payment_amount']))*100!=maximum_paise:raise ValueError()
            paise=Decimal(str(row['dispute_amount']))*100
            if not paise.is_finite() or paise!=paise.to_integral_value() or not 0<paise<=maximum_paise:raise ValueError()
            seen.add(identifier);results.append({'provider_id':identifier,'amount_paise':int(paise),'status':status})
        except (KeyError,ValueError,TypeError,InvalidOperation):raise ProviderUnknown('DISPUTE_RESPONSE_INVALID') from None
    return results


def external_disposition(refunds,disputes,gross_paise,granted_seconds,held_seconds,action,requested=None,already_revoked=0):
    """No pending fact can authorize release; loss principal bounds revocation."""
    pending=any(row['status'] not in {'SUCCESS','CANCELLED','REJECTED'} for row in refunds)
    pending=pending or any(not row['status'].endswith(('_MERCHANT_WON','_MERCHANT_LOST','_MERCHANT_ACCEPTED')) for row in disputes)
    if pending:raise ProviderUnknown('PROVIDER_OUTCOME_PENDING')
    refund_loss=sum(row['amount_paise'] for row in refunds if row['status']=='SUCCESS')
    lost_disputes=[row['amount_paise'] for row in disputes if row['status'].endswith(('_MERCHANT_LOST','_MERCHANT_ACCEPTED'))]
    if refund_loss and lost_disputes or len(lost_disputes)>1 or refund_loss>gross_paise:
        raise ProviderUnknown('PROVIDER_PRINCIPAL_AMBIGUOUS')
    loss=refund_loss or (lost_disputes[0] if lost_disputes else 0)
    minimum=min(held_seconds,max(0,(granted_seconds*loss+gross_paise-1)//gross_paise-already_revoked))
    if action=='restore':
        if loss:raise ProviderUnknown('VERIFIED_LOSS_PREVENTS_RESTORE')
        revoke=0
    elif action=='revoke':
        if not loss:raise ProviderUnknown('NO_VERIFIED_LOSS')
        revoke=max(minimum,requested or 0)
        if type(revoke) is not int or not 0<=revoke<=held_seconds:raise ProviderUnknown('REVOCATION_RANGE')
    else:raise ProviderUnknown('INVALID_REVIEW_ACTION')
    return {'verified_lost_paise':loss,'minimum_revoke_seconds':minimum,'seconds_to_revoke':revoke,'seconds_to_restore':held_seconds-revoke}
