ALTER TABLE nt.support_cases ADD COLUMN legal_state text NOT NULL DEFAULT 'pending_review' CHECK(legal_state IN ('pending_review','classified'));
ALTER TABLE nt.case_obligations ADD COLUMN acknowledged_at timestamptz;
ALTER TABLE nt.case_obligations ADD CONSTRAINT obligation_order CHECK(acknowledge_by>=received_at AND act_by>=acknowledge_by);
ALTER TABLE nt.case_obligations ADD CONSTRAINT obligation_status CHECK(status IN ('open','acknowledged','completed'));
