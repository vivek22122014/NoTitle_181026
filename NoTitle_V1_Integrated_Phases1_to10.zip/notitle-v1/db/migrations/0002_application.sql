-- Forward-only application schema. Deliberately no ordinary-message/audio tables.
CREATE SCHEMA nt;
ALTER TABLE nt_system.foundation_metadata DROP CONSTRAINT foundation_metadata_schema_version_check;
ALTER TABLE nt_system.foundation_metadata ADD CHECK (schema_version >= 1);
UPDATE nt_system.foundation_metadata SET schema_version=2;
CREATE TABLE nt.accounts (
 id uuid PRIMARY KEY, public_ref text NOT NULL UNIQUE, username text UNIQUE NOT NULL,
 password_hash text NOT NULL, recovery_verifier text UNIQUE NOT NULL, display_name text NOT NULL CHECK(length(display_name) BETWEEN 2 AND 24),
 gender text NOT NULL CHECK(gender IN ('male','female','other')), topic_id text NOT NULL DEFAULT 'general', bio text NOT NULL DEFAULT '' CHECK(length(bio)<=160),
 professional jsonb NOT NULL DEFAULT '{}', preferences jsonb NOT NULL DEFAULT '{"gender":"everyone","professional":false}',
 core_consent boolean NOT NULL, professional_consent boolean NOT NULL DEFAULT false,
 auth_generation bigint NOT NULL DEFAULT 1, safety_revision bigint NOT NULL DEFAULT 1,
 status text NOT NULL DEFAULT 'active' CHECK(status IN ('active','restricted','deleting','deleted')),
 created_at timestamptz NOT NULL DEFAULT now(), deleted_at timestamptz
);
CREATE TABLE nt.account_sessions (
 id uuid PRIMARY KEY, account_id uuid NOT NULL REFERENCES nt.accounts, token_hmac text UNIQUE NOT NULL,
 auth_generation bigint NOT NULL, created_at timestamptz NOT NULL DEFAULT now(), last_active timestamptz NOT NULL DEFAULT now(),
 expires_at timestamptz NOT NULL, absolute_expires timestamptz NOT NULL, reauth_at timestamptz,
 revoked_at timestamptz
);
CREATE INDEX sessions_owner ON nt.account_sessions(account_id,expires_at);
CREATE TABLE nt.policy_versions (
 kind text NOT NULL, version text NOT NULL, content_sha256 text NOT NULL, effective_at timestamptz,
 publication_state text NOT NULL CHECK(publication_state IN ('draft','reviewed','published')), PRIMARY KEY(kind,version)
);
CREATE TABLE nt.consent_records (
 id uuid PRIMARY KEY, account_id uuid REFERENCES nt.accounts, retained_subject_ref text NOT NULL,
 purpose text NOT NULL, choice boolean NOT NULL, policy_version text NOT NULL, text_digest text NOT NULL,
 recorded_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX consent_owner ON nt.consent_records(account_id,recorded_at);
CREATE TABLE nt.operation_results (
 scope_ref text NOT NULL, kind text NOT NULL, client_nonce uuid NOT NULL, keyed_digest text NOT NULL,
 result jsonb NOT NULL, created_at timestamptz NOT NULL DEFAULT now(), expires_at timestamptz NOT NULL DEFAULT now()+interval '24 hours',
 PRIMARY KEY(scope_ref,kind,client_nonce)
);
CREATE TABLE nt.friendships (
 low_account_id uuid REFERENCES nt.accounts, high_account_id uuid REFERENCES nt.accounts,
 revision bigint NOT NULL DEFAULT 1, accepted_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(low_account_id,high_account_id), CHECK(low_account_id<high_account_id)
);
CREATE INDEX friends_high ON nt.friendships(high_account_id);
CREATE TABLE nt.blocks (
 blocker_id uuid REFERENCES nt.accounts, blocked_id uuid REFERENCES nt.accounts, public_ref text UNIQUE NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(blocker_id,blocked_id), CHECK(blocker_id<>blocked_id)
);
CREATE INDEX blocks_inbound ON nt.blocks(blocked_id);
CREATE TABLE nt.account_notices (
 id uuid PRIMARY KEY, account_id uuid REFERENCES nt.accounts, kind text NOT NULL, safe_payload jsonb NOT NULL,
 issued_at timestamptz NOT NULL DEFAULT now(), seen_at timestamptz, expires_at timestamptz NOT NULL
);
CREATE TABLE nt.staff_accounts (
 id uuid PRIMARY KEY, username text UNIQUE NOT NULL, password_hash text NOT NULL,
 totp_ciphertext bytea NOT NULL, last_totp_counter bigint NOT NULL DEFAULT -1,
 status text NOT NULL DEFAULT 'active', role_version bigint NOT NULL DEFAULT 1
);
CREATE TABLE nt.staff_roles (staff_id uuid REFERENCES nt.staff_accounts, permission text NOT NULL, PRIMARY KEY(staff_id,permission));
CREATE TABLE nt.staff_sessions (
 token_hmac text PRIMARY KEY, staff_id uuid REFERENCES nt.staff_accounts, role_version bigint NOT NULL,
 mfa_at timestamptz NOT NULL, expires_at timestamptz NOT NULL, absolute_expires timestamptz NOT NULL
);
CREATE TABLE nt.staff_recovery_codes(staff_id uuid REFERENCES nt.staff_accounts, verifier text UNIQUE NOT NULL, consumed_at timestamptz);
CREATE TABLE nt.support_cases (
 id uuid PRIMARY KEY, public_ref text UNIQUE NOT NULL, account_id uuid REFERENCES nt.accounts,
 category text NOT NULL CHECK(category IN ('general','payment','safety','privacy','appeal','security')),
 subject_ciphertext bytea NOT NULL, status text NOT NULL DEFAULT 'open' CHECK(status IN ('open','in_progress','waiting_user','resolved','closed')),
 assigned_staff_id uuid REFERENCES nt.staff_accounts, parent_case_id uuid REFERENCES nt.support_cases,
 last_sequence bigint NOT NULL DEFAULT 0 CHECK(last_sequence>=0), seen_user_sequence bigint NOT NULL DEFAULT 0,
 seen_staff_sequence bigint NOT NULL DEFAULT 0, version bigint NOT NULL DEFAULT 1,
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(), closed_at timestamptz,
 CHECK(seen_user_sequence BETWEEN 0 AND last_sequence), CHECK(seen_staff_sequence BETWEEN 0 AND last_sequence),
 CHECK((status='closed')=(closed_at IS NOT NULL)), CHECK(parent_case_id<>id)
);
CREATE INDEX case_queue ON nt.support_cases(status,category,updated_at);
CREATE INDEX case_owner ON nt.support_cases(account_id,updated_at);
CREATE TABLE nt.case_messages (
 case_id uuid REFERENCES nt.support_cases, sequence bigint CHECK(sequence>0), sender_kind text NOT NULL CHECK(sender_kind IN ('user','staff')),
 sender_ref text NOT NULL, body_ciphertext bytea NOT NULL, client_nonce uuid NOT NULL, keyed_digest text NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(case_id,sequence), UNIQUE(case_id,sender_kind,client_nonce)
);
CREATE TABLE nt.case_internal_notes (
 id uuid PRIMARY KEY, case_id uuid REFERENCES nt.support_cases, staff_id uuid REFERENCES nt.staff_accounts,
 purpose text NOT NULL, body_ciphertext bytea NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE nt.case_events (
 id uuid PRIMARY KEY, case_id uuid REFERENCES nt.support_cases, actor_ref text NOT NULL, kind text NOT NULL,
 reason_code text NOT NULL, request_id text NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE nt.case_obligations (
 id uuid PRIMARY KEY, case_id uuid REFERENCES nt.support_cases, rule_version text NOT NULL, received_at timestamptz NOT NULL,
 acknowledge_by timestamptz NOT NULL, act_by timestamptz NOT NULL, status text NOT NULL DEFAULT 'open',
 completed_at timestamptz, evidence_ref text, escalation text NOT NULL DEFAULT 'none'
);
CREATE INDEX due_obligations ON nt.case_obligations(act_by) WHERE status<>'completed';
CREATE TABLE nt.access_audit (
 id uuid PRIMARY KEY, actor_ref text NOT NULL, purpose_code text NOT NULL, object_type text NOT NULL,
 object_ref text NOT NULL, action text NOT NULL, request_id text NOT NULL, created_at timestamptz NOT NULL DEFAULT now(), archive_batch text
);
CREATE TABLE nt.reports (
 id uuid PRIMARY KEY, public_ref text UNIQUE NOT NULL, reporter_ref text NOT NULL, subject_ref text NOT NULL,
 interaction_ref text NOT NULL, reason text NOT NULL, allegation_ciphertext bytea NOT NULL,
 case_id uuid REFERENCES nt.support_cases, attribution_kind text NOT NULL, submitted_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE nt.report_evidence (
 report_id uuid REFERENCES nt.reports, server_message_id text NOT NULL, sender_scoped_ref text NOT NULL,
 sent_at timestamptz NOT NULL, body_ciphertext bytea NOT NULL, source text NOT NULL CHECK(source='server_snapshot'),
 PRIMARY KEY(report_id,server_message_id)
);
CREATE TABLE nt.moderation_decisions (
 id uuid PRIMARY KEY, case_id uuid REFERENCES nt.support_cases, subject_ref text NOT NULL, action text NOT NULL,
 reason_code text NOT NULL, authority text NOT NULL, starts_at timestamptz NOT NULL, ends_at timestamptz,
 staff_id uuid REFERENCES nt.staff_accounts, appeal_ref text
);
CREATE TABLE nt.restrictions (
 id uuid PRIMARY KEY, subject_ref text NOT NULL, kind text NOT NULL, starts_at timestamptz NOT NULL,
 ends_at timestamptz, reason_code text NOT NULL, decision_id uuid REFERENCES nt.moderation_decisions, revision bigint NOT NULL DEFAULT 1
);
CREATE INDEX active_restrictions ON nt.restrictions(subject_ref,ends_at);
CREATE TABLE nt.sensitive_previews (
 nonce text PRIMARY KEY, actor_id uuid REFERENCES nt.staff_accounts, object_ref text NOT NULL,
 payload_digest text NOT NULL, payload jsonb NOT NULL, revisions jsonb NOT NULL, expires_at timestamptz NOT NULL, consumed_at timestamptz
);
CREATE TABLE nt.financial_subjects (
 id uuid PRIMARY KEY, account_id uuid UNIQUE REFERENCES nt.accounts ON DELETE SET NULL,
 ledger_revision bigint NOT NULL DEFAULT 1, last_accounted_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE nt.subject_controls (
 subject_id uuid PRIMARY KEY, account_id uuid UNIQUE REFERENCES nt.accounts,
 financial_subject_id uuid UNIQUE REFERENCES nt.financial_subjects,
 deletion_state text NOT NULL DEFAULT 'active', journal_applied_seq bigint NOT NULL DEFAULT 0, revision bigint NOT NULL DEFAULT 1
);
CREATE TABLE nt.scoped_receipts (
 public_ref text PRIMARY KEY, kind text NOT NULL CHECK(kind IN ('case','financial','deletion')),
 subject_ref text NOT NULL, verifier text UNIQUE NOT NULL, key_version integer NOT NULL DEFAULT 1,
 created_at timestamptz NOT NULL DEFAULT now(), revoked_at timestamptz
);
CREATE TABLE nt.scoped_status_sessions (
 token_hmac text PRIMARY KEY, receipt_ref text REFERENCES nt.scoped_receipts,
 expires_at timestamptz NOT NULL, absolute_expires timestamptz NOT NULL
);
CREATE VIEW nt.case_credentials AS SELECT * FROM nt.scoped_receipts WHERE kind='case';
CREATE VIEW nt.case_sessions AS SELECT s.* FROM nt.scoped_status_sessions s JOIN nt.scoped_receipts r ON r.public_ref=s.receipt_ref WHERE r.kind='case';
CREATE TABLE nt.plan_versions (
 code text NOT NULL, version text NOT NULL, gross_paise bigint NOT NULL CHECK(gross_paise>0), duration_seconds bigint NOT NULL CHECK(duration_seconds>0),
 currency text NOT NULL DEFAULT 'INR' CHECK(currency='INR'), enabled boolean NOT NULL DEFAULT false,
 tax_rule text NOT NULL DEFAULT 'unreviewed', policy_version text NOT NULL, PRIMARY KEY(code,version)
);
INSERT INTO nt.plan_versions(code,version,gross_paise,duration_seconds,policy_version) VALUES
 ('Short3','1',9900,259200,'v1-draft'),('Week7','1',19900,604800,'v1-draft'),
 ('Month30','1',49900,2592000,'v1-draft'),('Annual365','1',149900,31536000,'v1-draft');
CREATE TABLE nt.purchases (
 id uuid PRIMARY KEY, public_ref text UNIQUE NOT NULL, financial_subject_id uuid REFERENCES nt.financial_subjects,
 plan_code text NOT NULL, plan_version text NOT NULL, amount_paise bigint NOT NULL CHECK(amount_paise>0), duration_seconds bigint NOT NULL,
 merchant_order_id text UNIQUE NOT NULL, provider_order_id text UNIQUE, idempotency_key uuid UNIQUE NOT NULL,
 state text NOT NULL DEFAULT 'created', environment text NOT NULL CHECK(environment IN ('sandbox','live')), captured_at timestamptz,
 payment_session_ciphertext bytea, policy_version text NOT NULL, policy_digest text NOT NULL, policy_accepted_at timestamptz NOT NULL,
 tax_rule text NOT NULL, created_at timestamptz NOT NULL DEFAULT now(), FOREIGN KEY(plan_code,plan_version) REFERENCES nt.plan_versions
);
CREATE INDEX purchases_subject ON nt.purchases(financial_subject_id,created_at);
CREATE TABLE nt.payment_attempts (
 provider_payment_id text PRIMARY KEY, purchase_id uuid REFERENCES nt.purchases, amount_paise bigint NOT NULL,
 currency text NOT NULL CHECK(currency='INR'), environment text NOT NULL, status text NOT NULL, verified_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE nt.entitlement_lots (
 purchase_id uuid PRIMARY KEY REFERENCES nt.purchases, subject_id uuid REFERENCES nt.financial_subjects, grant_seq bigint NOT NULL,
 granted_seconds bigint NOT NULL CHECK(granted_seconds>0), consumed_seconds bigint NOT NULL DEFAULT 0 CHECK(consumed_seconds>=0),
 available_seconds bigint NOT NULL CHECK(available_seconds>=0), held_seconds bigint NOT NULL DEFAULT 0 CHECK(held_seconds>=0),
 revoked_seconds bigint NOT NULL DEFAULT 0 CHECK(revoked_seconds>=0), revision bigint NOT NULL DEFAULT 1,
 UNIQUE(subject_id,grant_seq), CHECK(granted_seconds=consumed_seconds+available_seconds+held_seconds+revoked_seconds)
);
CREATE TABLE nt.ledger_adjustments (
 id uuid PRIMARY KEY, subject_id uuid REFERENCES nt.financial_subjects, lot_id uuid REFERENCES nt.entitlement_lots(purchase_id),
 kind text NOT NULL, seconds bigint NOT NULL, origin_ref text UNIQUE NOT NULL, reason text NOT NULL, effective_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE nt.refunds (
 id uuid PRIMARY KEY, public_ref text UNIQUE NOT NULL, purchase_id uuid REFERENCES nt.purchases,
 origin_lot uuid REFERENCES nt.entitlement_lots(purchase_id), amount_paise bigint NOT NULL CHECK(amount_paise>0), held_seconds bigint NOT NULL CHECK(held_seconds>=0),
 state text NOT NULL CHECK(state IN ('held','submitting','pending','needs_review','succeeded','failed','cancelled')),
 remedy_basis text NOT NULL CHECK(remedy_basis IN ('payment_error','statutory_remedy','provider_bank_direction')),
 evidence_ref text NOT NULL, decision_reason text NOT NULL, preview_nonce text UNIQUE REFERENCES nt.sensitive_previews,
 provider_ref text UNIQUE NOT NULL, idempotency_key uuid UNIQUE NOT NULL, verified_at timestamptz, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE nt.receipts (
 public_ref text PRIMARY KEY, subject_id uuid REFERENCES nt.financial_subjects, purchase_id uuid REFERENCES nt.purchases,
 refund_id uuid REFERENCES nt.refunds, facts jsonb NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE nt.webhook_inbox (
 dedupe_digest text PRIMARY KEY, event_type text NOT NULL, merchant_order_id text NOT NULL,
 received_at timestamptz NOT NULL DEFAULT now(), processed_at timestamptz, attempts integer NOT NULL DEFAULT 0
);
CREATE TABLE nt.durable_jobs (
 id uuid PRIMARY KEY, kind text NOT NULL, dedupe_key text UNIQUE NOT NULL, object_ref text NOT NULL,
 state text NOT NULL DEFAULT 'ready' CHECK(state IN ('ready','running','retry','done','review')),
 available_at timestamptz NOT NULL DEFAULT now(), lease_owner text, lease_until timestamptz,
 attempts integer NOT NULL DEFAULT 0, last_error_code text
);
CREATE INDEX due_jobs ON nt.durable_jobs(available_at) WHERE state IN ('ready','retry','running');
CREATE TABLE nt.outbox (
 id uuid PRIMARY KEY, kind text NOT NULL, object_ref text NOT NULL, metric_id integer CHECK(metric_id BETWEEN 1 AND 26), processed_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE nt.privacy_requests (
 id uuid PRIMARY KEY, subject_id uuid REFERENCES nt.subject_controls, case_id uuid REFERENCES nt.support_cases,
 kind text NOT NULL, verification_state text NOT NULL DEFAULT 'pending', deadline timestamptz, status text NOT NULL DEFAULT 'received'
);
CREATE TABLE nt.privacy_exports (
 public_ref text PRIMARY KEY, subject_id uuid REFERENCES nt.subject_controls, state text NOT NULL DEFAULT 'pending',
 object_ciphertext bytea, expires_at timestamptz NOT NULL, delivered_at timestamptz
);
CREATE TABLE nt.legal_holds (
 id uuid PRIMARY KEY, subject_ref text NOT NULL, scope text NOT NULL, basis text NOT NULL,
 approver uuid REFERENCES nt.staff_accounts, review_at timestamptz NOT NULL, expires_at timestamptz NOT NULL,
 journal_seq bigint NOT NULL, state text NOT NULL DEFAULT 'active', CHECK(review_at<=expires_at)
);
CREATE TABLE nt.journal_checkpoints(stream_id text PRIMARY KEY, applied_seq bigint NOT NULL, hash text NOT NULL, independently_verified_at timestamptz);
CREATE TABLE nt.retention_registry(category text PRIMARY KEY, policy_version text NOT NULL, trigger_name text NOT NULL, duration_days integer, owner text NOT NULL);
INSERT INTO nt.retention_registry VALUES
 ('support','v1-draft','closed_at',90,'support'),('safety','v1-draft','closed_at',180,'safety'),
 ('profile','v1-draft','deleted_at',30,'privacy'),('consent','v1-draft','withdrawn_at',180,'privacy'),
 ('exports','v1-draft','created_at',1,'privacy'),('finance','unreviewed','statutory_trigger',NULL,'finance');
CREATE TABLE nt.aggregate_batches (id uuid PRIMARY KEY, digest text NOT NULL, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE nt.aggregate_buckets (
 resolution text NOT NULL CHECK(resolution IN ('minute','hour','day','month')), bucket timestamptz NOT NULL,
 metric_id integer NOT NULL CHECK(metric_id BETWEEN 1 AND 26), sample_count bigint NOT NULL CHECK(sample_count>=0),
 total double precision NOT NULL CHECK(total>=0), bins bigint[] NOT NULL CHECK(array_length(bins,1)=13),
 complete boolean NOT NULL DEFAULT true, PRIMARY KEY(resolution,bucket,metric_id)
);
CREATE TABLE nt.aggregate_rollups(resolution text NOT NULL, bucket timestamptz NOT NULL, verified_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(resolution,bucket));
GRANT USAGE ON SCHEMA nt TO nt_runtime;
GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA nt TO nt_runtime;
-- Runtime DDL remains prohibited. Dedicated role grants are applied by ops bootstrap.
