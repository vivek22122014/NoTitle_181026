-- Phase 3: immutable proof, explicit revisions and database-enforced session cap.
-- Existing policy/consent evidence is not rewritten as a stronger proof format.
UPDATE nt_system.foundation_metadata SET schema_version=3;
ALTER TABLE nt.accounts ADD COLUMN profile_revision bigint NOT NULL DEFAULT 1 CHECK(profile_revision>0);
ALTER TABLE nt.accounts ADD COLUMN preference_revision bigint NOT NULL DEFAULT 1 CHECK(preference_revision>0);
ALTER TABLE nt.accounts ADD COLUMN consent_revision bigint NOT NULL DEFAULT 1 CHECK(consent_revision>0);
ALTER TABLE nt.accounts ADD COLUMN recovery_key_version integer NOT NULL DEFAULT 1 CHECK(recovery_key_version>0);
ALTER TABLE nt.accounts ADD COLUMN session_revision bigint NOT NULL DEFAULT 0 CHECK(session_revision>=0);
ALTER TABLE nt.account_sessions ADD COLUMN key_version integer NOT NULL DEFAULT 1 CHECK(key_version>0);
ALTER TABLE nt.staff_sessions ADD COLUMN key_version integer NOT NULL DEFAULT 1 CHECK(key_version>0);
ALTER TABLE nt.staff_sessions ADD COLUMN last_active timestamptz NOT NULL DEFAULT now();
ALTER TABLE nt.scoped_status_sessions ADD COLUMN key_version integer NOT NULL DEFAULT 1 CHECK(key_version>0);
ALTER TABLE nt.scoped_status_sessions ADD COLUMN last_active timestamptz NOT NULL DEFAULT now();
ALTER TABLE nt.operation_results ADD COLUMN key_version integer NOT NULL DEFAULT 1 CHECK(key_version>0);
ALTER TABLE nt.consent_records ADD COLUMN proof_format integer NOT NULL DEFAULT 1 CHECK(proof_format IN (1,2));
ALTER TABLE nt.consent_records ADD COLUMN publication_digest text;
ALTER TABLE nt.consent_records ADD COLUMN decision_text text;
ALTER TABLE nt.consent_records ADD COLUMN decision_revision bigint;
ALTER TABLE nt.consent_records ALTER COLUMN recorded_at SET DEFAULT clock_timestamp();
ALTER TABLE nt.consent_records ADD CONSTRAINT consent_purpose CHECK(purpose IN ('adult','terms','core','professional'));
ALTER TABLE nt.consent_records ADD CONSTRAINT consent_exact_proof CHECK(proof_format=1 OR
 (publication_digest IS NOT NULL AND publication_digest ~ '^[0-9a-f]{64}$' AND text_digest ~ '^[0-9a-f]{64}$' AND decision_text IS NOT NULL AND decision_revision IS NOT NULL AND decision_revision>0));
ALTER TABLE nt.consent_records ADD CONSTRAINT consent_policy_snapshot FOREIGN KEY(purpose,policy_version) REFERENCES nt.policy_versions(kind,version) NOT VALID;
ALTER TABLE nt.policy_versions ADD COLUMN prompt_text text;
ALTER TABLE nt.policy_versions ADD COLUMN publication_digest text;
CREATE INDEX consent_latest ON nt.consent_records(account_id,purpose,recorded_at DESC,id);
CREATE INDEX operation_expiry ON nt.operation_results(expires_at);
CREATE INDEX operation_source_session ON nt.operation_results((result->>'source_session')) WHERE kind IN ('password_change','rotate_recovery');
CREATE INDEX scope_session_expiry ON nt.scoped_status_sessions(expires_at,absolute_expires);
ALTER TABLE nt.privacy_requests ADD COLUMN client_nonce uuid;
CREATE UNIQUE INDEX privacy_request_nonce ON nt.privacy_requests(subject_id,client_nonce);
ALTER TABLE nt.privacy_exports ADD COLUMN created_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE nt.privacy_exports ADD COLUMN client_nonce uuid;
CREATE UNIQUE INDEX export_request_nonce ON nt.privacy_exports(subject_id,client_nonce);

-- Caller and trigger both lock the account. The trigger also protects direct SQL
-- and another future session issuer from exceeding five live sessions.
CREATE FUNCTION nt.enforce_session_limit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE current_generation bigint; current_status text; live_count integer;
BEGIN
 UPDATE nt.accounts SET session_revision=session_revision+1 WHERE id=NEW.account_id RETURNING auth_generation,status INTO current_generation,current_status;
 IF NEW.revoked_at IS NULL AND NEW.expires_at>statement_timestamp() AND NEW.absolute_expires>statement_timestamp() THEN
  IF current_status NOT IN ('active','restricted') OR NEW.auth_generation<>current_generation THEN
   RAISE EXCEPTION 'SESSION_AUTHORITY_INVALID' USING ERRCODE='23514';
  END IF;
  SELECT count(*) INTO live_count FROM nt.account_sessions WHERE account_id=NEW.account_id
   AND id<>NEW.id AND revoked_at IS NULL AND expires_at>statement_timestamp() AND absolute_expires>statement_timestamp();
  IF live_count>=5 THEN RAISE EXCEPTION 'SESSION_LIMIT' USING ERRCODE='23514'; END IF;
 END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER session_limit BEFORE INSERT OR UPDATE ON nt.account_sessions FOR EACH ROW EXECUTE FUNCTION nt.enforce_session_limit();
REVOKE ALL ON FUNCTION nt.enforce_session_limit() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION nt.enforce_session_limit() TO nt_runtime,nt_private,nt_jobs;

-- The support role can validate and lock a presented account capability without
-- SELECT access to passwords, recovery verifiers or the whole session table.
CREATE FUNCTION nt.lock_case_account(aid uuid,presented_hmac text,generation bigint) RETURNS boolean
 LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,nt AS $$
DECLARE matched boolean;
BEGIN
 PERFORM 1 FROM nt.accounts WHERE id=aid FOR UPDATE;
 SELECT EXISTS(SELECT 1 FROM nt.accounts a JOIN nt.account_sessions s ON s.account_id=a.id
  WHERE a.id=aid AND a.auth_generation=generation AND s.auth_generation=a.auth_generation
  AND s.token_hmac=presented_hmac AND s.revoked_at IS NULL AND s.expires_at>clock_timestamp()
  AND s.absolute_expires>clock_timestamp() AND a.status IN ('active','restricted')) INTO matched;
 RETURN matched;
END;
$$;
REVOKE ALL ON FUNCTION nt.lock_case_account(uuid,text,bigint) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION nt.lock_case_account(uuid,text,bigint) TO nt_support;

REVOKE UPDATE,DELETE ON nt.consent_records FROM nt_runtime,nt_support,nt_private;
REVOKE UPDATE ON nt.consent_records FROM nt_jobs;
REVOKE INSERT,UPDATE,DELETE ON nt.policy_versions FROM nt_runtime,nt_support,nt_private;
REVOKE UPDATE,DELETE ON nt.policy_versions FROM nt_jobs;
GRANT SELECT,INSERT ON nt.policy_versions TO nt_jobs;
GRANT SELECT ON nt.retention_registry TO nt_runtime;
INSERT INTO nt.retention_registry VALUES
 ('account_sessions','v1-draft','idle_or_absolute_expiry',30,'identity'),
 ('scoped_sessions','v1-draft','idle_or_absolute_expiry',1,'identity'),
 ('operation_results','v1-draft','created_at',1,'identity')
 ON CONFLICT(category) DO NOTHING;
