-- Aggregate-only account inventory. Preserve existing view column names/order.
-- Total means retained registered accounts, including restricted accounts;
-- anonymous guests and accounts already deleting/deleted are excluded.
CREATE OR REPLACE VIEW nt.analytics_operational AS SELECT
 (SELECT count(*) FROM nt.accounts WHERE status='active') AS current_accounts,
 (SELECT count(*) FROM nt.support_cases WHERE status NOT IN ('resolved','closed')) AS open_cases,
 (SELECT count(*) FROM nt.accounts WHERE status IN ('active','restricted')) AS total_accounts;
GRANT SELECT ON nt.analytics_operational TO nt_analytics;
