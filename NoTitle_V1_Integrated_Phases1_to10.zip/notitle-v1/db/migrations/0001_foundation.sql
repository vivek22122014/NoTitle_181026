CREATE SEQUENCE nt_system.owner_epoch_seq AS bigint MINVALUE 1 NO CYCLE;
CREATE TABLE nt_system.foundation_metadata (
    singleton boolean PRIMARY KEY DEFAULT true CHECK (singleton),
    protocol_version integer NOT NULL CHECK (protocol_version = 1),
    schema_version integer NOT NULL CHECK (schema_version = 1)
);
INSERT INTO nt_system.foundation_metadata VALUES (true, 1, 1);
GRANT USAGE ON SCHEMA nt_system TO nt_runtime;
GRANT USAGE, SELECT ON SEQUENCE nt_system.owner_epoch_seq TO nt_runtime;
GRANT SELECT ON nt_system.foundation_metadata TO nt_runtime;
-- Ordinary conversations, queues, audio and guest profiles are intentionally absent.
