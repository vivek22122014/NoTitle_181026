-- Read only user-visible remedy status. Staff decision/evidence columns stay private.
GRANT SELECT(public_ref,purchase_id,amount_paise,state,remedy_basis,created_at,verified_at)
 ON nt.refunds TO nt_runtime;
