-- Restrict append-only records at the database role boundary.
REVOKE UPDATE ON nt.case_messages,nt.receipts,nt.payment_attempts,nt.consent_records,nt.case_events FROM nt_runtime,nt_support,nt_private,nt_jobs;
REVOKE UPDATE,DELETE ON nt.access_audit FROM nt_runtime,nt_support,nt_private;
REVOKE UPDATE ON nt.access_audit FROM nt_jobs;
GRANT UPDATE(archive_batch) ON nt.access_audit TO nt_jobs;
ALTER TABLE nt.case_internal_notes ADD COLUMN client_nonce uuid;
ALTER TABLE nt.case_internal_notes ADD COLUMN keyed_digest text;
CREATE UNIQUE INDEX case_note_nonce ON nt.case_internal_notes(case_id,staff_id,client_nonce);
CREATE UNIQUE INDEX obligation_rule_once ON nt.case_obligations(case_id,rule_version);
ALTER TABLE nt.case_events ADD COLUMN reason_ciphertext bytea;
