ALTER TABLE nt.purchases ADD COLUMN receipt_snapshot jsonb;
ALTER TABLE nt.receipts ADD COLUMN receipt_number bigint GENERATED ALWAYS AS IDENTITY;
CREATE UNIQUE INDEX receipt_number_unique ON nt.receipts(receipt_number);
GRANT USAGE,SELECT ON SEQUENCE nt.receipts_receipt_number_seq TO nt_jobs,nt_private;
ALTER TABLE nt.legal_holds ADD COLUMN release_nonce uuid;
CREATE UNIQUE INDEX receipt_refund_once ON nt.receipts(refund_id) WHERE refund_id IS NOT NULL;
CREATE UNIQUE INDEX receipt_capture_once ON nt.receipts(purchase_id) WHERE refund_id IS NULL;
