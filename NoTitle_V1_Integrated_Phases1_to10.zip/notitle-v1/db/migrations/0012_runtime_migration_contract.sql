-- Startup may verify migration identity, never write or delete migration history.
GRANT SELECT(name,sha256) ON nt_system.schema_migrations TO nt_runtime;
