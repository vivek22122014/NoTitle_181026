CREATE TABLE nt.external_financial_reviews (
 purchase_id uuid PRIMARY KEY REFERENCES nt.purchases,
 revision bigint NOT NULL DEFAULT 1 CHECK(revision>0),
 state text NOT NULL DEFAULT 'open' CHECK(state IN ('open','restored','revoked')),
 held_seconds bigint NOT NULL DEFAULT 0 CHECK(held_seconds>=0),
 event_refs jsonb NOT NULL DEFAULT '[]' CHECK(jsonb_typeof(event_refs)='array'),
 provider_digest text, resolved_preview text,
 created_at timestamptz NOT NULL DEFAULT now(),updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT,INSERT,UPDATE,DELETE ON nt.external_financial_reviews TO nt_private,nt_jobs;
CREATE INDEX external_resolution_receipt_preview ON nt.receipts((facts->>'preview_ref'))
 WHERE facts->>'document_kind'='external_financial_resolution';
