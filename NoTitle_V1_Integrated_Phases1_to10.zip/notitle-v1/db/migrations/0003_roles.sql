CREATE VIEW nt.analytics_operational AS SELECT
 (SELECT count(*) FROM nt.accounts WHERE status='active') AS current_accounts,
 (SELECT count(*) FROM nt.support_cases WHERE status NOT IN ('resolved','closed')) AS open_cases;
REVOKE ALL ON ALL TABLES IN SCHEMA nt FROM nt_runtime;
GRANT USAGE ON SCHEMA nt TO nt_runtime,nt_support,nt_private,nt_jobs,nt_analytics;
GRANT SELECT,INSERT,UPDATE,DELETE ON nt.accounts,nt.account_sessions,nt.consent_records,nt.operation_results,
 nt.financial_subjects,nt.subject_controls,nt.scoped_receipts,nt.friendships,nt.blocks,nt.account_notices,
 nt.purchases,nt.entitlement_lots,nt.privacy_requests,nt.privacy_exports,nt.durable_jobs,nt.outbox TO nt_runtime;
GRANT SELECT ON nt.policy_versions,nt.plan_versions,nt.restrictions,nt.support_cases,nt.receipts TO nt_runtime;
GRANT SELECT,INSERT,UPDATE,DELETE ON nt.support_cases,nt.case_messages,nt.case_events,nt.case_obligations,
 nt.reports,nt.report_evidence,nt.operation_results,nt.scoped_receipts,nt.scoped_status_sessions,nt.outbox TO nt_support;
GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA nt TO nt_private,nt_jobs;
REVOKE ALL ON nt.staff_accounts,nt.staff_roles,nt.staff_recovery_codes FROM nt_jobs;
GRANT SELECT ON nt.aggregate_buckets,nt.analytics_operational TO nt_analytics;
REVOKE INSERT,UPDATE,DELETE ON nt.access_audit,nt.case_events,nt.consent_records,nt.payment_attempts,nt.receipts FROM nt_analytics;
ALTER DEFAULT PRIVILEGES IN SCHEMA nt REVOKE ALL ON TABLES FROM PUBLIC;
-- Roles are NOINHERIT/NOSUPERUSER/NOCREATEDB/NOCREATEROLE; none has schema CREATE.
