"""Reuse only static exports bound to the current source and immutable Node image."""
import hashlib
import json
from pathlib import Path

EXCLUDED={'node_modules','.next','out','__pycache__'}


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def web_inputs(root):
    root=Path(root)
    files={str(p.relative_to(root)):sha(p) for p in sorted((root/'web').rglob('*'))
           if p.is_file() and not EXCLUDED.intersection(p.relative_to(root).parts) and p.suffix!='.tsbuildinfo'}
    for name in ('package.json','package-lock.json','infra/Dockerfile.web'):
        files[name]=sha(root/name)
    # Policy inputs and fixed routes affect the HTML and the consent digest.
    for base in ('policies','contracts'):
        for path in sorted((root/base).rglob('*.json')):
            files[str(path.relative_to(root))]=sha(path)
    for name in ('ops/check-web.mjs','ops/csp.py','ops/export_audit.py','ops/interface.py','ops/policies.py'):
        if (root/name).exists():files[name]=sha(root/name)
    config=json.loads((root/'versions.lock').read_text())
    files['node_image']=config['image_digests']['NODE_BASE']
    return hashlib.sha256(json.dumps(files,sort_keys=True).encode()).hexdigest()


def inventory(directory):
    result={}
    for path in sorted(directory.rglob('*')):
        if path.is_symlink():raise ValueError('Symlinks are not static build artifacts')
        if path.is_file() and path.name!='build-manifest.json':result[str(path.relative_to(directory))]=sha(path)
    return result


def record(root,directory):
    directory=Path(directory)
    for app in ('public','admin'):
        for name in ('index.html','404.html','foundation/index.html'):
            if not (directory/app/name).is_file():raise ValueError('Missing static export: '+app+'/'+name)
    (directory/'build-manifest.json').write_text(json.dumps({'source_sha256':web_inputs(root),'files':inventory(directory)},indent=2)+'\n')


def verify(root,directory):
    directory=Path(directory);recorded=json.loads((directory/'build-manifest.json').read_text())
    if recorded['source_sha256']!=web_inputs(root) or recorded['files']!=inventory(directory):
        raise ValueError('Static export inputs or artifact bytes changed; rebuild')
    return recorded
