#!/usr/bin/env python3
"""Local Phase 1 dispatcher. All subprocesses use argv arrays, never a shell."""
import argparse
import asyncio
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import secrets
import shutil
import signal
import tempfile
import subprocess
import sys
import time
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
LOCAL=ROOT/".local"
sys.path[:0]=[str(ROOT),str(ROOT/"api")]

class GateError(RuntimeError): pass

def run(args, **kwargs):
    return subprocess.run([str(a) for a in args],cwd=ROOT,check=True,**kwargs)

def save_private(path, value):
    path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    if path.exists(): return
    fd=os.open(path,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    with os.fdopen(fd,"w") as stream:
        stream.write(value);stream.flush();os.fsync(stream.fileno())

def secret(name):
    path=LOCAL/"secrets"/name
    if path.stat().st_mode & 0o077: raise GateError("Secret permissions must be 0600")
    return path.read_text().strip()

def configure(args):
    LOCAL.mkdir(mode=0o700,exist_ok=True)
    for name in ("pg_admin","pg_runtime","pg_migrator","journal_encryption","journal_signing","hmac_key","wrapping_key","pg_support","pg_private","pg_jobs","pg_analytics","pg_backup"):
        save_private(LOCAL/"secrets"/name,secrets.token_hex(32))
    for role,name in [("postgres","admin"),("nt_runtime","runtime"),("nt_migrator","migrator"),("nt_support","support"),("nt_private","private"),("nt_jobs","jobs"),("nt_analytics","analytics"),("nt_backup","backup")]:
        password=secret("pg_"+name)
        save_private(LOCAL/"secrets"/f"{name}_dsn",f"host=127.0.0.1 port=55432 dbname=notitle user={role} password={password} sslmode=disable")
    application=LOCAL/"application.json"
    if not application.exists():
        application.write_text(json.dumps({"public_origin":"http://127.0.0.1:8080","private_origin":"http://127.0.0.1:8081",
            "admission":True,"audio":False,"payments":False,"policy_version":"v1-draft",
            "policy_digest":hashlib.sha256((ROOT/"policies/publication.json").read_bytes()).hexdigest(),"qualification":{}},indent=2)+"\n")
    print("Local configuration ready; private secrets generated, existing values preserved.")

def lock_check():
    from ops.locks import LockError,verify
    try:return verify(ROOT)
    except (LockError,OSError,ValueError) as exc:
        raise GateError("Missing, stale or changed locks; run python3 ops/nt.py lock on an authorized network") from exc


def lock(args):
    from ops.locks import ARTIFACTS,inputs,sha256
    if args.check:
        lock_check();print("Dependency inputs, artifacts and image digests verified");return
    scopes=("python","web","images") if args.scope=="all" else (args.scope,)
    needed={"python":"uv","web":"npm","images":"docker"}
    for scope in scopes:
        if not shutil.which(needed[scope]):raise GateError("Install "+needed[scope]+" before resolving "+scope+" locks")
    cfg=json.loads((ROOT/"versions.lock").read_text())
    for scope in scopes:
        before=inputs(ROOT,scope)
        if scope=="python":
            run(["uv","pip","compile","api/requirements.in","--generate-hashes","--python-version","3.12","--output-file","api/requirements.lock"])
        elif scope=="web":
            run(["npm","install","--package-lock-only","--ignore-scripts","--no-audit","--no-fund"])
        else:
            images={}
            for key,tag in cfg["image_candidates"].items():
                run(["docker","pull",tag])
                result=run(["docker","image","inspect",tag,"--format","{{json .RepoDigests}}"],capture_output=True,text=True)
                candidates=json.loads(result.stdout)
                if not candidates or "@sha256:" not in candidates[0]:raise GateError("Image resolution failed")
                images[key]=candidates[0]
            (ROOT/ARTIFACTS[scope]).write_text("".join(key+"="+value+"\n" for key,value in images.items()))
            cfg["image_digests"]=images;cfg["resolved_candidates"]=dict(cfg["image_candidates"])
        if inputs(ROOT,scope)!=before:raise GateError("Dependency inputs changed during resolution; repeat that component")
        previous=cfg.setdefault("lock_inputs",{})
        if scope=="web":
            for key in list(previous):
                if key=="package.json" or key.startswith("web/"):del previous[key]
        previous.update(before)
        cfg.setdefault("lock_hashes",{})[ARTIFACTS[scope]]=sha256(ROOT/ARTIFACTS[scope])
        cfg["schema"]=2
        cfg["unresolved"]=["Run lock --check, advisory review and actual foundation qualification"]
        target=ROOT/"versions.lock.next"
        target.write_text(json.dumps(cfg,indent=2)+"\n");os.replace(target,ROOT/"versions.lock")
    print("Selected locks resolved. Review the changed inputs and artifacts before committing.")


def doctor(args):
    checks={"python_3_12":sys.version_info[:2]==(3,12)}
    if args.core:
        checks.update({name:importlib.util.find_spec(name) is not None for name in ("pydantic","cryptography")})
    else:
        checks.update({name:shutil.which(name) is not None for name in (("node","npm","docker") if args.locked else ("uv","node","npm","docker"))})
        if checks["node"]:
            version=run(["node","--version"],capture_output=True,text=True).stdout.strip()
            checks["node_24"]=version.startswith("v24.")
        try: lock_check();checks["resolved_locks"]=True
        except GateError: checks["resolved_locks"]=False
        if checks["docker"]:
            try: run(["docker","compose","version"],capture_output=True);run(["docker","info"],capture_output=True);checks["docker_engine"]=True
            except subprocess.CalledProcessError: checks["docker_engine"]=False
    print(json.dumps({"root":str(ROOT),"checks":checks,"admission":"development configuration"},indent=2))
    if not all(checks.values()): raise GateError("Prerequisites missing; see README.md")

def compose(*args, mode="product"):
    lock_check()
    return run(["docker","compose","--env-file","infra/images.env","-f","infra/compose.dev.yml",*args],env=dict(os.environ,NT_CADDY_CONFIG="./Caddyfile.foundation" if mode=="foundation" else "./Caddyfile.dev"))

def install(args):
    lock_check()
    python=ROOT/'.venv/bin/python'
    if not python.exists():run(["uv","venv","--python","3.12",str(ROOT/".venv")])
    else:run([python,'-c','import sys; assert sys.version_info[:2]==(3,12), "Python 3.12 required"'])
    run(["uv","pip","install","--python",str(ROOT/".venv/bin/python"),"--require-hashes","-r","api/requirements.lock"])

def require_runtime():
    if not importlib.util.find_spec("psycopg") or not importlib.util.find_spec("fastapi"):
        raise GateError("Run with .venv/bin/python after ops install")

async def bootstrap_db():
    import psycopg
    from psycopg import sql
    from ops.targets import local_dsn
    async with await psycopg.AsyncConnection.connect(local_dsn("admin",secret),autocommit=True) as conn:
        async with conn.cursor() as cur:
            for role,key in [("nt_migrator","pg_migrator"),("nt_runtime","pg_runtime"),("nt_support","pg_support"),("nt_private","pg_private"),("nt_jobs","pg_jobs"),("nt_analytics","pg_analytics"),("nt_backup","pg_backup")]:
                await cur.execute("SELECT 1 FROM pg_roles WHERE rolname=%s",(role,))
                if not await cur.fetchone(): await cur.execute(sql.SQL("CREATE ROLE {} LOGIN").format(sql.Identifier(role)))
                await cur.execute(sql.SQL("ALTER ROLE {} WITH LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOINHERIT PASSWORD {}").format(sql.Identifier(role),sql.Literal(secret(key))))
            await cur.execute("REVOKE ALL ON DATABASE notitle FROM PUBLIC")
            await cur.execute("GRANT CONNECT ON DATABASE notitle TO nt_runtime,nt_migrator,nt_support,nt_private,nt_jobs,nt_analytics,nt_backup")
            await cur.execute("GRANT CREATE ON DATABASE notitle TO nt_migrator")
            await cur.execute("REVOKE CREATE ON SCHEMA public FROM PUBLIC")
            await cur.execute("ALTER ROLE nt_runtime SET statement_timeout='2s'")
            await cur.execute("ALTER ROLE nt_runtime SET lock_timeout='500ms'")

async def migration(*, foundation=False):
    from app.repositories.migrations import migrate
    from ops.targets import local_dsn
    await migrate(local_dsn("migrator",secret),ROOT/"db/migrations",through=1 if foundation else None)

def db(args):
    require_runtime()
    if args.action=="bootstrap": asyncio.run(bootstrap_db())
    else: asyncio.run(migration(foundation=args.foundation))
    print("Database operation completed")

def build(args):
    if args.target in ("web","all"):
        from ops.interface import source_check
        source_check(ROOT)
    cfg=lock_check()
    if args.target in ("web","all"):
        from ops.builds import record
        LOCAL.mkdir(mode=0o700,exist_ok=True)
        # Export to a fresh directory, so removed routes cannot survive an old build.
        temporary=Path(tempfile.mkdtemp(prefix="exports-build-",dir=LOCAL))
        try:
            run(["docker","build","--file","infra/Dockerfile.web","--build-arg",f"NODE_BASE={cfg['image_digests']['NODE_BASE']}",
                 "--target","exports","--output","type=local,dest="+str(temporary),"."])
            from ops.export_audit import audit
            from ops.csp import generate
            audit(ROOT,temporary)
            for app in ('public','admin'):
                (temporary/(app+'-csp.caddy')).write_text(generate(temporary/app,checkout=app=='public'))
            record(ROOT,temporary)
            target=LOCAL/"exports"
            if target.exists():shutil.rmtree(target)
            os.replace(temporary,target)
        finally:
            if temporary.exists():shutil.rmtree(temporary)
    if args.target in ("api","all"):
        run(["docker","build","--file","infra/Dockerfile.api","--build-arg",f"PYTHON_BASE={cfg['image_digests']['PYTHON_BASE']}",
             "-t","notitle-api:v1-local","."])

def request(path):
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open("http://127.0.0.1:8000"+path,timeout=2) as result:
        return json.load(result)

def stop_runner(expected_pid=None):
    path=LOCAL/"runner.pid"
    if not path.exists(): return
    pid=int(path.read_text())
    if expected_pid is not None and pid!=expected_pid:raise GateError("Local owner changed; refusing to stop a different process")
    proc=Path(f"/proc/{pid}")
    if proc.exists():
        if b"app.runner" not in (proc/"cmdline").read_bytes() or (proc/"cwd").resolve()!=ROOT:
            raise GateError("PID identity mismatch; inspect manually")
        os.killpg(pid,signal.SIGTERM)
        for _ in range(50):
            if not proc.exists(): break
            time.sleep(.1)
        else: raise GateError("Runner did not stop; inspect process before retry")
    path.unlink()

def dev(args):
    from ops.local_lock import LocalBusy,operation
    try:
        with operation(LOCAL):return _dev(args)
    except LocalBusy as exc:raise GateError(str(exc)) from None


def _dev(args):
    if args.action=="down":
        stop_runner(args.expected_pid);compose("down");return
    if args.action=="status":
        print(json.dumps(request("/health/ready")));return
    require_runtime(); lock_check(); configure(args)
    if (LOCAL/"runner.pid").exists(): raise GateError("Existing runner PID; use dev status/down first")
    compose("up","-d","--wait","db",mode=args.mode)
    asyncio.run(bootstrap_db()); asyncio.run(migration(foundation=args.mode=="foundation"))
    if args.skip_build:
        from ops.builds import verify
        verify(ROOT,LOCAL/"exports")
    else:build(argparse.Namespace(target="web"))
    env=dict(os.environ,APP_ENV="local",APP_MODE=args.mode,PUBLIC_PORT="8000",PRIVATE_PORT="8001",NT_CONFIG_FILE=str(LOCAL/"application.json"),NT_SECRETS_DIR=str(LOCAL/"secrets"),DATABASE_DSN_FILE=str(LOCAL/"secrets/runtime_dsn"),PYTHONPATH=str(ROOT/"api"))
    log=open(LOCAL/"runner.log","ab")
    process=subprocess.Popen([sys.executable,"-m","app.runner"],cwd=ROOT,env=env,stdout=log,stderr=log,start_new_session=True)
    log.close();save_private(LOCAL/"runner.pid",str(process.pid))
    try:
        for _ in range(50):
            if process.poll() is not None: raise GateError("Runner exited; inspect .local/runner.log")
            try:
                readiness=request("/health/ready")["data"]
                if args.mode=="foundation" and (readiness.get("mode")!="foundation" or readiness.get("admission") is not False):raise GateError("Unexpected listener; foundation readiness not established")
                if args.mode=="realtime" and readiness.get("mode")!="realtime":raise GateError("Unexpected listener; realtime boundary not established")
                if args.mode=="product" and readiness.get("mode")=="foundation":raise GateError("Unexpected foundation listener")
                if args.mode=="identity" and (readiness.get('mode')!='identity' or readiness.get('admission') is not False):raise GateError('Unexpected listener; identity boundary not established')
                break
            except Exception: time.sleep(.2)
        else: raise GateError("Runner health deadline")
        compose("up","-d","--wait","--force-recreate","edge",mode=args.mode)
    except BaseException:
        if process.poll() is None: process.terminate();process.wait(timeout=5)
        (LOCAL/"runner.pid").unlink(missing_ok=True)
        raise
    print("Public http://127.0.0.1:8080 · private http://127.0.0.1:8081 · mode="+args.mode+" · local development only")

def contracts(args):
    from pydantic import TypeAdapter
    from app.contracts import Peer
    from app.domain.protocol import command_schema
    from app.http import models
    outputs={"command.schema.json":command_schema(),"peer.schema.json":Peer.model_json_schema()}
    outputs['http-requests.schema.json']={name:model.model_json_schema() for name,model in sorted(vars(models).items()) if isinstance(model,type) and issubclass(model,models.DTO) and model is not models.DTO}
    directory=ROOT/"contracts/generated";directory.mkdir(parents=True,exist_ok=True)
    for name,value in outputs.items():
        expected=json.dumps(value,indent=2,sort_keys=True)+"\n"; path=directory/name
        if args.check:
            if not path.exists() or path.read_text()!=expected: raise GateError("Contract drift")
        else: path.write_text(expected)
    print("Strict JSON contracts verified" if args.check else "Strict JSON contracts generated")
    from ops.identity_contracts import generate
    generate(ROOT,check=args.check)
    from ops.conversation_contracts import generate as conversation_contracts
    conversation_contracts(ROOT,check=args.check)

def tests(args):
    env=dict(os.environ,PYTHONPATH=os.pathsep.join([str(ROOT),str(ROOT/"api")]))
    suites=["unit"] if args.suite=="unit" else ["integration"] if args.suite=="integration" else ["unit","foundation"] if args.suite=="foundation" else ["unit","integration"]
    for suite in suites:
        if suite in {"integration","foundation"}:
            require_runtime()
            # Destructive failure injection is allowed only on this fixed local dev DB.
            env["NOTITLE_INTEGRATION"]="local-disposable"
        if suite=="foundation":
            run([sys.executable,"-m","unittest","tests.integration.test_postgres","tests.integration.test_http_provider","-v"],env=env)
        else:run([sys.executable,"-m","unittest","discover","-s",f"tests/{suite}","-v"],env=env)

def feasibility(args):
    gates=json.loads((ROOT/"docs/gates.json").read_text())
    print(json.dumps(gates,indent=2))
    raise GateError("Production qualification remains open; see evidence/REPORT.md")

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    commands=parser.add_subparsers(dest="command",required=True)
    p=commands.add_parser("doctor");p.add_argument("--core",action="store_true");p.add_argument("--locked",action="store_true");p.set_defaults(fn=doctor)
    commands.add_parser("configure").set_defaults(fn=configure)
    p=commands.add_parser("lock");p.add_argument("--check",action="store_true");p.add_argument("--scope",choices=["all","python","web","images"],default="all");p.set_defaults(fn=lock)
    commands.add_parser("install").set_defaults(fn=install)
    p=commands.add_parser("db");p.add_argument("action",choices=["bootstrap","migrate"]);p.add_argument("--foundation",action="store_true");p.set_defaults(fn=db)
    p=commands.add_parser("build");p.add_argument("--target",choices=["api","web","all"],default="all");p.set_defaults(fn=build)
    p=commands.add_parser("dev");p.add_argument("action",choices=["up","down","status"]);p.add_argument("--mode",choices=["foundation","identity","realtime","product"],default="product");p.add_argument("--skip-build",action="store_true");p.add_argument("--expected-pid",type=int);p.set_defaults(fn=dev)
    p=commands.add_parser("contracts");p.add_argument("--check",action="store_true");p.set_defaults(fn=contracts)
    p=commands.add_parser("test");p.add_argument("--suite",choices=["unit","integration","foundation","all"],default="unit");p.set_defaults(fn=tests)
    commands.add_parser("feasibility").set_defaults(fn=feasibility)
    from ops.foundation import add_commands
    add_commands(commands)
    from ops.interface import add_commands as interface_commands
    from ops.policies import add_commands as policy_commands
    interface_commands(commands);policy_commands(commands)
    from ops.identity import add_commands as identity_commands
    identity_commands(commands)
    from ops.conversation import add_commands as conversation_commands
    conversation_commands(commands)
    from ops.release import add_commands as release_commands
    release_commands(commands)
    args=parser.parse_args()
    try:
        result=args.fn(args)
        if type(result) is int:return result
    except GateError as exc: print(str(exc),file=sys.stderr);return 3
    except (OSError,ValueError,subprocess.CalledProcessError):
        print("Command failed. See prerequisite/configuration guidance; no secrets printed.",file=sys.stderr);return 4
    except Exception:
        print("Operation failed; admission remains closed. Inspect local test output.",file=sys.stderr);return 4
    return 0

if __name__=="__main__": raise SystemExit(main())
