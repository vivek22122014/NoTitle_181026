#!/usr/bin/env python3
import argparse,json,urllib.request

def check(base):
    for path in ('/health/live','/health/ready'):
        with urllib.request.urlopen(base+path,timeout=5) as response:
            body=json.load(response)
            if response.status!=200 or 'status' not in body.get('data',{}):raise RuntimeError('Health contract failed')
    print('Liveness and ownership readiness passed; feature qualification is separate.')
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--base',required=True);args=parser.parse_args();check(args.base.rstrip('/'))
