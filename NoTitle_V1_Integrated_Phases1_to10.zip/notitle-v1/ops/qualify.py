#!/usr/bin/env python3
"""Evidence collector. Missing environments fail qualification; they are never skips."""
import argparse,ast,hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CHECKS=('dependencies','integration','browser','restore','privacy','legal','security','load')

def source():
    failures=[];count=0
    for directory in ('api','relay','ops','tests'):
        for path in (ROOT/directory).rglob('*.py'):
            if '__pycache__' in path.parts:continue
            count+=1
            try:ast.parse(path.read_text(),filename=str(path))
            except SyntaxError:failures.append(str(path.relative_to(ROOT))+': syntax')
    for path in (ROOT/'web').rglob('*'):
        if path.suffix not in {'.tsx','.ts','.css','.json'} or any(p in path.parts for p in ('node_modules','.next','out')):continue
        content=path.read_text()
        if 'mailto:' in content:failures.append(str(path.relative_to(ROOT))+': support email link')
        if 'dangerouslySetInnerHTML' in content:failures.append(str(path.relative_to(ROOT))+': HTML injection boundary')
        if 'NEXT_PUBLIC_' in content and any(word in content.lower() for word in ('secret','password','private_key')):failures.append(str(path.relative_to(ROOT))+': public secret candidate')
    schemas='\n'.join(p.read_text().lower() for p in (ROOT/'db/migrations').glob('*.sql'))
    for table in ('chat_messages','audio_recordings','user_activity_logs'):
        if 'create table nt.'+table in schemas:failures.append('Forbidden persistent ordinary activity table: '+table)
    return {'status':'passed' if not failures else 'failed','python_files_parsed':count,'failures':failures,
            'limits':'Static checks only; not dependency, SQL, frontend, penetration or production qualification.'}

def collect(args):
    evidence=ROOT/'evidence';evidence.mkdir(exist_ok=True)
    result=source();(evidence/'source-checks.json').write_text(json.dumps(result,indent=2)+'\n')
    env=dict(os.environ,PYTHONPATH=str(ROOT/'api')+os.pathsep+str(ROOT))
    unit=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests/unit','-v'],cwd=ROOT,env=env,capture_output=True,text=True)
    (evidence/'unit-tests.txt').write_text(unit.stdout+unit.stderr)
    report={'recorded_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'source':result,
            'unit_status':'passed' if unit.returncode==0 else 'failed',
            'checks':{name:{'status':'not_run','reason':'Requires the separately documented environment/evidence.'} for name in CHECKS},
            'production_ready':False}
    (evidence/'qualification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'unit_status':report['unit_status'],'source_status':result['status'],'production_ready':False},indent=2))
    if unit.returncode or result['failures']:raise SystemExit(1)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('command',choices=['source','collect']);args=parser.parse_args()
    if args.command=='collect':collect(args)
    else:
        result=source();print(json.dumps(result,indent=2));raise SystemExit(0 if result['status']=='passed' else 1)
