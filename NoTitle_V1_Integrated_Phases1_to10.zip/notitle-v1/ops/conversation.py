"""Phase 4 uses the shared fixed-loopback setup/evidence pipeline."""
from ops.identity import configure,setup,verify
def add_commands(commands):
    parser=commands.add_parser('conversation',help='Phase 4 free matching and temporary text setup')
    parser.set_defaults(profile='realtime')
    actions=parser.add_subparsers(dest='conversation_action',required=True)
    actions.add_parser('configure').set_defaults(fn=configure)
    action=actions.add_parser('setup');action.add_argument('--locked',action='store_true');action.add_argument('--no-start',action='store_true');action.set_defaults(fn=setup)
    action=actions.add_parser('verify');action.add_argument('--level',choices=['core','integration','stack'],default='core');action.set_defaults(fn=verify)
