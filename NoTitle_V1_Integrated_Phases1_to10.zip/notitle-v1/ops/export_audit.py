"""Inspect actual Next exports, not source strings presented as rendered evidence."""
from html.parser import HTMLParser
import gzip
import json
from pathlib import Path
import re
from urllib.parse import unquote,urlsplit
import xml.etree.ElementTree as ET
from ops.interface import inventory,source_check
from ops.policies import check as check_policies,EMAIL

class Document(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.h1=0;self.title=[];self.in_title=False;self.hidden=0;self.text=[]
        self.metas={};self.canonical=[];self.scripts=[];self.links=[];self.violations=[];self.forms=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if any(k.lower().startswith('on') for k in a):self.violations.append('Inline event handler')
        if tag=='html' and a.get('lang')!='en':self.violations.append('Missing English language')
        if tag=='h1':self.h1+=1
        if tag=='title':self.in_title=True
        if tag in ('script','style'):self.hidden+=1
        if tag=='meta':self.metas[a.get('name') or a.get('property')]=a.get('content','')
        if tag=='link' and a.get('rel')=='canonical':self.canonical.append(a.get('href'))
        if tag=='script' and a.get('src'):self.scripts.append(a['src'])
        if tag in ('a','link') and a.get('href'):self.links.append(a['href'])
        if tag=='form':self.forms.append(a.get('method','get').lower())
        if tag=='input' and a.get('type')=='password' and self.forms and self.forms[-1]!='post':
            self.violations.append('Credential form can submit in URL')
    def handle_endtag(self,tag):
        if tag=='title':self.in_title=False
        if tag in ('script','style'):self.hidden=max(0,self.hidden-1)
        if tag=='form' and self.forms:self.forms.pop()
    def handle_data(self,value):
        if self.in_title:self.title.append(value)
        if not self.hidden:self.text.append(value)

def local_file(root,url):
    parsed=urlsplit(url)
    if parsed.scheme or parsed.netloc or not parsed.path.startswith('/') or parsed.query:
        raise ValueError('Export asset must use a local path without query')
    path=(root/unquote(parsed.path).lstrip('/')).resolve()
    if not path.is_relative_to(root.resolve()) or not path.is_file():raise ValueError('Missing/unsafe exported asset')
    return path

def norm(value):return ' '.join(value.split())

def audit(root,exports):
    root=Path(root);exports=Path(exports);source_check(root)
    routes=inventory(root);publication=check_policies(root)
    config=json.loads((root/'web/shared/site.json').read_text());seen={};initial={}
    for p in exports.rglob('*'):
        if p.is_symlink():raise ValueError('Symlink in export')
        if p.is_file() and p.suffix in ('.map','.env','.pem','.key'):raise ValueError('Source map or private file in export')
    for app in ('public','admin'):
        base=exports/app
        required=['index.html','404.html','foundation/index.html','robots.txt']
        if app=='public':required.append('sitemap.xml')
        if any(not (base/name).is_file() for name in required):raise ValueError('Incomplete '+app+' export')
        seen[app]=0
        for route in routes[app]:
            path=base/route['path'].strip('/')/'index.html'
            if not path.is_file():raise ValueError('Missing route export: '+app+route['path'])
            content=path.read_text();doc=Document();doc.feed(content);visible=norm(' '.join(doc.text))
            if doc.violations or doc.h1!=1 or not ''.join(doc.title).strip() or not doc.metas.get('description'):
                raise ValueError('Invalid accessible/metadata HTML: '+app+route['path']+' '+str(doc.violations))
            if EMAIL.search(visible):raise ValueError('Email exposed in rendered copy')
            if app=='admin' or not config['indexable'] or not route['indexable']:
                if 'noindex' not in doc.metas.get('robots',''):raise ValueError('Missing noindex')
            if app=='public':
                if len(doc.canonical)!=1 or not doc.canonical[0].startswith(config['public_origin']+'/'):
                    raise ValueError('Missing/incorrect canonical')
                if 'private-workspace-v1' in content or '/internal/v1' in content or 'NT_PRIVATE_BUNDLE' in content:
                    raise ValueError('Private content in public HTML')
                if route['kind']=='policy':
                    for heading,body in publication['policies'][route['policy']]['sections']:
                        if norm(heading) not in visible or norm(body) not in visible:raise ValueError('Policy not readable without JavaScript')
                    for key in ('content_sha256',):
                        if publication[key] not in visible:raise ValueError('Displayed policy digest mismatch')
            for href in doc.links:
                if href.startswith('/') and not href.startswith('//'):
                    parsed=urlsplit(href)
                    if parsed.query:raise ValueError('Query in static navigation')
                    target=base/unquote(parsed.path).lstrip('/')
                    if not target.is_file() and not (target/'index.html').is_file():raise ValueError('Broken local link: '+href)
            size=sum(len(gzip.compress(local_file(base,src).read_bytes(),mtime=0)) for src in set(doc.scripts))
            if app=='public' and route['kind'] in ('home','how','safety','policy','legal','contact','grievance','processors','deletion'):
                initial[route['path']]=size
                if size>150*1024:raise ValueError('Initial public JavaScript exceeds 150 KiB compressed: '+route['path'])
            seen[app]+=1
        if app=='public':
            for path in base.rglob('*'):
                if path.is_file() and path.suffix in ('.js','.html','.txt','.json'):
                    text=path.read_text()
                    if any(marker in text for marker in ('private-workspace-v1','NT_PRIVATE_BUNDLE','/internal/v1')):
                        raise ValueError('Private bundle/content in public export')
        elif 'Disallow: /' not in (base/'robots.txt').read_text():raise ValueError('Private robots is not closed')
    urls={node.text for node in ET.fromstring((exports/'public/sitemap.xml').read_text()).iter() if node.tag.endswith('}loc') or node.tag=='loc'}
    allowed={config['public_origin']+r['path'] for r in routes['public'] if r['indexable']} if config['indexable'] else set()
    if urls!=allowed:raise ValueError('Sitemap differs from allowlist')
    from ops.csp import generate
    for app in ('public','admin'):generate(exports/app)
    return {'status':'passed','routes_checked':seen,'public_initial_js_gzip_bytes':initial,
            'policy_content_sha256':publication['content_sha256'],
            'limits':'Actual HTML/assets checked. Keyboard, layout, focus, HTTP headers and interactions still need browser checks.'}
