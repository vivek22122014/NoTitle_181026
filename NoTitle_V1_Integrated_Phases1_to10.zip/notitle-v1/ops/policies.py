#!/usr/bin/env python3
"""Deterministic, fail-closed policy compilation. Never enables admission."""
from __future__ import annotations
import argparse
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import tempfile
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]
POLICY_IDS = ('privacy','terms','cookies','retention','billing','community','rights')
REVIEW_CHECKS = ('applicable_law','commencement_dates','processor_locations','no_email_feasibility',
                 'rights_deadlines','financial_retention','incident_notices','actual_practices','independent_appeal_review')
OPERATOR_FIELDS = ('legal_name','entity_type','postal_address','contact_route','outage_contact_route',
                   'grievance_role','privacy_role','governing_law','forum','launch_territories',
                   'registration_disclosure','tax_disclosure',
                   'lawful_basis_summary','rights_deadlines','financial_retention','security_retention',
                   'backup_retention','appeal_route','statutory_escalation')
PROCESSOR_FIELDS = ('name','purpose','data_categories','regions','subprocessors','transfer_arrangement','privacy_url')
SLOT = re.compile(r'\{\{operator\.([a-z_]+)\}\}')
EMAIL = re.compile(r'[\w.+-]+\s*@\s*[\w.-]+|mailto:|\[at\]|\(at\)', re.I)
UNRESOLVED = re.compile(r'\{\{|\}\}|\b(?:TODO|TBD|FIXME|lorem ipsum|your-domain|example\.com)\b', re.I)
UNSUPPORTED = re.compile(r'\bcompliant\b|100%\s+(?:secure|anonymous)|'
                         r'complies with (?:all|every) (?:laws?|regulations?)|'
                         r'guaranteed\s+(?:anonymity|security|erasure)|no refunds under any circumstances|'
                         r'refunds?\s+(?:for|on)\s+unused\s+(?:passes|subscriptions|purchases)', re.I)

def encoded(value): return (json.dumps(value,indent=2,ensure_ascii=False,sort_keys=True)+'\n').encode()
def digest(value): return hashlib.sha256(encoded(value)).hexdigest()
def read(path): return json.loads(Path(path).read_text())

def write_atomic(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(prefix=path.name+'.',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as stream:
            stream.write(encoded(value));stream.flush();os.fsync(stream.fileno())
        os.replace(name,path)
    finally: Path(name).unlink(missing_ok=True)

def instant(value):
    result=datetime.fromisoformat(value.replace('Z','+00:00'))
    if result.tzinfo is None: raise ValueError('Dates must include a timezone')
    return result

def contact(value,*,telephone=False):
    if not isinstance(value,str) or EMAIL.search(value): raise ValueError('No email exposure')
    if telephone and re.fullmatch(r'\+[1-9][0-9]{7,14}',value): return
    p=urlsplit(value)
    if (p.scheme!='https' or not p.hostname or p.username or p.password or p.query or p.fragment
            or p.port not in (None,443) or p.hostname in ('localhost','127.0.0.1')
            or p.hostname.endswith(('.internal','.test','.invalid'))):
        raise ValueError('Actual public HTTPS route required; no credentials, query or fragment')

def lint_copy(policies,*,reviewed):
    if set(policies)!=set(POLICY_IDS): raise ValueError('Exactly seven V1 policies required')
    for key,policy in policies.items():
        if set(policy)!={'title','sections'} or not isinstance(policy['title'],str) or not policy['title'].strip():
            raise ValueError('Invalid policy: '+key)
        if not isinstance(policy['sections'],list) or len(policy['sections'])<3: raise ValueError('Incomplete policy: '+key)
        headings=set()
        for section in policy['sections']:
            if not isinstance(section,list) or len(section)!=2 or any(not isinstance(s,str) or not s.strip() for s in section):
                raise ValueError('Invalid section: '+key)
            if section[0] in headings: raise ValueError('Duplicate heading: '+key)
            headings.add(section[0])
        copy=json.dumps(policy,ensure_ascii=False)
        if EMAIL.search(copy): raise ValueError('Email exposure: '+key)
        if UNSUPPORTED.search(copy): raise ValueError('Unsupported claim/refund contradiction: '+key)
        if reviewed and (UNRESOLVED.search(copy) or 'publication blocked' in copy.lower()):
            raise ValueError('Unresolved copy: '+key)
    for key in ('terms','billing'):
        text=json.dumps(policies[key]).lower()
        for phrase in ('no voluntary refunds','non-waivable','payment-error','binding','no automatic renewal'):
            if phrase not in text: raise ValueError('Missing remedy disclosure: '+key+' '+phrase)

def validate_operator(operator):
    if not isinstance(operator,dict) or set(operator)!=set(OPERATOR_FIELDS)|{'processors'}:
        raise ValueError('Operator fields must match template')
    for field in OPERATOR_FIELDS:
        v=operator[field]
        if field=='launch_territories':
            if not isinstance(v,list) or not v or any(not isinstance(x,str) or not x.strip() for x in v):
                raise ValueError('Actual launch territories required')
        elif not isinstance(v,str) or len(v.strip())<3 or len(v)>4000: raise ValueError('Actual fact required: '+field)
    copy=json.dumps(operator,ensure_ascii=False)
    if EMAIL.search(copy) or UNRESOLVED.search(copy) or UNSUPPORTED.search(copy): raise ValueError('Unresolved/forbidden operator copy')
    for field in ('contact_route','outage_contact_route','appeal_route'): contact(operator[field],telephone=field!='appeal_route')
    processors=operator['processors']
    if not isinstance(processors,list) or not processors: raise ValueError('Actual processors required')
    for p in processors:
        if not isinstance(p,dict) or set(p)!=set(PROCESSOR_FIELDS): raise ValueError('Processor fields must match template')
        for key,v in p.items():
            if key in ('data_categories','regions'):
                if not isinstance(v,list) or not v or any(not isinstance(x,str) or not x.strip() for x in v):
                    raise ValueError('Explicit categories/locations required')
            elif not isinstance(v,str) or not v.strip(): raise ValueError('Missing processor fact')
        contact(p['privacy_url'])
    if len({p['name'] for p in processors})!=len(processors): raise ValueError('Duplicate processor')

def validate_review(root,review,source_sha,now=None):
    now=now or datetime.now(timezone.utc)
    if any(review.get(k) is not True for k in REVIEW_CHECKS): raise ValueError('All review checks required')
    if review.get('source_sha256')!=source_sha: raise ValueError('Review/source mismatch')
    start,end=instant(review['reviewed_at']),instant(review['expires_at'])
    if not start<=now<end or (end-start).total_seconds()>180*86400: raise ValueError('Review expired/future/overlong')
    refs=review.get('evidence')
    if not isinstance(refs,list) or not refs: raise ValueError('Hashed review files required')
    for item in refs:
        relative=Path(item['path'])
        if relative.is_absolute() or '..' in relative.parts: raise ValueError('Evidence must stay in project')
        target=(root/relative).resolve()
        if not target.is_relative_to(root.resolve()) or not target.is_file(): raise ValueError('Missing evidence')
        if hashlib.sha256(target.read_bytes()).hexdigest()!=item['sha256']: raise ValueError('Evidence changed')

def compile_publication(source,operator=None,*,version='v1-draft',effective_at=None,review=None):
    if set(source)!={'schema','policies'} or source['schema']!=1: raise ValueError('Invalid source')
    policies=deepcopy(source['policies'])
    for p in policies.values():
        p['sections']=[[heading,SLOT.sub(lambda m:str(operator[m[1]]) if operator else
                'Not supplied — publication blocked',body)] for heading,body in p['sections']]
    state='reviewed' if operator else 'draft';lint_copy(policies,reviewed=state=='reviewed')
    public={'version':version,'state':state,'effective_at':effective_at,
            'operator':{k:v for k,v in operator.items() if k!='processors'} if operator else None,
            'processors':operator['processors'] if operator else [],'policies':policies}
    return {**public,'schema':2,'source_sha256':digest(source),'content_sha256':digest(public),
            'publication_blockers':[] if operator else list(OPERATOR_FIELDS)+['processors','current_review_evidence'],'review':review}

def generated(publication):
    return {k:v for k,v in publication.items() if k!='review'}|{'publication_sha256':digest(publication)}

def check(root=ROOT,*,require_reviewed=False):
    root=Path(root);p=read(root/'policies/publication.json');source=read(root/'policies/source.json')
    if p['state'] not in ('draft','reviewed'): raise ValueError('Invalid publication state')
    if require_reviewed and p['state']!='reviewed': raise ValueError('Publication is draft')
    if p['state']=='reviewed':
        operator=p['operator']|{'processors':p['processors']};validate_operator(operator)
        validate_review(root,p['review'],digest(source));instant(p['effective_at'])
        if any(p['review'].get(k)!=v for k,v in {'operator_sha256':digest(operator),'policy_version':p['version'],'effective_at':p['effective_at']}.items()):
            raise ValueError('Review/operator/version mismatch')
    else: operator=None
    expected=compile_publication(source,operator,version=p['version'],effective_at=p['effective_at'],review=p.get('review'))
    if expected!=p: raise ValueError('Source/publication drift')
    if read(root/'web/public/app/policies/generated.json')!=generated(p): raise ValueError('Rendered policy drift')
    return p

def store_publication(root,publication):
    # Crash between writes fails check() before build/release. Runtime acceptance is untouched.
    write_atomic(root/'policies/publication.json',publication)
    write_atomic(root/'web/public/app/policies/generated.json',generated(publication))

def publish(args,root=ROOT):
    root=Path(root);source=read(root/'policies/source.json');operator=read(args.operator);review=read(args.review)
    validate_operator(operator);validate_review(root,review,digest(source))
    if not re.fullmatch(r'[a-zA-Z0-9._-]{1,40}',args.version) or 'draft' in args.version.lower(): raise ValueError('Immutable version required')
    instant(args.effective_at)
    if any(review.get(k)!=v for k,v in {'operator_sha256':digest(operator),'policy_version':args.version,'effective_at':args.effective_at}.items()):
        raise ValueError('Review must bind actual operator, version and effective date')
    p=compile_publication(source,operator,version=args.version,effective_at=args.effective_at,review=review)
    history=root/'policies/history'/(args.version+'.json')
    if history.exists() and read(history)!=p: raise ValueError('Version immutable; choose new version')
    write_atomic(history,p);store_publication(root,p);return p

def add_commands(commands):
    p=commands.add_parser('policies',help='Compile/check reviewed copy; never enables admission')
    actions=p.add_subparsers(dest='policy_action',required=True)
    c=actions.add_parser('check');c.add_argument('--require-reviewed',action='store_true')
    actions.add_parser('compile');c=actions.add_parser('publish')
    c.add_argument('--operator',required=True,type=Path);c.add_argument('--review',required=True,type=Path)
    c.add_argument('--version',required=True);c.add_argument('--effective-at',required=True)
    c=actions.add_parser('prepare-review');c.add_argument('--operator',required=True,type=Path)
    c.add_argument('--version',required=True);c.add_argument('--effective-at',required=True)
    c.add_argument('--output',required=True,type=Path)
    p.set_defaults(fn=execute)

def execute(args):
    if args.policy_action=='prepare-review':
        operator=read(args.operator);validate_operator(operator);instant(args.effective_at)
        review={k:False for k in REVIEW_CHECKS}
        review.update(source_sha256=digest(read(ROOT/'policies/source.json')),operator_sha256=digest(operator),
                      policy_version=args.version,effective_at=args.effective_at,reviewed_at=None,expires_at=None,evidence=[])
        if args.output.exists():raise ValueError('Refuse to overwrite a review file')
        write_atomic(args.output,review);print('Review preparation saved with checks false. Obtain actual review and hashed evidence.');return
    if args.policy_action=='compile':
        if read(ROOT/'policies/publication.json')['state']!='draft': raise ValueError('Do not overwrite reviewed terms')
        p=compile_publication(read(ROOT/'policies/source.json'));store_publication(ROOT,p)
    elif args.policy_action=='publish': p=publish(args)
    else: p=check(require_reviewed=args.require_reviewed)
    print(json.dumps({'state':p['state'],'version':p['version'],'content_sha256':p['content_sha256'],
                      'publication_sha256':digest(p),'publication_blockers':p['publication_blockers'],'admission_changed':False},indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);add_commands(parser.add_subparsers(dest='command',required=True))
    try: execute(parser.parse_args())
    except (ValueError,OSError,KeyError,TypeError):
        print('Policy operation refused: check source, actual facts and current hashed review evidence.',file=sys.stderr);raise SystemExit(1)
