#!/usr/bin/env bash
# Run only on a fresh approved Ubuntu 24.04 LTS application host after reviewing this file.
set -euo pipefail
if [ "$(id -u)" -ne 0 ]; then echo 'Run as root on the selected application host.' >&2; exit 1; fi
. /etc/os-release
if [ "$ID" != ubuntu ] || [ "$VERSION_ID" != 24.04 ]; then echo 'This installer targets Ubuntu 24.04 LTS.' >&2; exit 1; fi
# Distribution-signed packages. Record the installed versions in release evidence.
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y docker.io docker-compose-v2 python3-venv postgresql-client restic ufw chrony unattended-upgrades ca-certificates acl
systemctl enable --now docker chrony
# Enable boot startup only; the unit refuses to run without a healthy committed release.
install -m 0644 "$(dirname "$0")/../infra/systemd/notitle-runtime.service" /etc/systemd/system/notitle-runtime.service
systemctl daemon-reload
systemctl enable notitle-runtime.service
install -d -m 0700 /etc/notitle/secrets
install -d -m 0750 /etc/notitle/runtime-secrets /opt/notitle/releases
install -d -m 0755 /var/lib/notitle
install -d -m 0700 -o 10001 -g 10001 /var/lib/notitle/journal
install -d -m 0750 /var/lib/notitle/caddy-data /var/lib/notitle/caddy-config
id notitle-backup >/dev/null 2>&1 || useradd --system --home /var/cache/notitle-backup --create-home notitle-backup
id notitle-monitor >/dev/null 2>&1 || useradd --system --no-create-home notitle-monitor
install -d -m 0700 -o 10001 -g 10001 /var/lib/notitle/journal/local
# Directory metadata only; encrypted journal record files remain mode 0600.
setfacl -m u:notitle-monitor:rx /var/lib/notitle/journal /var/lib/notitle/journal/local
install -d -m 0700 -o notitle-backup -g notitle-backup /var/cache/notitle-backup
install -d -m 0755 -o notitle-backup -g notitle-backup /var/lib/notitle/backup
ufw default deny incoming
ufw default allow outgoing
ufw allow OpenSSH
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable
# Narrow SSH to the operator address in the provider firewall before launch.
printf '* hard core 0\n* soft core 0\n' > /etc/security/limits.d/99-notitle.conf
swapoff -a
# Persist removal of swap using an operator-reviewed fstab change; never rewrite disk mounts blindly.
cat > /etc/sysctl.d/99-notitle.conf <<'EOF'
fs.suid_dumpable=0
kernel.core_pattern=|/bin/false
net.ipv4.tcp_syncookies=1
EOF
sysctl --system >/dev/null
echo 'Base host configured. Verify provider firewall, patch/reboot policy, disabled persistent swap and SSH host fingerprints before admission.'
