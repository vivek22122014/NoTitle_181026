#!/usr/bin/env python3
"""Generate a private mTLS CA and scoped relay/app certificates offline."""
import argparse,ipaddress,os,re
from datetime import datetime,timezone,timedelta
from pathlib import Path
from cryptography import x509
from cryptography.x509.oid import NameOID,ExtendedKeyUsageOID
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

def put(path,body):
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as file:file.write(body);file.flush();os.fsync(file.fileno())
def key_bytes(key):return key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption())
def create(args):
    ip=ipaddress.IPv4Address(args.relay_ip)
    if not re.fullmatch(r'[a-z0-9.-]+',args.relay_domain):raise ValueError('DNS name required')
    args.output.mkdir(mode=0o700,parents=True,exist_ok=False)
    now=datetime.now(timezone.utc);ca=ed25519.Ed25519PrivateKey.generate();name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'NoTitle private relay control CA')])
    cert=x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(ca.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now-timedelta(minutes=5)).not_valid_after(now+timedelta(days=3650)).add_extension(x509.BasicConstraints(ca=True,path_length=0),True).add_extension(x509.KeyUsage(False,False,False,False,False,True,True,None,None),True).sign(ca,None)
    put(args.output/'relay-ca.key',key_bytes(ca));put(args.output/'relay-ca.pem',cert.public_bytes(serialization.Encoding.PEM))
    for stem,common,usage in [('relay-control',args.relay_domain,ExtendedKeyUsageOID.SERVER_AUTH),('relay-client','notitle-application',ExtendedKeyUsageOID.CLIENT_AUTH)]:
        key=ed25519.Ed25519PrivateKey.generate()
        builder=x509.CertificateBuilder().subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,common)])).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now-timedelta(minutes=5)).not_valid_after(now+timedelta(days=90)).add_extension(x509.BasicConstraints(ca=False,path_length=None),True).add_extension(x509.ExtendedKeyUsage([usage]),True)
        if usage==ExtendedKeyUsageOID.SERVER_AUTH:builder=builder.add_extension(x509.SubjectAlternativeName([x509.DNSName(args.relay_domain),x509.IPAddress(ip)]),False)
        leaf=builder.sign(ca,None);put(args.output/(stem+'.key'),key_bytes(key));put(args.output/(stem+'.pem'),leaf.public_bytes(serialization.Encoding.PEM))
    print('Private control certificates created for 90 days. Keep the CA key offline; distribute only each host’s own leaf key and the public CA. These are separate from the public TURN TLS certificate.')
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--relay-ip',required=True);parser.add_argument('--relay-domain',required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    try:create(args)
    except Exception:raise SystemExit('PKI creation refused; supply actual relay values and a new private output directory.')
