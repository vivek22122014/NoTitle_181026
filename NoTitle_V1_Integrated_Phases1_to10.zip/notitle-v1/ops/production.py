#!/usr/bin/env python3
"""Local operator deployment tool. Never deploys from a browser-exposed agent."""
import argparse,asyncio,base64,hashlib,json,os,re,shutil,subprocess,sys,time,tempfile
from contextlib import contextmanager
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'api')]
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey,Ed25519PublicKey
from cryptography.hazmat.primitives.serialization import Encoding,PrivateFormat,PublicFormat,NoEncryption
from app.domain.security import canonical

REQUIRED=('dependencies','contracts','unit','integration','build','typecheck','browser','restore','privacy','legal','security','load','relay','merchant','payment_exceptions','accessibility','solo_rehearsal','sbom')
def run(argv,**kwargs):return subprocess.run([str(v) for v in argv],check=True,**kwargs)
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def private(path,data):
    path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    fd=os.open(path,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    with os.fdopen(fd,'wb') as file:file.write(data);file.flush();os.fsync(file.fileno())

def keygen(args):
    key=Ed25519PrivateKey.generate();private(args.key,key.private_bytes(Encoding.Raw,PrivateFormat.Raw,NoEncryption()))
    args.key.with_suffix('.pub').write_bytes(key.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw))
    print('Release signing key created. Keep the private key offline and copy only the public key to the deployment host.')

def validate_evidence(path):
    """Bind every accepted result to this exact source and contained artifact bytes."""
    from ops.foundation import source_digest
    from datetime import datetime,timezone,timedelta
    evidence=json.loads(path.read_text())
    if evidence.get('source_sha256')!=source_digest() or evidence.get('source_unchanged') is not True:
        raise ValueError('Qualification does not cover current unchanged source')
    recorded=datetime.fromisoformat(evidence['recorded_at'].replace('Z','+00:00'))
    age=datetime.now(timezone.utc)-recorded
    if age<timedelta(0) or age>timedelta(days=7):raise ValueError('Qualification freshness invalid')
    required=REQUIRED
    base=path.parent.resolve()
    for key in required:
        item=evidence.get('checks',{}).get(key,{})
        if item.get('status')!='passed':raise ValueError('Qualification incomplete: '+key)
        relative=Path(item['artifact'])
        artifact=(base/relative).resolve()
        if relative.is_absolute() or not artifact.is_relative_to(base) or not artifact.is_file() or digest(artifact)!=item.get('sha256'):
            raise ValueError('Evidence artifact mismatch')
    return evidence

def release(args):
    from ops.nt import lock_check
    lock_check()
    from ops.interface import source_check
    from ops.policies import check as check_policies
    source_check(ROOT);check_policies(ROOT,require_reviewed=True)
    if json.loads((ROOT/'web/shared/site.json').read_text())['mode']!='candidate':raise ValueError('Cannot release read-only interface fixtures as a product')
    from ops.export_audit import audit
    from ops.builds import verify as verify_exports
    verify_exports(ROOT,ROOT/'web-export')
    audit(ROOT,ROOT/'web-export')
    evidence=validate_evidence(args.evidence)
    if not re.fullmatch(r'[a-zA-Z0-9./:_-]+@sha256:[a-f0-9]{64}',args.image):raise ValueError('API digest required')
    manifest={'release_id':args.release_id,'api_image':args.image,'schema_read_min':3,'schema_read_max':3,'schema_write':3,
        'source_files':{str(path.relative_to(ROOT)):digest(path) for directory in ['api','db','web','relay','ops','infra','policies','contracts','web-export']
            for path in sorted((ROOT/directory).rglob('*')) if path.is_file() and '__pycache__' not in path.parts and path.suffix!='.pyc' and 'node_modules' not in path.parts and '.next' not in path.parts and 'out' not in path.parts},
        'qualification':{key:True for key in REQUIRED},'evidence_sha256':digest(args.evidence)}
    key=Ed25519PrivateKey.from_private_bytes(args.key.read_bytes())
    args.output.write_bytes(canonical({'manifest':manifest,'signature':base64.b64encode(key.sign(canonical(manifest))).decode()}))
    print('Signed release manifest created.')

def verify(path,key,release_dir):
    envelope=json.loads(path.read_text());manifest=envelope['manifest']
    Ed25519PublicKey.from_public_bytes(key.read_bytes()).verify(base64.b64decode(envelope['signature']),canonical(manifest))
    if not re.fullmatch(r'[A-Za-z0-9._-]{1,80}',manifest['release_id']):raise ValueError('Release name invalid')
    for relative,sha in manifest['source_files'].items():
        resolved=(release_dir/relative).resolve()
        if not resolved.is_relative_to(release_dir.resolve()) or digest(resolved)!=sha:raise ValueError('Release source mismatch')
    if not all(manifest['qualification'].get(key) for key in REQUIRED):raise ValueError('Release qualification missing')
    return manifest

def compose(args,*parts):
    run(['docker','compose','--env-file','/etc/notitle/images.env','-f',args.release_dir/'infra/compose.production.yml',*parts])

def prepare_edge(args):
    from ops.csp import generate
    files={'Caddyfile':(args.release_dir/'infra/Caddyfile.production').read_text(),
           'csp.caddy':generate(args.release_dir/'web-export/public',True),
           'admin-csp.caddy':generate(args.release_dir/'web-export/admin')}
    # Validate the target asset hashes without changing the running edge configuration.
    with tempfile.TemporaryDirectory(prefix='notitle-edge-') as directory:
        for name,body in files.items():(Path(directory)/name).write_text(body)
        run(['docker','run','--rm','--network','host','--env-file','/etc/notitle/site.env',
             '-v',directory+':/etc/notitle:ro',args.caddy_image,'caddy','validate','--config','/etc/notitle/Caddyfile'])
    return files

def install_edge(files):
    for name,body in files.items():
        target=Path('/etc/notitle')/name
        temporary=target.with_suffix(target.suffix+'.next')
        temporary.write_text(body);temporary.chmod(0o644);os.replace(temporary,target)

@contextmanager
def operation(args,kind):
    """Serialize local host changes and retain safe recovery metadata, never secrets."""
    import fcntl
    root=Path('/var/lib/notitle');root.mkdir(parents=True,exist_ok=True,mode=0o755)
    lock=root/'deployment.lock'
    with lock.open('a') as stream:
        try:fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise ValueError('Another deployment operation is running')
        manifest=json.loads(args.manifest.read_text())['manifest']
        record={'operation':kind,'release_id':manifest['release_id'],'release_directory':str(args.release_dir.resolve()),'manifest_sha256':digest(args.manifest),'started_at':time.time(),'stage':'preflight','status':'running'}
        args.operation_record=record
        try:
            record_stage(args,'preflight')
            yield
        except BaseException:
            record['status']='failed_closed';record_stage(args,record['stage']);raise
        else:
            record['status']='healthy';record_stage(args,'healthy')
        finally:fcntl.flock(stream,fcntl.LOCK_UN)

def record_stage(args,stage):
    record=getattr(args,'operation_record',None)
    if record is None:return
    record['stage']=stage;record['updated_at']=time.time()
    path=Path('/var/lib/notitle/deployment.json');temporary=path.with_suffix('.json.next')
    fd=os.open(temporary,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
    with os.fdopen(fd,'w') as file:json.dump(record,file,sort_keys=True);file.write('\n');file.flush();os.fsync(file.fileno())
    os.replace(temporary,path)

def deploy(args):
    if os.geteuid()!=0:raise ValueError('Authorized host operator required')
    verify(args.manifest,args.trust_key,args.release_dir)
    with operation(args,'deploy'):
        result=_deploy(args)
        run(['systemctl','enable','notitle-runtime.service'])
        return result

def _deploy(args):
    if os.geteuid()!=0:raise ValueError('Run on the application host as the authorized deployment operator')
    manifest=verify(args.manifest,args.trust_key,args.release_dir)
    for path in ('web-export/public/index.html','web-export/admin/index.html'):
        if not (args.release_dir/path).is_file():raise ValueError('Built web exports required')
    # Validate generated routing before stopping the current owner.
    edge_files=prepare_edge(args);record_stage(args,'edge_validated')
    run(['docker','pull',manifest['api_image']])
    compose(args,'stop','api');record_stage(args,'owner_stopped')
    # A failed backup or migration leaves the owner stopped for explicit repair.
    backup_environment=dict(os.environ)
    for line in Path('/etc/notitle/backup.env').read_text().splitlines():
        if line.strip() and not line.startswith('#'):
            name,value=line.split('=',1)
            if not re.fullmatch(r'[A-Z_][A-Z0-9_]*',name):raise ValueError('Invalid backup configuration')
            backup_environment[name]=value
    run([sys.executable,args.release_dir/'ops/backup.py','backup'],env=backup_environment);record_stage(args,'backup_verified')
    from app.repositories.migrations import migrate
    dsn=Path('/etc/notitle/secrets/migrator_dsn').read_text().strip()
    asyncio.run(migrate(dsn,args.release_dir/'db/migrations'));record_stage(args,'migrated')
    images=Path('/etc/notitle/images.env')
    images.write_text('API_IMAGE='+manifest['api_image']+'\nCADDY_IMAGE='+args.caddy_image+'\n');images.chmod(0o600)
    current=Path('/opt/notitle/current');previous=current.resolve() if current.exists() else None
    next_link=Path('/opt/notitle/next');next_link.unlink(missing_ok=True);next_link.symlink_to(args.release_dir.resolve(),target_is_directory=True);os.replace(next_link,current)
    if previous and previous!=args.release_dir.resolve():Path('/var/lib/notitle/previous-release').write_text(str(previous))
    record_stage(args,'release_switched')
    install_edge(edge_files)
    # Recreate: Docker bind mounts otherwise retain the old symlink target/inode.
    compose(args,'up','-d','--wait','--force-recreate','api','edge')
    run([sys.executable,args.release_dir/'ops/smoke.py','--base','http://127.0.0.1:8000'])
    print('Application release started. Verify the public domain, private tunnel and media evidence before opening admission.')

def rollback(args):
    if os.geteuid()!=0:raise ValueError('Authorized host operator required')
    verify(args.manifest,args.trust_key,args.release_dir)
    with operation(args,'rollback'):return _rollback(args)

def _rollback(args):
    # Roll back the application artifact only; never run the old migration inventory.
    if os.geteuid()!=0:raise ValueError('Authorized host operator required')
    manifest=verify(args.manifest,args.trust_key,args.release_dir)
    import psycopg
    with psycopg.connect(Path('/etc/notitle/secrets/runtime_dsn').read_text().strip()) as connection:
        schema=connection.execute('SELECT schema_version FROM nt_system.foundation_metadata WHERE singleton').fetchone()[0]
    if not manifest['schema_read_min']<=schema<=manifest['schema_read_max']:raise ValueError('Rollback schema incompatible; forward repair required')
    edge_files=prepare_edge(args)
    run(['docker','pull',manifest['api_image']]);compose(args,'stop','api')
    Path('/etc/notitle/images.env').write_text('API_IMAGE='+manifest['api_image']+'\nCADDY_IMAGE='+args.caddy_image+'\n')
    next_link=Path('/opt/notitle/next');next_link.unlink(missing_ok=True);next_link.symlink_to(args.release_dir.resolve(),target_is_directory=True);os.replace(next_link,Path('/opt/notitle/current'))
    install_edge(edge_files)
    # Recreate: Docker bind mounts otherwise retain the old symlink target/inode.
    compose(args,'up','-d','--wait','--force-recreate','api','edge')
    run([sys.executable,args.release_dir/'ops/smoke.py','--base','http://127.0.0.1:8000'])
    print('Compatible application artifact restored. Database contents were not rolled back.')

def render(args):
    import ipaddress
    from ops.csp import generate
    from app.runtime import read_secret
    config=json.loads(args.config.read_text())
    from ops.policies import check as check_policies,digest as policy_digest
    publication=check_policies(ROOT,require_reviewed=True)
    from ops.interface import validate_site
    site=validate_site(json.loads((ROOT/'web/shared/site.json').read_text()))
    if site['mode']!='candidate' or site['public_origin']!='https://'+config['app_domain']:raise ValueError('Rebuild the candidate for the actual public origin')
    if config.get('policy_version')!=publication['version'] or config.get('policy_digest')!=policy_digest(publication):raise ValueError('Runtime policy acceptance differs from displayed copy')
    from ops.export_audit import audit
    from ops.builds import verify as verify_exports
    verify_exports(ROOT,args.exports)
    audit(ROOT,args.exports)
    for key in ('app_domain','turn_domain'):
        if not re.fullmatch(r'[a-z0-9](?:[a-z0-9.-]{0,251}[a-z0-9])?',config[key]) or '.' not in config[key]:raise ValueError('Real DNS names required')
    for key in ('app_ip','relay_ip'):ipaddress.IPv4Address(config[key])
    args.output.mkdir(parents=True,exist_ok=True,mode=0o700)
    (args.output/'site.env').write_text('APP_DOMAIN='+config['app_domain']+'\n')
    (args.output/'runtime.env').write_text('APP_ENV=production\nDATABASE_DSN_FILE=/run/secrets/runtime_dsn\nNT_CONFIG_FILE=/etc/notitle/application.json\nNT_SECRETS_DIR=/run/secrets\nAWS_SHARED_CREDENTIALS_FILE=/run/secrets/journal_aws_credentials\nAWS_PROFILE=notitle-journal\nPUBLIC_PORT=8000\nPRIVATE_PORT=8001\n')
    (args.output/'application.json').write_text(json.dumps({'public_origin':'https://'+config['app_domain'],'private_origin':'https://admin.notitle.internal:8443',
        'admission':False,'audio':False,'payments':False,'policy_version':config['policy_version'],'policy_digest':config['policy_digest'],
        'journal_directory':'/var/lib/notitle/journal','qualification':config.get('qualification',{})},indent=2)+'\n')
    shutil.copyfile(ROOT/'infra/Caddyfile.production',args.output/'Caddyfile')
    (args.output/'csp.caddy').write_text(generate(args.exports/'public',True));(args.output/'admin-csp.caddy').write_text(generate(args.exports/'admin'))
    print('Deployment files generated. Review the release inputs; no server has been changed.')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);commands=parser.add_subparsers(dest='command',required=True)
    p=commands.add_parser('keygen');p.add_argument('--key',type=Path,required=True);p.set_defaults(fn=keygen)
    p=commands.add_parser('release');p.add_argument('--evidence',type=Path,required=True);p.add_argument('--image',required=True);p.add_argument('--release-id',required=True);p.add_argument('--key',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.set_defaults(fn=release)
    p=commands.add_parser('render');p.add_argument('--config',type=Path,required=True);p.add_argument('--exports',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.set_defaults(fn=render)
    for command,function in [('deploy',deploy),('rollback',rollback)]:
        p=commands.add_parser(command);p.add_argument('--release-dir',type=Path,required=True);p.add_argument('--manifest',type=Path,required=True);p.add_argument('--trust-key',type=Path,default=Path('/etc/notitle/release-signing.pub'));p.add_argument('--caddy-image',required=True);p.set_defaults(fn=function)
    args=parser.parse_args()
    try:args.fn(args)
    except Exception:raise SystemExit('Operation stopped: inspect qualification, signatures, prerequisites and configuration. Admission must remain closed.')
