#!/usr/bin/env python3
"""Real local HTTP boundary checks after the foundation stack has started."""
import json
import urllib.error
import urllib.request


def check():
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    def get(port,path,status):
        try:response=opener.open('http://127.0.0.1:'+str(port)+path,timeout=3)
        except urllib.error.HTTPError as exc:response=exc
        with response:
            if response.status!=status:raise ValueError('Unexpected HTTP status')
            body=response.read(2*1024*1024+1)
            if len(body)>2*1024*1024:raise ValueError('Response limit')
            return body,response.headers
    body,headers=get(8080,'/',200)
    if b'Foundation &amp; feasibility' not in body and b'Foundation & feasibility' not in body:raise ValueError('Wrong public static export')
    if headers.get('X-Content-Type-Options')!='nosniff':raise ValueError('Missing public header')
    body,headers=get(8081,'/',200)
    if b'Staff access is closed' not in body or headers.get('X-Robots-Tag')!='noindex':raise ValueError('Wrong private static export')
    body,_=get(8080,'/health/ready',200)
    data=json.loads(body)['data']
    if data.get('mode')!='foundation' or data.get('admission') is not False:raise ValueError('Foundation admission boundary failed')
    for port,path,status in [(8080,'/internal/v1/health',404),(8081,'/internal/v1/health',401),(8080,'/api/v1/me',404),(8080,'/not-a-route',404),(8081,'/not-a-route',404)]:get(port,path,status)
    print('Foundation HTTP checks passed: separate exports, owner readiness, closed admission, private denial and true 404s.')


if __name__=='__main__':
    try:check()
    except Exception:raise SystemExit('Foundation HTTP qualification failed. Inspect the local owner, proxy, export hashes and route boundaries.')
