/** Dependency-free build guard; full legal evidence is validated by ops/policies.py. */
import {readFileSync,readdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const read=name=>JSON.parse(readFileSync(path.join(root,name),'utf8'));
function ordered(value){if(Array.isArray(value))return value.map(ordered);if(value&&typeof value==='object')return Object.fromEntries(Object.keys(value).sort().map(k=>[k,ordered(value[k])]));return value;}
const canonical=value=>JSON.stringify(ordered(value),null,2)+'\n';
const sha=value=>createHash('sha256').update(value).digest('hex');
class GuardError extends Error{}
function assert(value,message){if(!value)throw new GuardError(message);}
try{
  const publication=read('policies/publication.json'),source=read('policies/source.json'),rendered=read('web/public/app/policies/generated.json'),site=read('web/shared/site.json');
  assert(publication.schema===2&&['draft','reviewed'].includes(publication.state),'Unknown publication');
  assert(publication.source_sha256===sha(canonical(source)),'Policy source changed; compile or review a new version');
  const operator=publication.operator,expected=structuredClone(source.policies);
  for(const policy of Object.values(expected))policy.sections=policy.sections.map(([heading,body])=>[heading,body.replace(/\{\{operator\.([a-z_]+)\}\}/g,(_,key)=>operator?operator[key]:'Not supplied — publication blocked')]);
  assert(canonical(expected)===canonical(publication.policies),'Policy rendering differs from source');
  const {review,...publicFields}=publication;
  assert(canonical(rendered)===canonical({...publicFields,publication_sha256:sha(readFileSync(path.join(root,'policies/publication.json')))}),'Frontend/publication drift');
  const content=Object.fromEntries(['version','state','effective_at','operator','processors','policies'].map(k=>[k,publication[k]]));
  assert(publication.content_sha256===sha(canonical(content)),'Content digest differs');
  const text=JSON.stringify(publication.policies)+' '+JSON.stringify(operator)+' '+JSON.stringify(publication.processors);
  assert(!/[\w.+-]+\s*@\s*[\w.-]+|mailto:|\[at\]|\(at\)/i.test(text),'Email exposure');
  assert(!/\bcompliant\b|100%\s+(?:secure|anonymous)|complies with (?:all|every) (?:laws?|regulations?)|guaranteed\s+(?:anonymity|security|erasure)|no refunds under any circumstances|refunds?\s+(?:for|on)\s+unused\s+(?:passes|subscriptions|purchases)/i.test(text),'Unsupported claim or refund exception');
  for(const id of ['terms','billing'])for(const phrase of ['no voluntary refunds','non-waivable','payment-error','binding','no automatic renewal'])assert(JSON.stringify(publication.policies[id]).toLowerCase().includes(phrase),'Missing refund/remedy disclosure');
  if(publication.state==='reviewed'){
    assert(operator&&publication.processors.length&&publication.publication_blockers.length===0,'Missing actual publication facts');
    assert(!/\{\{|\bTODO\b|\bTBD\b|publication blocked/i.test(text),'Unresolved reviewed copy');
    assert(review&&Date.parse(review.reviewed_at)<=Date.now()&&Date.now()<Date.parse(review.expires_at),'Policy review not current');
    assert(review.source_sha256===publication.source_sha256&&review.operator_sha256===sha(canonical({...operator,processors:publication.processors}))&&review.policy_version===publication.version&&review.effective_at===publication.effective_at,'Review is not bound to this copy');
  }
  assert(['interface','identity','realtime','candidate'].includes(site.mode),'Unknown interface mode');
  assert(!site.indexable||(site.mode==='candidate'&&publication.state==='reviewed'),'Draft/fixture build cannot be indexed');
  const routes=read('contracts/interface-routes.json');
  for(const app of ['public','admin'])assert(canonical(read(`web/${app}/route-data.json`))===canonical(routes[app]),'Route inventory drift');
  function scan(base){for(const entry of readdirSync(base,{withFileTypes:true})){if(['node_modules','.next','out'].includes(entry.name))continue;const name=path.join(base,entry.name);if(entry.isDirectory())scan(name);else if(/\.(tsx?|json|css)$/.test(name)){const content=readFileSync(name,'utf8');assert(!/(?:\.\.\/|@notitle\/)admin|web\/admin|NT_PRIVATE_BUNDLE|\/internal\/v1/.test(content),'Private import in public graph');}}}
  scan(path.join(root,'web/public'));scan(path.join(root,'web/shared'));
  console.log(`Interface build guard passed: ${site.mode}; policy ${publication.version} (${publication.state}). Full legal, artifact and browser gates remain separate.`);
}catch(error){console.error(`Interface build refused: ${error instanceof GuardError?error.message:'Invalid or missing build input; inspect the configured source files.'}`);process.exitCode=1;}
