"""Synthetic actor-only scan timing. Not PostgreSQL, sockets or capacity acceptance."""
import json,random,statistics,sys,time
from pathlib import Path
sys.path[:0]=[str(Path(__file__).resolve().parents[1]/'api')]
from app.coordinator.core import Coordinator
from app.domain.conversation import ConversationActor
from app.domain.metrics import Metrics

def measure():
    actor=ConversationActor(Coordinator(1,lambda:0),Metrics(),lambda:0,lambda:1800000000.,rng=random.Random(4))
    for index in range(100):
        ref=f'{index:032x}';actor.enter(ref,{'display_name':'Synthetic peer','gender':'male','topic_id':'general','bio':''},True,1800000100.)
        actor.connect(ref);actor.join(ref,'female');actor.drain(ref)
    times=[];checks=[]
    for _ in range(30):
        start=time.perf_counter();reservation=actor.reserve_match();times.append((time.perf_counter()-start)*1000);checks.append(actor.scan_checks)
        if reservation or actor.scan_checks>10000:raise RuntimeError('Bounded incompatible scan failed')
    return {'status':'passed','scenario':'100 incompatible waiters, 30 scans','checks_max':max(checks),
        'milliseconds':{'median':round(statistics.median(times),3),'maximum':round(max(times),3)},
        'limits':'Only synchronous actor timing in this environment; no DB, authorization, network, soak, RSS or production acceptance.'}
if __name__=='__main__':print(json.dumps(measure(),indent=2))
