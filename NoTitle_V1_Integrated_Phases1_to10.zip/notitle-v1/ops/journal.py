#!/usr/bin/env python3
"""Initialize an EMPTY independent journal prefix. Never overwrite a checkpoint."""
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'api'))
from app.domain.journal import Journal,canonical
from app.runtime import read_secret

def initialize(args):
    import boto3
    config=json.loads(read_secret(args.secrets/'journal_config'))
    client=boto3.client('s3',region_name=config['region'])
    bucket,prefix=config['bucket'],config['prefix'].rstrip('/')+'/'
    if client.list_objects_v2(Bucket=bucket,Prefix=prefix,MaxKeys=1).get('KeyCount',0):raise ValueError('Journal prefix is not empty')
    journal=Journal(args.work/'local',args.work/'stage',bytes.fromhex(read_secret(args.secrets/'journal_encryption')),bytes.fromhex(read_secret(args.secrets/'journal_signing')))
    anchor=journal.read(journal.local)[1]
    if anchor['seq']!=0:raise ValueError('Initial journal is not empty')
    client.put_object(Bucket=bucket,Key=prefix+'latest.json',Body=canonical(anchor),ContentType='application/json',IfNoneMatch='*')
    print('Empty independent journal initialized. Verify version retention, access isolation and recovery custody separately.')
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--secrets',type=Path,required=True);parser.add_argument('--work',type=Path,required=True);args=parser.parse_args()
    try:initialize(args)
    except Exception:raise SystemExit('Journal initialization refused or failed. Existing journal evidence was not overwritten.')
