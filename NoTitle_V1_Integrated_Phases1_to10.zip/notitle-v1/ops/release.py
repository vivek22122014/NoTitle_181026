"""One-command local full-V1 setup and source-bound release qualification.
No remote deployments, credentials, paid provider events or acceptance are fabricated.
"""
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PHASES={1:'foundation and feasibility',2:'interface and policy publication',3:'identity consent and privacy',4:'matching realtime and temporary text',5:'safety support and private operations',6:'friends invitations and profile completion',7:'audio and media teardown',8:'payment ledger and required remedies',9:'analytics and operational automation',10:'qualification launch and handoff'}
PHASE_SOURCES={1:('api/app/repositories/ownership.py','ops/foundation.py'),2:('web/public/components/Surface.tsx','ops/policies.py'),3:('api/app/services/identity.py','api/app/services/account_controls.py'),4:('api/app/services/conversation.py','web/shared/conversation.ts'),5:('api/app/services/support.py','api/app/services/moderation.py'),6:('api/app/services/social.py',),7:('api/app/services/media.py','relay/controller.py'),8:('api/app/services/billing.py','api/app/integrations/cashfree.py'),9:('api/app/services/analytics.py','ops/backup.py','ops/monitor.py'),10:('ops/release.py','ops/production.py')}
EXTERNAL_GATES=('privacy','legal','restore','security','load','relay','merchant','payment_exceptions','accessibility','solo_rehearsal','sbom')

def configure(args):
    from ops.identity import configure as identity_configure
    args.profile='candidate'
    identity_configure(args)
    print('Full local candidate configured; admission is local, audio/payments remain closed until separately qualified.')

def setup(args):
    from ops.nt import run
    configure(args)
    run([sys.executable,'ops/nt.py','lock',*(['--check'] if args.locked else [])])
    run([sys.executable,'ops/nt.py','install'])
    python=ROOT/'.venv/bin/python'
    run([python,'ops/nt.py','release','verify','--level','core'])
    if not args.no_start:run([python,'ops/nt.py','dev','up','--mode','product'])
    print('Candidate local stack ready. Audio requires the real relay; payments require a reviewed merchant sandbox configuration. No production gate was opened.')

def run_check(name,argv,directory,env,timeout=900):
    started=time.monotonic()
    try:
        result=subprocess.run([str(item) for item in argv],cwd=ROOT,env=env,capture_output=True,text=True,timeout=timeout)
        output=result.stdout+result.stderr;code=result.returncode;status='passed' if code==0 else 'failed'
    except (OSError,subprocess.TimeoutExpired):
        output='Unavailable command or timeout. No pass recorded.\n';code=None;status='blocked'
    path=directory/(name+'.log');path.write_text(output)
    print(name+': '+status,flush=True)
    return {'status':status,'returncode':code,'duration_seconds':round(time.monotonic()-started,3),
            'artifact':str(path.relative_to(directory.parent)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

def verify(args):
    from ops.foundation import source_digest,environment
    from ops.nt import GateError
    if os.environ.get('APP_ENV','local')!='local':raise GateError('Release qualification runs against a local disposable environment only')
    directory=ROOT/'evidence/release';directory.mkdir(parents=True,exist_ok=True)
    logs=directory/('run-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+os.urandom(3).hex());logs.mkdir()
    env=dict(os.environ,PYTHONPATH=str(ROOT/'api')+os.pathsep+str(ROOT));checks={}
    # Profile selection changes hashed generated source. Complete it before
    # binding the qualification run, so a clean full-stack run can be stable.
    if args.level in {'integration','stack'}:
        checks['configuration']=run_check('configuration',[sys.executable,'ops/nt.py','release','configure'],logs,env)
    before=source_digest()
    commands=[('core_prerequisites',[sys.executable,'ops/nt.py','doctor','--core']),
      ('contracts',[sys.executable,'ops/nt.py','contracts','--check']),
      ('unit',[sys.executable,'-m','unittest','discover','-s','tests/unit','-v']),
      ('client',['node','--test',*map(str,sorted((ROOT/'tests/qualification').glob('*client.test.mjs'))),'tests/qualification/audio-lifecycle.test.mjs']),
      ('interface',[sys.executable,'ops/nt.py','interface','check']),
      ('policies',[sys.executable,'ops/nt.py','policies','check']),
      ('source',[sys.executable,'ops/qualify.py','source']),
      ('matching_benchmark',[sys.executable,'ops/conversation_benchmark.py'])]
    for name,command in commands:checks[name]=run_check(name,command,logs,env)
    wanted=list(checks)
    for name in ('dependencies','integration','build','typecheck','browser'):
        checks[name]={'status':'not_run','reason':'Core-only verification does not qualify the running stack.'}
    if args.level in {'integration','stack'}:
        checks['dependencies']=run_check('dependencies',[sys.executable,'ops/nt.py','doctor','--locked'],logs,env);wanted.append('dependencies')
        healthy=checks['dependencies']['status']=='passed' and all(checks[name]['status']=='passed' for name in wanted)
        if (ROOT/'.local/runner.pid').exists():
            checks['owner_stopped']={'status':'blocked','reason':'Stop the local owner before migrations and failure injection.'};wanted.append('owner_stopped');healthy=False
        env['NOTITLE_INTEGRATION']='local-disposable'
        sequence=[('database',['docker','compose','--env-file','infra/images.env','-f','infra/compose.dev.yml','up','-d','--wait','db']),
          ('roles',[sys.executable,'ops/nt.py','db','bootstrap']),
          ('migration',[sys.executable,'ops/nt.py','db','migrate']),
          ('integration',[sys.executable,'ops/nt.py','test','--suite','integration'])]
        if args.level=='stack':sequence += [('build',[sys.executable,'ops/nt.py','build']),('browser_dependencies',['npm','ci','--ignore-scripts']),('typecheck',['npm','run','typecheck'])]
        for name,command in sequence:
            checks[name]=run_check(name,command,logs,env) if healthy else {'status':'blocked','reason':'An earlier real-stack prerequisite failed.'}
            wanted.append(name);healthy=healthy and checks[name]['status']=='passed'
        if args.level=='stack':
            pid=None
            try:
                if healthy:
                    checks['start']=run_check('start',[sys.executable,'ops/nt.py','dev','up','--mode','product','--skip-build'],logs,env);wanted.append('start');healthy=checks['start']['status']=='passed'
                    if healthy:pid=int((ROOT/'.local/runner.pid').read_text())
                for name,command in [('browser_runtime',['npx','playwright','install','chromium']),('browser',['npm','run','test:e2e'])]:
                    checks[name]=run_check(name,command,logs,env) if healthy else {'status':'blocked','reason':'The real candidate stack is unavailable.'};wanted.append(name);healthy=healthy and checks[name]['status']=='passed'
            finally:
                if pid is not None:checks['stop']=run_check('stop',[sys.executable,'ops/nt.py','dev','down','--expected-pid',str(pid)],logs,env);wanted.append('stop')
    after=source_digest()
    if before!=after:
        checks['source_stability']={'status':'failed','reason':'Source changed during qualification; rerun against final source.'};wanted.append('source_stability')
    for key in EXTERNAL_GATES:checks[key]={'status':'not_run','reason':'Requires separately reviewed real operational evidence; a unit or source check is insufficient.'}
    ready=all(checks[name]['status']=='passed' for name in wanted)
    report={'recorded_at':datetime.now(timezone.utc).isoformat(),'source_sha256':after,'source_unchanged':before==after,
      'level':args.level,'environment':environment(),'checks':checks,'requested_checks_passed':ready,
      'phases':{str(number):{'name':title,'implementation':'source_present' if all((ROOT/path).is_file() for path in PHASE_SOURCES[number]) else 'source_missing','source_files':list(PHASE_SOURCES[number]),'accepted':False,'reason':'File presence is not functional qualification. Full-stack and phase-specific external acceptance remain explicit gates.'} for number,title in PHASES.items()},
      'production_ready':False,'public_admission_authorized':False,
      'limits':'This report certifies only listed executed checks against this source digest. It never infers legal, paid merchant, relay, recovery, security or load approval.'}
    (directory/'latest.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'requested_checks_passed':ready,'production_ready':False,'report':'evidence/release/latest.json'},indent=2))
    return 0 if ready else 3

def add_commands(commands):
    parser=commands.add_parser('release',help='Full V1 local setup and honest qualification')
    actions=parser.add_subparsers(dest='release_action',required=True)
    actions.add_parser('configure').set_defaults(fn=configure)
    action=actions.add_parser('setup');action.add_argument('--locked',action='store_true');action.add_argument('--no-start',action='store_true');action.set_defaults(fn=setup)
    action=actions.add_parser('verify');action.add_argument('--level',choices=['core','integration','stack'],default='core');action.set_defaults(fn=verify)
