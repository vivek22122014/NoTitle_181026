#!/usr/bin/env python3
"""Validate and copy an externally reviewed rule pack into the private vault."""
import argparse,json,os,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'api'))
from app.domain.legal import LegalRules

def main(args):
    body=args.reviewed_pack.read_bytes();LegalRules(json.loads(body))
    if len(body)>65536:raise ValueError('Rule pack too large')
    fd=os.open(args.destination,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as file:file.write(body);file.flush();os.fsync(file.fileno())
    print('Reviewed rule pack validated and copied. Bind its review evidence to the release; this command is not legal approval.')
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--reviewed-pack',type=Path,required=True);parser.add_argument('--destination',type=Path,required=True);args=parser.parse_args()
    try:main(args)
    except Exception:raise SystemExit('Legal rule installation refused: validate review, coverage, dates, integer deadlines and a new private destination.')
