"""Bind dependency artifacts to their actual input files and selected image tags."""
import hashlib
import json
import re
from pathlib import Path


class LockError(ValueError):
    pass


ARTIFACTS = {
    "python": "api/requirements.lock",
    "web": "package-lock.json",
    "images": "infra/images.env",
}


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inputs(root, scope):
    root = Path(root)
    if scope == "python":
        paths = [root / "api/requirements.in"]
    elif scope == "web":
        paths = [root / "package.json", *sorted((root / "web").glob("*/package.json"))]
    else:
        return {}
    return {str(path.relative_to(root)): sha256(path) for path in paths}


def verify(root):
    root = Path(root)
    config = json.loads((root / "versions.lock").read_text())
    for name in ARTIFACTS.values():
        path = root / name
        if not path.is_file() or config.get("lock_hashes", {}).get(name) != sha256(path):
            raise LockError("Missing or changed dependency artifact: " + name)
    expected = {**inputs(root, "python"), **inputs(root, "web")}
    if config.get("lock_inputs") != expected:
        raise LockError("Dependency inputs changed; resolve the affected locks")
    selected = config.get("image_candidates", {})
    resolved = config.get("image_digests", {})
    if not selected or config.get("resolved_candidates") != selected or set(resolved) != set(selected):
        raise LockError("Image candidates have not been resolved")
    if any(not re.fullmatch(r"[a-zA-Z0-9./:_-]+@sha256:[a-f0-9]{64}", value) for value in resolved.values()):
        raise LockError("Immutable image digest required")
    actual = {}
    for line in (root / ARTIFACTS["images"]).read_text().splitlines():
        if line.strip():
            key, value = line.split("=", 1)
            if key in actual:
                raise LockError("Duplicate image key")
            actual[key] = value
    if actual != resolved:
        raise LockError("Image environment differs from reviewed digests")
    return config
