#!/usr/bin/env python3
"""Boot-only gate: never resurrect an interrupted or failed deployment.
This is not an API crash supervisor. The signed deploy/rollback CLI remains the
only writer of a healthy release operation record.
"""
import argparse,fcntl,json,subprocess
from pathlib import Path


def check(current=Path('/opt/notitle/current'),record=Path('/var/lib/notitle/deployment.json')):
    current=Path(current);record=Path(record)
    if not current.is_dir() or not (current/'infra/compose.production.yml').is_file():
        raise ValueError('Committed release unavailable')
    operation=json.loads(record.read_text())
    if operation.get('status')!='healthy' or operation.get('stage')!='healthy':
        raise ValueError('Deployment requires explicit operator repair')
    directory=operation.get('release_directory')
    if not isinstance(directory,str) or not Path(directory).is_absolute() or Path(directory).resolve()!=current.resolve():
        raise ValueError('Operation does not cover current release')
    return True


def start(current=Path('/opt/notitle/current'),record=Path('/var/lib/notitle/deployment.json'),lock=Path('/var/lib/notitle/deployment.lock')):
    # Hold the same lock as deployment across the final check and Compose call.
    # ExecCondition alone would have a check/start race with a signed migration.
    with Path(lock).open('a') as stream:
        try:fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise ValueError('Deployment is in progress')
        try:
            check(current,record)
            subprocess.run(['/usr/bin/docker','compose','--env-file','/etc/notitle/images.env','-f',str(Path(current)/'infra/compose.production.yml'),'up','-d','--wait'],check=True)
        finally:fcntl.flock(stream,fcntl.LOCK_UN)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',nargs='?',choices=['check','start'],default='check');args=parser.parse_args()
    try:start() if args.action=='start' else check()
    except Exception:raise SystemExit('Boot startup refused: no healthy committed release or deployment in progress. Inspect state and use the signed operator workflow.')
