#!/usr/bin/env python3
"""Create the initial owner using the migrator/operator CLI, never a public endpoint."""
import argparse,asyncio,base64,getpass,os,secrets,sys
from pathlib import Path
from uuid import uuid4
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'api'))
from app.runtime import ProductSettings,read_secret
from app.domain.security import Security,normalize_username
from app.services.primitives import Passwords

GRANTS={'cases.queue','cases.read','cases.triage','cases.claim','cases.assign','cases.reply','cases.manage','cases.notes','cases.legal',
        'reports.read','safety.decide','billing.remedies','privacy.read','privacy.holds','analytics.read','operations.read','audit.read','staff.manage'}

async def create(args):
    import psycopg
    username=normalize_username(args.username)
    password=getpass.getpass('New staff password (12+ characters): ')
    if password!=getpass.getpass('Repeat password: '):raise ValueError('Passwords differ')
    security=Security(bytes.fromhex(read_secret(args.secrets/'hmac_key')),bytes.fromhex(read_secret(args.secrets/'wrapping_key')))
    encoded=await Passwords().hash(password);staff_id=uuid4();totp=base64.b32encode(os.urandom(20)).decode()
    codes=[secrets.token_urlsafe(24) for _ in range(10)]
    async with await psycopg.AsyncConnection.connect(read_secret(args.secrets/'private_dsn')) as connection:
        await connection.execute('INSERT INTO nt.staff_accounts(id,username,password_hash,totp_ciphertext) VALUES(%s,%s,%s,%s)',(staff_id,username,encoded,security.encrypt('staff:'+str(staff_id),totp)))
        selected=GRANTS if args.role=='owner' else {'analytics.read'} if args.role=='analyst' else {'cases.queue','cases.read','cases.triage','cases.claim','cases.reply','cases.manage','cases.notes','reports.read','safety.decide'}
        for grant in sorted(selected):await connection.execute('INSERT INTO nt.staff_roles(staff_id,permission) VALUES(%s,%s)',(staff_id,grant))
        for code in codes:await connection.execute('INSERT INTO nt.staff_recovery_codes(staff_id,verifier) VALUES(%s,%s)',(staff_id,security.digest('staff_recovery',code)))
    fd=os.open(args.enrollment,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as stream:
        stream.write(f'NoTitle staff: {username}\nAuthenticator secret: {totp}\notpauth://totp/NoTitle:{username}?secret={totp}&issuer=NoTitle&algorithm=SHA1&digits=6&period=30\n\nOne-time recovery codes:\n'+'\n'.join(codes)+'\n')
        stream.flush();os.fsync(stream.fileno())
    print('Staff created. Import the private enrollment file into your authenticator and password manager; then remove the file securely.')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('username');parser.add_argument('--role',choices=['owner','moderator','analyst'],default='owner');parser.add_argument('--secrets',type=Path,default=ROOT/'.local/secrets');parser.add_argument('--enrollment',type=Path,default=ROOT/'.local/staff-enrollment.txt')
    args=parser.parse_args()
    try:asyncio.run(create(args))
    except Exception:raise SystemExit('Staff creation failed; inspect configuration and username without logging secrets.')
