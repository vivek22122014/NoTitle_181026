"""Executed Phase 2 evidence, with unrun qualification kept explicit."""
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]

def verify(args):
    evidence=ROOT/'evidence/phase2';evidence.mkdir(parents=True,exist_ok=True)
    checks={};environment=dict(os.environ,PYTHONPATH=str(ROOT/'api')+os.pathsep+str(ROOT))
    def run(name,argv):
        try:
            result=subprocess.run(argv,cwd=ROOT,env=environment,capture_output=True,text=True,timeout=900)
            output=result.stdout+result.stderr;status='passed' if result.returncode==0 else 'failed';code=result.returncode
        except (OSError,subprocess.TimeoutExpired):output='Command unavailable or exceeded its deadline. No pass recorded.\n';status='blocked';code=None
        log=evidence/(name+'.log');log.write_text(output)
        checks[name]={'status':status,'returncode':code,'artifact':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
        print(name+': '+status,flush=True);return status=='passed'
    python=sys.executable
    for name,argv in [('interfaces',[python,'ops/nt.py','interface','check']),
                      ('policies',[python,'ops/nt.py','policies','check']),
                      ('contracts',[python,'ops/nt.py','contracts','--check']),
                      ('unit',[python,'ops/nt.py','test','--suite','unit']),
                      ('build-guard',['node','ops/check-web.mjs']),
                      ('source',[python,'ops/qualify.py','source'])]:run(name,argv)
    core_passed=all(value['status']=='passed' for value in checks.values())
    for name in ('build','browser'):
        checks[name]={'status':'not_run','reason':'Requested level does not execute this check.'}
    if args.level in ('build','browser'):
        if core_passed and run('prerequisites',[python,'ops/nt.py','doctor','--locked']):
            run('build',[python,'ops/nt.py','build','--target','web'])
        else:checks['build']={'status':'blocked','reason':'Core or immutable-build prerequisites failed.'}
    if args.level=='browser':
        if checks['build']['status']=='passed':run('browser',['npm','run','test:interface'])
        else:checks['browser']={'status':'blocked','reason':'Actual typechecked Next exports are required first.'}
    report={'recorded_at':datetime.now(timezone.utc).isoformat(),'requested_level':args.level,'checks':checks,
            'core_passed':core_passed,'phase2_accepted':False,'production_ready':False,
            'manual_acceptance':{key:'not_run' for key in ('native_200_percent_zoom','software_keyboard','screen_reader','operator_legal_review','rendered_reviewed_copy')},
            'limits':'Unit artifact tests use synthetic HTML. Syntax parsing is not Next or TypeScript compilation. Browser success does not certify legal applicability.'}
    (evidence/'latest.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'core_passed':core_passed,'phase2_accepted':False,'production_ready':False},indent=2))
    wanted=['interfaces','policies','contracts','unit','build-guard','source']+([] if args.level=='core' else ['build'])+(['browser'] if args.level=='browser' else [])
    return 0 if all(checks[k]['status']=='passed' for k in wanted) else 1
