#!/usr/bin/env python3
"""Interactive managed PostgreSQL role setup. Credentials never enter argv/log output."""
import argparse,asyncio,getpass,os,secrets,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'api'))
ROLES={'runtime':'nt_runtime','migrator':'nt_migrator','support':'nt_support','private':'nt_private','jobs':'nt_jobs','analytics':'nt_analytics','backup':'nt_backup'}

def write_private(path,value):
    fd=os.open(path,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    with os.fdopen(fd,'w') as file:file.write(value);file.flush();os.fsync(file.fileno())

async def setup(args):
    import psycopg
    from psycopg import sql
    from psycopg.conninfo import make_conninfo
    from app.repositories.migrations import migrate
    args.secrets.mkdir(parents=True,exist_ok=True,mode=0o700)
    if args.migrate_only:
        await migrate((args.secrets/'migrator_dsn').read_text().strip(),ROOT/'db/migrations');return
    host=input('Managed PostgreSQL hostname from Connection Details: ').strip()
    port=int(input('PostgreSQL port: ').strip())
    database=input('Database name: ').strip();admin=input('Administrative user: ').strip()
    password=getpass.getpass('Administrative password: ')
    ca=Path(input('Absolute downloaded CA certificate path: ').strip()).resolve(strict=True)
    if not host or not database or not 1<=port<=65535:raise ValueError('Invalid connection details')
    common={'host':host,'port':port,'dbname':database,'sslmode':'verify-full','sslrootcert':str(ca)}
    async with await psycopg.AsyncConnection.connect(make_conninfo(**common,user=admin,password=password),autocommit=True) as connection:
        for name,role in ROLES.items():
            key=args.secrets/('pg_'+name)
            if not key.exists():write_private(key,secrets.token_hex(32))
            role_password=key.read_text().strip()
            found=await (await connection.execute('SELECT 1 FROM pg_roles WHERE rolname=%s',(role,))).fetchone()
            if not found:await connection.execute(sql.SQL('CREATE ROLE {} LOGIN').format(sql.Identifier(role)))
            await connection.execute(sql.SQL('ALTER ROLE {} WITH LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOINHERIT PASSWORD {}').format(sql.Identifier(role),sql.Literal(role_password)))
            await connection.execute(sql.SQL('GRANT CONNECT ON DATABASE {} TO {}').format(sql.Identifier(database),sql.Identifier(role)))
            await connection.execute(sql.SQL("ALTER ROLE {} SET statement_timeout='2s'").format(sql.Identifier(role)))
            await connection.execute(sql.SQL("ALTER ROLE {} SET lock_timeout='500ms'").format(sql.Identifier(role)))
            path=args.secrets/(name+'_dsn')
            if not path.exists():write_private(path,make_conninfo(**common,user=role,password=role_password))
        await connection.execute(sql.SQL('GRANT CREATE ON DATABASE {} TO nt_migrator').format(sql.Identifier(database)))
        await connection.execute('REVOKE CREATE ON SCHEMA public FROM PUBLIC')
    for key in ('hmac_key','wrapping_key','journal_encryption','journal_signing'):
        path=args.secrets/key
        if not path.exists():write_private(path,secrets.token_hex(32))
    print('Restricted role DSNs and application keys are ready. Run migrate-only with the owner stopped; install only the runtime subset.')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--secrets',type=Path,required=True);parser.add_argument('--migrate-only',action='store_true');args=parser.parse_args()
    try:asyncio.run(setup(args))
    except Exception:raise SystemExit('Managed database setup failed. Verify provider role authority, CA/hostname and credentials; no connection secrets were printed.')
