#!/usr/bin/env python3
"""Archive minimal access audit into independently retained encrypted objects."""
import argparse,asyncio,hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'api'))
from app.domain.security import Security
from app.runtime import read_secret

async def archive(args):
    import boto3,psycopg
    from psycopg.rows import dict_row
    config=json.loads(read_secret(args.secrets/'audit_archive_config'))
    if config.get('reviewed_retention_days')!=180:raise ValueError('Reviewed archive schedule required')
    client=boto3.client('s3',region_name=config['region'])
    security=Security(bytes.fromhex(read_secret(args.secrets/'hmac_key')),bytes.fromhex(read_secret(args.secrets/'wrapping_key')))
    async with await psycopg.AsyncConnection.connect(read_secret(args.secrets/'jobs_dsn'),row_factory=dict_row,autocommit=True) as connection:
        cursor=await connection.execute("SELECT id,actor_ref,purpose_code,object_type,object_ref,action,request_id,created_at FROM nt.access_audit WHERE archive_batch IS NULL AND created_at<now()-interval '1 day' ORDER BY created_at,id LIMIT 1000")
        rows=await cursor.fetchall()
        if not rows:return
        body=json.dumps(rows,sort_keys=True,separators=(',',':'),default=str)
        reference=security.digest('audit_batch',body);key=config['prefix'].rstrip('/')+'/'+reference+'.enc'
        encrypted=security.encrypt('audit_archive:'+reference,body)
        try:await asyncio.to_thread(client.put_object,Bucket=config['bucket'],Key=key,Body=encrypted,IfNoneMatch='*')
        except Exception:
            # Identical prior batch may have uploaded before a lost acknowledgment.
            pass
        response=await asyncio.to_thread(client.get_object,Bucket=config['bucket'],Key=key)
        remote=response['Body'].read(4*1024*1024+1)
        if len(remote)>4*1024*1024 or security.decrypt('audit_archive:'+reference,remote)!=body:raise ValueError('Archive verification failed')
        async with connection.transaction():
            await connection.execute('UPDATE nt.access_audit SET archive_batch=%s WHERE id=ANY(%s) AND archive_batch IS NULL',(reference,[r['id'] for r in rows]))
            # Only archived records expire here; object lifecycle/holds are separately reviewed.
            await connection.execute("DELETE FROM nt.access_audit WHERE created_at<now()-interval '180 days' AND archive_batch IS NOT NULL")
    print('Bounded audit batch archived and verified; no plaintext audit was printed.')
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--secrets',type=Path,required=True);args=parser.parse_args()
    try:asyncio.run(archive(args))
    except Exception:raise SystemExit('Audit archival failed; source audit records were retained.')
