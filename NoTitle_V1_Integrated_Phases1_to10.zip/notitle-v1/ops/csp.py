"""Hash exported Next inline scripts; never allow unsafe-eval or arbitrary scripts."""
import argparse,base64,hashlib
from html.parser import HTMLParser
from pathlib import Path
class Scripts(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=False);self.active=False;self.values=[];self.current=[]
    def handle_starttag(self,tag,attrs):
        if tag=='script':self.active='src' not in dict(attrs);self.current=[]
    def handle_data(self,data):
        if self.active:self.current.append(data)
    def handle_endtag(self,tag):
        if tag=='script' and self.active:self.values.append(''.join(self.current));self.active=False

def generate(directory,checkout=False):
    directory=Path(directory)
    if any(path.is_symlink() for path in directory.rglob('*')):raise ValueError('Symlink in export')
    hashes=set()
    for path in directory.rglob('*.html'):
        parser=Scripts();parser.feed(path.read_text())
        hashes.update("'sha256-"+base64.b64encode(hashlib.sha256(value.encode()).digest()).decode()+"'" for value in parser.values)
    if not hashes:raise ValueError('Build exports before generating CSP')
    base="default-src 'self'; script-src 'self' "+' '.join(sorted(hashes))+"; script-src-attr 'none'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; media-src 'self' blob:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'; frame-src 'none'; worker-src 'none'"
    if len(base)>16*1024:raise ValueError('CSP exceeds the reviewed header budget; use per-route hashes')
    out='header Content-Security-Policy "'+base+'"\n'
    if checkout:
        # Mutually exclusive matchers avoid depending on Caddy header ordering.
        out='@standard not path /checkout /checkout/*\nheader @standard Content-Security-Policy "'+base+'"\n'
        policy=base.replace("script-src 'self'", "script-src 'self' https://sdk.cashfree.com").replace("connect-src 'self'", "connect-src 'self' https://api.cashfree.com https://sandbox.cashfree.com").replace("frame-src 'none'","frame-src https://sdk.cashfree.com https://api.cashfree.com https://sandbox.cashfree.com https://payments.cashfree.com https://payments-test.cashfree.com")
        out+='@checkout path /checkout /checkout/*\nheader @checkout Content-Security-Policy "'+policy+'"\n'
    return out
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('directory',type=Path);parser.add_argument('output',type=Path);parser.add_argument('--checkout',action='store_true');args=parser.parse_args()
    args.output.write_text(generate(args.directory,args.checkout))
