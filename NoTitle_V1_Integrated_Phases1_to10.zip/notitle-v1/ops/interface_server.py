"""Loopback-only, read-only exported UI preview. Never an API or production server."""
from functools import partial
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import threading
from urllib.parse import unquote,urlsplit
from ops.csp import generate

MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8',
      '.css':'text/css; charset=utf-8','.txt':'text/plain; charset=utf-8',
      '.json':'application/json; charset=utf-8','.xml':'application/xml; charset=utf-8',
      '.svg':'image/svg+xml','.png':'image/png','.ico':'image/x-icon','.woff2':'font/woff2'}

def resolve_asset(root,path,private=False):
    parsed=urlsplit(path)
    if parsed.query or parsed.fragment or parsed.netloc or parsed.scheme:return None
    clean=unquote(parsed.path)
    if (not clean.startswith('/') or '\\' in clean or '\x00' in clean or
            any(part in ('.','..') or part.startswith('.') for part in clean.split('/'))):return None
    if clean=='/api' or clean.startswith('/api/') or clean=='/ws' or clean=='/internal' or clean.startswith('/internal/'):
        return None
    if not private and (clean=='/admin' or clean.startswith('/admin/')):return None
    root=Path(root).resolve();target=root/clean.lstrip('/')
    # Never follow a symlink, even if its final destination is inside the export.
    if any(p.is_symlink() for p in [target,*target.parents] if p.is_relative_to(root)):return None
    target=target.resolve()
    if not target.is_relative_to(root):return None
    if target.is_dir():target=target/'index.html'
    return target if target.is_file() and target.suffix in MIME else None

def security_headers(csp,private=False):
    return {'Content-Security-Policy':csp,'Cache-Control':'no-store',
            'Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY',
            'Permissions-Policy':'camera=(), microphone=(), geolocation=()',
            'X-Robots-Tag':'noindex, nofollow, noarchive'}

class Handler(BaseHTTPRequestHandler):
    server_version='NoTitlePreview';sys_version=''
    def __init__(self,*args,root,private,csp,**kwargs):
        self.root=Path(root);self.private=private;self.csp=csp;super().__init__(*args,**kwargs)
    def log_message(self,*args):pass # No request URLs, queries or credentials in preview logs.
    def do_HEAD(self):self.respond(head=True)
    def do_GET(self):self.respond()
    def do_POST(self):self.respond(unsupported=True)
    do_PUT=do_POST
    do_PATCH=do_POST
    do_DELETE=do_POST
    do_OPTIONS=do_POST
    def respond(self,head=False,unsupported=False):
        path=None if unsupported else resolve_asset(self.root,self.path,self.private)
        status=405 if unsupported else 200 if path else 404
        data=path.read_bytes() if path else (self.root/'404.html').read_bytes()
        self.send_response(status)
        for key,value in security_headers(self.csp,self.private).items():self.send_header(key,value)
        self.send_header('Content-Type',MIME.get(path.suffix,'text/html; charset=utf-8') if path else 'text/html; charset=utf-8')
        self.send_header('Content-Length',str(len(data)));self.end_headers()
        if not head:self.wfile.write(data)

def server(root,port,private=False):
    csp=generate(Path(root)).split('"',1)[1].rsplit('"',1)[0]
    return ThreadingHTTPServer(('127.0.0.1',port),partial(Handler,root=root,private=private,csp=csp))

def serve(root,exports,port=8080,private_port=8081):
    from ops.builds import verify
    from ops.export_audit import audit
    if not 1024<=port<=65535 or not 1024<=private_port<=65535 or port==private_port:raise ValueError('Use two distinct unprivileged ports')
    verify(root,exports);audit(root,exports)
    servers=[];threads=[]
    try:
        # Bind both before exposing either, as with the application runner.
        servers.append(server(Path(exports)/'public',port))
        servers.append(server(Path(exports)/'admin',private_port,True))
        for instance in servers:
            thread=threading.Thread(target=instance.serve_forever,daemon=True);thread.start();threads.append(thread)
        print(f'Read-only UI: http://127.0.0.1:{port} · private http://127.0.0.1:{private_port} · Ctrl+C to stop',flush=True)
        for thread in threads:thread.join()
    except KeyboardInterrupt:pass
    finally:
        for instance,thread in zip(servers,threads):instance.shutdown();thread.join(timeout=2)
        for instance in servers:instance.server_close()
