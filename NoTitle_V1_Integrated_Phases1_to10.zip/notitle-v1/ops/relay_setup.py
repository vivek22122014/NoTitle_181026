#!/usr/bin/env python3
"""Render a dedicated relay host configuration from actual IP/domain/certificate inputs."""
import argparse,ipaddress,json,re
from pathlib import Path

def render(args):
    cfg=json.loads(args.config.read_text());ip=str(ipaddress.IPv4Address(cfg['relay_ip']))
    if not re.fullmatch(r'[a-z0-9.-]+',cfg['turn_domain']):raise ValueError('Invalid TURN domain')
    for field in ('tls_certificate','tls_key','control_certificate','control_key','control_ca'):
        if not cfg[field].startswith('/') or any(c in cfg[field] for c in '\n\r'):raise ValueError('Absolute certificate paths required')
    args.output.mkdir(parents=True,exist_ok=True,mode=0o700)
    base=f'''listening-port=3478
tls-listening-port=443
listening-ip={ip}
relay-ip={ip}
min-port=49152
max-port=50175
realm={cfg['turn_domain']}
fingerprint
use-auth-secret
no-tcp-relay
no-multicast-peers
no-stun
no-tlsv1
no-tlsv1_1
user-quota=4
total-quota=256
max-allocate-lifetime=600
cli-ip=127.0.0.1
cli-port=5766
cli-max-output-sessions=4
cert={cfg['tls_certificate']}
pkey={cfg['tls_key']}
no-stdout-log
log-file=/dev/null
denied-peer-ip=0.0.0.0-255.255.255.255
allowed-peer-ip={ip}
'''
    (args.output/'turnserver.base.conf').write_text(base)
    control={'relay_ip':ip,'turn_domain':cfg['turn_domain'],'control_bind':ip,'control_port':9443,'cli_port':5766,
             'cli_password_file':'/etc/notitle-relay/cli_password','turn_secret_file':'/etc/notitle-relay/turn_secret',
             'guard_socket':'/run/notitle-relay/guard.sock','history_file':'/var/lib/notitle-relay/history.json',
             'certificate':cfg['control_certificate'],'key':cfg['control_key'],'ca':cfg['control_ca']}
    (args.output/'controller.json').write_text(json.dumps(control,indent=2)+'\n');(args.output/'controller.json').chmod(0o600)
    units={
     'notitle-guard.service':f'''[Unit]
Description=NoTitle narrow relay kernel helper
[Service]
Type=simple
WorkingDirectory=/opt/notitle/current
ExecStart=/usr/bin/python3 -m relay.guard_socket --relay-ip {ip} --controller-uid 10002
CapabilityBoundingSet=CAP_NET_ADMIN CAP_CHOWN CAP_DAC_OVERRIDE
NoNewPrivileges=true
Restart=no
''',
     'notitle-coturn.service':'''[Unit]
Description=NoTitle guarded coturn
Requires=notitle-guard.service
After=notitle-guard.service
[Service]
Type=simple
User=notitle-relay
WorkingDirectory=/var/lib/notitle-relay
ExecStart=/usr/bin/turnserver -c /etc/notitle-relay/turnserver.conf
AmbientCapabilities=CAP_NET_BIND_SERVICE
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
NoNewPrivileges=true
Restart=no
''',
     'notitle-controller.service':'''[Unit]
Description=NoTitle mTLS relay controller
Requires=notitle-coturn.service notitle-guard.service
After=notitle-coturn.service notitle-guard.service
BindsTo=notitle-coturn.service notitle-guard.service
[Service]
Type=simple
User=notitle-relay
WorkingDirectory=/opt/notitle/current
ExecStart=/usr/bin/python3 -m relay.controller --config /etc/notitle-relay/controller.json
NoNewPrivileges=true
Restart=no
''',
     'notitle-relay.service':'''[Unit]
Description=NoTitle verified clean relay boot
After=network-online.target
[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/usr/bin/python3 /opt/notitle/current/ops/relay_boot.py
ExecStop=/usr/bin/systemctl stop notitle-controller notitle-coturn notitle-guard
[Install]
WantedBy=multi-user.target
'''}
    for name,body in units.items():(args.output/name).write_text(body)
    print('Relay configuration and units rendered. Install on the isolated host only after pinning the coturn build and verifying certificates/firewall/users.')
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--config',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args();render(args)
