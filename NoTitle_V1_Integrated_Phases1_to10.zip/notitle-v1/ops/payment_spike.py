"""Explicit sandbox probe. Credentials and phone are prompted privately, never persisted."""
import argparse,asyncio,getpass,json,os,secrets,sys
from pathlib import Path
from uuid import uuid4
from ops.nt import ROOT,LOCAL,save_private
from app.integrations.cashfree import CashfreeSandbox,verified_capture,reference,ProviderUnknown

async def probe(args):
    reference(args.order)
    directory=LOCAL/'cashfree';directory.mkdir(parents=True,exist_ok=True,mode=0o700)
    path=directory/(args.order+'.json')
    if args.action=='create' and not path.exists():
        save_private(path,json.dumps({'order_id':args.order,'paise':100,'nonce':str(uuid4()),
                                     'refund_id':'rf_'+secrets.token_hex(12),'refund_nonce':str(uuid4())}))
    if not path.exists():raise ValueError('Run create once to persist the intent before provider work')
    intent=json.loads(path.read_text())
    api=CashfreeSandbox(getpass.getpass('Sandbox client ID: '),getpass.getpass('Sandbox client secret: '))
    try:
        if args.action=='create':
            result=await api.create_order(args.order,intent['paise'],'test_'+args.order,
                                           getpass.getpass('Sandbox test phone (10 digits): '),intent['nonce'])
            # Checkout token stays private; a browser callback still cannot grant entitlement.
            save_private(directory/(args.order+'.checkout.json'),json.dumps(result))
            print('Sandbox order response saved privately. Complete payment in provider sandbox only.')
        elif args.action=='fetch':
            order=await api.fetch_order(args.order);payments=await api.fetch_payments(args.order)
            capture=verified_capture(order,payments,args.order,intent['paise'])
            print(json.dumps({'verified_capture':capture is not None,'entitlement_granted':False}))
        elif args.action=='refund':
            # Sandbox only: demonstrates required-remedy transport, no V1 voluntary-refund feature.
            result=await api.create_required_refund(args.order,intent['refund_id'],intent['paise'],
                                                    'verified_payment_error',intent['refund_nonce'])
            print(json.dumps({'sandbox_refund_state':result.get('refund_status','UNKNOWN')}))
        else:
            result=await api.fetch_refund(args.order,intent['refund_id'])
            print(json.dumps({'sandbox_refund_state':result.get('refund_status','UNKNOWN')}))
    finally:await api.close()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['create','fetch','refund','fetch-refund'])
    parser.add_argument('--order',required=True,help='Stable synthetic order reference, reuse on retry')
    args=parser.parse_args()
    try:asyncio.run(probe(args))
    except ProviderUnknown:
        print('UNKNOWN. Fetch the same order/refund reference before retrying; do not create a new intent.');return 4
    except Exception:
        print('Sandbox probe failed; no provider credentials/body printed.');return 4
    return 0
if __name__=='__main__':raise SystemExit(main())
