"""Local Phase 3 setup and evidence. No remote target or production admission."""
import argparse
from datetime import datetime,timezone
import hashlib,json,os
from pathlib import Path
import subprocess,sys

ROOT=Path(__file__).resolve().parents[1]

def local_application(existing,publication):
    if existing.get('public_origin')!='http://127.0.0.1:8080' or existing.get('private_origin')!='http://127.0.0.1:8081':
        raise ValueError('Identity setup requires the fixed loopback development origins')
    return existing|{'admission':True,'audio':False,'payments':False,'policy_version':publication['version']}

def configure(args):
    from ops.nt import configure as base,run,GateError
    if os.environ.get('APP_ENV','local')!='local':raise GateError('Identity setup is local only')
    if (ROOT/'.local/runner.pid').exists():raise GateError('Stop the local owner before changing identity configuration')
    base(args)
    path=ROOT/'.local/application.json';raw=(ROOT/'policies/publication.json').read_bytes()
    config=local_application(json.loads(path.read_text()),json.loads(raw));config['policy_digest']=hashlib.sha256(raw).hexdigest()
    temp=path.with_suffix('.json.next');temp.write_text(json.dumps(config,indent=2)+'\n');temp.chmod(0o600);os.replace(temp,path)
    profile=getattr(args,'profile','identity')
    run([sys.executable,'ops/nt.py','interface','configure','--mode',profile])
    print('Local '+profile+' profile configured. Existing keys are preserved; payments and media stay closed.')

def setup(args):
    from ops.nt import run
    configure(args)
    run([sys.executable,'ops/nt.py','lock',*(['--check'] if args.locked else [])])
    run([sys.executable,'ops/nt.py','install'])
    python=ROOT/'.venv/bin/python'
    profile=getattr(args,'profile','identity');command='conversation' if profile=='realtime' else 'identity'
    run([python,'ops/nt.py',command,'verify','--level','core'])
    if not args.no_start:run([python,'ops/nt.py','dev','up','--mode',profile])
    print('Setup completed locally. Run '+command+' verify --level stack after stopping the owner to collect full local evidence.')
    return 0

def verify(args):
    from ops.foundation import source_digest,environment
    from ops.nt import GateError
    if os.environ.get('APP_ENV','local')!='local':raise GateError('Identity qualification is local only')
    profile=getattr(args,'profile','identity');phase=4 if profile=='realtime' else 3;command='conversation' if phase==4 else 'identity'
    directory=ROOT/('evidence/phase'+str(phase));directory.mkdir(parents=True,exist_ok=True)
    logs=directory/('run-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+os.urandom(3).hex());logs.mkdir()
    checks={};env=dict(os.environ,PYTHONPATH=str(ROOT/'api')+os.pathsep+str(ROOT));python=sys.executable
    def check(name,argv,timeout=900):
        try:
            result=subprocess.run([str(v) for v in argv],cwd=ROOT,env=env,capture_output=True,text=True,timeout=timeout)
            output=result.stdout+result.stderr;code=result.returncode;status='passed' if code==0 else 'failed'
        except (OSError,subprocess.TimeoutExpired):output='Command unavailable or timed out. No pass recorded.\n';code=None;status='blocked'
        path=logs/(name+'.log');path.write_text(output)
        checks[name]={'status':status,'returncode':code,'artifact':str(path.relative_to(directory)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
        print(name+': '+status,flush=True);return status=='passed'
    for name,argv in [('prerequisites',[python,'ops/nt.py','doctor','--core']),('contracts',[python,'ops/nt.py','contracts','--check']),
        ('unit',[python,'ops/nt.py','test','--suite','unit']),('coordinator',['node','--test','tests/qualification/identity-client.test.mjs']),
        ('interfaces',[python,'ops/nt.py','interface','check']),('policies',[python,'ops/nt.py','policies','check']),
        ('build_guard',['node','ops/check-web.mjs']),('source',[python,'ops/qualify.py','source'])]:check(name,argv)
    if phase==4:
        check('conversation_client',['node','--test','tests/qualification/conversation-client.test.mjs'])
        check('matching_benchmark',[python,'ops/conversation_benchmark.py'])
    wanted=list(checks);core=all(c['status']=='passed' for c in checks.values())
    checks.update({key:{'status':'not_run','reason':'Core level does not execute a real stack.'} for key in ('integration','build','typecheck','browser')})
    if args.level in ('integration','stack'):
        ready=check('stack_prerequisites',[python,'ops/nt.py','doctor','--locked']);wanted.append('stack_prerequisites')
        if (ROOT/'.local/runner.pid').exists():
            checks['owner_stopped']={'status':'blocked','reason':'Stop the local owner before migration/failure injection.'};wanted.append('owner_stopped');ready=False
        if ready and core:
            healthy=True
            env['NOTITLE_INTEGRATION']='local-disposable'
            commands=[('configuration',[python,'ops/nt.py',command,'configure']),
                ('database',['docker','compose','--env-file','infra/images.env','-f','infra/compose.dev.yml','up','-d','--wait','db']),
                ('roles',[python,'ops/nt.py','db','bootstrap']),('migration',[python,'ops/nt.py','db','migrate']),
                ('integration',[python,'ops/nt.py','test','--suite','integration'])]
            for name,argv in commands:
                if healthy:healthy=check(name,argv)
                else:checks[name]={'status':'blocked','reason':'An earlier setup or integration check failed.'}
                wanted.append(name)
            if args.level=='stack':
                if healthy:healthy=check('build',[python,'ops/nt.py','build'])
                else:checks['build']={'status':'blocked','reason':'Real integration must pass before the build.'}
                wanted.append('build')
                if healthy:
                    pid=None
                    try:
                        healthy=check('start',[python,'ops/nt.py','dev','up','--mode',profile,'--skip-build']);wanted.append('start')
                        if healthy:
                            pid=int((ROOT/'.local/runner.pid').read_text())
                            healthy=check('browser_packages',['npm','ci','--ignore-scripts']);wanted.append('browser_packages')
                            if healthy:healthy=check('browser_install',['npx','playwright','install','chromium']);wanted.append('browser_install')
                            if healthy:
                                healthy=check('typecheck',['npm','run','typecheck']);wanted.append('typecheck')
                                if healthy:check('browser',['npm','run','test:conversation' if phase==4 else 'test:identity'])
                                else:checks['browser']={'status':'blocked','reason':'Typecheck failed.'}
                            else:checks['browser']={'status':'blocked','reason':'Browser prerequisites failed.'}
                        else:checks['browser']={'status':'blocked','reason':'Local identity stack did not start.'}
                    finally:
                        if pid is not None:check('stop',[python,'ops/nt.py','dev','down','--expected-pid',str(pid)]);wanted.append('stop')
                else:checks['browser']={'status':'blocked','reason':'No actual identity export available.'}
                wanted.append('browser')
        else:
            checks['integration']={'status':'blocked','reason':'Real dependency locks, Docker or a stopped owner are required.'};wanted.append('integration')
            if args.level=='stack':
                for name in ('build','typecheck','browser'):checks[name]={'status':'blocked','reason':'Real integration prerequisites failed.'};wanted.append(name)
    passed=all(checks[key]['status']=='passed' for key in wanted)
    report={'recorded_at':datetime.now(timezone.utc).isoformat(),'phase':phase,'level':args.level,'runtime_profile':profile,'source_sha256':source_digest(),
        'environment':environment(),'checks':checks,'requested_checks_passed':passed,'phase'+str(phase)+'_accepted':False,'production_ready':False,
        'external_gates':{'legal_review':'not_supplied','independent_host_loss_restore':'not_run','assistive_technology_review':'not_run'},
        'limits':'Core tests include real cryptography and the actual coordinator; scripted database I/O is not PostgreSQL locking, ACL, migration or browser qualification. A local stack does not certify production legal or infrastructure suitability.'}
    (directory/'latest.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'requested_checks_passed':passed,'phase'+str(phase)+'_accepted':False,'production_ready':False},indent=2))
    return 0 if passed else 3

def add_commands(commands):
    parser=commands.add_parser('identity',help='Phase 3 local setup and qualification')
    actions=parser.add_subparsers(dest='identity_action',required=True)
    actions.add_parser('configure').set_defaults(fn=configure)
    action=actions.add_parser('setup');action.add_argument('--locked',action='store_true');action.add_argument('--no-start',action='store_true');action.set_defaults(fn=setup)
    action=actions.add_parser('verify');action.add_argument('--level',choices=['core','integration','stack'],default='core');action.set_defaults(fn=verify)
