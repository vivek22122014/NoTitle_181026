#!/usr/bin/env python3
"""Root-only clean relay restart; must never run while unmanaged coturn is present."""
import os,secrets,subprocess
from pathlib import Path

def run(argv,**kwargs):return subprocess.run(argv,check=True,**kwargs)
def main():
    if os.geteuid()!=0:raise ValueError('Root required')
    run(['systemctl','stop','notitle-controller','notitle-coturn','notitle-guard'])
    running=subprocess.run(['pgrep','-x','turnserver'],capture_output=True)
    if running.returncode==0:raise ValueError('Unmanaged coturn remains; refusing history reset')
    existing=subprocess.run(['nft','list','table','inet','notitle_guard'],capture_output=True)
    if existing.returncode==0:run(['nft','delete','table','inet','notitle_guard'])
    root=Path('/etc/notitle-relay');secret=secrets.token_hex(32)
    for name,value in [('turn_secret',secret),('cli_password',secrets.token_hex(32))]:
        path=root/name;path.write_text(value);path.chmod(0o400);os.chown(path,10002,10002)
    password=(root/'cli_password').read_text()
    path=root/'turnserver.conf';path.write_text((root/'turnserver.base.conf').read_text()+'static-auth-secret='+secret+'\ncli-password='+password+'\n')
    path.chmod(0o400);os.chown(path,10002,10002)
    history=Path('/var/lib/notitle-relay/history.json');history.unlink(missing_ok=True)
    Path('/run/notitle-relay/guard.sock').unlink(missing_ok=True)
    run(['systemctl','start','notitle-guard','notitle-coturn','notitle-controller'])
if __name__=='__main__':
    try:main()
    except Exception:raise SystemExit('Relay remains closed: clean boot requirements failed. No secret values were logged.')
