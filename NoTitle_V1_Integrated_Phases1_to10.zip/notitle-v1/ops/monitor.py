#!/usr/bin/env python3
"""Health, backup-age, disk, certificate and optional external deadman monitoring.
Alert payloads contain fixed status codes only. No content, URL or secrets are logged.
"""
import argparse,json,os,shutil,socket,ssl,time,urllib.parse,urllib.request
from pathlib import Path

def https_secret(path):
    value=Path(path).read_text().strip();url=urllib.parse.urlsplit(value)
    if url.scheme!='https' or not url.hostname or url.username or url.password or url.fragment:raise ValueError('HTTPS transport required')
    return value

def status_alerts(backup,current,disk_used_fraction,certificate_expires=None):
    alerts=[]
    if not backup or not isinstance(backup.get('last_success'),(int,float)):alerts.append('BACKUP_STATUS_UNAVAILABLE')
    elif current-backup['last_success']>90000 or backup['last_success']>current+300:alerts.append('BACKUP_OVERDUE')
    if disk_used_fraction>=.85:alerts.append('DISK_BUDGET_WARNING')
    if certificate_expires is not None and certificate_expires-current<21*86400:alerts.append('TLS_CERTIFICATE_EXPIRING')
    return alerts

def certificate_expiry(health_url):
    parsed=urllib.parse.urlsplit(health_url)
    if parsed.scheme!='https':return None
    context=ssl.create_default_context()
    with socket.create_connection((parsed.hostname,parsed.port or 443),timeout=5) as connection:
        with context.wrap_socket(connection,server_hostname=parsed.hostname) as stream:
            return ssl.cert_time_to_seconds(stream.getpeercert()['notAfter'])

JOURNAL_WARN_AT=8500

def journal_capacity_alerts(directory):
    # Metadata only: never read encrypted record content or journal credentials.
    # Iteration is capped even if the directory is unexpectedly oversized.
    try:
        count=0
        with os.scandir(directory) as entries:
            for entry in entries:
                if entry.name.endswith('.record'):
                    count+=1
                    if count>=JOURNAL_WARN_AT:return ['JOURNAL_CAPACITY']
    except OSError:return ['JOURNAL_CAPACITY_UNAVAILABLE']
    return []

def monitor(config_path=Path('/etc/notitle/monitor.json')):
    config=json.loads(Path(config_path).read_text());alerts=[]
    try:
        with urllib.request.urlopen(config['health_url'],timeout=5) as response:
            body=json.loads(response.read(8193))
            if response.status!=200 or body.get('data',{}).get('status') not in {'ready','maintenance'}:alerts.append('OWNER_UNHEALTHY')
    except Exception:alerts.append('OWNER_UNREACHABLE')
    try:backup=json.loads(Path(config['backup_status_file']).read_text())
    except Exception:backup=None
    try:
        disk=shutil.disk_usage(config.get('disk_path','/var/lib/notitle'));fraction=(disk.total-disk.free)/disk.total
    except Exception:fraction=1
    try:expires=certificate_expiry(config['health_url'])
    except Exception:alerts.append('TLS_CERTIFICATE_UNVERIFIED');expires=None
    alerts+=status_alerts(backup,time.time(),fraction,expires)
    if config.get('journal_directory'):alerts+=journal_capacity_alerts(config['journal_directory'])
    # A successful heartbeat must originate here, so an external deadman also
    # detects loss of this host, its timer or outbound connectivity.
    if not alerts and config.get('heartbeat_url_file'):
        try:
            with urllib.request.urlopen(https_secret(config['heartbeat_url_file']),timeout=10) as response:
                if not 200<=response.status<300:raise ValueError('Heartbeat failed')
        except Exception:alerts.append('MONITOR_HEARTBEAT_FAILED')
    if alerts:
        webhook=https_secret(config['alert_webhook_file'])
        request=urllib.request.Request(webhook,data=json.dumps({'text':'NoTitle: '+', '.join(sorted(set(alerts)))}).encode(),headers={'Content-Type':'application/json'},method='POST')
        with urllib.request.urlopen(request,timeout=10) as response:
            if not 200<=response.status<300:raise ValueError('Alert delivery failed')
        raise SystemExit(1)

def setup(args):
    if os.geteuid()!=0:raise ValueError('Authorized host operator required')
    import grp
    parsed=urllib.parse.urlsplit(args.health_url)
    if parsed.scheme!='https' or not parsed.hostname or parsed.username or parsed.password or parsed.fragment:raise ValueError('Public HTTPS readiness URL required')
    if parsed.path!='/health/ready' or parsed.query:raise ValueError('Use the public /health/ready endpoint')
    directory=Path('/etc/notitle');directory.mkdir(mode=0o755,parents=True,exist_ok=True);group=grp.getgrnam('notitle-monitor').gr_gid
    config={'health_url':args.health_url,'backup_status_file':'/var/lib/notitle/backup/status.json','disk_path':'/var/lib/notitle'}
    journal_directory=getattr(args,'journal_directory',None)
    application=directory/'application.json'
    if journal_directory is None and application.is_file():
        root=json.loads(application.read_text()).get('journal_directory')
        if root:journal_directory=Path(root)/'local'
    if journal_directory is not None:config['journal_directory']=str(journal_directory)
    for key,source in [('alert_webhook_file',args.alert_webhook_file),('heartbeat_url_file',args.heartbeat_url_file)]:
        if source is None:continue
        value=https_secret(source);target=directory/('monitor-'+key.removesuffix('_file'))
        fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o640)
        with os.fdopen(fd,'w') as file:file.write(value+'\n')
        os.chown(target,0,group);config[key]=str(target)
    path=directory/'monitor.json';fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o644)
    with os.fdopen(fd,'w') as file:json.dump(config,file,indent=2);file.write('\n')
    root=Path(__file__).resolve().parents[1]
    for name in ('notitle-monitor.service','notitle-monitor.timer'):shutil.copyfile(root/'infra/systemd'/name,Path('/etc/systemd/system')/name)
    if journal_directory is not None:print('Grant notitle-monitor read/execute directory metadata access to the journal parent and local directory; record files must remain private. Missing access triggers JOURNAL_CAPACITY_UNAVAILABLE.')
    print('Monitor files prepared. Test actual alert and deadman delivery before enabling the timer; no test message was sent.')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);actions=parser.add_subparsers(dest='command')
    run=actions.add_parser('check');run.add_argument('--config',type=Path,default=Path('/etc/notitle/monitor.json'))
    install=actions.add_parser('setup');install.add_argument('--health-url',required=True);install.add_argument('--alert-webhook-file',type=Path,required=True);install.add_argument('--heartbeat-url-file',type=Path);install.add_argument('--journal-directory',type=Path,help='Record metadata directory; monitor user needs directory-only read/execute access, not record read access. Defaults to production application journal_directory/local when configured.')
    args=parser.parse_args()
    try:
        if args.command=='setup':setup(args)
        else:monitor(getattr(args,'config',Path('/etc/notitle/monitor.json')))
    except Exception:raise SystemExit('Monitoring failed; inspect configuration, transport and timer status. No credentials were logged.')
