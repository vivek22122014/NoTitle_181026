#!/usr/bin/env python3
"""Reapply role ACLs after a no-owner/no-acl restore; never rewrite migration history."""
import argparse,asyncio,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'api'))

async def repair(args):
    import psycopg
    from app.repositories.ownership import OWNER_LOCK
    async with await psycopg.AsyncConnection.connect(args.dsn_file.read_text().strip()) as connection:
        if (await (await connection.execute('SELECT current_user')).fetchone())[0]!='nt_migrator':raise ValueError('Restore objects as nt_migrator')
        if not (await (await connection.execute('SELECT pg_try_advisory_xact_lock(%s)',(OWNER_LOCK,))).fetchone())[0]:raise ValueError('Owner must be stopped')
        for path in sorted((ROOT/'db/migrations').glob('*.sql')):
            body=re.sub(r'--[^\n]*','',path.read_text())
            for statement in body.split(';'):
                value=statement.strip()
                if value.startswith(('GRANT ','REVOKE ','ALTER DEFAULT PRIVILEGES ')):
                    await connection.execute(value,prepare=False)
    print('Versioned role ACLs reapplied. Admission remains closed pending journal replay and restore qualification.')
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--dsn-file',type=Path,required=True);args=parser.parse_args()
    try:asyncio.run(repair(args))
    except Exception:raise SystemExit('Grant recovery refused; use the isolated restored database owned by nt_migrator with all restricted roles provisioned.')
