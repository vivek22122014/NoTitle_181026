"""Serialize local start/stop commands; never replace another command's PID file."""
from contextlib import contextmanager
import fcntl
import os
from pathlib import Path


class LocalBusy(RuntimeError):
    pass


@contextmanager
def operation(directory):
    directory=Path(directory);directory.mkdir(mode=0o700,parents=True,exist_ok=True)
    fd=os.open(directory/'dispatcher.lock',os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW,0o600)
    try:
        try:fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise LocalBusy('Another local start/stop is running') from None
        yield
    finally:os.close(fd)
