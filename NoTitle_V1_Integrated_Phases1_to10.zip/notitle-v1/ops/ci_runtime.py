#!/usr/bin/env python3
"""Install Node from the already reviewed image digest, without an unpinned action."""
import argparse
import os
from pathlib import Path
import subprocess
import sys
from uuid import uuid4
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from ops.locks import verify


def install_node(destination):
    config=verify(ROOT)
    destination=destination.resolve()
    destination.mkdir(mode=0o700,parents=True,exist_ok=False)
    container='notitle-ci-node-'+uuid4().hex
    created=False
    try:
        subprocess.run(['docker','create','--name',container,'--entrypoint','/bin/true',config['image_digests']['NODE_BASE']],check=True,stdout=subprocess.DEVNULL)
        created=True
        subprocess.run(['docker','cp',container+':/usr/local/.',str(destination)],check=True)
        result=subprocess.run([str(destination/'bin/node'),'--version'],check=True,capture_output=True,text=True)
        if result.stdout.strip()!='v'+config['node']:raise ValueError('Locked Node version differs from image')
        path_file=Path(os.environ['GITHUB_PATH'])
        with path_file.open('a') as file:file.write(str(destination/'bin')+'\n')
    finally:
        if created:subprocess.run(['docker','rm',container],check=True,stdout=subprocess.DEVNULL)
    print('Node installed from the reviewed immutable image; PATH applies to later CI steps.')


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--destination',type=Path,required=True);args=parser.parse_args()
    try:install_node(args.destination)
    except Exception:raise SystemExit('CI runtime setup refused; inspect reviewed locks, image access, destination and runner environment.')
