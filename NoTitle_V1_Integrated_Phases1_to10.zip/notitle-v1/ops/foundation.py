"""One-command local foundation setup and reproducible, honest feasibility evidence."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
EXCLUDED={'.local','.venv','node_modules','.next','out','__pycache__','.git'}


def source_digest():
    files={}
    for directory in ('api','ops','db','infra','contracts','web','relay','policies','tests'):
        for path in sorted((ROOT/directory).rglob('*')):
            if path.is_file() and not EXCLUDED.intersection(path.relative_to(ROOT).parts) and path.suffix not in {'.pyc','.tsbuildinfo'}:
                files[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
    for name in ('package.json','versions.lock','.github/workflows/verify.yml',*(p.name for p in sorted(ROOT.glob('playwright*.config.ts')))):
        path=ROOT/name
        if path.is_file():files[name]=hashlib.sha256(path.read_bytes()).hexdigest()
    return hashlib.sha256(json.dumps(files,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def environment():
    versions={}
    for name in ('pydantic','cryptography','fastapi','uvicorn','psycopg','httpx'):
        try:versions[name]=importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:versions[name]=None
    return {'python':sys.version.split()[0],
        'tools':{name:bool(shutil.which(name)) for name in ('uv','node','npm','docker','turnserver','nft')},
        'modules':{name:bool(importlib.util.find_spec(name)) for name in versions},
        'installed_library_versions':versions,
        'registry_resolution':'Not attempted by verify; setup/lock performs explicit resolution.',
        'limits':'Available-library core tests are not a hash-locked integration qualification.'}


def verify(args):
    report_path=args.report or ROOT/'evidence/phase1/latest.json'
    report_path.parent.mkdir(parents=True,exist_ok=True)
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    logs=report_path.parent/('run-'+stamp+'-'+os.urandom(3).hex());logs.mkdir(mode=0o700)
    checks={}
    env=dict(os.environ,PYTHONPATH=str(ROOT/'api')+os.pathsep+str(ROOT))
    def check(name,argv,timeout=600):
        started=time.monotonic()
        try:
            result=subprocess.run([str(value) for value in argv],cwd=ROOT,env=env,capture_output=True,text=True,timeout=timeout)
            output=result.stdout+result.stderr;code=result.returncode
            status='passed' if code==0 else 'failed'
        except (OSError,subprocess.TimeoutExpired):
            output='Required command unavailable or deadline exceeded. No success inferred.\n';code=None;status='blocked'
        path=logs/(name+'.txt');path.write_text(output)
        checks[name]={'status':status,'exit_code':code,'duration_seconds':round(time.monotonic()-started,3),
            'artifact':str(path.relative_to(report_path.parent)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
        print(name+': '+status,flush=True)
        return status=='passed'
    core=[
        check('core_prerequisites',[sys.executable,'ops/nt.py','doctor','--core']),
        check('contracts',[sys.executable,'ops/nt.py','contracts','--check']),
        check('unit_tests',[sys.executable,'-m','unittest','discover','-s','tests/unit','-v']),
        check('source_boundaries',[sys.executable,'ops/qualify.py','source']),
    ]
    requested=list(checks)
    if args.level in {'integration','stack'}:
        prereq=check('stack_prerequisites',[sys.executable,'ops/nt.py','doctor','--locked'])
        requested.append('stack_prerequisites')
        owner_running=(ROOT/'.local/runner.pid').exists()
        if owner_running:
            checks['local_owner_running']={'status':'blocked','reason':'Stop the current local owner before integration failure injection.'}
            requested.append('local_owner_running')
        if prereq and all(core) and not owner_running:
            sequence=[
                ('local_configuration',[sys.executable,'ops/nt.py','configure']),
                ('local_database',['docker','compose','--env-file','infra/images.env','-f','infra/compose.dev.yml','up','-d','--wait','db']),
                ('local_roles',[sys.executable,'ops/nt.py','db','bootstrap']),
                ('foundation_migration',[sys.executable,'ops/nt.py','db','migrate','--foundation']),
                ('postgres_process_http',[sys.executable,'-m','unittest','tests.integration.test_postgres','tests.integration.test_http_provider','-v']),
            ]
            env['NOTITLE_INTEGRATION']='local-disposable'
            healthy=True
            for name,command in sequence:
                if healthy:healthy=check(name,command)
                else:checks[name]={'status':'blocked','reason':'An earlier local foundation step failed.'}
                requested.append(name)
            if args.level=='stack':
                if healthy:healthy=check('static_exports',[sys.executable,'ops/nt.py','build','--target','web'],timeout=1200)
                else:checks['static_exports']={'status':'blocked','reason':'Local foundation tests failed.'}
                requested.append('static_exports')
                if healthy:
                    started_pid=None
                    try:
                        healthy=check('foundation_start',[sys.executable,'ops/nt.py','dev','up','--mode','foundation','--skip-build'])
                        requested.append('foundation_start')
                        if healthy:
                            started_pid=int((ROOT/'.local/runner.pid').read_text())
                            check('foundation_http',[sys.executable,'ops/foundation_smoke.py'])
                        else:checks['foundation_http']={'status':'blocked','reason':'Local foundation startup failed.'}
                        requested.append('foundation_http')
                    finally:
                        if started_pid is not None:
                            check('foundation_stop',[sys.executable,'ops/nt.py','dev','down','--expected-pid',str(started_pid)])
                            requested.append('foundation_stop')
        else:
            for name in ('postgres_process_http','static_exports'):
                if name=='static_exports' and args.level!='stack':continue
                checks[name]={'status':'blocked','reason':'Foundation dependencies or local Docker unavailable.'}
                requested.append(name)
    success=all(checks[name]['status']=='passed' for name in requested)
    report={'recorded_at':datetime.now(timezone.utc).isoformat(),'phase':1,'level':args.level,
        'source_sha256':source_digest(),'environment':environment(),'checks':checks,
        'requested_checks_passed':success,'phase1_accepted':False,'production_admission':'closed',
        'external_gates':{
            'relay_packet_guard':'not_run','cloud_host_loss_restore':'not_run',
            'merchant_sandbox_and_late_remedy':'not_run','region_cost_and_legal_contact':'not_supplied'},
        'limits':'Core tests and fixture adapters are not real PostgreSQL, Next.js, cloud, payment or RTP qualification.'}
    temporary=report_path.with_suffix(report_path.suffix+'.next')
    temporary.write_text(json.dumps(report,indent=2)+'\n');os.replace(temporary,report_path)
    print('Report: '+str(report_path)+'; Phase 1 acceptance remains open.')
    return 0 if success else 3


def setup(args):
    # Explicit operator action: configure, resolve real artifacts, install and start locally.
    from ops.nt import run
    run([sys.executable,'ops/nt.py','configure'])
    run([sys.executable,'ops/nt.py','lock',*(['--check'] if args.locked else [])])
    run([sys.executable,'ops/nt.py','install'])
    python=ROOT/'.venv/bin/python'
    run([python,'ops/nt.py','contracts','--check'])
    run([python,'ops/nt.py','test','--suite','unit'])
    if not args.no_start:run([python,'ops/nt.py','dev','up','--mode','foundation'])
    print('Local foundation setup completed. Run foundation verify --level stack before marking integration accepted.')
    return 0


def add_commands(commands):
    parser=commands.add_parser('foundation',help='Phase 1 local setup and measured feasibility checks')
    actions=parser.add_subparsers(dest='foundation_action',required=True)
    action=actions.add_parser('setup');action.add_argument('--locked',action='store_true');action.add_argument('--no-start',action='store_true');action.set_defaults(fn=setup)
    action=actions.add_parser('verify');action.add_argument('--level',choices=['core','integration','stack'],default='core');action.add_argument('--report',type=Path);action.set_defaults(fn=verify)
