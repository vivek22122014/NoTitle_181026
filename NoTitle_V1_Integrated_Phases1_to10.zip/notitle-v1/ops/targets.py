"""A local development command cannot silently target a managed database."""


class TargetError(ValueError):
    pass


def assert_local_fields(fields, role, password):
    expected = {"host":"127.0.0.1", "port":"55432", "dbname":"notitle", "user":"postgres" if role=="admin" else "nt_"+role, "sslmode":"disable"}
    if any(fields.get(key)!=value for key,value in expected.items()):
        raise TargetError("Disposable local database required")
    if fields.get("hostaddr", "127.0.0.1")!="127.0.0.1" or fields.get("service"):
        raise TargetError("Alternate connection targets are forbidden")
    if not password or fields.get("password")!=password:
        raise TargetError("Local generated credential binding required")
    return fields


def local_dsn(role, read_secret):
    from psycopg.conninfo import conninfo_to_dict
    dsn=read_secret(role+"_dsn")
    assert_local_fields(conninfo_to_dict(dsn),role,read_secret("pg_"+role))
    return dsn
