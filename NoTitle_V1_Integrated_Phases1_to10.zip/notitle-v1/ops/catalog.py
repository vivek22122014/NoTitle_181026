#!/usr/bin/env python3
"""Install immutable, accountant-reviewed pass versions; no provider payment occurs."""
import argparse,asyncio,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'api'))
from app.domain.receipts import ReceiptConfiguration
from app.domain.ledger import PLANS

async def install(args):
    import psycopg
    from psycopg.rows import dict_row
    config=ReceiptConfiguration(json.loads(args.reviewed_receipts.read_text()))
    async with await psycopg.AsyncConnection.connect((args.secrets/'migrator_dsn').read_text().strip(),row_factory=dict_row) as connection:
        for code,row in config.pack['plans'].items():
            gross,seconds=PLANS[code]
            cursor=await connection.execute('SELECT * FROM nt.plan_versions WHERE code=%s AND version=%s FOR UPDATE',(code,row['version']))
            previous=await cursor.fetchone()
            if previous and (previous['gross_paise'],previous['duration_seconds'],previous['tax_rule'],previous['policy_version'])!=(gross,seconds,row['tax_rule'],args.policy_version):raise ValueError('Existing plan version is immutable; choose a new version')
            await connection.execute('INSERT INTO nt.plan_versions(code,version,gross_paise,duration_seconds,tax_rule,policy_version) VALUES(%s,%s,%s,%s,%s,%s) ON CONFLICT DO NOTHING',(code,row['version'],gross,seconds,row['tax_rule'],args.policy_version))
            if args.enable:
                await connection.execute('UPDATE nt.plan_versions SET enabled=(version=%s) WHERE code=%s',(row['version'],code))
        await connection.execute("UPDATE nt.plan_versions SET enabled=false WHERE code='Annual365'")
    print('Reviewed catalog versions installed. Application-level payments and release gates still apply. Annual365 remains disabled.')
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--secrets',type=Path,required=True);parser.add_argument('--reviewed-receipts',type=Path,required=True);parser.add_argument('--policy-version',required=True);parser.add_argument('--enable',action='store_true');args=parser.parse_args()
    try:asyncio.run(install(args))
    except Exception:raise SystemExit('Catalog installation refused; verify configuration, immutable versions and migration role access.')
