#!/usr/bin/env python3
"""Encrypted independent PostgreSQL backups. Configure PGSERVICEFILE and restic secrets."""
import argparse,json,os,subprocess,time
from contextlib import contextmanager
from pathlib import Path

def run(argv,**kwargs):return subprocess.run(argv,check=True,**kwargs)
def write_status(path,data):
    """A crash cannot truncate the last completed backup checkpoint."""
    path=Path(path);temporary=path.with_suffix('.json.next')
    fd=os.open(temporary,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o644)
    os.fchmod(fd,0o644)  # Safe status metadata must be readable by the separate monitor user.
    with os.fdopen(fd,'w') as file:json.dump(data,file,sort_keys=True);file.write('\n');file.flush();os.fsync(file.fileno())
    os.replace(temporary,path)
    directory=os.open(path.parent,os.O_RDONLY)
    try:os.fsync(directory)
    finally:os.close(directory)

@contextmanager
def backup_lock(directory=Path('/var/lib/notitle/backup')):
    import fcntl
    directory=Path(directory);owner=directory.stat();path=directory/'backup.lock'
    fd=os.open(path,os.O_WRONLY|os.O_CREAT,0o600)
    if os.geteuid()==0:os.fchown(fd,owner.st_uid,owner.st_gid)
    with os.fdopen(fd,'a') as stream:
        try:fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise ValueError('Backup already running')
        try:yield
        finally:fcntl.flock(stream,fcntl.LOCK_UN)

def backup():
    with backup_lock():return perform_backup()

def perform_backup():
    if not os.environ.get('RESTIC_PASSWORD_FILE') or not os.environ.get('PGSERVICEFILE'):raise ValueError('Private service and backup credentials required')
    dump=subprocess.Popen(['pg_dump','--dbname=service=notitle_backup','--format=custom','--no-owner','--no-acl'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
    try:
        result=subprocess.run(['restic','backup','--stdin','--stdin-filename','notitle.dump','--tag','notitle-pending','--json'],stdin=dump.stdout,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
        dump.stdout.close()
        if dump.wait()!=0 or result.returncode!=0:raise ValueError('Backup failed')
        run(['restic','check','--read-data-subset=1%'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        summaries=[json.loads(line) for line in result.stdout.splitlines() if line.strip()]
        snapshot=next(row['snapshot_id'] for row in summaries if row.get('message_type')=='summary' and row.get('snapshot_id'))
        run(['restic','tag','--add','notitle-verified','--remove','notitle-pending',snapshot],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        run(['restic','forget','--tag','notitle-verified','--keep-daily','30','--prune'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        write_status('/var/lib/notitle/backup/status.json',{'last_success':time.time(),'snapshot_id':snapshot,'scope':'database','verification':'repository sample check; restore rehearsal separate'})
    finally:
        if dump.poll() is None:dump.kill();dump.wait()

def restore(args):
    if not args.isolated_target:raise ValueError('An isolated target is required')
    # The operator prepares a separate service entry; never accept the production service name.
    if args.service=='notitle_backup' or args.service=='notitle_runtime':raise ValueError('Production target refused')
    listing=run(['restic','snapshots','--tag','notitle-verified','--json'],capture_output=True,text=True)
    snapshots=json.loads(listing.stdout)
    if not snapshots:raise ValueError('No verified snapshot')
    if args.snapshot=='latest':snapshot=max(snapshots,key=lambda row:row['time'])['id']
    else:
        matches=[row for row in snapshots if row['id']==args.snapshot]
        if len(matches)!=1:raise ValueError('Exact verified snapshot ID required')
        snapshot=matches[0]['id']
    check=run(['psql','--no-psqlrc','--dbname=service='+args.service,'--tuples-only','--no-align','--command',"SELECT count(*) FROM pg_tables WHERE schemaname NOT IN ('pg_catalog','information_schema')"],capture_output=True,text=True)
    if check.stdout.strip()!='0':raise ValueError('Restore target must be empty')
    source=subprocess.Popen(['restic','dump',snapshot,'notitle.dump'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
    try:
        result=subprocess.run(['pg_restore','--dbname=service='+args.service,'--single-transaction','--exit-on-error','--no-owner','--no-acl'],stdin=source.stdout,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        source.stdout.close()
        if source.wait()!=0 or result.returncode!=0:raise ValueError('Restore failed')
    finally:
        if source.poll() is None:source.kill();source.wait()
    print('Database restored into isolated target. Keep admission closed; replay the independent journal and requalify before any traffic.')

if __name__=='__main__':
    parser=argparse.ArgumentParser();commands=parser.add_subparsers(dest='command',required=True)
    commands.add_parser('backup');p=commands.add_parser('restore');p.add_argument('--snapshot',default='latest');p.add_argument('--service',required=True);p.add_argument('--isolated-target',action='store_true');args=parser.parse_args()
    try:backup() if args.command=='backup' else restore(args)
    except Exception:raise SystemExit('Backup/restore failed. No credentials or database content were logged.')
