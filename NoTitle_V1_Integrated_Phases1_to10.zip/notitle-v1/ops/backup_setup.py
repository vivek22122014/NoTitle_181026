#!/usr/bin/env python3
"""Install backup service files from the private vault on the application host."""
import argparse,json,os,pwd,secrets,shutil
from pathlib import Path

def setup(args):
    from psycopg.conninfo import conninfo_to_dict
    if os.geteuid()!=0:raise ValueError('Root required')
    values=conninfo_to_dict((args.vault/'backup_dsn').read_text())
    if values.get('sslmode')!='verify-full' or values['user']!='nt_backup':raise ValueError('Read-only verified-TLS backup role required')
    account=pwd.getpwnam('notitle-backup');directory=Path('/etc/notitle/backup')
    directory.mkdir(mode=0o700,parents=True,exist_ok=True);os.chown(directory,account.pw_uid,account.pw_gid)
    def put(name,body):
        target=directory/name;fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'wb') as file:file.write(body);file.flush();os.fsync(file.fileno())
        os.chown(target,account.pw_uid,account.pw_gid)
    put('db_ca.pem',Path(values['sslrootcert']).read_bytes())
    service='[notitle_backup]\n'+'\n'.join(key+'='+values[key] for key in ('host','port','dbname','user'))+'\nsslmode=verify-full\nsslrootcert=/etc/notitle/backup/db_ca.pem\n'
    put('pg_service.conf',service.encode())
    escape=lambda value:value.replace('\\','\\\\').replace(':','\\:')
    put('pgpass',(':'.join(escape(values[key]) for key in ('host','port','dbname','user','password'))+'\n').encode())
    put('restic_password',secrets.token_urlsafe(48).encode())
    put('aws_credentials',args.aws_credentials.read_bytes())
    if '\n' in args.repository or not args.repository.startswith('s3:https://'):raise ValueError('Private S3 repository required')
    env=Path(__file__).resolve().parents[1]/'infra/backup.env.example'
    Path('/etc/notitle/backup.env').write_text(env.read_text()+'\nRESTIC_REPOSITORY='+args.repository+'\n')
    for name in ('notitle-backup.service','notitle-backup.timer'):
        shutil.copyfile(env.parent/'systemd'/name,Path('/etc/systemd/system')/name)
    print('Backup files installed. Store the restic password in independent recovery custody, initialize the repository, then start and verify the timer.')
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--vault',type=Path,required=True);parser.add_argument('--repository',required=True);parser.add_argument('--aws-credentials',type=Path,required=True);args=parser.parse_args()
    try:setup(args)
    except Exception:raise SystemExit('Backup installation stopped. Validate existing private files, read-only database role and object credentials; do not overwrite recovery secrets.')
