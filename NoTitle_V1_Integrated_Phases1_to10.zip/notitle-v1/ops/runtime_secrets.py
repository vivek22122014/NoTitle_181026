#!/usr/bin/env python3
"""Install an allowlisted runtime subset, rewriting only the database CA location."""
import argparse,os,shutil
from pathlib import Path

def install(args):
    from psycopg.conninfo import conninfo_to_dict,make_conninfo
    if os.geteuid()!=0:raise ValueError('Root installation required')
    args.destination.mkdir(mode=0o700,parents=True,exist_ok=True)
    names=['hmac_key','wrapping_key','journal_encryption','journal_signing','journal_config','journal_aws_credentials','legal_rules']
    if args.payments:names+=['cashfree_client_id','cashfree_secret','receipt_configuration']
    if args.audio:names+=['relay_config','relay-client.pem','relay-client.key','relay-ca.pem']
    def put(name,body):
        target=args.destination/name
        if target.exists():raise ValueError('Existing runtime secret: rotate through a reviewed release, not overwrite')
        fd=os.open(target,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o400)
        with os.fdopen(fd,'wb') as file:file.write(body);file.flush();os.fsync(file.fileno())
        os.chown(target,10001,10001)
    put('db_ca.pem',args.ca.read_bytes())
    for role in ('runtime','support','private','jobs','analytics'):
        values=conninfo_to_dict((args.vault/(role+'_dsn')).read_text().strip());values['sslrootcert']='/run/secrets/db_ca.pem'
        if values.get('sslmode')!='verify-full':raise ValueError('Verified database TLS required')
        put(role+'_dsn',make_conninfo(**values).encode())
    for name in names:put(name,(args.vault/name).read_bytes())
    os.chown(args.destination,10001,10001);args.destination.chmod(0o700)
    print('Allowlisted runtime subset installed. Migrator, administrator, signing and backup secrets were excluded.')
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--vault',type=Path,required=True);parser.add_argument('--destination',type=Path,required=True);parser.add_argument('--ca',type=Path,required=True);parser.add_argument('--payments',action='store_true');parser.add_argument('--audio',action='store_true');args=parser.parse_args()
    try:install(args)
    except Exception:raise SystemExit('Secret installation stopped. Inspect private paths/permissions without printing their contents.')
