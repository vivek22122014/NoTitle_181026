"""Foundation lifecycle/repair tests; fake IO is not PostgreSQL acceptance evidence."""
import asyncio
from contextlib import asynccontextmanager
import json
import os
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from app.lifecycle import ownership
from app.repositories.database import Pool, PoolUnavailable
from app.settings import Settings
from ops.locks import LockError, inputs, sha256, verify


class Lease:
    epoch = 9
    def __init__(self):
        self.closed = False
        self.failure = asyncio.Event()
    async def prove(self):
        if self.failure.is_set():
            raise ConnectionError("Synthetic proof loss")
    async def close(self):
        self.closed = True


class Lifecycle(unittest.IsolatedAsyncioTestCase):
    async def test_constructor_failure_releases_lease_and_stops_heartbeat(self):
        lease = Lease()
        async def acquire(dsn):return lease
        with self.assertRaisesRegex(ValueError, "constructor"):
            async with ownership("synthetic", acquire) as owned:
                task = owned.heartbeat
                raise ValueError("constructor")
        self.assertTrue(lease.closed)
        self.assertTrue(task.done())
        self.assertFalse(owned.coordinator.alive)

    async def test_startup_proof_failure_fences_before_listeners_exist(self):
        lease = Lease();lease.failure.set()
        async def acquire(dsn):return lease
        async with ownership("synthetic", acquire) as owned:
            await asyncio.sleep(0)
            self.assertTrue(owned.heartbeat.done())
            self.assertFalse(owned.coordinator.alive)
        self.assertTrue(lease.closed)


class FakeConnection:
    def __init__(self):
        self.closed = False
        self.committed = self.rolled_back = False
    async def close(self):self.closed = True
    @asynccontextmanager
    async def transaction(self):
        try:yield self
        except BaseException:
            self.rolled_back = True
            raise
        else:self.committed = True


class Pools(unittest.IsolatedAsyncioTestCase):
    async def make_pool(self, size=1):
        self.created = []
        async def connector(dsn):
            value = FakeConnection();self.created.append(value);return value
        pool = Pool("synthetic", size, connector=connector, acquire_timeout=.02)
        await pool.open()
        self.addAsyncCleanup(pool.close)
        return pool

    async def test_dead_slot_reconnects_inside_fixed_budget(self):
        pool = await self.make_pool()
        old = self.created[0];old.closed = True
        async with pool.transaction() as connection:
            self.assertIsNot(connection, old)
        self.assertEqual(len(pool.connections), 1)
        self.assertEqual(sum(not c.closed for c in self.created), 1)
        self.assertTrue(connection.committed)

    async def test_cancel_rolls_back_and_returns_exact_slot(self):
        pool = await self.make_pool();entered = asyncio.Event()
        async def work():
            async with pool.transaction():
                entered.set();await asyncio.Event().wait()
        task = asyncio.create_task(work());await entered.wait();task.cancel()
        with self.assertRaises(asyncio.CancelledError):await task
        self.assertTrue(self.created[0].rolled_back)
        async with pool.transaction() as connection:self.assertIs(connection, self.created[0])

    async def test_busy_pool_times_out_without_growing(self):
        pool = await self.make_pool()
        async with pool.transaction():
            with self.assertRaises(TimeoutError):
                async with pool.transaction():self.fail("Busy slot admitted")
        self.assertEqual(len(self.created), 1)

    async def test_failed_repair_keeps_a_retryable_slot(self):
        pool = await self.make_pool();self.created[0].closed = True
        normal = pool.connector
        async def fail(dsn):raise ConnectionError("Synthetic connection failure")
        pool.connector = fail
        with self.assertRaises(ConnectionError):
            async with pool.transaction():self.fail("Broken slot admitted")
        self.assertEqual(pool.queue.qsize(), 1)
        pool.connector = normal
        async with pool.transaction():pass

    async def test_partial_open_failure_closes_prior_connections(self):
        created = []
        async def connect(dsn):
            if created:raise ConnectionError("Synthetic partial open")
            value = FakeConnection();created.append(value);return value
        pool = Pool("synthetic", 2, connector=connect)
        with self.assertRaises(ConnectionError):await pool.open()
        self.assertTrue(created[0].closed)
        self.assertFalse(pool.connections)
        self.assertTrue(pool.closed)

    async def test_closed_pool_rejects_immediately(self):
        pool = await self.make_pool();await pool.close()
        with self.assertRaises(PoolUnavailable):
            async with pool.transaction():pass


class InputLocks(unittest.TestCase):
    def setUp(self):
        self.temp = TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        for directory in ("api", "infra", "web/public"):(self.root/directory).mkdir(parents=True)
        for name,body in {"api/requirements.in":"synthetic==1\n", "api/requirements.lock":"synthetic fixture only", "package.json":"{}", "web/public/package.json":"{}", "package-lock.json":"{}"}.items():
            (self.root/name).write_text(body)
        image = "python@sha256:"+"a"*64
        (self.root/"infra/images.env").write_text("PYTHON_BASE="+image+"\n")
        self.config = {"image_candidates":{"PYTHON_BASE":"python:synthetic"},"resolved_candidates":{"PYTHON_BASE":"python:synthetic"},"image_digests":{"PYTHON_BASE":image},"lock_inputs":{**inputs(self.root,"python"),**inputs(self.root,"web")},"lock_hashes":{name:sha256(self.root/name) for name in ("api/requirements.lock","package-lock.json","infra/images.env")}}
        self.write()
    def write(self):(self.root/"versions.lock").write_text(json.dumps(self.config))
    def test_fixture_with_matching_inputs_and_artifacts_is_consistent(self):verify(self.root)
    def test_changed_python_input_invalidates_existing_artifact(self):
        (self.root/"api/requirements.in").write_text("synthetic==2\n")
        with self.assertRaises(LockError):verify(self.root)
    def test_changed_workspace_input_invalidates_existing_artifact(self):
        (self.root/"web/public/package.json").write_text('{"changed":true}')
        with self.assertRaises(LockError):verify(self.root)
    def test_changed_image_candidate_invalidates_old_digest(self):
        self.config['image_candidates']['PYTHON_BASE']='python:another';self.write()
        with self.assertRaises(LockError):verify(self.root)
    def test_mutated_artifact_is_rejected(self):
        (self.root/"api/requirements.lock").write_text('tampered')
        with self.assertRaises(LockError):verify(self.root)


class ModeSettings(unittest.TestCase):
    def test_foundation_is_local_only_and_ports_remain_distinct(self):
        with TemporaryDirectory() as directory:
            path = Path(directory)/'dsn';path.write_text('synthetic');path.chmod(0o600)
            env={'DATABASE_DSN_FILE':str(path),'APP_ENV':'local','APP_MODE':'foundation'}
            with patch.dict(os.environ,env,clear=True):self.assertEqual(Settings.load().mode,'foundation')
            for change in ({'APP_ENV':'production','NT_CONFIG_FILE':'exists'}, {'APP_ENV':'staging'}, {'PUBLIC_PORT':'8001'}):
                with patch.dict(os.environ,{**env,**change},clear=True):
                    with self.assertRaises(ValueError):Settings.load()
    def test_unknown_mode_cannot_fall_back_to_product(self):
        with patch.dict(os.environ,{'APP_MODE':'mistyped'},clear=True):
            with self.assertRaises(ValueError):Settings.load()

class LocalTargets(unittest.TestCase):
    def fields(self):return {'host':'127.0.0.1','port':'55432','dbname':'notitle','user':'postgres','sslmode':'disable','password':'synthetic-only'}
    def test_exact_generated_local_target_is_allowed(self):
        from ops.targets import assert_local_fields
        assert_local_fields(self.fields(),'admin','synthetic-only')
    def test_hostaddr_service_and_other_credentials_cannot_redirect_bootstrap(self):
        from ops.targets import assert_local_fields,TargetError
        for change in ({'host':'managed.example.test'},{'hostaddr':'203.0.113.2'},{'service':'external'},{'port':'5432'},{'dbname':'production'},{'password':'another'}):
            with self.assertRaises(TargetError):assert_local_fields({**self.fields(),**change},'admin','synthetic-only')


class ExportIntegrity(unittest.TestCase):
    def setUp(self):
        self.temp=TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)
        for directory in ('web/public','infra','exports/public/foundation','exports/admin/foundation'):(self.root/directory).mkdir(parents=True)
        for path in ('package.json','package-lock.json','web/public/page.tsx','infra/Dockerfile.web'):(self.root/path).write_text('synthetic fixture')
        (self.root/'versions.lock').write_text(json.dumps({'image_digests':{'NODE_BASE':'synthetic@sha256:'+'b'*64}}))
        for app in ('public','admin'):
            for path in ('index.html','404.html','foundation/index.html'):(self.root/'exports'/app/path).write_text('synthetic fixture')
    def test_source_change_prevents_reusing_old_exports(self):
        from ops.builds import record,verify
        record(self.root,self.root/'exports');verify(self.root,self.root/'exports')
        (self.root/'web/public/page.tsx').write_text('changed')
        with self.assertRaises(ValueError):verify(self.root,self.root/'exports')
    def test_added_or_changed_export_is_rejected(self):
        from ops.builds import record,verify
        record(self.root,self.root/'exports')
        (self.root/'exports/public/stale.html').write_text('old route')
        with self.assertRaises(ValueError):verify(self.root,self.root/'exports')
    def test_missing_foundation_route_rejects_incomplete_build(self):
        from ops.builds import record
        (self.root/'exports/admin/foundation/index.html').unlink()
        with self.assertRaises(ValueError):record(self.root,self.root/'exports')


class EvidenceFailure(unittest.TestCase):
    def test_missing_stack_prerequisites_replace_an_old_success_report(self):
        from argparse import Namespace
        from subprocess import CompletedProcess
        from ops import foundation
        with TemporaryDirectory() as directory:
            path=Path(directory)/'report.json';path.write_text('{"requested_checks_passed":true}')
            def run(command,**kwargs):
                failed='--locked' in command
                return CompletedProcess(command,3 if failed else 0,'synthetic fixture\n','')
            with patch.object(foundation,'ROOT',Path(directory)),patch.object(foundation.subprocess,'run',side_effect=run),patch('builtins.print'):
                code=foundation.verify(Namespace(level='stack',report=path))
            result=json.loads(path.read_text())
            self.assertEqual(code,3)
            self.assertFalse(result['requested_checks_passed'])
            self.assertFalse(result['phase1_accepted'])
            self.assertEqual(result['checks']['postgres_process_http']['status'],'blocked')

class LocalCommandOwnership(unittest.TestCase):
    def test_two_dispatchers_cannot_change_the_local_pid_concurrently(self):
        from ops.local_lock import operation,LocalBusy
        with TemporaryDirectory() as directory:
            with operation(directory):
                with self.assertRaises(LocalBusy):
                    with operation(directory):self.fail('Concurrent local mutation admitted')
            with operation(directory):pass
    def test_expected_pid_guard_never_signals_a_replacement_owner(self):
        from ops import nt
        with TemporaryDirectory() as directory:
            local=Path(directory);(local/'runner.pid').write_text('12345')
            with patch.object(nt,'LOCAL',local),patch.object(nt.os,'killpg') as kill:
                with self.assertRaises(nt.GateError):nt.stop_runner(expected_pid=54321)
                kill.assert_not_called()
            self.assertEqual((local/'runner.pid').read_text(),'12345')
