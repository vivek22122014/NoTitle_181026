"""Cross-feature owner integration; fake identity/relay I/O is not live service proof."""
import asyncio,json,unittest
from contextlib import asynccontextmanager
from types import SimpleNamespace
from unittest.mock import patch
from uuid import uuid4
from app.domain.conversation_contracts import EVENT
from app.domain.errors import DomainError
from app.http.models import Ticket
from app.services.conversation import Conversation
from app.services.media import Media
from app.services.social import Social
from tests.unit.test_phase4 import actor,FakeIdentity,command,flush
from tests.unit.test_audio_integration import Relay


class IntegratedV1(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.rt,self.clock=actor();self.identity=FakeIdentity(self.rt)
        self.social=Social(None,self.rt);self.relay=Relay()
        self.media=Media(self.rt,self.relay,'203.0.113.1')
        self.service=Conversation(self.rt,self.identity,social=self.social,media=self.media)
        self.a=await self.binding();self.b=await self.binding()
        self.pair=self.rt.pair(self.a.principal.ref,self.b.principal.ref)

    async def asyncTearDown(self):await self.service.close()

    async def binding(self):
        principal=self.identity.add();ticket=await self.service.prepare(principal,Ticket())
        binding=await self.service.connect(ticket['ticket'],{'guest':principal.token})
        self.rt.drain(principal.ref);return binding

    async def execute(self,binding,kind,payload):
        dto=command(self.rt,binding.principal.ref,kind,payload)
        return await self.service.execute(binding,dto,self.service.begin(binding,dto))

    def match(self):
        self.rt.start(*self.pair);flush(self.rt)
        return self.rt.current(self.a.principal.ref)

    async def friends(self):
        interaction=self.match()
        await self.execute(self.a,'friend.request',{'interaction_handle':interaction.id})
        await self.execute(self.b,'friend.request',{'interaction_handle':interaction.id})
        self.rt.end(self.a.principal.ref);flush(self.rt)
        return self.social.relationship(self.pair)['handle']

    async def ringing(self):
        interaction=self.match()
        await self.execute(self.a,'call.request',{'interaction_handle':interaction.id})
        return interaction,interaction.call['id']

    def strict_events(self):
        result=[]
        for ref in self.pair:
            for event in self.rt.drain(ref):
                EVENT.validate_python(event);result.append(event)
        return result

    async def test_mutual_friendship_uses_registered_feature_dispatch_and_scoped_wire(self):
        interaction=self.match();payload={'interaction_handle':interaction.id}
        first=await self.execute(self.a,'friend.request',payload)
        self.assertNotIn(self.pair,self.rt.friends);self.assertEqual(first['status'],'pending')
        await self.execute(self.b,'friend.request',payload)
        self.assertIn(self.pair,self.rt.friends)
        events=self.strict_events();self.assertTrue(any(event['type']=='friend.accepted' for event in events))
        for event in events:
            raw=json.dumps(event)
            for identity in self.pair:self.assertNotIn(identity,raw)

    async def test_named_invitation_publication_is_single_and_not_random_search(self):
        handle=await self.friends()
        await self.execute(self.a,'friend.invite',{'relationship_handle':handle})
        invite=self.rt.invites[self.pair]
        await self.execute(self.b,'friend.invite.respond',{'invite_handle':invite['handle'],'accept':True})
        self.assertEqual(len(self.rt.interactions),1);self.assertFalse(self.rt.waiters)
        events=self.strict_events();started=[event for event in events if event['type']=='interaction.started']
        self.assertEqual(len(started),2);self.assertEqual({event['data']['search_command_id'] for event in started},{None})

    async def test_remove_beats_inflight_invitation_authorization(self):
        handle=await self.friends()
        await self.execute(self.a,'friend.invite',{'relationship_handle':handle})
        invite=self.rt.invites[self.pair];self.identity.barrier=asyncio.Event()
        pending=asyncio.create_task(self.execute(self.b,'friend.invite.respond',{'invite_handle':invite['handle'],'accept':True}))
        await asyncio.sleep(0);await self.social.remove(self.a.principal,handle,1)
        self.identity.barrier.set()
        with self.assertRaises(DomainError):await pending
        self.assertFalse(self.rt.interactions);self.assertNotIn(self.pair,self.rt.friends)

    async def test_mutual_audio_dispatch_and_credentials_remain_call_scoped(self):
        interaction,call_id=await self.ringing()
        self.assertFalse(self.relay.requests)
        await self.execute(self.b,'call.respond',{'interaction_handle':interaction.id,'call_id':call_id,'accept':True})
        self.assertIn(call_id,self.media.reserved)
        events=self.strict_events();connected=[event for event in events if event['type']=='call.connect']
        self.assertEqual(len(connected),2)
        self.assertEqual({event['data']['call_id'] for event in connected},{call_id})
        self.assertEqual({event['data']['negotiation_revision'] for event in connected},{2})
        for event in events:
            if event['type'] not in {'call.connect','call.refresh'}:self.assertNotIn('credential',json.dumps(event))

    async def test_end_beats_inflight_relay_create_and_no_credentials_are_published(self):
        interaction,call_id=await self.ringing();self.relay.release=asyncio.Event()
        accept=asyncio.create_task(self.execute(self.b,'call.respond',{'interaction_handle':interaction.id,'call_id':call_id,'accept':True}))
        await self.relay.started.wait()
        end=command(self.rt,self.a.principal.ref,'interaction.end',{'interaction_handle':interaction.id})
        self.service.control(self.a,end);self.relay.release.set()
        with self.assertRaises(DomainError):await accept
        self.assertFalse(self.rt.interactions)
        self.assertFalse(any(event['type']=='call.connect' for event in self.strict_events()))
        self.assertIn(call_id,self.media.reserved);await self.media.pump()
        self.assertNotIn(call_id,self.media.reserved)

    async def test_block_beats_inflight_relay_create_and_removes_friend(self):
        interaction,call_id=await self.ringing();self.rt.friends.add(self.pair);self.relay.release=asyncio.Event()
        accept=asyncio.create_task(self.execute(self.b,'call.respond',{'interaction_handle':interaction.id,'call_id':call_id,'accept':True}))
        await self.relay.started.wait();await self.social.block(self.a.principal,self.b.principal.ref)
        self.relay.release.set()
        with self.assertRaises(DomainError):await accept
        self.assertTrue(self.rt.blocked(*self.pair));self.assertNotIn(self.pair,self.rt.friends)
        self.assertFalse(any(event['type']=='call.connect' for event in self.strict_events()))
        await self.media.pump();self.assertNotIn(call_id,self.media.reserved)

    async def test_call_stop_bypasses_stalled_authorization_and_idle_deadline(self):
        interaction,call_id=await self.ringing()
        self.identity.barrier=asyncio.Event();self.a.access.deadline=self.clock()-1
        dto=command(self.rt,self.a.principal.ref,'call.cancel',{'interaction_handle':interaction.id,'call_id':call_id})
        result=await asyncio.wait_for(self.service.stop_audio(self.a,dto,self.service.begin(self.a,dto)),.5)
        self.assertTrue(result['ok']);self.assertEqual(interaction.call['state'],'teardown')
        self.identity.barrier.set();await self.media.pump();self.assertIsNone(interaction.call)

    async def test_old_call_control_cannot_stop_new_call(self):
        interaction,call_id=await self.ringing()
        old=command(self.rt,self.a.principal.ref,'call.end',{'interaction_handle':interaction.id,'call_id':call_id})
        self.rt.end_call(interaction,'ended');await self.media.pump();self.clock.advance(16)
        await self.execute(self.a,'call.request',{'interaction_handle':interaction.id});new=interaction.call
        with self.assertRaises(DomainError):await self.service.stop_audio(self.a,old,self.service.begin(self.a,old))
        self.assertIs(interaction.call,new);self.assertEqual(new['state'],'ringing')

    async def test_participation_fence_denies_social_and_audio_with_no_late_publish(self):
        interaction=self.match();self.identity.participation_fences.add(self.a.principal.ref)
        with self.assertRaises(DomainError):await self.execute(self.a,'friend.request',{'interaction_handle':interaction.id})
        self.assertFalse(self.rt.interactions);self.assertFalse(self.rt.requests);self.assertFalse(self.relay.requests)

    async def test_shutdown_cancels_media_effect_and_keeps_teardown_work(self):
        interaction,call_id=await self.ringing();self.relay.release=asyncio.Event()
        accept=asyncio.create_task(self.execute(self.b,'call.respond',{'interaction_handle':interaction.id,'call_id':call_id,'accept':True}))
        await self.relay.started.wait();await self.service.close()
        await asyncio.gather(accept,return_exceptions=True)
        self.assertTrue(accept.done());self.assertFalse(self.rt.interactions)
        self.assertFalse(self.service.pending);self.assertIn(call_id,self.rt.media_ends)

    async def save_overtaken(self,ending_binding):
        """The SQL double models a committed INSERT with its context exit pending."""
        interaction=self.match()
        for ref in self.pair:self.rt.people[ref].registered=True
        await self.execute(self.a,'friend.request',{'interaction_handle':interaction.id})
        committed=asyncio.Event();release=asyncio.Event();durable=set();queries=[]
        pair=self.pair;first=True;created={'revision':1,'accepted_at':'exact-insert-time'}
        class Connection:
            async def execute(self,sql,args):
                queries.append((sql,args))
                if sql.startswith('DELETE'):durable.discard(pair)
        connection=Connection()
        @asynccontextmanager
        async def transaction():
            nonlocal first
            yield connection
            if first:
                first=False;durable.add(pair);committed.set();await release.wait()
        self.social.db=SimpleNamespace(transaction=transaction)
        ids=sorted([uuid4(),uuid4()])
        async def rows(*args):return [{'id':ids[0],'public_ref':pair[0]},{'id':ids[1],'public_ref':pair[1]}]
        async def row(_,sql,args):
            if sql.startswith('INSERT'):return created
            if 'count(*)' in sql:return {'n':0}
            return None
        with patch('app.services.social.many',rows),patch('app.services.social.one',row):
            accept=asyncio.create_task(self.execute(self.b,'friend.request',{'interaction_handle':interaction.id}))
            await asyncio.wait_for(committed.wait(),1)
            end=command(self.rt,ending_binding.principal.ref,'interaction.end',{'interaction_handle':interaction.id})
            self.service.control(ending_binding,end);release.set()
            result=await asyncio.gather(accept,return_exceptions=True)
            await self.social.close()
        self.assertIsInstance(result[0],(DomainError,asyncio.CancelledError))
        self.assertFalse(durable);self.assertNotIn(pair,self.rt.friends)
        self.assertFalse(self.social.durable_tasks)
        self.assertEqual(len(queries),1);self.assertIn('accepted_at=%s',queries[0][0])
        self.assertFalse(any(event['type']=='friend.persisted' for event in self.strict_events()))

    async def test_partner_end_after_friend_commit_compensates_exact_row_before_ack(self):
        await self.save_overtaken(self.a)

    async def test_own_end_cancelling_accept_worker_still_compensates_durable_friendship(self):
        await self.save_overtaken(self.b)
