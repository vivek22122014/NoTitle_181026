"""Release orchestration checks: execute real report writing with scripted checks.
These prove scheduling/failure handling, never full-stack qualification.
"""
import argparse,hashlib,json,os,subprocess,unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from ops import release

class ReleaseWorkflow(unittest.TestCase):
    def exercise(self,level='stack',fail=(),source_changed=False,owner=False):
        temporary=TemporaryDirectory();self.addCleanup(temporary.cleanup);root=Path(temporary.name)
        client=root/'tests/qualification';client.mkdir(parents=True);(client/'identity-client.test.mjs').write_text('')
        if owner:
            (root/'.local').mkdir();(root/'.local/runner.pid').write_text('77')
        calls=[]
        def run_check(name,argv,directory,env,timeout=900):
            calls.append((name,[str(value) for value in argv],dict(env)))
            passed=name not in fail
            if name=='start' and passed:
                (root/'.local').mkdir(exist_ok=True);(root/'.local/runner.pid').write_text('123')
            if name=='stop':(root/'.local/runner.pid').unlink(missing_ok=True)
            return {'status':'passed' if passed else 'failed','artifact':'fake.log','sha256':'scripted-not-real-qualification'}
        with patch.object(release,'ROOT',root),patch.object(release,'run_check',side_effect=run_check),patch('ops.foundation.source_digest',side_effect=['before','after'] if source_changed else ['stable','stable']),patch('ops.foundation.environment',return_value={'qualification':'scripted orchestration only'}),patch.dict(os.environ,{'APP_ENV':'local'}):
            result=release.verify(argparse.Namespace(level=level))
        report=json.loads((root/'evidence/release/latest.json').read_text())
        return result,report,calls
    def test_stack_installs_root_dependencies_before_typecheck_and_runs_product(self):
        code,report,calls=self.exercise();names=[name for name,_,_ in calls]
        self.assertEqual(code,0);self.assertLess(names.index('browser_dependencies'),names.index('typecheck'))
        start=next(argv for name,argv,_ in calls if name=='start')
        self.assertEqual(start[start.index('--mode')+1],'product')
        client=next(argv for name,argv,_ in calls if name=='client')
        self.assertTrue(any(value.endswith('identity-client.test.mjs') for value in client))
        self.assertIn('tests/qualification/audio-lifecycle.test.mjs',client)
        integration=next(env for name,_,env in calls if name=='integration');self.assertEqual(integration['NOTITLE_INTEGRATION'],'local-disposable')
        stop=next(argv for name,argv,_ in calls if name=='stop');self.assertEqual(stop[-2:],['--expected-pid','123'])
        self.assertFalse(report['production_ready']);self.assertTrue(all(not phase['accepted'] for phase in report['phases'].values()))
    def test_dependency_failure_blocks_database_build_and_browser(self):
        code,report,calls=self.exercise(fail={'dependencies'});names=[name for name,_,_ in calls]
        self.assertEqual(code,3)
        for name in ('database','migration','build','typecheck','start','browser'):self.assertNotIn(name,names)
        self.assertEqual(report['checks']['integration']['status'],'blocked');self.assertFalse(report['production_ready'])
    def test_typecheck_failure_prevents_owner_start(self):
        code,report,calls=self.exercise(fail={'typecheck'})
        self.assertEqual(code,3);self.assertNotIn('start',[name for name,_,_ in calls]);self.assertEqual(report['checks']['browser']['status'],'blocked')
    def test_browser_failure_stops_only_our_started_owner(self):
        code,report,calls=self.exercise(fail={'browser'})
        self.assertEqual(code,3);self.assertEqual(calls[-1][0],'stop');self.assertEqual(report['checks']['stop']['status'],'passed')
    def test_existing_owner_blocks_destructive_database_tests(self):
        code,report,calls=self.exercise(owner=True)
        self.assertEqual(code,3);self.assertEqual(report['checks']['owner_stopped']['status'],'blocked')
        self.assertNotIn('database',[name for name,_,_ in calls]);self.assertNotIn('stop',[name for name,_,_ in calls])
    def test_source_change_prevents_reusing_results(self):
        code,report,_=self.exercise(level='core',source_changed=True)
        self.assertEqual(code,3);self.assertFalse(report['source_unchanged']);self.assertEqual(report['checks']['source_stability']['status'],'failed')
    def test_core_does_not_infer_external_gates(self):
        code,report,calls=self.exercise(level='core');self.assertEqual(code,0)
        self.assertEqual(set(report['phases']),{str(value) for value in range(1,11)})
        for gate in release.EXTERNAL_GATES:self.assertEqual(report['checks'][gate]['status'],'not_run')
        self.assertNotIn('dependencies',[name for name,_,_ in calls])

class CheckArtifact(unittest.TestCase):
    def test_timeout_is_blocked_and_artifact_bytes_are_bound(self):
        with TemporaryDirectory() as temporary:
            directory=Path(temporary)/'run';directory.mkdir()
            with patch('ops.release.subprocess.run',side_effect=subprocess.TimeoutExpired(['test'],1)):
                result=release.run_check('unavailable',['test'],directory,{})
            artifact=directory.parent/result['artifact']
            self.assertEqual(result['status'],'blocked');self.assertIsNone(result['returncode'])
            self.assertEqual(result['sha256'],hashlib.sha256(artifact.read_bytes()).hexdigest())

class JournalCapacityMonitoring(unittest.TestCase):
    def test_metadata_only_capacity_threshold_and_missing_directory(self):
        from ops.monitor import journal_capacity_alerts
        with TemporaryDirectory() as temporary:
            directory=Path(temporary)
            with patch('ops.monitor.JOURNAL_WARN_AT',3):
                for number in range(2):(directory/f'{number:020d}.record').write_bytes(b'unread private bytes')
                self.assertEqual(journal_capacity_alerts(directory),[])
                (directory/'00000000000000000002.record').write_bytes(b'unread private bytes')
                self.assertEqual(journal_capacity_alerts(directory),['JOURNAL_CAPACITY'])
            self.assertEqual(journal_capacity_alerts(directory/'missing'),['JOURNAL_CAPACITY_UNAVAILABLE'])
    def test_unreadable_directory_never_silently_passes(self):
        from ops.monitor import journal_capacity_alerts
        with patch('ops.monitor.os.scandir',side_effect=PermissionError('private directory')):
            self.assertEqual(journal_capacity_alerts('/private'),['JOURNAL_CAPACITY_UNAVAILABLE'])

class AccountInventoryMetrics(unittest.IsolatedAsyncioTestCase):
    async def test_distinct_registered_active_and_current_activity_definitions(self):
        from contextlib import asynccontextmanager
        from types import SimpleNamespace
        from unittest.mock import AsyncMock
        from app.domain.metrics import Metrics
        from app.services.analytics import Analytics
        connection=SimpleNamespace(execute=AsyncMock())
        @asynccontextmanager
        async def transaction(role):
            self.assertEqual(role,'analytics');yield connection
        realtime=SimpleNamespace(people={},clock=lambda:0)
        analytics=Analytics(SimpleNamespace(transaction=transaction),Metrics(),realtime)
        principal=SimpleNamespace(permission=lambda value:self.assertEqual(value,'analytics.read'))
        with patch('app.services.analytics.one',AsyncMock(return_value={'current_accounts':10,'total_accounts':12,'open_cases':2})),patch('app.services.analytics.many',AsyncMock(return_value=[])):
            result=await analytics.summary(principal)
        self.assertEqual((result['total_accounts'],result['current_accounts'],result['active_now']),(12,10,0))
        self.assertIn('restricted',result['total_accounts_definition'])
        self.assertIn('excludes guests',result['total_accounts_definition'])
        self.assertIn('not a recent-activity',result['current_accounts_definition'])

class RuntimeBootSafety(unittest.TestCase):
    def test_only_healthy_current_release_can_boot(self):
        from ops.runtime_boot import check
        with TemporaryDirectory() as temporary:
            directory=Path(temporary);release_dir=directory/'release';(release_dir/'infra').mkdir(parents=True);(release_dir/'infra/compose.production.yml').write_text('services: {}\n');current=directory/'current';current.symlink_to(release_dir,target_is_directory=True);record=directory/'deployment.json'
            for status in ('running','failed_closed'):
                record.write_text(json.dumps({'status':status,'stage':'migrated','release_directory':str(release_dir)}))
                with self.assertRaises(ValueError):check(current,record)
            record.write_text(json.dumps({'status':'healthy','stage':'healthy','release_directory':str(release_dir)}));self.assertTrue(check(current,record))
            other=directory/'other';other.mkdir();record.write_text(json.dumps({'status':'healthy','stage':'healthy','release_directory':str(other)}))
            with self.assertRaises(ValueError):check(current,record)
    def test_old_missing_operation_metadata_requires_reviewed_deploy(self):
        from ops.runtime_boot import check
        with TemporaryDirectory() as temporary:
            directory=Path(temporary);(directory/'infra').mkdir();(directory/'infra/compose.production.yml').write_text('services: {}\n');record=directory/'deployment.json';record.write_text(json.dumps({'status':'healthy','stage':'healthy'}))
            with self.assertRaises(ValueError):check(directory,record)

class RuntimeBootLocking(unittest.TestCase):
    def test_deployment_lock_blocks_docker_start_and_success_uses_exact_compose(self):
        from ops.runtime_boot import start
        import fcntl
        with TemporaryDirectory() as temporary:
            directory=Path(temporary);release_dir=directory/'release';(release_dir/'infra').mkdir(parents=True);(release_dir/'infra/compose.production.yml').write_text('services: {}\n');record=directory/'deployment.json';record.write_text(json.dumps({'status':'healthy','stage':'healthy','release_directory':str(release_dir)}));lock=directory/'deployment.lock'
            with lock.open('a') as stream,patch('ops.runtime_boot.subprocess.run') as docker:
                fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
                with self.assertRaises(ValueError):start(release_dir,record,lock)
                docker.assert_not_called();fcntl.flock(stream,fcntl.LOCK_UN)
                start(release_dir,record,lock)
                argv=docker.call_args.args[0];self.assertEqual(argv[:3],['/usr/bin/docker','compose','--env-file']);self.assertEqual(argv[-3:],['up','-d','--wait'])
