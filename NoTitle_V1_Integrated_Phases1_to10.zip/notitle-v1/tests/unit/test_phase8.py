"""Billing boundary tests; no live merchant or provider execution is implied."""
from contextlib import asynccontextmanager
from types import SimpleNamespace
from unittest.mock import AsyncMock,Mock
from uuid import uuid4
import unittest
import base64,hashlib,hmac,json,time

from app.domain.errors import DomainError
from app.integrations.cashfree import CashfreeSandbox, verified_capture, verified_refunds, ProviderUnknown
from app.services.billing import Billing
from app.domain.receipts import ReceiptConfiguration


class Cursor:
    def __init__(self,db):self.db=db
    async def fetchone(self):return self.db.row
    async def fetchall(self):return self.db.rows


class SnapshotDatabase:
    def __init__(self,row=None,rows=None):self.row=row;self.rows=rows;self.calls=[]
    @asynccontextmanager
    async def transaction(self,*args):yield self
    async def execute(self,sql,params=()):self.calls.append((sql,params));return Cursor(self)


class MatchingLedger(unittest.IsolatedAsyncioTestCase):
    def fixture(self):
        db=SnapshotDatabase({'ledger_revision':41,'accounted':1000,'observed':1010,'available':100})
        return Billing(db,None,None,SimpleNamespace(policy_version='v1')),db,SimpleNamespace(kind='account',account_id=uuid4())

    async def test_repeated_authorization_preserves_revision_and_expiry(self):
        billing,db,account=self.fixture()
        first=await billing.matching_entitlement(account)
        db.row['observed']+=1
        second=await billing.matching_entitlement(account)
        self.assertEqual(first,{'available_seconds':90,'premium_until':1100,'entitlement_revision':41})
        self.assertEqual(second,{'available_seconds':89,'premium_until':1100,'entitlement_revision':41})
        self.assertEqual(len(db.calls),2)
        self.assertTrue(all(sql.lstrip().startswith('SELECT') for sql,_ in db.calls))

    async def test_expiry_does_not_create_negative_time_or_new_revision(self):
        billing,db,account=self.fixture();db.row['observed']=1200
        self.assertEqual(await billing.entitlement(account),{'available_seconds':0,'premium_until':0,'entitlement_revision':41})

    async def test_hold_or_revocation_changes_available_authority(self):
        billing,db,account=self.fixture();before=await billing.matching_entitlement(account)
        db.row.update(ledger_revision=42,accounted=1010,available=20)
        after=await billing.matching_entitlement(account)
        self.assertNotEqual(before['entitlement_revision'],after['entitlement_revision'])
        self.assertEqual(after['premium_until'],1030);self.assertEqual(after['available_seconds'],20)

    async def test_guest_never_borrows_account_or_financial_entitlement(self):
        billing,db,_=self.fixture()
        for kind in ('guest','financial','bootstrap'):
            self.assertEqual(await billing.matching_entitlement(SimpleNamespace(kind=kind)),{'available_seconds':0,'premium_until':0,'entitlement_revision':0})
        self.assertEqual(db.calls,[])

    async def test_missing_subject_fails_closed(self):
        billing,db,account=self.fixture();db.row=None
        with self.assertRaises(DomainError) as caught:await billing.matching_entitlement(account)
        self.assertEqual(caught.exception.code,'NOT_FOUND')

    async def test_clock_rollback_does_not_consume_extra_time(self):
        billing,db,account=self.fixture();db.row['observed']=900
        result=await billing.matching_entitlement(account)
        self.assertEqual(result['available_seconds'],100)
        self.assertEqual(result['premium_until'],1100)


class HostedOrder(unittest.IsolatedAsyncioTestCase):
    def provider(self):
        provider=object.__new__(CashfreeSandbox);provider.request=AsyncMock(return_value={'order_id':'nt_test'})
        return provider

    async def test_return_is_server_supplied_and_does_not_include_credentials(self):
        provider=self.provider();nonce=uuid4()
        await provider.create_order('nt_test',9900,'test_subject','9999999999',nonce,return_url='https://notitle.example/billing/status/?purchase_ref='+'a'*32)
        args,kwargs=provider.request.call_args
        self.assertEqual(args,('POST','/orders'));self.assertEqual(kwargs['nonce'],nonce)
        self.assertEqual(kwargs['payload']['order_meta']['return_url'],'https://notitle.example/billing/status/?purchase_ref='+'a'*32)
        self.assertEqual(set(kwargs['payload']['customer_details']),{'customer_id','customer_phone'})

    async def test_unsafe_return_url_rejected_before_network(self):
        for url in ('javascript:alert(1)','https://user:secret@notitle.example/','http://notitle.example/','https://notitle.example/#secret'):
            provider=self.provider()
            with self.assertRaises(ValueError):await provider.create_order('nt_test',9900,'test_subject','9999999999',uuid4(),return_url=url)
            provider.request.assert_not_awaited()

    async def test_local_disposable_return_can_use_loopback_http(self):
        provider=self.provider();await provider.create_order('nt_test',9900,'test_subject','9999999999',uuid4(),return_url='http://127.0.0.1:8080/billing/status/')
        provider.request.assert_awaited_once()


class CaptureSafety(unittest.TestCase):
    def test_authorized_but_explicitly_uncaptured_payment_never_grants(self):
        order={'order_id':'nt_test','order_amount':99,'order_currency':'INR','order_status':'PAID'}
        payment={'payment_status':'SUCCESS','payment_amount':99,'payment_currency':'INR','cf_payment_id':'1','is_captured':False}
        self.assertIsNone(verified_capture(order,[payment],'nt_test',9900))

    def test_unexpected_provider_shapes_fail_closed(self):
        for order,payments in ((None,[]),({},{}),({},['not a payment'])):
            self.assertIsNone(verified_capture(order,payments,'nt_test',9900))

    def test_reviewed_receipt_facts_are_detached_from_mutable_configuration(self):
        pack={'state':'reviewed','review_evidence_ref':'disposable-review','merchant':{'legal_name':'Synthetic merchant','postal_address':'Synthetic address','contact_route':'/support/'},
              'plans':{'Short3':{'version':'1','tax_rule':'reviewed','net_paise':9900,'taxes':[]}}}
        config=ReceiptConfiguration(pack);first=config.snapshot('Short3','1','reviewed',9900)
        pack['merchant']['legal_name']='Changed input';first['merchant']['legal_name']='Changed snapshot';first['taxes'].append({'name':'invalid mutation','paise':1})
        second=config.snapshot('Short3','1','reviewed',9900)
        self.assertEqual(second['merchant']['legal_name'],'Synthetic merchant');self.assertEqual(second['taxes'],[])


class SaleGates(unittest.IsolatedAsyncioTestCase):
    async def test_external_adjustment_review_blocks_sales_by_default(self):
        billing=Billing(None,None,object(),None,True);billing.public_origin='https://notitle.example';billing.receipt_configuration=object()
        for action in (lambda:billing.purchase(None,None),lambda:billing.resume_purchase(None,'a'*32)):
            with self.assertRaises(DomainError) as caught:await action()
            self.assertEqual(caught.exception.code,'PAYMENT_EXCEPTION_REVIEW_REQUIRED')

    async def test_closed_sales_fail_before_database_or_provider_dependency(self):
        billing=Billing(None,None,None,None,False)
        with self.assertRaises(DomainError) as caught:await billing.purchase(None,None)
        self.assertEqual(caught.exception.code,'PAYMENTS_UNAVAILABLE');self.assertEqual(caught.exception.status,503)

    async def test_maintenance_closes_new_and_resumed_sales_without_disabling_provider(self):
        provider=object();billing=Billing(None,None,provider,None,True);billing.admission=lambda:False
        for action in (lambda:billing.purchase(None,None),lambda:billing.resume_purchase(None,'a'*32)):
            with self.assertRaises(DomainError) as caught:await action()
            self.assertEqual(caught.exception.code,'PAYMENTS_UNAVAILABLE');self.assertEqual(caught.exception.status,503)
        self.assertIs(billing.provider,provider)

    async def test_receipt_origin_provider_and_annual_gates(self):
        rows=[{'code':code,'version':'1','gross_paise':9900,'duration_seconds':259200,'currency':'INR','enabled':True,'tax_rule':'reviewed','policy_version':'v1'} for code in ('Short3','Annual365')]
        db=SnapshotDatabase(rows=rows);billing=Billing(db,None,object(),SimpleNamespace(policy_version='v1'),True)
        for config,origin in ((None,None),(SimpleNamespace(snapshot=lambda *args:{'net_paise':9900,'taxes':[]}),None),(None,'https://notitle.example')):
            billing.receipt_configuration=config;billing.public_origin=origin
            self.assertFalse(any(row['enabled'] for row in (await billing.plans())['items']))
        billing.receipt_configuration=SimpleNamespace(snapshot=lambda *args:{'net_paise':9900,'taxes':[]});billing.public_origin='https://notitle.example';billing.external_adjustments_ready=lambda:True
        result=await billing.plans();self.assertTrue(result['items'][0]['enabled']);self.assertFalse(result['items'][1]['enabled'])
        self.assertEqual(result['renewal'],'none')
        billing.admission=lambda:False
        self.assertFalse(any(row['enabled'] for row in (await billing.plans())['items']))


class ExternalRefundFacts(unittest.TestCase):
    def row(self,**changes):return {'order_id':'nt_test','cf_payment_id':'123','cf_refund_id':'456','refund_id':'dashboard_refund','refund_currency':'INR','refund_amount':'49.50','refund_status':'SUCCESS'}|changes

    def test_only_exact_independent_refund_facts_are_accepted(self):
        self.assertEqual(verified_refunds([self.row()],'nt_test','123',9900),[{'provider_id':'456','merchant_id':'dashboard_refund','amount_paise':4950,'status':'SUCCESS'}])
        self.assertEqual(verified_refunds([],'nt_test','123',9900),[])

    def test_wrong_association_currency_amount_status_or_duplicate_fails_closed(self):
        for rows in ([self.row(order_id='other')],[self.row(cf_payment_id='999')],[self.row(refund_currency='USD')],[self.row(refund_amount='NaN')],[self.row(refund_amount='100.00')],[self.row(refund_amount='1.001')],[self.row(refund_status='UNKNOWN')],[self.row(),self.row()],{},['bad']):
            with self.assertRaises(ProviderUnknown):verified_refunds(rows,'nt_test','123',9900)

    def test_provider_refund_states_remain_explicit(self):
        for status in ('SUCCESS','PENDING','PENDING_APPROVAL','ONHOLD','CANCELLED','REJECTED'):
            self.assertEqual(verified_refunds([self.row(refund_status=status)],'nt_test','123',9900)[0]['status'],status)


class ExternalReviewDeduplication(unittest.IsolatedAsyncioTestCase):
    async def test_recorded_hold_does_not_advance_accounting_or_hold_twice(self):
        db=SnapshotDatabase({'id':uuid4()});billing=Billing(db,None,None,None)
        billing.account_lots=AsyncMock(side_effect=AssertionError('Repeated accounting'))
        await billing.hold_external(db,{}, {},'external-refund:sandbox:1','external_refund_hold',{})
        billing.account_lots.assert_not_awaited()

    async def test_live_projection_ignores_stale_seconds_and_pauses_revoked_search(self):
        ref='a'*32;person=SimpleNamespace(premium_until=2000)
        actor=SimpleNamespace(people={ref:person},waiters={ref:SimpleNamespace(gender='male')},wall=lambda:1000,pause_preferences=Mock())
        db=SnapshotDatabase({'public_ref':ref,'ledger_revision':2,'accounted':1000,'observed':1000,'available':0})
        billing=Billing(db,None,None,SimpleNamespace(realtime=actor))
        await billing.publish_available({'account_id':uuid4()},999999)
        self.assertEqual(person.premium_until,0);actor.pause_preferences.assert_called_once_with(ref)

    async def test_unrelated_available_pass_is_not_revoked_by_old_projection(self):
        ref='a'*32;person=SimpleNamespace(premium_until=0)
        actor=SimpleNamespace(people={ref:person},waiters={},wall=lambda:1000,pause_preferences=Mock())
        db=SnapshotDatabase({'public_ref':ref,'ledger_revision':2,'accounted':1000,'observed':1000,'available':100})
        billing=Billing(db,None,None,SimpleNamespace(realtime=actor))
        await billing.publish_available({'account_id':uuid4()},0)
        self.assertEqual(person.premium_until,1100);actor.pause_preferences.assert_not_called()


class ExternalWebhookContracts(unittest.IsolatedAsyncioTestCase):
    async def deliver(self,billing,payload):
        body=json.dumps(payload,separators=(',',':')).encode();stamp=str(int(time.time()*1000));secret=b'synthetic-only'
        signature=base64.b64encode(hmac.new(secret,stamp.encode()+body,hashlib.sha256).digest()).decode()
        return await billing.webhook(body,stamp,signature,secret)

    async def test_official_refund_shape_has_refund_order_not_data_order(self):
        db=SnapshotDatabase();billing=Billing(db,None,None,None)
        result=await self.deliver(billing,{'type':'REFUND_STATUS_WEBHOOK','data':{'refund':{'order_id':'nt_test','cf_refund_id':123,'refund_id':'refund_test','refund_amount':99,'refund_currency':'INR','refund_status':'SUCCESS'}}})
        self.assertEqual(result,{'received':True})
        self.assertEqual(db.calls[0][1][1:],[ 'REFUND_STATUS_WEBHOOK','nt_test'] if isinstance(db.calls[0][1],list) else ('REFUND_STATUS_WEBHOOK','nt_test'))

    async def test_official_payment_shape_still_accepts_data_order(self):
        db=SnapshotDatabase();billing=Billing(db,None,None,None)
        self.assertEqual(await self.deliver(billing,{'type':'PAYMENT_SUCCESS_WEBHOOK','data':{'order':{'order_id':'nt_test'}}}),{'received':True})

    async def test_signed_dispute_only_requests_protection_not_a_money_action(self):
        row={'id':uuid4(),'public_ref':'a'*32,'financial_subject_id':uuid4(),'environment':'sandbox'}
        db=SnapshotDatabase(row);billing=Billing(db,None,None,None)
        billing.hold_external=AsyncMock();billing.publish_available=AsyncMock();billing.refund=AsyncMock(side_effect=AssertionError('No refund initiation'))
        result=await self.deliver(billing,{'type':'DISPUTE_CREATED','data':{'order_details':{'order_id':'nt_test'},'dispute':{'dispute_id':'123','dispute_status':'DISPUTE_CREATED'}}})
        self.assertEqual(result,{'received':True});billing.hold_external.assert_awaited_once();billing.refund.assert_not_awaited()
        self.assertEqual(billing.hold_external.call_args.args[-1]['verification'],'signed_notice_pending_independent_review')
        self.assertTrue(any('ledger_revision=ledger_revision+1' in sql for sql,_ in db.calls))

    async def test_unsigned_dispute_cannot_hold_a_subject(self):
        billing=Billing(None,None,None,None);billing.hold_external=AsyncMock()
        with self.assertRaises(DomainError):await billing.webhook(b'{"type":"DISPUTE_CREATED"}',str(int(time.time()*1000)),'forged',b'synthetic-only')
        billing.hold_external.assert_not_awaited()
