"""Phase 4 actual actor/service tests. Fake identity I/O is not PostgreSQL proof."""
import asyncio,copy,json,random,unittest
from contextlib import asynccontextmanager
from datetime import datetime,timezone,timedelta
from unittest.mock import AsyncMock,patch
from types import SimpleNamespace
from uuid import uuid4
from pydantic import ValidationError
from app.coordinator.core import Coordinator,Fenced
from app.domain.conversation import ConversationActor
from app.domain.conversation_contracts import COMMAND,EVENT,SendPayload,decode,strict_json
from app.domain.errors import DomainError
from app.domain.metrics import Metrics
from app.domain.security import Security,token
from app.http.models import Ticket
from app.services.conversation import Conversation,Access
from app.services.primitives import Principal

class Clock:
    def __init__(self):self.now=100.;self.authority=Coordinator(7,self)
    def __call__(self):return self.now
    def wall(self):return self.now+1800000000
    def advance(self,seconds):self.now+=seconds;self.authority.last_proof=self.now

def profile(gender='other',topic='general',professional=None):
    return {'display_name':'Synthetic person','gender':gender,'topic_id':topic,'bio':'','professional':professional or {}}

def actor():
    clock=Clock();return ConversationActor(clock.authority,Metrics(),clock,clock.wall,rng=random.Random(39)),clock

def enter(rt,ref=None,gender='other',premium=False,topic='general',professional=None):
    ref=ref or uuid4().hex;rt.enter(ref,profile(gender,topic,professional),premium,rt.wall()+100 if premium else 0);rt.connect(ref);rt.drain(ref);return ref

def command(rt,ref,kind,payload,nonce=None):
    return COMMAND.validate_python({'protocol_version':2,'command_id':nonce or str(uuid4()),'type':kind,'owner_epoch':rt.authority.epoch,
        'socket_generation':rt.people[ref].generation,'interaction_epoch':rt.people[ref].revision,'payload':payload})

def flush(rt):
    for ref in rt.people:rt.drain(ref)

class Phase4Contracts(unittest.TestCase):
    def test_decode_rejects_unknown_coercion_duplicate_nonfinite_and_oversize(self):
        rt,_=actor();ref=enter(rt);good=command(rt,ref,'heartbeat',{'client_time':1.}).model_dump();decode(json.dumps(good))
        for bad in (good|{'protocol_version':1},good|{'socket_generation':True},good|{'token':'private'},good|{'payload':{'client_time':float('nan')}}):
            with self.assertRaises((ValueError,ValidationError)):decode(json.dumps(bad))
        for raw in ('{"a":1,"a":2}','{"a":NaN}',' '*8193):
            with self.assertRaises((ValueError,DomainError)):strict_json(raw)

    def test_text_limits_are_unicode_and_byte_bounded_plain_text(self):
        handle=uuid4().hex
        SendPayload(interaction_handle=handle,text='a'*2000);SendPayload(interaction_handle=handle,text='<script>plain</script>\n\t')
        for text in ('','a'*2001,'🙂'*1600,'x\x00y','x\x85y','\ud800'):
            with self.assertRaises((ValueError,UnicodeError)):SendPayload(interaction_handle=handle,text=text)

class Phase4Actor(unittest.TestCase):
    def setUp(self):self.rt,self.clock=actor()
    def person(self,**kwargs):return enter(self.rt,**kwargs)
    def pair(self):
        a,b=self.person(),self.person();self.rt.join(a);self.rt.join(b);self.rt.match();flush(self.rt);return a,b,self.rt.current(a)

    def test_oldest_feasible_anchor_skips_incompatible_head(self):
        a=self.person(gender='male',premium=True);self.rt.join(a,'female');self.clock.advance(.2)
        b=self.person(gender='male');self.rt.join(b);self.clock.advance(.2);c=self.person(gender='male');self.rt.join(c)
        reservation=self.rt.reserve_match();self.assertEqual(set(reservation.members),{b,c});self.rt.publish(reservation);self.assertIn(a,self.rt.waiters)

    def test_mutual_strict_gender_and_both_directions_block(self):
        a=self.person(gender='male',premium=True);b=self.person(gender='female',premium=True)
        self.rt.join(a,'female');self.rt.join(b,'female');self.assertIsNone(self.rt.reserve_match())
        self.rt.join(b,'male');self.rt.blocks.add((b,a));self.assertIsNone(self.rt.reserve_match());self.rt.blocks.clear();self.assertIsNotNone(self.rt.reserve_match())

    def test_uniform_random_ties_do_not_sort_persistent_identity(self):
        a,b,c=self.person(),self.person(),self.person()
        for p in (a,b,c):self.rt.join(p)
        choices=set()
        for _ in range(80):r=self.rt.reserve_match();choices.add(r.members[1]);self.rt.release(r.id)
        self.assertEqual(choices,{b,c})

    def test_exact_fractional_professional_score_and_general_talk(self):
        a=self.person(premium=True,topic='career');b=self.person(topic='career',professional={'industry':['tech'],'interests':['one']})
        self.rt.join(a,professional={'industry':['tech','health'],'interests':['one','two']},general_talk=False);self.rt.join(b,general_talk=False)
        self.assertAlmostEqual(self.rt.score(self.rt.waiters[a],self.rt.waiters[b]),.5+(.1+.05)/2)
        self.rt.waiters[b].general_talk=True;self.assertAlmostEqual(self.rt.score(self.rt.waiters[a],self.rt.waiters[b]),.5)
        self.clock.advance(5);self.assertEqual(self.rt.score(self.rt.waiters[a],self.rt.waiters[b]),5)

    def test_premium_expiry_pauses_strict_never_broadens_preserves_age(self):
        a=self.person(premium=True);self.rt.join(a,'male');since=self.rt.waiters[a].since;self.clock.advance(101);self.rt.tick()
        self.assertNotIn(a,self.rt.waiters);self.assertEqual(self.rt.paused_ages[a],since)
        with self.assertRaises(DomainError):self.rt.join(a,'female')
        self.rt.join(a,'everyone');self.assertEqual(self.rt.waiters[a].since,since)

    def test_preference_edit_and_stale_reservation_preserve_wait_age(self):
        a,b=self.person(),self.person();self.rt.join(a);since=self.rt.waiters[a].since;self.rt.join(b);reservation=self.rt.reserve_match()
        self.clock.advance(.2);self.rt.pause_preferences(a);self.rt.join(a)
        self.assertEqual(self.rt.waiters[a].since,since)
        with self.assertRaises(DomainError):self.rt.publish(reservation)
        self.assertFalse(self.rt.interactions)

    def test_active_profile_or_optional_consent_edit_keeps_current_conversation(self):
        a,b,current=self.pair();self.rt.pause_preferences(a);events=self.rt.drain(a)
        self.assertIs(self.rt.current(a),current);self.assertEqual(events[-1]['type'],'state.snapshot');self.assertEqual(events[-1]['data']['state'],'matched')

    def test_disconnect_and_entitlement_expiry_invalidate_reservations(self):
        a,b=self.person(premium=True),self.person();self.rt.join(a);self.rt.join(b);r=self.rt.reserve_match();self.rt.disconnect(a)
        with self.assertRaises(DomainError):self.rt.publish(r)
        self.rt.connect(a);self.rt.join(a);r=self.rt.reserve_match();self.clock.advance(101)
        with self.assertRaises(DomainError):self.rt.publish(r)

    def test_repeat_exclusion_penalty_and_expiry(self):
        a,b,_=self.pair();self.rt.end(a);self.rt.join(a);self.rt.join(b)
        self.clock.advance(3.999);self.assertIsNone(self.rt.reserve_match());self.clock.advance(.001)
        r=self.rt.reserve_match();self.assertIsNotNone(r);self.rt.release(r.id)
        self.assertAlmostEqual(self.rt.score(self.rt.waiters[a],self.rt.waiters[b]),4-60)
        self.clock.advance(296);self.rt.tick();self.assertFalse(self.rt.recent);self.assertEqual(self.rt.score(self.rt.waiters[a],self.rt.waiters[b]),300)

    def test_scoped_peer_projection_and_frozen_profile(self):
        a,b,interaction=self.pair();view=self.rt.describe(a);handle=view['peer']['peer_handle'];self.assertNotEqual(handle,b)
        self.assertEqual(set(view['peer']),{'peer_handle','display_name','gender','topic_id','bio'})
        self.rt.enter(b,profile()|{'display_name':'Changed name'});self.assertEqual(self.rt.describe(a)['peer']['display_name'],'Synthetic person')
        self.rt.end(a);self.assertEqual(self.rt.resolve_peer(a,handle),b);self.assertEqual(self.rt.people[b].pending_profile['display_name'],'Changed name')
        self.clock.advance(4);self.rt.join(a);self.rt.join(b);self.rt.match();self.assertNotEqual(handle,self.rt.describe(a)['peer']['peer_handle'])
        self.assertEqual(self.rt.describe(a)['peer']['display_name'],'Changed name')

    def test_bounded_ring_sequence_delivery_and_no_sender_identity(self):
        a,b,interaction=self.pair();nonce=str(uuid4())
        first=self.rt.text(a,'Synthetic temporary text',nonce);view=self.rt.describe(b)['messages'][0]
        self.assertEqual(view['sender'],'peer');self.assertIsNone(view['command_id']);self.assertNotIn(a,json.dumps(view));self.assertFalse(view['delivered'])
        with self.assertRaises(DomainError):self.rt.delivered(a,first['message_id'],first['sequence'])
        with self.assertRaises(DomainError):self.rt.delivered(b,first['message_id'],999)
        self.rt.delivered(b,first['message_id'],first['sequence']);self.rt.delivered(b,first['message_id'],first['sequence']);self.assertTrue(self.rt.describe(a)['messages'][0]['delivered'])
        for _ in range(45):self.rt.text(a,'文'*2000);flush(self.rt)
        self.assertLessEqual(len(interaction.messages),30);self.assertLessEqual(interaction.bytes,65536);self.assertEqual(interaction.next_sequence,46)
        sequences=[m['sequence'] for m in interaction.messages];self.assertEqual(sequences,sorted(set(sequences)))

    def test_end_erases_ring_and_queued_plaintext_both_sides(self):
        a,b,interaction=self.pair();self.rt.text(a,'Never persist this');self.rt.end(a)
        self.assertFalse(interaction.messages);self.assertEqual(interaction.bytes,0);self.assertFalse(self.rt.interactions)
        for p in (a,b):self.assertNotIn('Never persist this',json.dumps(self.rt.drain(p)))

    def test_disconnect_no_send_grace_reconnect_and_eventual_erasure(self):
        a,b,interaction=self.pair();self.rt.text(a,'RAM only');flush(self.rt);self.rt.disconnect(a)
        with self.assertRaises(DomainError):self.rt.text(b,'not while interrupted')
        self.clock.advance(24);self.rt.connect(a);self.assertEqual(self.rt.describe(a)['messages'][0]['text'],'RAM only');self.assertNotIn(a,self.rt.waiters)
        self.rt.disconnect(a);self.clock.advance(25);self.rt.tick();self.assertFalse(interaction.messages);self.assertFalse(self.rt.interactions)

    def test_slow_reader_capacity_and_owner_fence(self):
        a,b,interaction=self.pair()
        for _ in range(65):self.rt.emit(a,'heartbeat.ack',{'client_time':1.})
        self.assertFalse(self.rt.people[a].connected);self.assertLessEqual(len(self.rt.people[a].events),64)
        self.rt.fence();self.assertFalse(interaction.messages);self.assertFalse(self.rt.people);self.assertFalse(self.rt.ended_handles)

    def test_two_hundred_admitted_and_one_hundred_waiter_caps(self):
        refs=[self.person() for _ in range(200)]
        with self.assertRaises(DomainError):self.person()
        for ref in refs[:100]:self.rt.join(ref)
        with self.assertRaises(DomainError):self.rt.join(refs[100])
        self.rt.reserve_match(max_checks=37);self.assertLessEqual(self.rt.scan_checks,37)

    def test_randomized_safety_one_interaction_per_identity(self):
        refs=[self.person() for _ in range(30)];rng=random.Random(29)
        for _ in range(350):
            p=rng.choice(refs);person=self.rt.people[p]
            if person.interaction:self.rt.end(p)
            elif person.connected:
                if rng.randrange(4)==0:self.rt.cancel(p)
                else:self.rt.join(p)
            self.rt.match();flush(self.rt);self.clock.advance(.1)
            memberships=[ref for item in self.rt.interactions.values() for ref in (item.left,item.right)]
            self.assertEqual(len(memberships),len(set(memberships)));self.assertFalse(set(self.rt.waiters)&set(memberships))

class FakeIdentity:
    def __init__(self,rt):
        self.rt=rt;self.security=Security(b'h'*32,b'e'*32);self.guests={};self.principals={};self.tickets={};self.participation_fences=set();self.fenced_subjects=set();self.renewals=0;self.barrier=None
    def add(self):
        raw=token();ref=uuid4().hex;row=profile()|{'core_consent':True,'status':'active','profile_revision':1,'preference_revision':1}
        principal=Principal('guest',ref,raw,account=row);self.principals[raw]=principal
        self.guests[self.security.digest('guest',raw)]={'until':self.rt.clock()+1800,'absolute':self.rt.clock()+7200};return principal
    async def resolve(self,cookies):
        if self.barrier:await self.barrier.wait()
        result=self.principals.get(cookies.get('guest') or cookies.get('account'));return copy.deepcopy(result)
    async def guest_access(self,principal):return principal.account
    async def foreground(self,p):
        self.renewals+=1
        if p.kind=='guest':self.guests[self.security.digest('guest',p.token)]['until']=self.rt.clock()+1800
    def prune(self):self.tickets={k:v for k,v in self.tickets.items() if v['until']>self.rt.clock()}

class Phase4Service(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):self.rt,self.clock=actor();self.identity=FakeIdentity(self.rt);self.service=Conversation(self.rt,self.identity)
    async def asyncTearDown(self):await self.service.close()
    async def binding(self,principal=None):
        p=principal or self.identity.add();ticket=await self.service.prepare(p,Ticket());binding=await self.service.connect(ticket['ticket'],{'guest':p.token});self.rt.drain(p.ref);return binding
    async def run_command(self,binding,kind,payload,nonce=None):
        c=command(self.rt,binding.principal.ref,kind,payload,nonce);return c,await self.service.execute(binding,c,self.service.begin(binding,c))
    async def pair(self):
        a,b=await self.binding(),await self.binding()
        for p in (a,b):await self.run_command(p,'queue.join',{'profile_revision':1,'preference_revision':1})
        await self.service.validate_pair(self.rt.reserve_match());flush(self.rt);return a,b,self.rt.current(a.principal.ref)

    async def test_ticket_single_use_cookie_bound_and_sixty_second_expiry(self):
        p=self.identity.add();t=await self.service.prepare(p,Ticket())
        with self.assertRaises(DomainError):await self.service.connect(t['ticket'],{'guest':'wrong'})
        with self.assertRaises(DomainError):await self.service.connect(t['ticket'],{'guest':p.token})
        t=await self.service.prepare(p,Ticket());self.clock.advance(60)
        with self.assertRaises(DomainError):await self.service.connect(t['ticket'],{'guest':p.token})

    async def test_explicit_takeover_and_old_generation_rejected(self):
        b=await self.binding();p=b.principal
        with self.assertRaises(DomainError):await self.service.prepare(p,Ticket())
        with self.assertRaises(DomainError):await self.service.prepare(p,Ticket(takeover=True,known_socket_generation=999))
        t=await self.service.prepare(p,Ticket(takeover=True,known_socket_generation=b.generation));new=await self.service.connect(t['ticket'],{'guest':p.token})
        self.assertGreater(new.generation,b.generation)
        c=command(self.rt,p.ref,'heartbeat',{'client_time':1.})
        with self.assertRaises(DomainError):self.service.begin(b,c)

    async def test_cancel_overtakes_waiting_authorization_and_cannot_resurrect_search(self):
        b=await self.binding();self.identity.barrier=asyncio.Event();c=command(self.rt,b.principal.ref,'queue.join',{'profile_revision':1,'preference_revision':1});key=self.service.begin(b,c)
        task=asyncio.create_task(self.service.execute(b,c,key));await asyncio.sleep(0)
        cancel=command(self.rt,b.principal.ref,'queue.cancel',{'search_command_id':c.command_id});self.service.control(b,cancel);self.identity.barrier.set()
        await asyncio.gather(task,return_exceptions=True);self.assertFalse(self.rt.waiters);self.assertFalse(self.service.pending)

    async def test_cancel_after_matching_ends_only_its_own_search(self):
        a,b,old=await self.pair();ref=a.principal.ref;target=old.searches[ref]
        c=command(self.rt,ref,'queue.cancel',{'search_command_id':target});self.service.control(a,c);self.assertFalse(self.rt.interactions)
        self.clock.advance(4)
        for p in (a,b):await self.run_command(p,'queue.join',{'profile_revision':1,'preference_revision':1})
        await self.service.validate_pair(self.rt.reserve_match());new=self.rt.current(ref)
        stale=command(self.rt,ref,'queue.cancel',{'search_command_id':target});self.service.control(a,stale);self.assertIs(self.rt.current(ref),new)

    async def test_end_preempts_inflight_text_and_late_http_cannot_end_new_interaction(self):
        a,b,old=await self.pair();ref=a.principal.ref;self.identity.barrier=asyncio.Event()
        text=command(self.rt,ref,'text.send',{'interaction_handle':old.id,'text':'Must never arrive'});task=asyncio.create_task(self.service.execute(a,text,self.service.begin(a,text)));await asyncio.sleep(0)
        end=command(self.rt,ref,'interaction.end',{'interaction_handle':old.id});ack=self.service.control(a,end,http=True);self.identity.barrier.set();await asyncio.gather(task,return_exceptions=True)
        self.assertFalse(old.messages);self.clock.advance(4)
        for p in (a,b):await self.run_command(p,'queue.join',{'profile_revision':1,'preference_revision':1})
        await self.service.validate_pair(self.rt.reserve_match());new=self.rt.current(ref)
        self.assertEqual(self.service.control(a,end,http=True),ack);self.assertIs(self.rt.current(ref),new)
        end2=command(self.rt,ref,'interaction.end',{'interaction_handle':old.id});self.assertEqual(self.service.control(a,end2,http=True)['status'],'already_ended');self.assertIs(self.rt.current(ref),new)

    async def test_next_ends_before_authorization_can_fail(self):
        a,b,old=await self.pair();ref=a.principal.ref
        next_command=command(self.rt,ref,'interaction.next',{'interaction_handle':old.id,'profile_revision':1,'preference_revision':1})
        key=self.service.begin(a,next_command);self.assertFalse(old.messages);self.assertFalse(self.rt.interactions)
        self.identity.principals.pop(a.principal.token)
        with self.assertRaises((DomainError,asyncio.CancelledError)):await self.service.execute(a,next_command,key)
        self.assertFalse(self.rt.waiters);self.assertFalse(self.rt.interactions)

    async def test_idempotent_text_nonce_conflict_ack_contains_no_text(self):
        a,b,interaction=await self.pair();ref=a.principal.ref
        c,ack=await self.run_command(a,'text.send',{'interaction_handle':interaction.id,'text':'Private synthetic text'})
        self.assertIsNone(self.service.begin(a,c));self.assertEqual(len(interaction.messages),1);self.assertNotIn('Private synthetic text',json.dumps(self.rt.people[ref].commands))
        changed=command(self.rt,ref,'text.send',{'interaction_handle':interaction.id,'text':'Different text'},c.command_id)
        with self.assertRaises(DomainError):self.service.begin(a,changed)
        self.assertLessEqual(len(json.dumps(ack)),512)

    async def test_stale_owner_epoch_and_interaction_revision_cannot_send(self):
        a,b,interaction=await self.pair();ref=a.principal.ref;c=command(self.rt,ref,'text.send',{'interaction_handle':interaction.id,'text':'Synthetic stale text'})
        for changes in ({'owner_epoch':6},{'interaction_epoch':c.interaction_epoch-1},{'socket_generation':c.socket_generation+1}):
            with self.assertRaises(DomainError):self.service.begin(a,COMMAND.validate_python(c.model_dump()|changes))
        self.assertFalse(interaction.messages)

    async def test_ended_peer_handle_remains_usable_for_block_without_identity_exposure(self):
        a,b,interaction=await self.pair();handle=self.rt.describe(a.principal.ref)['peer']['peer_handle'];self.rt.end(b.principal.ref)
        other=self.rt.resolve_peer(a.principal.ref,handle);self.rt.block(a.principal.ref,other);self.assertTrue(self.rt.blocked(a.principal.ref,b.principal.ref))

    async def test_pair_effect_revalidates_after_async_work(self):
        a,b=await self.binding(),await self.binding()
        for p in (a,b):await self.run_command(p,'queue.join',{'profile_revision':1,'preference_revision':1})
        reservation=self.rt.reserve_match();self.identity.barrier=asyncio.Event();task=asyncio.create_task(self.service.validate_pair(reservation));await asyncio.sleep(0)
        self.rt.pause_preferences(a.principal.ref);self.identity.barrier.set();await task
        self.assertFalse(self.rt.interactions);self.assertFalse(self.rt.reservations)

    async def test_idle_renewal_excludes_heartbeat_resume_and_delivery(self):
        b=await self.binding();ref=b.principal.ref
        await self.run_command(b,'heartbeat',{'client_time':1.});await self.run_command(b,'session.resume',{'last_server_sequence':0});self.assertEqual(self.identity.renewals,0)
        await self.run_command(b,'queue.join',{'profile_revision':1,'preference_revision':1});self.assertEqual(self.identity.renewals,1)
        self.clock.advance(1);await self.run_command(b,'session.resume',{'last_server_sequence':0});self.assertEqual(self.identity.renewals,1)

    async def test_unavailable_service_clears_conversations_and_explicit_reconnect_recovers(self):
        a,b,interaction=await self.pair();self.rt.text(a.principal.ref,'Temporary');self.service.degrade()
        self.assertFalse(interaction.messages);self.assertFalse(self.service.available)
        ticket=await self.service.prepare(a.principal,Ticket());self.assertTrue(self.service.available);await self.service.connect(ticket['ticket'],{'guest':a.principal.token});self.assertFalse(self.rt.waiters)

    async def test_bounded_cache_and_retired_binding_cleanup(self):
        b=await self.binding();ref=b.principal.ref
        for _ in range(160):
            c=command(self.rt,ref,'heartbeat',{'client_time':1.});self.service.acknowledge(b,c);self.rt.drain(ref)
        self.assertEqual(len(self.rt.people[ref].commands),128)
        self.clock.advance(120);self.rt.tick();self.assertFalse(self.rt.people[ref].commands)
        self.rt.disconnect(ref);self.clock.advance(1801);self.service.step();self.assertNotIn(ref,self.service.bindings)

    async def test_guest_never_receives_paid_ledger_entitlement(self):
        async def fake_ledger(_):raise AssertionError('Guest ledger must not be called')
        self.service.ledger=fake_ledger;b=await self.binding();self.assertEqual(b.access.premium_until,0)

    async def test_service_shutdown_erases_transcripts_and_tickets(self):
        a,b,interaction=await self.pair();self.rt.text(a.principal.ref,'Temporary synthetic');await self.service.close()
        self.assertFalse(interaction.messages);self.assertFalse(self.service.bindings);self.assertFalse(self.identity.tickets)

    async def test_registered_paid_filter_uses_test_only_stable_ledger_and_expiry(self):
        @asynccontextmanager
        async def transaction():yield object()
        self.identity.db=SimpleNamespace(transaction=transaction)
        p=self.identity.add();p.kind='account';p.account['auth_generation']=1
        expires=datetime.fromtimestamp(self.rt.wall(),timezone.utc)+timedelta(hours=1)
        p.account.update(session_expires_at=expires,session_absolute_expires=expires)
        async def locked(_,principal):return principal.account
        self.identity.lock_account=locked;self.service.accounts=SimpleNamespace(current_policy=AsyncMock(return_value=True))
        class SyntheticLedger:
            async def __call__(self,principal):return {'premium_until':until,'entitlement_revision':9}
        until=self.rt.wall()+10;self.service.ledger=SyntheticLedger()
        with patch('app.services.conversation.one',AsyncMock(return_value=None)):
            ticket=await self.service.prepare(p,Ticket());b=await self.service.connect(ticket['ticket'],{'account':p.token})
            await self.run_command(b,'queue.join',{'profile_revision':1,'preference_revision':1,'gender':'female','general_talk':False})
            self.assertEqual(self.rt.waiters[p.ref].gender,'female');self.clock.advance(10);self.rt.tick();self.assertNotIn(p.ref,self.rt.waiters)

    async def test_reserved_control_dispatch_precedes_ordinary_work(self):
        order=[]
        tasks=[asyncio.create_task(self.service.transition(lambda n=n:order.append(n))) for n in range(80)]
        tasks.append(asyncio.create_task(self.service.transition(lambda:order.append('end'),control=True)))
        await asyncio.gather(*tasks);self.assertEqual(order[0],'end');self.assertEqual(len(order),81)

    async def test_ordinary_mailbox_saturation_preserves_control_reserve(self):
        for _ in range(2048):self.service.mailbox.submit(lambda:None)
        with self.assertRaises(DomainError):await self.service.transition(lambda:None)
        self.assertTrue(self.rt.authority.alive)
        result=await self.service.transition(lambda:'stopped',control=True);self.assertEqual(result,'stopped')

    async def test_control_saturation_fences_owner_and_clears_temporary_state(self):
        a,b,interaction=await self.pair();self.rt.text(a.principal.ref,'Temporary synthetic')
        for _ in range(256):self.service.mailbox.submit(lambda:None,control=True)
        with self.assertRaises(DomainError):await self.service.transition(lambda:None,control=True)
        self.assertFalse(self.rt.authority.alive);self.assertFalse(interaction.messages);self.assertFalse(self.rt.people)

if __name__=='__main__':unittest.main()
