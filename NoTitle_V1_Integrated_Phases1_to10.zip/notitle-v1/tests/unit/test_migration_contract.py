import hashlib,unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from app.domain.migration_contract import inventory,verify_applied,packaged_inventory

class MigrationContract(unittest.TestCase):
    def test_missing_or_changed_additive_migration_blocks_startup_even_with_same_schema_version(self):
        required={'0008_identity_privacy.sql':'old','0012_runtime_migration_contract.sql':'new'}
        for rows in ([('0008_identity_privacy.sql','old')],[('0008_identity_privacy.sql','old'),('0012_runtime_migration_contract.sql','changed')]):
            with self.assertRaisesRegex(RuntimeError,'REQUIRED_MIGRATIONS_NOT_APPLIED'):verify_applied(required,rows)
    def test_compatible_old_artifact_can_read_database_with_additional_applied_migrations(self):
        self.assertTrue(verify_applied({'0001_foundation.sql':'old'},[('0001_foundation.sql','old'),('0012_runtime_migration_contract.sql','new')]))
    def test_packaged_inventory_is_based_on_actual_sql_bytes(self):
        actual=packaged_inventory();self.assertIn('0001_foundation.sql',actual);self.assertIn('0012_runtime_migration_contract.sql',actual)
        root=Path(__file__).resolve().parents[2]
        self.assertEqual(actual['0012_runtime_migration_contract.sql'],hashlib.sha256((root/'db/migrations/0012_runtime_migration_contract.sql').read_bytes()).hexdigest())
    def test_symlinked_or_duplicate_number_inventory_is_not_a_release_input(self):
        with TemporaryDirectory() as temporary:
            root=Path(temporary);(root/'0001_first.sql').write_text('SELECT 1;');(root/'0001_duplicate.sql').write_text('SELECT 2;')
            with self.assertRaises(RuntimeError):inventory(root)
            (root/'0001_duplicate.sql').unlink();(root/'0002_second.sql').symlink_to(root/'0001_first.sql')
            with self.assertRaises(RuntimeError):inventory(root)
    def test_missing_intermediate_migration_is_not_a_complete_inventory(self):
        with TemporaryDirectory() as temporary:
            root=Path(temporary);(root/'0001_first.sql').write_text('SELECT 1;');(root/'0003_third.sql').write_text('SELECT 3;')
            with self.assertRaises(RuntimeError):inventory(root)
