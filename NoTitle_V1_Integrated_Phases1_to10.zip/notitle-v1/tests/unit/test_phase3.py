"""Real cryptography/actor tests and scripted-I/O service fault tests.

Scripted I/O exercises service control flow; PostgreSQL locking/ACL qualification
is separately covered by the integration suite and is never inferred here.
"""
import asyncio
from contextlib import asynccontextmanager
from datetime import datetime,timezone,timedelta
import hashlib,json,os,struct
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock,patch
from uuid import uuid4
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from pydantic import ValidationError
from app.coordinator.core import Coordinator
from app.domain.errors import DomainError
from app.domain.metrics import Metrics
from app.domain.policy import PolicySnapshot
from app.domain.projections import owner,OwnerResponse
from app.domain.realtime import Realtime
from app.domain.security import Security,token,validate_password
from app.http import models as m
from app.http.identity_scope import allowed
from app.services.account_controls import AccountControls
from app.services.identity import Identity
from app.services.primitives import Passwords,Principal,Reservations

ROOT=Path(__file__).resolve().parents[2]
PUBLICATION=ROOT/'policies/publication.json'

def policy():return PolicySnapshot.load(PUBLICATION,'v1-draft',hashlib.sha256(PUBLICATION.read_bytes()).hexdigest())
def choices(professional=False):
    snapshot=policy()
    return {'adult':True,'terms':True,'core':True,'professional':professional,'policy_version':snapshot.version,'policy_digest':snapshot.publication_digest}
def profile():return {'display_name':'Test person','gender':'other','topic_id':'general','bio':''}

class ScriptedDatabase:
    def __init__(self):self.connection=SimpleNamespace(execute=AsyncMock())
    @asynccontextmanager
    async def transaction(self,role='public'):yield self.connection

def identity():
    security=Security(b'h'*32,b'e'*32);rt=Realtime(Coordinator(1),Metrics());db=ScriptedDatabase();snapshot=policy()
    with patch('app.services.identity.Passwords') as constructor:
        constructor.return_value=SimpleNamespace(hash=AsyncMock(return_value='new-phc'),verify=AsyncMock(return_value=True),needs_rehash=lambda _:False)
        service=Identity(db,security,rt,snapshot.version,snapshot.publication_digest,snapshot)
    return service

class Phase3Security(unittest.TestCase):
    def test_versioned_verifier_and_cookie_derivation(self):
        security=Security(b'h'*32,b'e'*32,key_version=2);secret=token()
        self.assertTrue(security.verify('receipt',secret,security.verifier('receipt',secret)))
        self.assertFalse(security.verify('account',secret,security.verifier('receipt',secret)))
        self.assertFalse(security.verify('receipt',secret,'h1:'+security.digest('receipt',secret)))
        a=security.derived_token('registration',secret,'nonce','subject')
        self.assertEqual(len(a),43);self.assertEqual(a,security.derived_token('registration',secret,'nonce','subject'))
        self.assertNotEqual(a,security.derived_token('password_change',secret,'nonce','subject'))

    def test_envelope_rotation_retains_old_records_and_authenticates_header(self):
        old=Security(b'h'*32,b'e'*32)
        new=Security(b'h'*32,b'n'*32,wrapping_version=2,previous_wrapping_keys={1:b'e'*32})
        record=old.encrypt('case:1','private content')
        self.assertEqual(new.decrypt('case:1',record),'private content')
        newer=new.encrypt('case:1','new private content');self.assertEqual(newer[:5],b'\x02'+struct.pack('>I',2))
        with self.assertRaises(DomainError):old.decrypt('case:1',newer)
        with self.assertRaises(Exception):new.decrypt('case:2',newer)
        with self.assertRaises(Exception):new.decrypt('case:1',newer[:4]+bytes([1])+newer[5:])

    def test_legacy_envelope_is_readable_without_rewriting_it(self):
        key,wrap,nonce=b'd'*32,b'w'*12,b'n'*12;aad=b'nt:v1:legacy'
        legacy=b'\x01'+wrap+AESGCM(b'e'*32).encrypt(wrap,key,aad)+nonce+AESGCM(key).encrypt(nonce,b'old data',aad)
        self.assertEqual(Security(b'h'*32,b'e'*32).decrypt('legacy',legacy),'old data')

    def test_policy_snapshot_binds_exact_bytes_and_defensive_public_copy(self):
        snapshot=policy();public=snapshot.public();public['purposes']['core']['label']='changed'
        self.assertNotEqual(snapshot.purposes['core']['label'],'changed')
        with TemporaryDirectory() as directory:
            path=Path(directory)/'publication.json';path.write_bytes(PUBLICATION.read_bytes()+b' ')
            with self.assertRaises(DomainError):PolicySnapshot.load(path,snapshot.version,snapshot.publication_digest)
        with self.assertRaises(DomainError):PolicySnapshot.load(PUBLICATION,snapshot.version,snapshot.publication_digest,production=True)

    def test_old_policy_can_withdraw_but_cannot_grant(self):
        snapshot=policy();dto=SimpleNamespace(choice=False,policy_version='retired',policy_digest='0'*64)
        snapshot.validate(dto,withdrawal=True);dto.choice=True
        with self.assertRaises(DomainError):snapshot.validate(dto,withdrawal=True)

    def test_preparation_is_one_intent_and_never_persists_the_secret(self):
        now=[0];reservations=Reservations(Security(b'h'*32,b'e'*32),lambda:now[0]);shown=reservations.prepare('principal','recovery','prepare-nonce')
        proof=m.Proof(reservation_id=shown['reservation_id'],secret=shown['secret'],saved=True)
        first=reservations.claim('principal','recovery',proof,'commit-nonce','payload')
        self.assertIs(first,reservations.claim('principal','recovery',proof,'commit-nonce','payload'))
        self.assertNotIn('secret',json.dumps(first))
        for principal,kind,nonce,digest in [('other','recovery','commit-nonce','payload'),('principal','case','commit-nonce','payload'),('principal','recovery','commit-nonce','changed')]:
            with self.assertRaises(DomainError):reservations.claim(principal,kind,proof,nonce,digest)
        now[0]=600
        with self.assertRaises(DomainError):reservations.claim('principal','recovery',proof,'commit-nonce','payload')

    def test_strict_inputs_reject_controls_impersonation_extra_fields_and_bad_nonce(self):
        for name in ('Admin','Ａｄｍｉｎ','hello\u202eworld','a\x00b'):
            with self.assertRaises(ValidationError):m.Profile(**(profile()|{'display_name':name}))
        with self.assertRaises(ValidationError):m.Profile(**profile(),employer='private employer')
        with self.assertRaises(ValidationError):m.ExportRequest(client_nonce='-'*36)
        with self.assertRaises(ValidationError):m.Consents(**{k:v for k,v in choices().items() if k!='policy_digest'})
        with self.assertRaises(ValidationError):m.Mfa(username='staff_user',password='A private passphrase',code='000000',end_guest=True)
        self.assertEqual(validate_password('  Secret passphrase  '),'  Secret passphrase  ')
        with self.assertRaises(DomainError):validate_password('x'*129)

    def test_owner_projection_ignores_db_secrets_and_response_forbids_extras(self):
        row=profile()|{'password_hash':'secret','recovery_verifier':'secret','id':uuid4(),'username':'owner_name'}
        value=owner(Principal('account',uuid4().hex,'token',account=row))
        self.assertNotIn('secret',json.dumps(value));self.assertEqual(value['username'],'owner_name')
        with self.assertRaises(ValidationError):OwnerResponse(**value,policy_current=True,entitlement={'available_seconds':0,'premium_until':0,'entitlement_revision':0},password_hash='secret')

    def test_identity_surface_excludes_later_runtime_and_admin_content(self):
        for path in ('/api/v1/auth/register','/api/v1/me/consents','/api/v1/privacy/exports','/api/v1/support/cases'):self.assertTrue(allowed(path))
        for path in ('/api/v1/ws','/api/v1/ws/ticket','/api/v1/billing/purchases','/api/v1/friends','/internal/v1/cases'):self.assertFalse(allowed(path))
        self.assertFalse(allowed('/internal/v1/analytics',True));self.assertTrue(allowed('/internal/v1/privacy/holds',True))

    def test_private_files_reject_public_modes_and_symlinks(self):
        from app.domain.private_files import read_private
        with TemporaryDirectory() as directory:
            path=Path(directory)/'secret';path.write_text('local fixture');path.chmod(0o600)
            self.assertEqual(read_private(path),'local fixture')
            path.chmod(0o644)
            with self.assertRaises(ValueError):read_private(path)
            path.chmod(0o600);link=Path(directory)/'link';link.symlink_to(path)
            with self.assertRaises(ValueError):read_private(link)

    def test_identity_configuration_is_local_and_never_enables_paid_or_media_features(self):
        from ops.identity import local_application
        fixture={'public_origin':'http://127.0.0.1:8080','private_origin':'http://127.0.0.1:8081','audio':True,'payments':True,'qualification':{'legal':False}}
        configured=local_application(fixture,{'version':'v1-draft'})
        self.assertFalse(configured['audio']);self.assertFalse(configured['payments']);self.assertTrue(configured['admission'])
        self.assertEqual(configured['qualification'],fixture['qualification'])
        with self.assertRaises(ValueError):local_application(fixture|{'public_origin':'https://production.test'},{'version':'v1-draft'})

class Phase3Passwords(unittest.IsolatedAsyncioTestCase):
    async def test_real_argon2_policy_and_unknown_account_path(self):
        passwords=Passwords();value='  A private passphrase  '
        encoded=await passwords.hash(value)
        self.assertIn('$argon2id$v=19$m=65536,t=3,p=1$',encoded);self.assertFalse(passwords.needs_rehash(encoded))
        self.assertTrue(await passwords.verify(value,encoded));self.assertFalse(await passwords.verify(value.strip(),encoded))
        self.assertFalse(await passwords.verify(value,None));self.assertTrue(passwords.needs_rehash(encoded.replace('m=65536','m=32768')))
        self.assertFalse(await passwords.verify(value,encoded.replace('m=65536','m=999999999')))
        self.assertFalse(await passwords.verify(value,'$argon2id$v=19$m=65536,t=3,p=1$broken'))

class Phase3ActorPrivacy(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.identity=identity();self.controls=AccountControls(self.identity,{})
        boot=self.identity.new_bootstrap();self.guest=self.identity.guest(boot,m.Guest(**profile(),consents=choices(True)))
    def change(self,purpose,value,revision=1,nonce=None):
        purpose_info=self.identity.policy.purposes[purpose]
        return m.ConsentChange(purpose=purpose,choice=value,expected_revision=revision,client_nonce=nonce or str(uuid4()),policy_version='retired' if not value else self.identity.policy_version,policy_digest='0'*64 if not value else self.identity.policy_digest,text_digest=purpose_info['text_digest' if value else 'withdrawal_digest'])
    async def test_guest_proof_has_four_exact_choices_and_no_credentials(self):
        result=await self.controls.proof(self.guest)
        self.assertEqual({r['purpose'] for r in result['items']},{'adult','terms','core','professional'})
        self.assertTrue(all(r['proof_format']==2 and r['decision_text'] and len(r['text_digest'])==64 for r in result['items']))
        self.assertNotIn(self.guest.token,json.dumps(result));self.assertTrue(result['temporary'])
    async def test_optional_withdrawal_clears_private_choices_queue_and_replays_once(self):
        guest=self.identity.guests[self.identity.security.digest('guest',self.guest.token)]
        guest['profile']['professional']={'industry':['technology']};guest['profile']['preferences']={'industry':['technology']}
        self.identity.realtime.connect(self.guest.ref);self.identity.realtime.join(self.guest.ref)
        revision=self.identity.realtime.people[self.guest.ref].revision
        self.identity.tickets['old-intent']={'ref':self.guest.ref,'until':9999999999}
        dto=self.change('professional',False);first=await self.controls.consent(self.guest,dto)
        self.assertEqual(first,await self.controls.consent(self.guest,dto));self.assertEqual(len(guest['proof']),5)
        self.assertEqual(guest['profile']['professional'],{});self.assertEqual(guest['profile']['preferences'],{})
        self.assertNotIn(self.guest.ref,self.identity.realtime.waiters);self.assertTrue(guest['profile']['core_consent'])
        self.assertNotIn('old-intent',self.identity.tickets);self.assertGreater(self.identity.realtime.people[self.guest.ref].revision,revision)
        with self.assertRaises(DomainError):await self.controls.consent(self.guest,dto.model_copy(update={'choice':True}))
    async def test_core_withdrawal_ends_participation_without_revoking_help_identity(self):
        await self.controls.consent(self.guest,self.change('core',False))
        self.assertIn(self.guest.ref,self.identity.participation_fences)
        self.assertNotIn(self.guest.ref,self.identity.fenced_subjects)
        self.assertEqual((await self.identity.resolve({'guest':self.guest.token})).kind,'guest')
        self.assertFalse(self.identity.realtime.people[self.guest.ref].connected)
        await self.identity.logout(self.guest)
        self.assertIsNone(await self.identity.resolve({'guest':self.guest.token}));self.assertNotIn(self.guest.ref,self.identity.realtime.people)
        self.assertNotIn(self.guest.ref,self.identity.participation_fences)
    async def test_expired_guest_is_retired_not_rehydrated(self):
        self.identity.guests[self.identity.security.digest('guest',self.guest.token)]['until']=0
        self.identity.participation_fences.add(self.guest.ref)
        self.assertIsNone(await self.identity.resolve({'guest':self.guest.token}));self.assertNotIn(self.guest.ref,self.identity.realtime.people)
        self.assertNotIn(self.guest.ref,self.identity.participation_fences)
    async def test_separate_private_bootstrap_cannot_be_used_for_public_guest(self):
        private=self.identity.new_bootstrap('private')
        self.assertIsNone(await self.identity.resolve({'bootstrap':private.token}))
        self.assertEqual((await self.identity.resolve({'admin_bootstrap':private.token},private=True)).kind,'bootstrap')

class Phase3LostResponses(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.identity=identity();self.boot=self.identity.new_bootstrap();self.aid=uuid4();self.ref=uuid4().hex;self.sid=uuid4();self.proof_secret=token()
        self.account={'id':self.aid,'public_ref':self.ref,'status':'active','auth_generation':2,'password_hash':'old-phc','recovery_verifier':self.identity.security.verifier('receipt',self.proof_secret)}
        self.dto=m.Register(**profile(),consents=choices(),username='owner_name',password='A private passphrase',proof={'reservation_id':uuid4().hex,'secret':self.proof_secret,'saved':True},client_nonce=str(uuid4()))
    async def test_registration_replay_after_ram_loss_returns_same_cookie_no_new_session(self):
        result={'generation':2,'session_id':str(self.sid),'registered':True}
        op={'keyed_digest':self.identity.request_digest('registration',self.dto),'result':result}
        with patch('app.services.identity.one',AsyncMock(side_effect=[self.account,op,{'id':self.sid}])):
            secret=await self.identity.registration(self.boot,self.dto)
        self.assertEqual(secret,self.identity.security.derived_token('registration',self.proof_secret,self.dto.client_nonce,self.ref))
        self.identity.passwords.hash.assert_not_awaited();self.identity.db.connection.execute.assert_not_awaited()
    async def test_registration_retry_cannot_bypass_changed_intent_or_later_generation(self):
        for digest,generation in [('wrong',2),(self.identity.request_digest('registration',self.dto),1)]:
            op={'keyed_digest':digest,'result':{'generation':generation,'session_id':str(self.sid)}}
            with patch('app.services.identity.one',AsyncMock(side_effect=[self.account,op])):
                with self.assertRaises(DomainError):await self.identity.registration(self.boot,self.dto)
        self.identity.passwords.hash.assert_not_awaited()
    async def test_recovery_retry_uses_saved_new_proof_and_never_reuses_old_code(self):
        dto=m.Recover(username='owner_name',password='Replacement passphrase',recovery_secret=token(),proof=self.dto.proof,client_nonce=str(uuid4()))
        op={'keyed_digest':self.identity.request_digest('recovery',dto),'result':{'generation':2,'recovered':True}}
        with patch('app.services.identity.one',AsyncMock(side_effect=[self.account,op])):await self.identity.recover(self.boot,dto)
        self.identity.passwords.hash.assert_not_awaited();self.assertFalse(self.identity.reservations.items)
        with patch('app.services.identity.one',AsyncMock(side_effect=[self.account,None])):
            with self.assertRaisesRegex(DomainError,'PREPARATION_REQUIRED'):await self.identity.recover(self.boot,dto.model_copy(update={'client_nonce':str(uuid4())}))
    async def test_spent_account_cookie_proves_only_original_recorded_credential_retry(self):
        old_cookie=token();dto=m.PasswordChange(password='Replacement passphrase',client_nonce=str(uuid4()))
        principal=Principal('credential_retry','',old_cookie);source=self.account|{'source_session':self.sid}
        result={'generation':2,'source_session':str(self.sid),'session_id':str(uuid4())}
        op={'keyed_digest':self.identity.request_digest('password_change',dto),'result':result}
        with patch('app.services.identity.one',AsyncMock(side_effect=[source,op,{'id':uuid4()}])):
            secret=await self.identity.credential_change(principal,dto,'password_change')
        self.assertEqual(secret,self.identity.security.derived_token('password_change',old_cookie,dto.client_nonce,self.ref));self.identity.passwords.hash.assert_not_awaited()
        for kind in ('case','financial','deletion','bootstrap'):
            with self.assertRaises(DomainError):await self.identity.credential_change(Principal(kind,self.ref,old_cookie),dto,'password_change')
    async def test_reauthentication_does_not_grant_after_generation_race(self):
        principal=Principal('account',self.ref,token(),self.aid,self.sid,self.account)
        raced=self.account|{'auth_generation':3,'reauth_at':datetime.now(timezone.utc)}
        with patch('app.services.identity.one',AsyncMock(return_value=raced)):
            with self.assertRaisesRegex(DomainError,'AUTHENTICATION_REQUIRED'):await self.identity.reauthenticate(principal,'A private passphrase')
        self.identity.db.connection.execute.assert_not_awaited()
    async def test_guest_end_while_hashing_wins_conversion(self):
        guest=self.identity.guest(self.boot,m.Guest(**profile(),consents=choices()))
        shown=self.identity.reservations.prepare(guest.ref,'recovery',str(uuid4()))
        dto=self.dto.model_copy(update={'proof':m.Proof(reservation_id=shown['reservation_id'],secret=shown['secret'],saved=True)})
        async def hash_and_end(_):self.identity.realtime.end(guest.ref);return 'new-phc'
        self.identity.passwords.hash=hash_and_end
        with patch('app.services.identity.one',AsyncMock(side_effect=[None,None,None])):
            with self.assertRaisesRegex(DomainError,'CONVERSION_CHANGED'):await self.identity.registration(guest,dto)
        self.assertFalse(any('INSERT INTO nt.accounts' in call.args[0] for call in self.identity.db.connection.execute.call_args_list))

    async def test_support_rechecks_account_before_releasing_plaintext(self):
        from app.services.support import Support
        service=Support(self.identity.db,self.identity.security,self.identity)
        principal=Principal('account',self.ref,token(),self.aid,self.sid,self.account)
        with patch('app.services.support.one',AsyncMock(return_value={'authorized':False})),patch.object(self.identity.security,'decrypt') as decrypt:
            with self.assertRaisesRegex(DomainError,'AUTHENTICATION_REQUIRED'):await service.messages(principal,'case-ref')
            decrypt.assert_not_called()

    async def test_guest_end_during_database_effects_rejects_before_commit(self):
        guest=self.identity.guest(self.boot,m.Guest(**profile(),consents=choices()))
        shown=self.identity.reservations.prepare(guest.ref,'recovery',str(uuid4()))
        dto=self.dto.model_copy(update={'proof':m.Proof(reservation_id=shown['reservation_id'],secret=shown['secret'],saved=True)})
        async def execute(sql,*_):
            if 'INSERT INTO nt.outbox' in sql:self.identity.realtime.end(guest.ref)
        self.identity.db.connection.execute=AsyncMock(side_effect=execute)
        with patch('app.services.identity.one',AsyncMock(side_effect=[None,None,None])),patch.object(self.identity,'create_session',AsyncMock(return_value=(token(),str(uuid4())))),patch.object(self.identity,'record_consents',AsyncMock()),patch.object(self.identity,'save_operation',AsyncMock()):
            with self.assertRaisesRegex(DomainError,'CONVERSION_CHANGED'):await self.identity.registration(guest,dto)
        self.assertIsNotNone(await self.identity.resolve({'guest':guest.token}))

    async def test_support_capability_does_not_require_participation_consent(self):
        from app.services.support import Support
        service=Support(self.identity.db,self.identity.security,self.identity)
        principal=Principal('account',self.ref,token(),self.aid,self.sid,self.account|{'core_consent':False,'status':'restricted'})
        with patch('app.services.support.one',AsyncMock(return_value={'authorized':True})):
            await service.lock_account_authority(self.identity.db.connection,principal)

if __name__=='__main__':unittest.main()
