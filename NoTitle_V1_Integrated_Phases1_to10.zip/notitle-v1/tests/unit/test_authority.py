import asyncio
import unittest
from app.coordinator.core import Coordinator,Fenced
from app.supervision import supervise

class Authority(unittest.TestCase):
    def setUp(self):
        self.now=0.;self.c=Coordinator(7,lambda:self.now)
    def test_late_result_cannot_revive_end(self):
        stamp=self.c.reserve("user");self.c.end("user")
        with self.assertRaises(Fenced):self.c.publish(stamp,b"ok")
        self.assertFalse(self.c.live)
    def test_previous_epoch_rejected(self):
        stamp=self.c.reserve("user");other=Coordinator(8,lambda:0);other.reserve("user")
        with self.assertRaises(Fenced):other.publish(stamp,b"ok")
    def test_uncertainty_fences_synchronously(self):
        stamp=self.c.reserve("user");self.c.publish(stamp,b"x")
        self.now=2
        with self.assertRaises(Fenced):self.c.publish(stamp,b"late")
        self.assertFalse(self.c.alive);self.assertFalse(self.c.live)
    def test_late_heartbeat_cannot_restore_authority(self):
        self.now=2.1
        with self.assertRaises(Fenced):self.c.heartbeat()
        self.assertFalse(self.c.alive)
    def test_cannot_reanimate_fenced_owner(self):
        self.c.fence()
        with self.assertRaises(Fenced):self.c.heartbeat()
    def test_bounded_identity_budget(self):
        for i in range(200):self.c.reserve(str(i))
        with self.assertRaises(Fenced):self.c.reserve("excess")
    def test_large_effect_rejected(self):
        stamp=self.c.reserve("user")
        with self.assertRaises(ValueError):self.c.publish(stamp,b"x"*513)

class Supervision(unittest.IsolatedAsyncioTestCase):
    async def scenario(self,lose_db=False,lose_listener=False,stop_normally=False):
        c=Coordinator(1)
        class Lease:
            async def prove(self):
                if lose_db:raise ConnectionError("synthetic DB loss")
        stop=asyncio.Event()
        async def listener():
            if lose_listener:return
            await asyncio.Event().wait()
        tasks=[asyncio.create_task(listener()),asyncio.create_task(asyncio.Event().wait())]
        if stop_normally:stop.set()
        try:
            if stop_normally:await asyncio.wait_for(supervise(Lease(),c,tasks,stop),1)
            else:
                with self.assertRaises(RuntimeError):await asyncio.wait_for(supervise(Lease(),c,tasks,stop),1)
            self.assertFalse(c.alive)
        finally:
            for task in tasks:task.cancel()
            await asyncio.gather(*tasks,return_exceptions=True)
    async def test_listener_exit_fences_both(self):await self.scenario(lose_listener=True)
    async def test_db_loss_fences(self):await self.scenario(lose_db=True)
    async def test_normal_stop_fences(self):await self.scenario(stop_normally=True)
