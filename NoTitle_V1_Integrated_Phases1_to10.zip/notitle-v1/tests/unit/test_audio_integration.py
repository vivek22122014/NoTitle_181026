"""Consent/effect race coverage; these tests do not qualify real RTP teardown."""
import asyncio,unittest
from types import SimpleNamespace
from app.domain.conversation import ConversationActor
from app.domain.errors import DomainError
from app.services.media import Media

class Relay:
    def __init__(self):self.requests=[];self.started=asyncio.Event();self.release=None;self.absent=True
    async def request(self,method,path,payload):
        self.requests.append((path,payload))
        if path=='/calls' or path.endswith('/refresh'):
            self.started.set()
            if self.release:await self.release.wait()
            return {'ice_servers':{str(index):[{'urls':['turn:turn.example.test:3478?transport=udp'],'username':'call-user','credential':'secret'}] for index in range(2)}}
        if path.endswith('/candidate'):return {'authorized':True}
        if path.endswith('/end'):return {'allocations_absent':self.absent}
        return {'connected':[]}

class AudioIntegration(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.now=100.;self.authority=SimpleNamespace(epoch=1,assert_authority=lambda:None)
        self.rt=ConversationActor(self.authority,SimpleNamespace(add=lambda *args:None),lambda:self.now,lambda:1000.)
        for identity in ('a','b'):
            self.rt.enter(identity,{'display_name':identity*2,'gender':'other','topic_id':'general','bio':''});self.rt.connect(identity)
        self.rt.start('a','b');self.interaction=self.rt.current('a');self.relay=Relay();self.media=Media(self.rt,self.relay,'203.0.113.1')
    def invite(self):return self.rt.call_request('a')['call_id']
    async def test_request_has_no_credentials_and_caller_cannot_self_accept(self):
        self.invite();self.assertFalse(self.relay.requests)
        with self.assertRaises(DomainError):self.media.reserve_accept('a',True)
        self.assertFalse(self.media.reserved)
    async def test_decline_never_provisions_or_releases_unknown_allocations(self):
        self.invite();self.assertIsNone(self.media.reserve_accept('b',False));self.assertFalse(self.relay.requests)
        self.assertEqual(self.interaction.call['state'],'teardown')
        await self.media.pump();self.assertIsNone(self.interaction.call)
    async def test_end_during_create_keeps_capacity_until_late_create_is_denied(self):
        ref=self.invite();self.relay.release=asyncio.Event();effect=self.media.reserve_accept('b',True)
        provision=asyncio.create_task(self.media.provision(effect));await self.relay.started.wait()
        self.rt.end('a');await self.media.pump()
        self.assertIn(ref,self.media.reserved);self.assertFalse(any(path.endswith('/end') for path,_ in self.relay.requests))
        self.relay.release.set()
        with self.assertRaises(DomainError):await provision
        self.assertIn(ref,self.media.reserved);await self.media.pump();self.assertNotIn(ref,self.media.reserved)
        self.assertTrue(any(path.endswith('/end') for path,_ in self.relay.requests))
    async def test_cancellation_keeps_teardown_reservation(self):
        ref=self.invite();self.relay.release=asyncio.Event();effect=self.media.reserve_accept('b',True)
        task=asyncio.create_task(self.media.provision(effect));await self.relay.started.wait();task.cancel()
        with self.assertRaises(asyncio.CancelledError):await task
        self.assertIn(ref,self.media.reserved);self.assertIn(ref,self.rt.media_ends)
        await self.media.pump();self.assertNotIn(ref,self.media.reserved)
    async def test_failed_allocation_cleanup_does_not_release_capacity(self):
        ref=self.invite();await self.media.accept('b',True);self.rt.end('a');self.relay.absent=False
        with self.assertRaises(DomainError):await self.media.pump()
        self.assertIn(ref,self.media.reserved);self.assertIn(ref,self.rt.media_ends)
    async def test_capacity_counts_removed_interactions_waiting_for_confirmation(self):
        self.invite();self.media.reserved.update(str(index) for index in range(25))
        with self.assertRaises(DomainError):self.media.reserve_accept('b',True)
        self.assertEqual(self.interaction.call['state'],'ringing')
    async def test_remote_and_both_browser_readiness_required(self):
        ref=self.invite();await self.media.accept('b',True)
        self.media.connected('a',ref);self.media.connected('b',ref);self.assertEqual(self.interaction.call['state'],'connecting')
        self.interaction.call['relay_ready']=True;self.media.maybe_connected(self.interaction)
        self.assertEqual(self.interaction.call['state'],'connected')
    async def test_refresh_revisions_and_rate_limit(self):
        ref=self.invite();await self.media.accept('b',True);self.interaction.call['state']='connected'
        with self.assertRaises(DomainError):self.media.reserve_refresh('a',ref)
        self.now+=300;effect=self.media.reserve_refresh('a',ref)
        self.assertEqual(effect.revision,3);await self.media.provision(effect)
        self.assertTrue(any(path.endswith('/refresh') for path,_ in self.relay.requests))
    async def test_signals_cannot_use_previous_negotiation_or_direct_path(self):
        ref=self.invite();await self.media.accept('b',True)
        payload={'call_id':ref,'negotiation_revision':1,'candidate':'candidate:1 1 udp 1 203.0.113.1 49152 typ relay'}
        with self.assertRaises(DomainError):self.media.prepare_signal('a','call.ice',payload)
        payload['negotiation_revision']=2
        with self.assertRaises(DomainError):self.media.signal('a','call.ice',payload)
    async def test_candidate_revalidated_after_external_lookup(self):
        ref=self.invite();await self.media.accept('b',True)
        original=self.relay.request
        async def lookup(method,path,payload):
            result=await original(method,path,payload)
            if path.endswith('/candidate'):self.rt.end_call(self.interaction,'ended')
            return result
        self.relay.request=lookup
        async def transition(function):return function()
        payload={'call_id':ref,'negotiation_revision':2,'candidate':'candidate:1 1 udp 1 203.0.113.1 49152 typ relay'}
        with self.assertRaises(DomainError):await self.media.forward_signal('a','call.ice',payload,transition,lambda:None)
    async def test_no_controller_fails_closed_before_consent_change(self):
        self.invite();disabled=Media(self.rt)
        with self.assertRaises(DomainError):disabled.reserve_accept('b',True)
        self.assertEqual(self.interaction.call['state'],'ringing')

    async def test_shutdown_denies_all_known_calls_without_renewing_owner(self):
        ref=self.invite();await self.media.accept('b',True)
        self.rt.end_call(self.interaction,'shutdown');self.relay.requests.clear()
        result=await self.media.shutdown()
        self.assertEqual(result,{'confirmed':1,'pending':0})
        self.assertNotIn(ref,self.media.reserved);self.assertNotIn(ref,self.rt.media_ends)
        self.assertIsNone(self.interaction.call)
        self.assertEqual([path for path,_ in self.relay.requests],['/calls/'+ref+'/end'])
        await self.media.pump();self.assertEqual(len(self.relay.requests),1)
    async def test_shutdown_unknown_cleanup_keeps_reservation_and_deny_queue(self):
        ref=self.invite();await self.media.accept('b',True);self.rt.end('a');self.relay.absent=False
        result=await self.media.shutdown()
        self.assertEqual(result,{'confirmed':0,'pending':1})
        self.assertIn(ref,self.media.reserved);self.assertIn(ref,self.rt.media_ends)
    async def test_shutdown_timeout_is_bounded_and_does_not_claim_absence(self):
        ref=self.invite();await self.media.accept('b',True);self.rt.end('a')
        async def stalled(method,path,payload):await asyncio.Event().wait()
        self.relay.request=stalled
        result=await asyncio.wait_for(self.media.shutdown(timeout=.02),.2)
        self.assertEqual(result,{'confirmed':0,'pending':1});self.assertIn(ref,self.media.reserved)
    async def test_cancelled_provision_preserves_error_when_mailbox_closed(self):
        ref=self.invite();self.relay.release=asyncio.Event();effect=self.media.reserve_accept('b',True)
        async def closed(function):raise DomainError('SERVICE_UNAVAILABLE',503)
        task=asyncio.create_task(self.media.provision(effect,transition=closed));await self.relay.started.wait();task.cancel()
        with self.assertRaises(asyncio.CancelledError):await task
        self.assertIn(ref,self.rt.media_ends);self.assertIn(ref,self.media.reserved)

class CandidateAttribution(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        from relay.controller import Controller
        from relay.guard import Guard,Allocation
        self.controller=Controller.__new__(Controller);self.controller.lock=asyncio.Lock();self.controller.guard=Guard('203.0.113.1');self.controller.guard.owner_lease(1,1)
        self.ref='a'*32;self.controller.calls={self.ref:{'users':['participant_a','participant_b'],'ended':False}}
        self.lookups=[]
        async def allocations(user):
            self.lookups.append(user)
            return [Allocation('123',user,'203.0.113.1',49152 if user=='participant_a' else 49153)]
        self.controller.allocations=allocations
    async def test_only_exact_participant_allocation_can_be_advertised(self):
        path='/calls/'+self.ref+'/candidate'
        result=await self.controller.request(path,{'owner_epoch':1,'side':0,'port':49152});self.assertTrue(result['authorized'])
        result=await self.controller.request(path,{'owner_epoch':1,'side':0,'port':49153});self.assertFalse(result['authorized'])
        self.assertEqual(self.lookups,['participant_a','participant_a'])
    async def test_stale_owner_and_ended_calls_cannot_authorize_candidates(self):
        from relay.guard import RelayDenied
        path='/calls/'+self.ref+'/candidate'
        with self.assertRaises(RelayDenied):await self.controller.request(path,{'owner_epoch':2,'side':0,'port':49152})
        self.controller.calls[self.ref]['ended']=True
        with self.assertRaises(RelayDenied):await self.controller.request(path,{'owner_epoch':1,'side':0,'port':49152})
        self.assertEqual(self.lookups,[])
    async def test_boolean_side_and_unknown_payload_fields_rejected(self):
        from relay.guard import RelayDenied
        path='/calls/'+self.ref+'/candidate'
        for payload in ({'owner_epoch':1,'side':True,'port':49152},{'owner_epoch':1,'side':0,'port':49152,'username':'other'}):
            with self.assertRaises(RelayDenied):await self.controller.request(path,payload)
