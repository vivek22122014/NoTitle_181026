import unittest
from relay.guard import Guard,Allocation,RelayDenied,parse_sessions,ruleset
from relay.guard_socket import transaction
IP="203.0.113.10"
def snapshot(user="user_a",port=49152):
    # Synthetic fixture derived from upstream print format; not a captured build fixture.
    return f" 1) id=000000000000000001, user <{user}>:\n client protocol TLS, relay protocol UDP\n relay addr {IP}:{port}\n Total sessions: 1\n"
class Relay(unittest.TestCase):
    def setUp(self):
        self.now=10.;self.g=Guard(IP,lambda:self.now);self.g.owner_lease(1,1)
        self.a=[Allocation('1','user_a',IP,49152)];self.b=[Allocation('2','user_b',IP,49153)];self.call='a'*32
    def authorize(self):self.g.authorize(self.call,self.a,self.b,self.now+20,1)
    def test_exact_parser(self):
        self.assertEqual(parse_sessions(snapshot(),'user_a',IP)[0].port,49152)
        with self.assertRaises(RelayDenied):parse_sessions(snapshot('user_a_suffix'),'user_a',IP)
    def test_truncated_and_foreign_snapshot(self):
        for raw in [snapshot().replace('Total sessions: 1',''),snapshot(port=1234),snapshot().replace(IP,'203.0.113.99'),snapshot().replace('Total sessions: 1','Total sessions: 2')]:
            with self.assertRaises(RelayDenied):parse_sessions(raw,'user_a',IP)
    def test_unknown_schema_no_allow(self):
        with self.assertRaises(RelayDenied):parse_sessions('unknown CLI format','user_a',IP)
        self.assertNotIn('add element',self.g.transaction())
    def test_lease_kernel_timeout_bounded(self):
        self.authorize();self.assertEqual(self.g.transaction().count('timeout 5000ms'),2)
        self.now+=5;self.assertNotIn('add element',self.g.transaction())
    def test_end_revokes_immediately_and_replay_cannot_restore(self):
        self.authorize();self.g.end(self.call)
        self.assertNotIn('add element',self.g.transaction())
        with self.assertRaises(RelayDenied):self.authorize()
    def test_port_reuse_contains_every_call(self):
        self.authorize();self.g.end(self.call)
        with self.assertRaises(RelayDenied):self.g.authorize('b'*32,self.a,self.b,self.now+20,1)
        self.assertTrue(self.g.contained);self.assertNotIn('add element',self.g.transaction())
    def test_changed_allocation_same_call_contains(self):
        self.authorize()
        with self.assertRaises(RelayDenied):self.g.authorize(self.call,[Allocation('999','user_a',IP,49152)],self.b,self.now+20,1)
        self.assertTrue(self.g.contained)
    def test_old_owner_and_expired_owner(self):
        with self.assertRaises(RelayDenied):self.g.owner_lease(1,1)
        self.now=41
        with self.assertRaises(RelayDenied):self.authorize()
        self.assertNotIn('add element',self.g.transaction())
    def test_new_owner_demands_restart(self):
        with self.assertRaises(RelayDenied):self.g.owner_lease(2,1)
        self.assertTrue(self.g.contained)
    def test_helper_rejects_arbitrary_firewall_commands(self):
        for value in [{'command':'flush ruleset'},{'pairs':[[49152,49153,5001]]},{'pairs':[['49152',49153,100]]},{'pairs':[[49152,49153,100],[49152,49153,100]]}]:
            with self.assertRaises(ValueError):transaction(value)
    def test_helper_empty_is_deny(self):self.assertEqual(transaction({'pairs':[]}),'flush set inet notitle_guard pairs\n')
    def test_table_has_early_deny_and_bounded_timeout(self):
        script=ruleset(IP)
        self.assertIn('priority -200',script);self.assertIn('timeout 5s; size 800',script)
        self.assertNotIn('ct state established',script)
