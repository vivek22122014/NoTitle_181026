"""Real owner/social transition tests. SQL doubles do not prove PostgreSQL concurrency."""
import asyncio,unittest
from uuid import uuid4
from unittest.mock import AsyncMock,patch
from contextlib import asynccontextmanager
from types import SimpleNamespace
from pydantic import TypeAdapter,ValidationError
from app.domain.errors import DomainError
from app.domain.social_contracts import FriendRequest,FriendRespond,FriendInvite,FriendInviteRespond
from app.services.social import Social
from app.services.conversation_social import ConversationSocial
from tests.unit.test_phase4 import actor,FakeIdentity,command,flush
from app.services.conversation import Conversation
from app.http.models import Ticket
from app.http.models import Preferences,ProfileUpdate
from app.services.account_controls import AccountControls

MODELS={'friend.request':FriendRequest,'friend.respond':FriendRespond,'friend.invite':FriendInvite,'friend.invite.respond':FriendInviteRespond}

class Phase6(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.rt,self.clock=actor();self.identity=FakeIdentity(self.rt);self.social=Social(None,self.rt)
        self.service=Conversation(self.rt,self.identity,social=self.social);self.handler=ConversationSocial(self.service)
        self.a=await self.binding();self.b=await self.binding();self.pair=self.rt.pair(self.a.principal.ref,self.b.principal.ref)
    async def asyncTearDown(self):await self.service.close()
    async def binding(self):
        p=self.identity.add();ticket=await self.service.prepare(p,Ticket());binding=await self.service.connect(ticket['ticket'],{'guest':p.token});self.rt.drain(p.ref);return binding
    def connect_pair(self):
        self.rt.start(*self.pair);flush(self.rt)
    def model(self,binding,kind,payload):
        ref=binding.principal.ref
        return MODELS[kind].model_validate({'protocol_version':2,'type':kind,'command_id':str(uuid4()),'owner_epoch':self.rt.authority.epoch,'socket_generation':binding.generation,'interaction_epoch':self.rt.people[ref].revision,'payload':payload})
    async def run_social(self,binding,kind,payload):
        c=self.model(binding,kind,payload);key=self.service.begin(binding,c);revision=self.service.pending[key][1]
        try:return await self.handler.execute(binding,c,revision)
        finally:self.service.pending.pop(key,None)
    async def request(self,binding):return await self.run_social(binding,'friend.request',{'interaction_handle':self.rt.people[binding.principal.ref].interaction})
    async def friend_pair(self):
        self.connect_pair();await self.request(self.a);await self.request(self.b)
        self.rt.end(self.a.principal.ref);flush(self.rt)

    async def test_crossed_request_mutual_temporary_no_database(self):
        self.connect_pair();await self.request(self.a);self.assertNotIn(self.pair,self.rt.friends)
        await self.request(self.b);self.assertIn(self.pair,self.rt.friends);self.assertNotIn(self.pair,self.rt.requests)
        items=(await self.social.friends(self.a.principal))['items'];self.assertEqual(len(items),1)
        self.assertEqual(items[0]['persistence'],'temporary');self.assertNotEqual(items[0]['relationship_handle'],self.b.principal.ref)
        self.assertEqual(set(items[0]['peer']),{'peer_handle','display_name','gender','topic_id','bio'})
    async def test_decline_generic_closed_and_end_expires_request(self):
        self.connect_pair();await self.request(self.a);request=self.rt.requests[self.pair]
        await self.run_social(self.b,'friend.respond',{'request_handle':request['handle'],'accept':False})
        self.assertNotIn(self.pair,self.rt.friends);events=self.rt.drain(self.a.principal.ref)
        self.assertEqual(events[-1]['type'],'friend.request_closed');self.assertEqual(set(events[-1]['data']),{'request_handle'})
        await self.request(self.a);request=self.rt.requests[self.pair];self.rt.end(self.a.principal.ref)
        with self.assertRaises(DomainError):await self.run_social(self.b,'friend.respond',{'request_handle':request['handle'],'accept':True})
    async def test_limit_applies_to_both_and_no_unilateral_friend(self):
        self.connect_pair()
        for _ in range(100):
            pair=self.rt.pair(self.b.principal.ref,uuid4().hex);self.rt.friends.add(pair);self.social.relationship(pair)['persistence']='saved'
        with self.assertRaises(DomainError) as error:await self.request(self.a)
        self.assertEqual(error.exception.code,'FRIEND_LIMIT');self.assertNotIn(self.pair,self.rt.requests)
    async def test_wrong_interaction_or_request_handle_not_authorized(self):
        self.connect_pair()
        with self.assertRaises(DomainError):await self.run_social(self.a,'friend.request',{'interaction_handle':uuid4().hex})
        await self.request(self.a)
        with self.assertRaises(DomainError):await self.run_social(self.b,'friend.respond',{'request_handle':uuid4().hex,'accept':True})
        self.assertNotIn(self.pair,self.rt.friends)
    async def test_named_crossed_invites_create_exactly_one_free_interaction(self):
        await self.friend_pair();handle=self.social.relationship(self.pair)['handle']
        # Random strict preferences and four-second repeat exclusion do not restrict named friendship.
        await self.run_social(self.a,'friend.invite',{'relationship_handle':handle})
        result=await self.run_social(self.b,'friend.invite',{'relationship_handle':handle})
        self.assertEqual(result['status'],'accepted');self.assertEqual(len(self.rt.interactions),1)
        self.assertEqual(self.rt.current(self.a.principal.ref).source,'friend');self.assertNotIn(self.pair,self.rt.invites)
    async def test_invites_expire_and_never_interrupt_busy_peer(self):
        await self.friend_pair();handle=self.social.relationship(self.pair)['handle']
        await self.run_social(self.a,'friend.invite',{'relationship_handle':handle});invite=self.rt.invites[self.pair]
        self.clock.advance(31)
        with self.assertRaises(DomainError):await self.run_social(self.b,'friend.invite.respond',{'invite_handle':invite['handle'],'accept':True})
        self.assertFalse(self.rt.interactions)
        c=await self.binding();self.rt.start(self.b.principal.ref,c.principal.ref)
        with self.assertRaises(DomainError):await self.run_social(self.a,'friend.invite',{'relationship_handle':handle})
        self.assertEqual(self.rt.current(self.b.principal.ref).right,c.principal.ref)
    async def test_remove_invalidates_pending_invite_and_scoped_handle(self):
        await self.friend_pair();handle=self.social.relationship(self.pair)['handle']
        await self.run_social(self.a,'friend.invite',{'relationship_handle':handle});invite=self.rt.invites[self.pair]
        await self.social.remove(self.a.principal,handle,1)
        self.assertNotIn(self.pair,self.rt.friends);self.assertNotIn(self.pair,self.rt.invites)
        with self.assertRaises(DomainError):await self.run_social(self.b,'friend.invite.respond',{'invite_handle':invite['handle'],'accept':True})
        with self.assertRaises(DomainError):self.social.target(uuid4().hex,handle)
    async def test_block_prevents_acceptance_and_discards_relation(self):
        await self.friend_pair();handle=self.social.relationship(self.pair)['handle']
        await self.run_social(self.a,'friend.invite',{'relationship_handle':handle});invite=self.rt.invites[self.pair]
        result=await self.social.block(self.b.principal,handle);self.assertFalse(result['persisted'])
        self.assertTrue(self.rt.blocked(*self.pair));self.assertNotIn(self.pair,self.rt.friends)
        with self.assertRaises(DomainError):await self.run_social(self.b,'friend.invite.respond',{'invite_handle':invite['handle'],'accept':True})
    async def test_delayed_authorization_cannot_start_after_remove(self):
        await self.friend_pair();handle=self.social.relationship(self.pair)['handle']
        await self.run_social(self.a,'friend.invite',{'relationship_handle':handle});invite=self.rt.invites[self.pair]
        barrier=asyncio.Event();self.identity.barrier=barrier
        task=asyncio.create_task(self.run_social(self.b,'friend.invite.respond',{'invite_handle':invite['handle'],'accept':True}))
        await asyncio.sleep(0);await self.social.remove(self.a.principal,handle,1);barrier.set()
        with self.assertRaises(DomainError):await task
        self.assertFalse(self.rt.interactions)
    async def test_saved_only_after_commit_and_failed_save_stays_temporary(self):
        self.connect_pair()
        for ref in self.pair:self.rt.people[ref].registered=True
        await self.request(self.a);started=asyncio.Event();finish=asyncio.Event()
        async def save(*args):started.set();await finish.wait();self.social.relationship(self.pair)['persistence']='saved'
        self.social.save_friend=save
        task=asyncio.create_task(self.request(self.b));await started.wait()
        self.assertEqual(self.social.view(*self.pair)['persistence'],'saving');finish.set();await task
        self.assertEqual(self.social.view(*self.pair)['persistence'],'saved')
    async def test_failed_durable_save_never_emits_persisted(self):
        self.connect_pair()
        for ref in self.pair:self.rt.people[ref].registered=True
        await self.request(self.a);self.social.save_friend=AsyncMock(side_effect=RuntimeError('unavailable'))
        with self.assertRaises(DomainError):await self.request(self.b)
        self.assertEqual(self.social.view(*self.pair)['persistence'],'temporary')
        self.assertFalse(any(event['type']=='friend.persisted' for event in self.rt.drain(self.a.principal.ref)))
    async def test_presence_has_only_three_coarse_states(self):
        self.assertEqual(self.social.presence(self.a.principal.ref),'available');self.connect_pair()
        self.assertEqual(self.social.presence(self.a.principal.ref),'busy');self.rt.disconnect(self.b.principal.ref)
        self.assertEqual(self.social.presence(self.b.principal.ref),'offline')
    async def test_retired_guest_friend_expires_and_releases_quota(self):
        await self.friend_pair();self.rt.retire(self.b.principal.ref)
        result=await self.social.friends(self.a.principal)
        self.assertEqual(result['items'],[]);self.assertNotIn(self.pair,self.rt.friends)
    async def test_unknown_fields_and_stale_socket_fail(self):
        self.connect_pair();c=self.model(self.a,'friend.request',{'interaction_handle':self.rt.people[self.a.principal.ref].interaction})
        with self.assertRaises(ValidationError):FriendRequest.model_validate(c.model_dump()|{'password':'forbidden'})
        self.rt.connect(self.a.principal.ref,True,self.a.generation)
        with self.assertRaises(DomainError):self.service.begin(self.a,c)

class SaveRace(unittest.IsolatedAsyncioTestCase):
    async def test_block_list_is_owned_bounded_and_has_stable_keyset_cursor(self):
        rt,_=actor();queries=[];account=uuid4()
        @asynccontextmanager
        async def transaction():yield object()
        social=Social(type('DB',(),{'transaction':staticmethod(transaction)})(),rt)
        rows=[{'public_ref':uuid4().hex,'created_at':'2026-10-17T01:02:03Z'} for _ in range(101)]
        async def many_rows(_,sql,args):queries.append((sql,args));return rows
        with patch('app.services.social.many',many_rows):result=await social.blocks(SimpleNamespace(kind='account',account_id=account))
        self.assertEqual(len(result['items']),100);self.assertEqual(result['next_cursor'],rows[99]['public_ref'])
        self.assertEqual(queries[0][1][0],account);self.assertIn('created_at DESC,public_ref DESC',queries[0][0])
        with patch('app.services.social.one',AsyncMock(return_value=None)):
            with self.assertRaises(DomainError):await social.blocks(SimpleNamespace(kind='account',account_id=account),cursor=uuid4().hex)

    async def test_stale_hydration_cannot_resurrect_removed_pair(self):
        rt,_=actor();from tests.unit.test_phase4 import enter
        a,b=enter(rt),enter(rt);pair=rt.pair(a,b);rt.friends.add(pair);started=asyncio.Event();finish=asyncio.Event()
        @asynccontextmanager
        async def transaction():yield object()
        social=Social(type('DB',(),{'transaction':staticmethod(transaction)})(),rt);state=social.relationship(pair);state['persistence']='saved'
        async def rows(_,sql,args):
            if 'nt.friendships' in sql:started.set();await finish.wait();return [{'left_ref':a,'right_ref':b}]
            return []
        with patch('app.services.social.many',rows):
            task=asyncio.create_task(social.hydrate(SimpleNamespace(kind='account',account_id=uuid4())))
            await started.wait();await social.remove(SimpleNamespace(kind='guest',ref=a),state['handle'],1);finish.set();await task
        self.assertNotIn(pair,rt.friends)

    async def test_stale_friend_list_cannot_resurrect_removed_pair(self):
        rt,_=actor();from tests.unit.test_phase4 import enter,profile
        a,b=enter(rt),enter(rt);pair=rt.pair(a,b);rt.friends.add(pair);started=asyncio.Event();finish=asyncio.Event()
        @asynccontextmanager
        async def transaction():yield object()
        social=Social(type('DB',(),{'transaction':staticmethod(transaction)})(),rt);state=social.relationship(pair);state['persistence']='saved'
        async def rows(*args):started.set();await finish.wait();return [{'peer_handle':b,**profile(),'revision':1}]
        with patch('app.services.social.many',rows):
            task=asyncio.create_task(social.friends(SimpleNamespace(kind='account',ref=a,account_id=uuid4())))
            await started.wait();await social.remove(SimpleNamespace(kind='guest',ref=a),state['handle'],1);finish.set();result=await task
        self.assertNotIn(pair,rt.friends);self.assertEqual(result['items'],[])

    async def test_cancellation_during_commit_reconciles_before_social_close(self):
        rt,_=actor();from tests.unit.test_phase4 import enter
        a,b=enter(rt),enter(rt);pair=rt.pair(a,b)
        for ref in pair:rt.people[ref].registered=True
        rt.friends.add(pair);queries=[];committing=asyncio.Event();finish=asyncio.Event();transactions=0
        class Connection:
            async def execute(self,sql,args):queries.append((sql,args))
        connection=Connection()
        @asynccontextmanager
        async def transaction():
            nonlocal transactions
            transactions+=1;number=transactions
            yield connection
            if number==1:committing.set();await finish.wait()
        db=type('DB',(),{'transaction':staticmethod(transaction)})();social=Social(db,rt)
        ids=sorted([uuid4(),uuid4()]);created={'revision':1,'accepted_at':'exact-cancelled-timestamp'}
        async def rows(*args):return [{'id':ids[0],'public_ref':a},{'id':ids[1],'public_ref':b}]
        async def row(_,sql,args):
            if 'INSERT INTO' in sql:return created
            if 'count(*)' in sql:return {'n':0}
            return None
        with patch('app.services.social.many',rows),patch('app.services.social.one',row):
            task=asyncio.create_task(social.save_friend(a,b,{ref:rt.people[ref].revision for ref in pair}))
            await committing.wait();task.cancel();await asyncio.sleep(0)
            self.assertTrue(social.durable_tasks);finish.set()
            with self.assertRaises(asyncio.CancelledError):await task
            await social.close()
        self.assertFalse(social.durable_tasks);self.assertNotIn(pair,rt.friends)
        self.assertEqual(len(queries),1);self.assertIn('accepted_at=%s',queries[0][0]);self.assertEqual(queries[0][1][-1],created['accepted_at'])

    async def test_remove_after_commit_compensates_exact_insert(self):
        rt,_=actor();from tests.unit.test_phase4 import enter
        a,b=enter(rt),enter(rt);pair=rt.pair(a,b)
        for ref in pair:rt.people[ref].registered=True
        rt.friends.add(pair);queries=[]
        class Connection:
            async def execute(self,sql,args):queries.append((sql,args))
        connection=Connection()
        @asynccontextmanager
        async def transaction():
            yield connection
            if not queries:rt.friends.discard(pair);social.invalidate(pair)
        db=type('DB',(),{'transaction':staticmethod(transaction)})();social=Social(db,rt)
        ids=sorted([uuid4(),uuid4()]);created={'revision':1,'accepted_at':'exact-created-timestamp'}
        async def rows(*args):return [{'id':ids[0],'public_ref':a},{'id':ids[1],'public_ref':b}]
        async def row(_,sql,args):
            if 'INSERT INTO' in sql:return created
            if 'count(*)' in sql:return {'n':0}
            return None
        with patch('app.services.social.many',rows),patch('app.services.social.one',row):
            with self.assertRaises(DomainError):await social.save_friend(a,b,{ref:rt.people[ref].revision for ref in pair})
        self.assertEqual(len(queries),1);self.assertIn('accepted_at=%s',queries[0][0]);self.assertEqual(queries[0][1][-1],created['accepted_at'])

class GuestPreferences(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.rt,self.clock=actor();self.identity=FakeIdentity(self.rt);self.identity.db=None;self.identity.realtime=self.rt;self.principal=self.identity.add()
        self.principal.account.update(professional_consent=True,professional={},preferences={})
        self.record=self.identity.guests[self.identity.security.digest('guest',self.principal.token)];self.record['profile']=self.principal.account
        self.controls=AccountControls(self.identity,{key:['one','two'] for key in ('industry','role','experience','interests','topics')})
    async def test_optional_guest_values_are_ram_only_and_revision_checked(self):
        dto=Preferences(expected_revision=1,gender='everyone',professional_enabled=True,industry=['one'],interests=['one','two'])
        result=await self.controls.preferences(self.principal,dto)
        self.assertEqual(result['scope'],'current_identity');self.assertEqual(self.record['profile']['professional']['industry'],['one']);self.assertIsNone(self.identity.db)
        with self.assertRaises(DomainError):await self.controls.preferences(self.principal,dto)
    async def test_guest_optional_consent_and_catalog_values_enforced(self):
        with self.assertRaises(DomainError):await self.controls.preferences(self.principal,Preferences(expected_revision=1,industry=['uncontrolled']))
        self.record['profile']['professional_consent']=False
        with self.assertRaises(DomainError):await self.controls.preferences(self.principal,Preferences(expected_revision=1,industry=['one']))
        with self.assertRaises(DomainError):await self.controls.preferences(self.principal,Preferences(expected_revision=1,gender='female'))
        await self.controls.preferences(self.principal,Preferences(expected_revision=1))
        self.assertEqual(self.record['profile']['professional'],{})
    async def test_guest_assigned_name_cannot_be_changed(self):
        values={key:self.principal.account[key] for key in ('display_name','gender','topic_id','bio')}
        with self.assertRaises(DomainError) as error:await self.controls.profile(self.principal,ProfileUpdate(**(values|{'display_name':'Chosen name'}),expected_revision=1))
        self.assertEqual(error.exception.code,'GUEST_NAME_FIXED')
