from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import os,unittest
from app.settings import Settings
from ops.nt import save_private,lock_check,GateError
class Configuration(unittest.TestCase):
    def test_existing_secret_never_rotates_on_rerun(self):
        with TemporaryDirectory() as root:
            p=Path(root)/'secret';save_private(p,'first');save_private(p,'second')
            self.assertEqual(p.read_text(),'first');self.assertEqual(p.stat().st_mode&0o777,0o600)
    def test_production_refused(self):
        with patch.dict(os.environ,{'APP_ENV':'production'}):
            with self.assertRaises(ValueError):Settings.load()
    def test_insecure_dsn_permissions_rejected(self):
        with TemporaryDirectory() as root:
            p=Path(root)/'dsn';p.write_text('private');p.chmod(0o644)
            with patch.dict(os.environ,{'APP_ENV':'local','DATABASE_DSN_FILE':str(p)}):
                with self.assertRaises(ValueError):Settings.load()
