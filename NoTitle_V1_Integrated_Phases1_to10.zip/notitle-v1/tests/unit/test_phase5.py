"""Safety business rules and fail-closed scripted-I/O fault tests.

These tests use the real bounded actor and cryptography. Scripted DB responses
exercise release ordering; they do not qualify PostgreSQL ACLs or locking.
"""
import asyncio
from contextlib import asynccontextmanager
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock,patch
from uuid import uuid4
from app.coordinator.core import Coordinator
from app.domain.conversation import ConversationActor
from app.domain.errors import DomainError
from app.domain.metrics import Metrics
from app.domain.security import Security,safe_staff_reply
from app.http.models import ReportPrepare,Report
from app.services.moderation import Moderation
from app.services.primitives import Principal
from app.services.support import Support

class Database:
    def __init__(self):self.connection=SimpleNamespace(execute=AsyncMock())
    @asynccontextmanager
    async def transaction(self,role='support'):yield self.connection

def setup():
    clock=[100.];rt=ConversationActor(Coordinator(1),Metrics(),clock=lambda:clock[0],wall=lambda:1700000000.+clock[0])
    for ref in ('a'*32,'b'*32):
        rt.enter(ref,{'display_name':'Person '+ref[0],'gender':'other','topic_id':'general','bio':''});rt.connect(ref)
    rt.start('a'*32,'b'*32)
    identity=SimpleNamespace(realtime=rt,resolve=AsyncMock())
    security=Security(b'h'*32,b'e'*32)
    return Support(Database(),security,identity),rt,clock,Principal('guest','a'*32,'t'*43)

class SafetySnapshot(unittest.TestCase):
    def test_freeze_before_end_and_no_stable_peer_identity_projection(self):
        support,rt,clock,p=setup();rt.text(p.ref,'Selected evidence')
        handle=rt.describe(p.ref)['peer']['peer_handle'];interaction=rt.person(p.ref).interaction
        view=support.prepare_report(p,handle,interaction,True)
        self.assertTrue(view['locally_blocked']);self.assertIsNone(rt.person(p.ref).interaction)
        self.assertEqual(view['messages'][0]['sender'],'me');self.assertNotIn(p.ref,str(view))
        self.assertNotIn('b'*32,str(view));self.assertEqual(view['messages'][0]['text'],'Selected evidence')
        self.assertFalse(rt.interactions);self.assertTrue(rt.blocked('a'*32,'b'*32))
        self.assertEqual(rt.snapshots[view['snapshot_ref']]['messages'][0]['text'],'Selected evidence')

    def test_ended_report_contains_attribution_without_reconstructing_text(self):
        support,rt,clock,p=setup();rt.text(p.ref,'Erased ordinary text')
        handle=rt.describe(p.ref)['peer']['peer_handle'];interaction=rt.person(p.ref).interaction
        rt.end(p.ref);view=support.prepare_report(p,handle,interaction,True)
        self.assertTrue(view['attribution_only']);self.assertEqual(view['messages'],[])
        self.assertEqual(rt.snapshots[view['snapshot_ref']]['bytes'],0)

    def test_unowned_handle_and_expired_attribution_fail(self):
        support,rt,clock,p=setup();handle=rt.describe(p.ref)['peer']['peer_handle'];interaction=rt.person(p.ref).interaction
        with self.assertRaises(DomainError):support.prepare_report(p,'c'*32,interaction,True)
        rt.end(p.ref);clock[0]+=601
        with self.assertRaises(DomainError):support.prepare_report(p,handle,interaction,True)

    def test_one_snapshot_per_identity_and_two_minute_cleanup(self):
        support,rt,clock,p=setup();first=support.prepare_report(p,block=False);second=support.prepare_report(p,block=False)
        self.assertNotIn(first['snapshot_ref'],rt.snapshots);self.assertEqual(len(rt.snapshots),1)
        clock[0]+=121;rt.tick();self.assertNotIn(second['snapshot_ref'],rt.snapshots)

    def test_staff_reply_rejects_support_email_and_secret_solicitation(self):
        for value in ('Contact staff@example.test','Please send your recovery code','Provide your card number'):
            with self.assertRaises(DomainError):safe_staff_reply(value)
        safe_staff_reply('Your request is being reviewed. Do not send sensitive credentials.')

    def test_strict_report_prepare_rejects_unknown_fields(self):
        with self.assertRaises(ValueError):ReportPrepare(peer_handle='a'*32,secret='s')
        self.assertTrue(ReportPrepare().block)

class StaffRelease(unittest.IsolatedAsyncioTestCase):
    async def test_audit_failure_releases_no_plaintext(self):
        support,rt,clock,p=setup();staff=Principal('staff','staff','s'*43,account_id='id',grants=frozenset({'cases.read','cases.triage'}))
        case={'id':'case','public_ref':'ref','assigned_staff_id':None,'last_sequence':1}
        support.lock_staff_authority=AsyncMock();support.audit=AsyncMock(side_effect=RuntimeError('audit unavailable'))
        support.revalidate_read=AsyncMock();decrypt=patch.object(support.security,'decrypt',wraps=support.security.decrypt)
        with patch('app.services.support.one',AsyncMock(return_value=case)),patch('app.services.support.many',AsyncMock(return_value=[{'sequence':1}])),decrypt as plain:
            with self.assertRaises(RuntimeError):await support.messages(staff,'ref',request_id='request')
            plain.assert_not_called();support.revalidate_read.assert_not_awaited()

    async def test_grant_revocation_after_audit_releases_no_plaintext(self):
        support,rt,clock,p=setup();staff=Principal('staff','staff','s'*43,account_id='id',grants=frozenset({'cases.read','cases.triage'}))
        case={'id':'case','public_ref':'ref','assigned_staff_id':None,'last_sequence':1}
        support.lock_staff_authority=AsyncMock();support.audit=AsyncMock();support.revalidate_read=AsyncMock(side_effect=DomainError('AUTHENTICATION_REQUIRED',401))
        with patch('app.services.support.one',AsyncMock(return_value=case)),patch('app.services.support.many',AsyncMock(return_value=[{'sequence':1}])),patch.object(support.security,'decrypt') as plain:
            with self.assertRaises(DomainError):await support.messages(staff,'ref',request_id='request')
            plain.assert_not_called();support.audit.assert_awaited_once()

    async def test_staff_mutation_lock_rejects_missing_or_revoked_session(self):
        support,rt,clock,p=setup();staff=Principal('staff','staff','s'*43,account_id='id',grants=frozenset({'cases.reply'}))
        with patch('app.services.support.one',AsyncMock(return_value=None)):
            with self.assertRaises(DomainError):await support.lock_staff_authority(support.db.connection,staff)
        with patch('app.services.support.one',AsyncMock(return_value={'staff_id':'id'})),patch('app.services.support.many',AsyncMock(return_value=[])):
            with self.assertRaises(DomainError):await support.lock_staff_authority(support.db.connection,staff)

    def test_independent_appeal_reviewer_and_owned_subject(self):
        staff=Principal('staff','staff','s',account_id='reviewer')
        case={'category':'appeal','account_id':'subject'};account={'id':'subject'}
        with self.assertRaises(DomainError):Moderation.independent_reviewer(staff,case,account,{'staff_id':'reviewer'})
        with self.assertRaises(DomainError):Moderation.independent_reviewer(staff,case,{'id':'outsider'},{'staff_id':'original'})
        with self.assertRaises(DomainError):Moderation.independent_reviewer(staff,case,account,None)
        Moderation.independent_reviewer(staff,case,account,{'staff_id':'original'})

class ReportRetry(unittest.IsolatedAsyncioTestCase):
    async def test_committed_nonce_recovers_without_any_live_snapshot(self):
        support,rt,clock,p=setup()
        dto=Report(category='safety',subject='Report',body='An allegation',reason='harassment',snapshot_ref='e'*32,selected_ids=['c'*32],client_nonce=str(uuid4()))
        payload=dto.model_dump(exclude={'proof','snapshot_ref','selected_ids','reason','block','attribution_only_accepted'})
        payload['report']={'snapshot_ref':dto.snapshot_ref,'reason':dto.reason,'selected_ids':dto.selected_ids}
        result={'case_ref':'d'*32,'status':'open'}
        with patch('app.services.support.one',AsyncMock(return_value={'keyed_digest':support.digest(payload),'result':result})):
            self.assertEqual(await support.report_retry(p,dto),result)
        self.assertFalse(rt.snapshots)

    async def test_conflicting_nonce_cannot_recover_an_unrelated_case(self):
        support,rt,clock,p=setup()
        dto=Report(category='safety',subject='Report',body='Changed allegation',reason='other',snapshot_ref='e'*32,client_nonce=str(uuid4()))
        with patch('app.services.support.one',AsyncMock(return_value={'keyed_digest':'different','result':{'case_ref':'d'*32}})):
            with self.assertRaises(DomainError):await support.report_retry(p,dto)

class GuestModeration(unittest.IsolatedAsyncioTestCase):
    """Scripted SQL boundaries; no claim of live PostgreSQL race qualification."""
    def fixture(self,category='safety'):
        import sys,types
        from datetime import datetime,timezone,timedelta
        from unittest.mock import Mock
        from app.http.models import Decision
        support,rt,clock,p=setup();ref='b'*32
        guest={'ref':ref,'profile':{'safety_revision':3},'until':__import__('time').monotonic()+1800,'absolute':__import__('time').monotonic()+86400}
        support.identity.guests={'hashed-token':guest};support.identity.fence=Mock()
        support.lock_staff_authority=AsyncMock()
        service=Moderation(support.db,support.security,support.identity,support,None)
        staff=Principal('staff','reviewer','s'*43,account_id='reviewer',grants=frozenset({'safety.decide','cases.triage'}),mfa_at=datetime.now(timezone.utc))
        case={'id':'case-id','public_ref':'c'*32,'category':category,'account_id':None,'assigned_staff_id':None,'version':2,'parent_case_id':None}
        dto=Decision(case_ref=case['public_ref'],subject_ref=ref,action='restrict',reason_code='harassment',duration_hours=24,reason='Reviewed selected evidence')
        payload=dto.model_dump();preview={'actor_id':'reviewer','consumed_at':None,'expires_at':datetime.now(timezone.utc)+timedelta(seconds=120),
            'payload':payload,'payload_digest':support.security.digest('preview',__import__('app.domain.security',fromlist=['canonical']).canonical(payload).decode()),
            'revisions':{'target_kind':'guest','safety':3,'case':2,'last_decision':None}}
        # Jsonb wrapping only: all SQL behavior is explicitly scripted below.
        class Jsonb:
            def __init__(self,obj):self.obj=obj
        modules={name:types.ModuleType(name) for name in ('psycopg','psycopg.types','psycopg.types.json')}
        modules['psycopg.types.json'].Jsonb=Jsonb
        return support,service,staff,case,dto,preview,guest,patch.dict(sys.modules,modules)

    async def test_live_guest_preview_captures_kind_and_revision(self):
        support,service,staff,case,dto,preview,guest,jsonb=self.fixture()
        with jsonb,patch('app.services.moderation.one',AsyncMock(side_effect=[case,None,None])):
            result=await service.preview(staff,dto)
        self.assertEqual(result['target_kind'],'guest')
        stored=support.db.connection.execute.await_args_list[-1].args[1][-1].obj
        self.assertEqual(stored['target_kind'],'guest');self.assertEqual(stored['safety'],3)
        self.assertIn('subject:'+dto.subject_ref,str(support.db.connection.execute.await_args_list))

    async def test_conversion_invalidates_pending_guest_preview(self):
        support,service,staff,case,dto,preview,guest,jsonb=self.fixture()
        with jsonb,patch('app.services.moderation.one',AsyncMock(side_effect=[preview,case,{'id':'new-account','safety_revision':3}])):
            with self.assertRaises(DomainError) as error:await service.confirm(staff,'p'*32,'request')
        self.assertEqual(error.exception.code,'PREVIEW_STALE');support.identity.fence.assert_not_called()
        self.assertEqual(guest['profile']['safety_revision'],3)
        self.assertFalse(any('INSERT INTO nt.restrictions' in call.args[0] for call in support.db.connection.execute.await_args_list))

    async def test_guest_restriction_is_durable_before_ram_fence(self):
        support,service,staff,case,dto,preview,guest,jsonb=self.fixture()
        with jsonb,patch('app.services.moderation.one',AsyncMock(side_effect=[preview,case,None,None])):
            result=await service.confirm(staff,'p'*32,'request')
        self.assertEqual(result['action'],'restrict');self.assertEqual(guest['profile']['safety_revision'],4)
        support.identity.fence.assert_called_once_with(dto.subject_ref,'safety_decision')
        statements=[call.args[0] for call in support.db.connection.execute.await_args_list]
        self.assertTrue(any('INSERT INTO nt.restrictions' in query for query in statements))
        self.assertFalse(any('INSERT INTO nt.account_notices' in query for query in statements))
        self.assertFalse(any('UPDATE nt.accounts SET safety_revision' in query for query in statements))

    async def test_concurrent_guest_decision_invalidates_other_preview(self):
        support,service,staff,case,dto,preview,guest,jsonb=self.fixture()
        with jsonb,patch('app.services.moderation.one',AsyncMock(side_effect=[preview,case,None,{'id':uuid4(),'staff_id':'other'}])):
            with self.assertRaises(DomainError) as error:await service.confirm(staff,'p'*32,'request')
        self.assertEqual(error.exception.code,'PREVIEW_STALE');support.identity.fence.assert_not_called()

    async def test_guest_appeal_uses_root_case_sender_provenance(self):
        support,service,staff,case,dto,preview,guest,jsonb=self.fixture('appeal')
        case['parent_case_id']='original-case'
        with patch('app.services.moderation.one',AsyncMock(return_value={'sender_ref':dto.subject_ref})) as query:
            await service.appeal_owner(support.db.connection,case)
        self.assertEqual(query.await_args.args[2],('original-case',))
        target,_=service.guest_target(dto.subject_ref)
        Moderation.independent_reviewer(staff,case,target,{'staff_id':'original-reviewer'})
        with self.assertRaises(DomainError):Moderation.independent_reviewer(staff,case,target,{'staff_id':'reviewer'})
        case['guest_ref']='unrelated'
        with self.assertRaises(DomainError):Moderation.independent_reviewer(staff,case,target,{'staff_id':'original-reviewer'})

    async def test_failed_commit_does_not_announce_or_bump_guest_revision(self):
        support,service,staff,case,dto,preview,guest,jsonb=self.fixture()
        @asynccontextmanager
        async def rollback(role='private'):
            yield support.db.connection
            raise RuntimeError('commit failed')
        support.db.transaction=rollback
        with jsonb,patch('app.services.moderation.one',AsyncMock(side_effect=[preview,case,None,None])):
            with self.assertRaises(RuntimeError):await service.confirm(staff,'p'*32,'request')
        self.assertEqual(guest['profile']['safety_revision'],3);support.identity.fence.assert_not_called()
