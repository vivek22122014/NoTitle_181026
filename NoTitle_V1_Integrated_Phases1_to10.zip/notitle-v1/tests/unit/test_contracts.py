import json
import unittest
from uuid import uuid4
from pydantic import TypeAdapter,ValidationError
from app.contracts import Peer,TextPayload,Command
class Contracts(unittest.TestCase):
    def test_peer_rejects_private_fields(self):
        value=dict(peer_handle=uuid4(),display_name="Peer",gender="male",topic_id="general",bio="")
        self.assertEqual(len(Peer(**value).model_dump()),5)
        for key in ("username","account_id","premium","industry","ip"):
            with self.assertRaises(ValidationError):Peer(**value,**{key:"private"})
    def test_utf8_and_character_bounds(self):
        with self.assertRaises(ValidationError):TextPayload(text="🙂"*1800)
        with self.assertRaises(ValidationError):TextPayload(text="x"*2001)
        self.assertEqual(TextPayload(text="safe").text,"safe")
    def test_strict_event_discriminator_and_epoch(self):
        event={"protocol_version":1,"command_id":str(uuid4()),"owner_epoch":1,"socket_generation":1,
               "interaction_epoch":1,"type":"text.send","payload":{"text":"hello"}}
        adapter=TypeAdapter(Command)
        adapter.validate_json(json.dumps(event))
        for key,value in [("owner_epoch","1"),("type","admin.grant"),("protocol_version",2)]:
            with self.assertRaises(ValidationError):adapter.validate_json(json.dumps({**event,key:value}))
