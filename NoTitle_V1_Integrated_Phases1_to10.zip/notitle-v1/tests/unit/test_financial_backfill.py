"""Worker scheduling/failure isolation; not provider or PostgreSQL qualification."""
import unittest
from contextlib import asynccontextmanager
from types import SimpleNamespace
from unittest.mock import AsyncMock,Mock,patch
from app.jobs.worker import Worker

class FinancialBackfill(unittest.IsolatedAsyncioTestCase):
    async def test_periodic_backfill_is_bounded_and_transport_failure_does_not_stop_worker(self):
        connection=SimpleNamespace(execute=AsyncMock())
        @asynccontextmanager
        async def transaction(role):
            self.assertEqual(role,'jobs');yield connection
        identity=SimpleNamespace(prune=Mock())
        billing=SimpleNamespace(enqueue_backfill=AsyncMock(side_effect=[RuntimeError('unavailable'),None]))
        worker=Worker(SimpleNamespace(transaction=transaction),{},SimpleNamespace(),identity,billing=billing)
        worker.last_legal=worker.last_flush=worker.last_retention=1000000
        with patch('app.jobs.worker.one',AsyncMock(return_value=None)),patch('app.jobs.worker.time.monotonic',side_effect=[61,90,122]):
            await worker.step();self.assertEqual(worker.last_error,'PAYMENT_BACKFILL_FAILED')
            await worker.step();self.assertEqual(billing.enqueue_backfill.await_count,1)
            await worker.step();self.assertEqual(billing.enqueue_backfill.await_count,2)
        self.assertEqual(identity.prune.call_count,3)
