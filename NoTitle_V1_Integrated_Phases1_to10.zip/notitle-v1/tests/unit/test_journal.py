from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from uuid import uuid4
import unittest
from app.domain.journal import Journal,JournalCorrupt,exclusive,ZERO

class Journals(unittest.TestCase):
    def setUp(self):
        self.tmp=TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.j=Journal(self.root/"local",self.root/"independent",b"a"*32,b"b"*32)
        self.subject=str(uuid4())
    def payload(self,action="delete"):
        return {"operation_id":str(uuid4()),"subject_ref":self.subject,"action":action}
    def test_delete_survives_old_database(self):
        head=self.j.append(self.payload())
        recovered_database={self.subject:{"active":True}}
        for key,state in self.j.replay(head).items():
            if state["deleted"]:recovered_database[key]["active"]=False
        self.assertFalse(recovered_database[self.subject]["active"])
    def test_no_plaintext_subject_in_ciphertext(self):
        self.j.append(self.payload())
        self.assertNotIn(self.subject.encode(),next(self.j.replica.glob('*.record')).read_bytes())
    def test_tamper_fails_closed(self):
        head=self.j.append(self.payload());p=next(self.j.replica.glob('*.record'))
        raw=bytearray(p.read_bytes());raw[len(raw)//2]^=1;p.write_bytes(raw)
        with self.assertRaises(JournalCorrupt):self.j.replay(head)
    def test_truncation_fails_against_independent_anchor(self):
        head=self.j.append(self.payload());next(self.j.replica.glob('*.record')).unlink()
        with self.assertRaises(JournalCorrupt):self.j.replay(head)
    def test_anchor_tamper_rejected(self):
        head=self.j.append(self.payload());head['seq']=0;head['tip']=ZERO
        with self.assertRaises(JournalCorrupt):self.j.replay(head)
    def test_idempotent_retry_and_nonce_conflict(self):
        payload=self.payload();head=self.j.append(payload)
        self.assertEqual(head,self.j.append(payload))
        with self.assertRaises(JournalCorrupt):self.j.append({**payload,"action":"hold"})
    def test_replica_failure_is_not_acknowledged_then_safe_retry(self):
        payload=self.payload()
        def fail(path,data):
            if path.parent==self.j.replica:raise OSError("offline")
            return exclusive(path,data)
        with patch('app.domain.journal.exclusive',side_effect=fail):
            with self.assertRaises(OSError):self.j.append(payload)
        head=self.j.append(payload)
        self.assertEqual(head['seq'],1)
        self.assertTrue(self.j.replay(head)[self.subject]['deleted'])
    def test_hold_release_never_resurrects_deleted(self):
        self.j.append(self.payload());self.j.append(self.payload('hold'))
        head=self.j.append(self.payload('release_hold'))
        self.assertEqual(self.j.replay(head)[self.subject],{'deleted':True,'held':False})
    def test_missing_middle_rejected(self):
        self.j.append(self.payload());head=self.j.append(self.payload('hold'))
        sorted(self.j.replica.glob('*.record'))[0].unlink()
        with self.assertRaises(JournalCorrupt):self.j.replay(head)

class ReceiptRestore(unittest.TestCase):
    def test_delete_receipt_authority_survives_old_database(self):
        with TemporaryDirectory() as directory:
            root=Path(directory);journal=Journal(root/'local',root/'remote',b'x'*32,b'y'*32)
            subject=str(uuid4());reference=uuid4().hex
            anchor=journal.append({'operation_id':str(uuid4()),'subject_ref':subject,'action':'delete','receipt_ref':reference,'receipt_verifier':'a'*64})
            self.assertEqual(journal.replay(anchor)[subject]['receipts'][reference],'a'*64)
