import base64
import hashlib
import hmac
import random
import struct
import unittest
from unittest.mock import patch
from app.domain.security import Security,normalize_username,totp_counter,safe_staff_reply
from app.domain.errors import DomainError
from app.domain.ledger import Lot,advance,hold,settle
from app.domain.metrics import Metrics,suppress,HISTOGRAMS
from app.domain.realtime import Realtime
from app.domain.media import candidate,sdp
from app.coordinator.core import Coordinator
from app.services.primitives import Reservations,Limiter

class SecurityTests(unittest.TestCase):
    def setUp(self):self.security=Security(b'h'*32,b'e'*32)
    def test_encryption_binds_scope_and_is_randomized(self):
        left=self.security.encrypt('case:1','private message');right=self.security.encrypt('case:1','private message')
        self.assertNotEqual(left,right);self.assertNotIn(b'private message',left)
        self.assertEqual(self.security.decrypt('case:1',left),'private message')
        with self.assertRaises(Exception):self.security.decrypt('case:2',left)
        with self.assertRaises(Exception):self.security.decrypt('case:1',left[:-1]+bytes([left[-1]^1]))
    def test_credentials_are_purpose_bound(self):
        self.assertFalse(self.security.verify('account','secret',self.security.digest('receipt','secret')))
        self.assertTrue(self.security.verify('account','secret',self.security.digest('account','secret')))
    def test_cursor_is_scoped_and_expires(self):
        cursor=self.security.cursor('case:a',{'after':4},100)
        self.assertEqual(self.security.open_cursor('case:a',cursor,99),{'after':4})
        for scope,now in [('case:b',99),('case:a',101)]:
            with self.assertRaises(DomainError):self.security.open_cursor(scope,cursor,now)
    def test_username_rules(self):
        self.assertEqual(normalize_username('User_1'),'user_1')
        for value in ('admin','ab','email@example.test','has spaces','x'*25):
            with self.assertRaises(DomainError):normalize_username(value)
    def test_totp_cannot_be_replayed(self):
        secret=base64.b32encode(b'12345678901234567890').decode()
        digest=hmac.new(b'12345678901234567890',struct.pack('>Q',1),hashlib.sha1).digest();offset=digest[-1]&15
        code=str((struct.unpack('>I',digest[offset:offset+4])[0]&0x7fffffff)%1000000).zfill(6)
        self.assertEqual(totp_counter(secret,code,-1,30),1)
        with self.assertRaises(DomainError):totp_counter(secret,code,1,30)
    def test_staff_reply_filter(self):
        safe_staff_reply('Please provide your purchase reference.')
        for value in ('Write to operator@example.test','Please send your password','Share your recovery code'):
            with self.assertRaises(DomainError):safe_staff_reply(value)
    def test_prepare_requires_saved_proof_exact_scope(self):
        reservations=Reservations(self.security,lambda:0)
        receipt=reservations.prepare('guest:a','case','nonce')
        self.assertEqual(reservations.proof('guest:a','case',receipt['reservation_id'],receipt['secret'],True)['kind'],'case')
        for scope,saved in [('guest:b',True),('guest:a',False)]:
            with self.assertRaises(DomainError):reservations.proof(scope,'case',receipt['reservation_id'],receipt['secret'],saved)
        self.assertNotIn('secret',reservations.items[receipt['reservation_id']])
    def test_rate_limiter_is_bounded_without_evicting_active_limits(self):
        limiter=Limiter(lambda:0,max_keys=1);limiter.take('one',1,60)
        for key in ('one','two'):
            with self.assertRaises(DomainError):limiter.take(key,1,60)

class LedgerTests(unittest.TestCase):
    def test_fifo_and_origin_hold(self):
        first=Lot('a',1,100,available=100);second=Lot('b',2,200,available=200)
        advance([second,first],0,80);self.assertEqual((first.available,second.available),(20,200))
        hold(first,20,'payment_error');advance([first,second],80,100)
        self.assertEqual((first.held,second.available),(20,180))
        settle(first,20,False);advance([first,second],100,105)
        self.assertEqual((first.available,second.available),(15,180))
    def test_required_success_revokes_only_origin(self):
        first=Lot('a',1,100,available=100);other=Lot('b',2,200,available=200)
        hold(first,100,'statutory_remedy');settle(first,100,True)
        self.assertEqual(first.revoked,100);self.assertEqual(other.available,200)
        with self.assertRaises(DomainError):settle(first,100,True)
    def test_voluntary_and_overhold_refused(self):
        lot=Lot('a',1,100,available=100)
        for amount,basis in [(101,'payment_error'),(1,'change_of_mind'),(-1,'statutory_remedy')]:
            with self.assertRaises(DomainError):hold(lot,amount,basis)
    def test_clock_rollback_never_creates_time(self):
        lot=Lot('a',1,100,available=100)
        self.assertEqual(advance([lot],100,90),100);self.assertEqual(lot.available,100)
    def test_random_conservation(self):
        rng=random.Random(12)
        lot=Lot('a',1,10000,available=10000);clock=0
        for _ in range(500):
            next_clock=clock+rng.randint(0,10);advance([lot],clock,next_clock);clock=next_clock
            amount=rng.randint(0,lot.available);hold(lot,amount,'payment_error')
            settle(lot,amount,rng.choice([True,False]));lot.check()

class MatchingTests(unittest.TestCase):
    def setUp(self):
        self.t=0;self.clock=lambda:self.t
        self.authority=Coordinator(1,self.clock);self.metrics=Metrics();self.rt=Realtime(self.authority,self.metrics,self.clock,lambda:1000+self.t)
    def add(self,name,gender='other',premium=0,topic='general'):
        self.rt.enter(name,{'display_name':name*2,'gender':gender,'topic_id':topic,'bio':''},premium_until=premium)
        self.rt.connect(name)
    def tick(self,seconds):self.t+=seconds;self.authority.last_proof=self.t;self.rt.tick()
    def test_mutual_compatibility_and_no_head_blocking(self):
        self.add('a','male',2000);self.add('b','female');self.add('c','female')
        self.rt.join('a','male');self.rt.join('b');self.rt.join('c');self.rt.match()
        self.assertIn('a',self.rt.waiters);self.assertEqual(self.rt.people['b'].interaction,self.rt.people['c'].interaction)
    def test_free_cannot_use_gender_filter(self):
        self.add('a')
        with self.assertRaises(DomainError):self.rt.join('a','female')
    def test_oldest_compatible_anchor_is_served(self):
        for name in ('a','b','c'):self.add(name)
        self.rt.join('a');self.t=1;self.authority.last_proof=1;self.rt.join('b');self.rt.join('c');self.rt.match()
        self.assertIsNotNone(self.rt.people['a'].interaction);self.assertEqual(len(self.rt.waiters),1)
    def test_end_clears_text_and_prevents_immediate_repeat(self):
        self.add('a');self.add('b');self.rt.start('a','b');self.rt.text('a','private')
        self.rt.end('a');self.assertFalse(self.rt.interactions)
        self.rt.join('a');self.rt.join('b');self.rt.match();self.assertEqual(len(self.rt.waiters),2)
        self.tick(4);self.assertEqual(len(self.rt.interactions),1)
    def test_text_ring_and_peer_projection(self):
        self.add('a');self.add('b');interaction=self.rt.start('a','b')
        for i in range(40):self.rt.text('a',str(i));self.rt.drain('a');self.rt.drain('b')
        self.assertEqual(len(interaction.messages),30)
        self.assertEqual(set(self.rt.peer('a')),{'peer_handle','display_name','gender','topic_id','bio'})
    def test_snapshot_is_separate_after_end(self):
        self.add('a');self.add('b');self.rt.start('a','b');self.rt.text('a','selected')
        snapshot=self.rt.prepare_report('a');self.rt.end('a')
        self.assertEqual(self.rt.snapshots[snapshot['snapshot_ref']]['messages'][0]['text'],'selected')
        self.tick(121);self.assertFalse(self.rt.snapshots)
    def test_block_removes_live_contact_and_prevents_matching(self):
        self.add('a');self.add('b');self.rt.start('a','b');self.rt.block('a','b')
        self.rt.join('a');self.rt.join('b');self.tick(5)
        self.assertEqual(len(self.rt.waiters),2);self.assertFalse(self.rt.interactions)
    def test_report_block_survives_peer_end_but_requires_own_live_snapshot(self):
        self.add('a');self.add('b');self.add('c');self.rt.start('a','b')
        snapshot=self.rt.prepare_report('a');self.rt.end('b')
        with self.assertRaises(DomainError):self.rt.block('a','b')
        with self.assertRaises(DomainError):self.rt.block('c','b',snapshot['snapshot_ref'])
        self.rt.block('a','b',snapshot['snapshot_ref']);self.assertTrue(self.rt.blocked('a','b'))
        self.tick(121)
        with self.assertRaises(DomainError):self.rt.block('a','b',snapshot['snapshot_ref'])
    def test_offline_known_friend_can_be_blocked(self):
        self.add('a');self.rt.friends.add(self.rt.pair('a','offline'))
        self.rt.block('a','offline');self.assertTrue(self.rt.blocked('a','offline'))
        self.assertFalse(self.rt.friends)
    def test_premium_expiry_pauses_without_broadening(self):
        self.add('a','male',1001);self.rt.join('a','female');self.tick(2)
        self.assertNotIn('a',self.rt.waiters)
    def test_audio_needs_mutual_consent_and_disconnect_tears_down(self):
        self.add('a');self.add('b');interaction=self.rt.start('a','b');self.rt.call_request('a')
        with self.assertRaises(DomainError):self.rt.call_respond('a',True)
        self.rt.call_respond('b',True);self.rt.disconnect('a')
        self.assertEqual(interaction.call['state'],'teardown');self.assertEqual(len(self.rt.media_ends),1)
    def test_takeover_is_explicit(self):
        self.add('a')
        with self.assertRaises(DomainError):self.rt.connect('a')
        self.assertEqual(self.rt.connect('a',True,1),2)
    def test_slow_receiver_disconnects_at_bound(self):
        self.add('a')
        for _ in range(100):self.rt.emit('a','test',{})
        self.assertFalse(self.rt.people['a'].connected);self.assertLessEqual(len(self.rt.people['a'].events),64)

class MediaTests(unittest.TestCase):
    def test_candidate_only_allows_exact_relay(self):
        value='candidate:1 1 udp 100 203.0.113.1 49152 typ relay raddr 192.168.1.1 rport 3000 generation 0'
        clean=candidate(value,'203.0.113.1');self.assertNotIn('192.168',clean)
        for altered in [value.replace('typ relay','typ host'),value.replace('203.0.113.1','203.0.113.2'),value.replace('49152','80')]:
            with self.assertRaises(DomainError):candidate(altered,'203.0.113.1')
    def test_video_and_data_are_rejected(self):
        for value in ('m=video 9 UDP/TLS/RTP/SAVPF 96','m=application 9 UDP/DTLS/SCTP webrtc-datachannel'):
            with self.assertRaises(DomainError):sdp(value,'203.0.113.1')

class MetricsTests(unittest.TestCase):
    def test_fixed_histogram_disjoint_bins(self):
        metrics=Metrics()
        for value in (0,5,6,100000):metrics.add('api_latency_ms',value)
        _,(_,total,bins)=next(iter(metrics.drain().items()))
        self.assertEqual(sum(bins),4);self.assertEqual(bins[0],2);self.assertEqual(bins[1],1);self.assertEqual(bins[-1],1)
        self.assertFalse(metrics.values)
    def test_dynamic_labels_and_nonfinite_values_rejected(self):
        metrics=Metrics()
        for name,value in [('user:123',1),('registrations',float('nan')),('matches',-1)]:
            with self.assertRaises(DomainError):metrics.add(name,value)
    def test_small_cohort_has_no_hidden_value(self):
        self.assertIsNone(suppress(9)['value']);self.assertEqual(suppress(10)['value'],10)



class LegalTests(unittest.TestCase):
    def pack(self):
        return {'state':'reviewed','review_evidence_ref':'synthetic-test-evidence',
                'reviewed_categories':['general','payment','safety','privacy','appeal','security'],
                'rules':[{'id':'fixture','version':'1','authority_ref':'synthetic-test-only',
                          'categories':['privacy'],'automatic':True,'effective_from':'2026-01-01T00:00:00+00:00',
                          'effective_until':'2027-01-01T00:00:00+00:00','acknowledge_seconds':60,'act_seconds':120}]}
    def test_deadlines_bind_original_receipt_not_later_classification(self):
        from app.domain.legal import LegalRules
        from datetime import datetime,timezone,timedelta
        rules=LegalRules(self.pack());received=datetime(2026,2,1,tzinfo=timezone.utc)
        row=rules.applicable('privacy',received)[0];ack,act=rules.deadlines(row,received)
        self.assertEqual(ack,received+timedelta(seconds=60));self.assertEqual(act,received+timedelta(seconds=120))
        self.assertFalse(rules.applicable('general',received))
        self.assertFalse(rules.applicable('privacy',datetime(2027,1,1,tzinfo=timezone.utc)))
    def test_unreviewed_and_invalid_clocks_are_rejected(self):
        from app.domain.legal import LegalRules
        for name,value in [('state','draft'),('reviewed_categories',['privacy'])]:
            pack=self.pack();pack[name]=value
            with self.assertRaises(DomainError):LegalRules(pack)
        pack=self.pack();pack['rules'][0]['act_seconds']=1
        with self.assertRaises(DomainError):LegalRules(pack)
        self.assertFalse(LegalRules().reviewed)

class ReceiptTests(unittest.TestCase):
    def pack(self):
        return {'state':'reviewed','review_evidence_ref':'synthetic-fixture','merchant':{'legal_name':'Test Fixture Only','postal_address':'Synthetic laboratory','contact_route':'https://example.test/rights'},'plans':{'Short3':{'version':'fixture-1','tax_rule':'synthetic-test-zero','net_paise':9900,'taxes':[]}}}
    def test_receipt_requires_review_and_exact_conservation(self):
        from app.domain.receipts import ReceiptConfiguration
        row=ReceiptConfiguration(self.pack()).snapshot('Short3','fixture-1','synthetic-test-zero',9900)
        self.assertEqual(row['net_paise'],9900);self.assertEqual(row['document_kind'],'payment_receipt')
        pack=self.pack();pack['plans']['Short3']['net_paise']=9800
        with self.assertRaises(DomainError):ReceiptConfiguration(pack)
    def test_wrong_version_or_annual_cannot_use_receipt_configuration(self):
        from app.domain.receipts import ReceiptConfiguration
        config=ReceiptConfiguration(self.pack())
        with self.assertRaises(DomainError):config.snapshot('Short3','wrong','synthetic-test-zero',9900)
        pack=self.pack();pack['plans']['Annual365']=pack['plans'].pop('Short3')
        with self.assertRaises(DomainError):ReceiptConfiguration(pack)

class ProtocolTests(unittest.TestCase):
    def test_live_end_contract_and_boolean_epochs(self):
        import json
        from uuid import uuid4
        from app.domain.protocol import validate
        command={'protocol_version':1,'command_id':str(uuid4()),'type':'interaction.end','owner_epoch':1,'socket_generation':1,'interaction_epoch':1,'payload':{}}
        self.assertEqual(validate(json.dumps(command))['type'],'interaction.end')
        command['owner_epoch']=True
        with self.assertRaises(DomainError):validate(json.dumps(command))
    def test_unknown_payload_and_large_non_sdp_frames_rejected(self):
        import json
        from uuid import uuid4
        from app.domain.protocol import validate
        command={'protocol_version':1,'command_id':str(uuid4()),'type':'text.send','owner_epoch':1,'socket_generation':1,'interaction_epoch':1,'payload':{'text':'safe','extra':'not allowed'}}
        with self.assertRaises(DomainError):validate(json.dumps(command))
        command['payload']={'text':'x'*9000}
        with self.assertRaises(DomainError):validate(json.dumps(command))

if __name__=='__main__':unittest.main()

class PasswordCapacity(unittest.IsolatedAsyncioTestCase):
    async def test_cancelled_request_does_not_release_running_hash_capacity(self):
        import asyncio,threading
        from app.services.primitives import Passwords
        worker=Passwords.__new__(Passwords);worker.semaphore=asyncio.Semaphore(1);worker.running=set()
        started=threading.Event();release=threading.Event()
        def cpu():started.set();release.wait(2);return True
        task=asyncio.create_task(worker.work(cpu))
        try:
            while not started.is_set():await asyncio.sleep(.001)
            task.cancel()
            with self.assertRaises(asyncio.CancelledError):await task
            self.assertTrue(worker.semaphore.locked())
            release.set();await asyncio.gather(*worker.running)
            self.assertFalse(worker.semaphore.locked())
        finally:release.set()
