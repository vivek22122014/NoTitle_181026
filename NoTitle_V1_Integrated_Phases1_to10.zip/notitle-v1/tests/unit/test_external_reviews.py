"""Provider-bound review safety tests; mocked transport is not merchant evidence."""
from contextlib import asynccontextmanager
from datetime import datetime,timezone,timedelta
from types import SimpleNamespace
from uuid import uuid4
from unittest.mock import AsyncMock
import unittest
from app.domain.errors import DomainError
from app.domain.security import Security
from app.integrations.cashfree import CashfreeSandbox,verified_disputes,external_disposition,ProviderUnknown
from app.services.billing import Billing
from app.services.primitives import Principal


def dispute(**changes):
    return {'dispute_id':42,'dispute_status':'CHARGEBACK_MERCHANT_WON','dispute_amount':'49.50','dispute_amount_currency':'INR',
        'order_details':{'order_id':'nt_test','cf_payment_id':'123','order_currency':'INR','payment_currency':'INR','order_amount':'99.00','payment_amount':'99.00'},
        'customer_details':{'customer_phone':'synthetic-only'}}|changes

class Parser(unittest.TestCase):
    def test_validated_projection_excludes_customer_information(self):
        row=verified_disputes([dispute()],'nt_test','123',9900)[0]
        self.assertEqual(row,{'provider_id':'42','amount_paise':4950,'status':'CHARGEBACK_MERCHANT_WON'})

    def test_unknown_and_invented_provider_states_never_authorize_release(self):
        for status in ('CHARGEBACK_CONTEST_REQUESTED','RETRIEVAL_CONTEST_REQUESTED','future_won','DISPUTE_CLOSED'):
            with self.assertRaises(ProviderUnknown):verified_disputes([dispute(dispute_status=status)],'nt_test','123',9900)

    def test_wrong_order_payment_currency_amount_and_duplicate_fail_closed(self):
        details=dispute()['order_details']
        rows=[dispute(order_details=details|{'order_id':'nt_other'}),dispute(order_details=details|{'cf_payment_id':'999'}),
              dispute(dispute_amount_currency='USD'),dispute(dispute_amount='NaN'),dispute(dispute_amount='100'),dispute(dispute_amount='1.001')]
        for row in rows:
            with self.assertRaises(ProviderUnknown):verified_disputes([row],'nt_test','123',9900)
        with self.assertRaises(ProviderUnknown):verified_disputes([dispute(),dispute()],'nt_test','123',9900)

class Disposition(unittest.TestCase):
    def test_pending_refund_or_dispute_cannot_be_restored_or_revoked(self):
        for action in ('restore','revoke'):
            for refunds,disputes in (([{'status':'PENDING','amount_paise':9900}],[]),([],[{'status':'CHARGEBACK_UNDER_REVIEW','amount_paise':9900}])):
                with self.assertRaises(ProviderUnknown):external_disposition(refunds,disputes,9900,100,90,action)

    def test_verified_loss_sets_minimum_and_caps_at_remaining_external_hold(self):
        facts=[{'status':'SUCCESS','amount_paise':4950}]
        result=external_disposition(facts,[],9900,100,90,'revoke',0)
        self.assertEqual(result['minimum_revoke_seconds'],50);self.assertEqual(result['seconds_to_revoke'],50);self.assertEqual(result['seconds_to_restore'],40)
        self.assertEqual(external_disposition([{'status':'SUCCESS','amount_paise':9900}],[],9900,100,90,'revoke')['seconds_to_revoke'],90)

    def test_verified_loss_prevents_total_restore(self):
        with self.assertRaises(ProviderUnknown):external_disposition([{'status':'SUCCESS','amount_paise':1}],[],9900,100,90,'restore')

    def test_merchant_win_and_cancelled_refund_can_restore_original_held_time(self):
        result=external_disposition([{'status':'CANCELLED','amount_paise':9900}],[{'status':'CHARGEBACK_MERCHANT_WON','amount_paise':9900}],9900,100,90,'restore')
        self.assertEqual(result['seconds_to_restore'],90);self.assertEqual(result['seconds_to_revoke'],0)

    def test_ceiling_rounds_loss_up_without_revoking_beyond_the_hold(self):
        self.assertEqual(external_disposition([{'status':'SUCCESS','amount_paise':1}],[],9900,100,90,'revoke')['minimum_revoke_seconds'],1)
        with self.assertRaises(ProviderUnknown):external_disposition([{'status':'SUCCESS','amount_paise':9900}],[],9900,100,90,'revoke',91)

    def test_mixed_refund_and_chargeback_cannot_guess_overlap(self):
        with self.assertRaises(ProviderUnknown):external_disposition([{'status':'SUCCESS','amount_paise':4950}],[{'status':'CHARGEBACK_MERCHANT_LOST','amount_paise':4950}],9900,100,90,'revoke')

    def test_multiple_lost_dispute_principals_remain_held(self):
        with self.assertRaises(ProviderUnknown):external_disposition([],[{'status':'CHARGEBACK_MERCHANT_LOST','amount_paise':3000},{'status':'DISPUTE_MERCHANT_ACCEPTED','amount_paise':3000}],9900,100,90,'revoke')

    def test_prior_origin_revocation_is_not_charged_again(self):
        result=external_disposition([{'status':'SUCCESS','amount_paise':2000},{'status':'SUCCESS','amount_paise':1000}],[],10000,100,70,'revoke',already_revoked=20)
        self.assertEqual(result['minimum_revoke_seconds'],10);self.assertEqual(result['seconds_to_revoke'],10)

class Cursor:
    def __init__(self,row):self.row=row
    async def fetchone(self):return self.row
    async def fetchall(self):return []
class Database:
    def __init__(self,rows):self.rows=list(rows);self.calls=[]
    @asynccontextmanager
    async def transaction(self,*args):yield self
    async def execute(self,*args):self.calls.append(args);return Cursor(self.rows.pop(0) if self.rows else None)

class ProviderBinding(unittest.IsolatedAsyncioTestCase):
    async def test_documented_dispute_paths_are_read_only_and_identifier_bounded(self):
        provider=object.__new__(CashfreeSandbox);provider.request=AsyncMock(return_value=[])
        await provider.fetch_disputes('nt_test');self.assertEqual(provider.request.call_args.args,('GET','/orders/nt_test/disputes'))
        await provider.fetch_dispute('42');self.assertEqual(provider.request.call_args.args,('GET','/disputes/42'))
        with self.assertRaises(ValueError):await provider.fetch_dispute('../foreign')

    def setup_service(self):
        database=Database([{'event_refs':['external-dispute:sandbox:42:prior']}])
        provider=SimpleNamespace(fetch_order=AsyncMock(return_value={'order_id':'nt_test','order_currency':'INR','order_amount':'99'}),fetch_refunds=AsyncMock(return_value=[]),fetch_disputes=AsyncMock(return_value=[]),fetch_dispute=AsyncMock(return_value=dispute()))
        billing=Billing(database,Security(b'a'*32,b'b'*32),provider,None)
        purchase={'id':uuid4(),'merchant_order_id':'nt_test','amount_paise':9900,'environment':'sandbox'}
        return billing.reviews,provider,purchase

    async def test_missing_signed_dispute_requires_independent_specific_lookup(self):
        service,provider,purchase=self.setup_service()
        facts,_=await service.provider_state(purchase,'123')
        provider.fetch_dispute.assert_awaited_once_with('42');self.assertEqual(facts['disputes'][0]['status'],'CHARGEBACK_MERCHANT_WON')

    async def test_omitted_dispute_cannot_be_assumed_won_on_lookup_failure(self):
        service,provider,purchase=self.setup_service();provider.fetch_dispute.side_effect=ProviderUnknown('UNKNOWN')
        with self.assertRaises(DomainError) as caught:await service.provider_state(purchase,'123')
        self.assertEqual(caught.exception.code,'PROVIDER_VERIFICATION_UNAVAILABLE')

    async def test_provider_details_must_still_match_exact_dispute_id(self):
        service,provider,purchase=self.setup_service();provider.fetch_dispute.return_value=dispute(dispute_id=43)
        with self.assertRaises(DomainError):await service.provider_state(purchase,'123')

    async def test_current_staff_role_and_fresh_mfa_are_required_again(self):
        service,_,_=self.setup_service();p=Principal('staff','staff','private',account_id=uuid4(),grants=frozenset({'billing.remedies'}))
        stale={'role_version':1,'mfa_at':datetime.now(timezone.utc)-timedelta(minutes=6)}
        with self.assertRaises(DomainError):await service.staff(Database([stale]),p)
        fresh={'role_version':2,'mfa_at':datetime.now(timezone.utc)}
        with self.assertRaises(DomainError):await service.staff(Database([fresh,None]),p)
        with self.assertRaises(DomainError):await service.staff(Database([fresh,{'permission':'billing.remedies'}]),p,role=1)

    async def test_committed_result_survives_preview_cleanup_and_does_not_refetch_provider(self):
        service,_,_=self.setup_service();p=Principal('staff','staff','private',account_id=uuid4(),grants=frozenset({'billing.remedies'}))
        result={'purchase_ref':'a'*32,'state':'revoked','seconds_to_revoke':50,'seconds_to_restore':40}
        database=Database([{'role_version':1,'mfa_at':datetime.now(timezone.utc)},{'permission':'billing.remedies'},{'result':result}]);service.db=database
        service.provider_state=AsyncMock(side_effect=AssertionError('Committed action must not run again'))
        self.assertEqual(await service.confirm(p,uuid4().hex,'synthetic-retry'),result)
        self.assertFalse(any('sensitive_previews' in args[0] for args in database.calls));service.provider_state.assert_not_awaited()

    async def test_immutable_receipt_recovers_result_after_operation_cleanup_with_audit(self):
        service,_,_=self.setup_service();p=Principal('staff','staff','private',account_id=uuid4(),grants=frozenset({'billing.remedies'}))
        result={'purchase_ref':'a'*32,'state':'revoked','verified_lost_paise':4950,'minimum_revoke_seconds':50,'seconds_to_revoke':50,'seconds_to_restore':40}
        database=Database([{'role_version':1,'mfa_at':datetime.now(timezone.utc)},{'permission':'billing.remedies'},None,{'facts':result|{'document_kind':'external_financial_resolution','decision_reason':'private extra not returned'}}]);service.db=database
        service.provider_state=AsyncMock(side_effect=AssertionError('Recovery is read-only'))
        self.assertEqual(await service.confirm(p,uuid4().hex,'synthetic-recovery'),result)
        self.assertTrue(any('INSERT INTO nt.access_audit' in args[0] for args in database.calls));service.provider_state.assert_not_awaited()
