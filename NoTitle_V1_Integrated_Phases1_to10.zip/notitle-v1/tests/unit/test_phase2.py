"""Policy, artifact and HTTP boundary tests. Synthetic HTML is not a Next build."""
import argparse
from copy import deepcopy
from datetime import datetime,timedelta,timezone
import hashlib
from html import escape
import http.client
import json
from pathlib import Path
import shutil
from tempfile import TemporaryDirectory
import threading
import unittest

from ops import policies
from ops.interface import generate,inventory,source_check,validate_site
from ops.export_audit import audit,Document
from ops.interface_server import resolve_asset,server
from ops.csp import generate as csp

ROOT=Path(__file__).resolve().parents[2]

class Project(unittest.TestCase):
    def setUp(self):
        self.temp=TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)
        for name in ('policies','contracts','web'):
            shutil.copytree(ROOT/name,self.root/name,ignore=shutil.ignore_patterns('node_modules','.next','out','__pycache__'))
    def data(self,path):return json.loads((self.root/path).read_text())
    def write(self,path,value):
        p=self.root/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(policies.encoded(value))

class Publication(Project):
    def facts(self):
        operator={k:'Synthetic unit-test '+k.replace('_',' ') for k in policies.OPERATOR_FIELDS}
        operator.update(launch_territories=['Synthetic test territory'],contact_route='https://contact.notitle-fixture.net/intake',
                        outage_contact_route='+919876543210',appeal_route='https://contact.notitle-fixture.net/appeal',
                        processors=[{'name':'Synthetic unit-test provider','purpose':'Fixture only',
                                     'data_categories':['test data'],'regions':['test region'],
                                     'subprocessors':'Synthetic reviewed registry','transfer_arrangement':'Synthetic fixture arrangement',
                                     'privacy_url':'https://provider.notitle-fixture.net/privacy'}])
        now=datetime.now(timezone.utc)
        self.write('evidence/legal-test.json',{'synthetic':True,'not_legal_approval':True})
        evidence=self.root/'evidence/legal-test.json'
        review={k:True for k in policies.REVIEW_CHECKS}
        review.update(source_sha256=policies.digest(self.data('policies/source.json')),operator_sha256=policies.digest(operator),
                      policy_version='unit-test-v1',effective_at='2026-10-17T00:00:00Z',reviewed_at=(now-timedelta(hours=1)).isoformat(),
                      expires_at=(now+timedelta(days=7)).isoformat(),evidence=[{'path':'evidence/legal-test.json','sha256':hashlib.sha256(evidence.read_bytes()).hexdigest()}])
        self.write('operator.json',operator);self.write('review.json',review)
        return operator,review,argparse.Namespace(operator=self.root/'operator.json',review=self.root/'review.json',version='unit-test-v1',effective_at=review['effective_at'])
    def test_draft_compilation_is_deterministic_and_not_reviewed(self):
        p=policies.check(self.root);self.assertEqual(p['state'],'draft');self.assertTrue(p['publication_blockers'])
        self.assertEqual(p,policies.compile_publication(self.data('policies/source.json')))
        with self.assertRaises(ValueError):policies.check(self.root,require_reviewed=True)
    def test_reviewed_copy_binds_operator_version_source_and_file_digest(self):
        operator,review,args=self.facts();p=policies.publish(args,self.root)
        policies.check(self.root,require_reviewed=True)
        generated=self.data('web/public/app/policies/generated.json')
        self.assertNotIn('review',generated)
        self.assertEqual(generated['publication_sha256'],hashlib.sha256((self.root/'policies/publication.json').read_bytes()).hexdigest())
        self.assertIn(operator['legal_name'],p['policies']['privacy']['sections'][0][1])
        self.assertEqual(policies.publish(args,self.root),p)
    def test_missing_facts_do_not_modify_draft(self):
        operator,review,args=self.facts();operator['legal_name']=None;self.write('operator.json',operator)
        before=(self.root/'policies/publication.json').read_bytes()
        with self.assertRaises(ValueError):policies.publish(args,self.root)
        self.assertEqual(before,(self.root/'policies/publication.json').read_bytes())
    def test_email_in_any_operator_or_processor_value_is_refused(self):
        operator,_,_=self.facts()
        for bad in ('help@host.tld','help [at] host.tld','mailto:help'):
            p=deepcopy(operator);p['processors'][0]['subprocessors']=bad
            with self.subTest(bad=bad),self.assertRaises(ValueError):policies.validate_operator(p)
    def test_unsafe_contact_and_credentials_in_url_are_refused(self):
        for bad in ('http://host.tld','https://name:secret@host.tld','https://host.tld/?secret=x','https://host.tld/#secret','https://localhost/a'):
            with self.subTest(bad=bad),self.assertRaises(ValueError):policies.contact(bad)
    def test_unresolved_inputs_and_unsupported_claims_are_refused(self):
        source=self.data('policies/source.json');operator,_,_=self.facts()
        for text in ('TBD','{{operator.missing}}','100% secure','fully GDPR compliant','We are GDPR compliant','Complies with all laws','no refunds under any circumstances','Refunds for unused passes'):
            bad=deepcopy(source);bad['policies']['privacy']['sections'][0][1]=text
            with self.subTest(text=text),self.assertRaises((ValueError,KeyError)):policies.compile_publication(bad,operator)
    def test_required_remedies_and_no_renewal_cannot_disappear(self):
        p=self.data('policies/source.json')['policies']
        for phrase in ('non-waivable','payment-error','binding','no automatic renewal'):
            bad=deepcopy(p)
            bad['billing']['sections']=[[a,b.replace(phrase,'removed').replace(phrase.capitalize(),'removed')] for a,b in bad['billing']['sections']]
            with self.subTest(phrase=phrase),self.assertRaises(ValueError):policies.lint_copy(bad,reviewed=False)
    def test_expired_future_and_unbound_reviews_are_refused(self):
        _,review,args=self.facts()
        for changes in ({'expires_at':'2020-01-01T00:00:00Z'},{'reviewed_at':'2099-01-01T00:00:00Z'},{'operator_sha256':'0'*64},{'source_sha256':'0'*64},{'policy_version':'different'},{'actual_practices':False}):
            self.write('review.json',review|changes)
            with self.subTest(changes=changes),self.assertRaises(ValueError):policies.publish(args,self.root)
    def test_changed_evidence_and_path_escape_are_refused(self):
        _,review,args=self.facts();self.write('evidence/legal-test.json',{'changed':True})
        with self.assertRaises(ValueError):policies.publish(args,self.root)
        review['evidence'][0]['path']='../outside';self.write('review.json',review)
        with self.assertRaises(ValueError):policies.publish(args,self.root)
    def test_generated_and_source_drift_block_build(self):
        p=self.data('web/public/app/policies/generated.json');p['version']='changed';self.write('web/public/app/policies/generated.json',p)
        with self.assertRaises(ValueError):source_check(self.root)
    def test_reviewed_version_cannot_be_silently_rewritten(self):
        _,review,args=self.facts();policies.publish(args,self.root)
        source=self.data('policies/source.json');source['policies']['privacy']['sections'][1][1]+=' Material change.'
        self.write('policies/source.json',source);review['source_sha256']=policies.digest(source);self.write('review.json',review)
        with self.assertRaises(ValueError):policies.publish(args,self.root)

class Interfaces(Project):
    def test_fixed_inventory_and_separate_generated_routes(self):
        source_check(self.root);generate(self.root,check=True)
        records=inventory(self.root);self.assertEqual(len(records['public']),46);self.assertEqual(len(records['admin']),10)
        public=self.data('web/public/route-data.json');self.assertFalse(any(r['path']=='/cases/' for r in public))
    def test_missing_route_and_private_import_fail_source_check(self):
        (self.root/'web/public/app/chat/page.tsx').unlink()
        with self.assertRaises(ValueError):source_check(self.root)
        generate(self.root);(self.root/'web/public/Bad.ts').write_text("import '../admin/app/Candidate';")
        with self.assertRaises(ValueError):source_check(self.root)
    def test_only_public_origin_configuration_is_allowed(self):
        good=dict(schema=1,mode='interface',public_origin='http://127.0.0.1:8080',indexable=False)
        validate_site(good)
        for bad in (good|{'indexable':True},good|{'public_origin':'https://operator:secret@host.tld'},good|{'public_origin':'https://host.tld/path'},good|{'unknown':'secret'}):
            with self.assertRaises(ValueError):validate_site(bad)

class Artifacts(Project):
    def exports(self):
        exports=self.root/'exports';publication=policies.check(self.root)
        if exports.exists():shutil.rmtree(exports)
        for app,routes in ((k,v) for k,v in inventory(self.root).items() if k!='schema'):
            base=exports/app;base.mkdir(parents=True)
            (base/'bundle.js').write_text('/* synthetic audit fixture only */')
            for route in routes:
                body='<h1>'+escape(route['title'])+'</h1>'
                if route['kind']=='policy':
                    body+='<p>'+publication['content_sha256']+'</p>'
                    for heading,text in publication['policies'][route['policy']]['sections']:body+='<h2>'+escape(heading)+'</h2><p>'+escape(text)+'</p>'
                html=('<!doctype html><html lang="en"><head><title>'+escape(route['title'])+'</title><meta name="description" content="Synthetic test"><meta name="robots" content="noindex, nofollow"><link rel="canonical" href="http://127.0.0.1:8080'+route['path']+'"></head><body>'+body+'<script>self.__test=1;</script><script src="/bundle.js"></script></body></html>')
                target=base/route['path'].strip('/')/'index.html';target.parent.mkdir(parents=True,exist_ok=True);target.write_text(html)
            for relative in ('404.html','foundation/index.html'):
                path=base/relative;path.parent.mkdir(parents=True,exist_ok=True);path.write_text('<h1>Synthetic not found</h1><script>self.__test=1;</script>')
            (base/'robots.txt').write_text('User-agent: *\nDisallow: /\n')
        (exports/'public/sitemap.xml').write_text('<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"/>')
        return exports
    def test_synthetic_artifact_audit_exercises_policy_html_and_assets(self):
        result=audit(self.root,self.exports());self.assertEqual(result['routes_checked'],{'public':46,'admin':10})
    def test_policy_missing_from_no_javascript_html_is_refused(self):
        exports=self.exports();path=exports/'public/privacy/index.html';path.write_text(path.read_text().replace('Temporary conversations','Removed section'))
        with self.assertRaises(ValueError):audit(self.root,exports)
    def test_private_bundle_in_public_assets_is_refused(self):
        exports=self.exports();(exports/'public/bundle.js').write_text('const marker="private-workspace-v1";')
        with self.assertRaises(ValueError):audit(self.root,exports)
    def test_broken_link_inline_handler_and_source_map_are_refused(self):
        for addition in ('<a href="/missing/">Missing</a>','<button onclick="alert(1)">Bad</button>'):
            exports=self.exports();p=exports/'public/index.html';p.write_text(p.read_text()+addition)
            with self.subTest(addition=addition),self.assertRaises(ValueError):audit(self.root,exports)
        exports=self.exports();(exports/'public/bundle.js.map').write_text('{}')
        with self.assertRaises(ValueError):audit(self.root,exports)
    def test_sitemap_cannot_index_private_or_owner_routes(self):
        exports=self.exports();(exports/'public/sitemap.xml').write_text('<urlset><url><loc>http://127.0.0.1:8080/account/privacy/</loc></url></urlset>')
        with self.assertRaises(ValueError):audit(self.root,exports)
    def test_csp_is_bound_to_export_scripts_and_checkout_is_scoped(self):
        exports=self.exports();first=csp(exports/'public');self.assertNotIn('cashfree',first);self.assertNotIn('unsafe-eval',first)
        self.assertIn("script-src-attr 'none'",first);self.assertIn("worker-src 'none'",first)
        p=exports/'public/index.html';p.write_text(p.read_text().replace('self.__test=1','self.__test=2'))
        self.assertNotEqual(first,csp(exports/'public'))
        checkout=csp(exports/'public',True)
        self.assertIn('@checkout path /checkout /checkout/*',checkout)
        self.assertNotIn('cashfree',checkout.splitlines()[0])
    def test_secret_forms_cannot_fall_back_to_get(self):
        parser=Document();parser.feed('<form><input type="password"></form>');self.assertTrue(parser.violations)
        parser=Document();parser.feed('<form method="post"><input type="password"></form>');self.assertFalse(parser.violations)
    def test_preview_http_has_true_404_private_boundary_and_no_store(self):
        exports=self.exports();instance=server(exports/'public',0);thread=threading.Thread(target=instance.serve_forever,daemon=True);thread.start()
        self.addCleanup(instance.server_close);self.addCleanup(instance.shutdown)
        for path,expected in (('/',200),('/not-here/',404),('/internal/v1/bootstrap',404),('/admin/',404),('/?secret=never-log-this',404)):
            connection=http.client.HTTPConnection('127.0.0.1',instance.server_port,timeout=3)
            connection.request('GET',path);response=connection.getresponse();response.read()
            self.assertEqual(response.status,expected);self.assertEqual(response.getheader('Cache-Control'),'no-store')
            self.assertIn('noindex',response.getheader('X-Robots-Tag'));self.assertIn('sha256-',response.getheader('Content-Security-Policy'));connection.close()
    def test_preview_path_traversal_and_symlinks_are_refused(self):
        exports=self.exports();base=exports/'public'
        for path in ('/../admin/index.html','/%2e%2e/admin/index.html','//admin/index.html','/bundle.js?token=x'):
            self.assertIsNone(resolve_asset(base,path))
        (base/'leak.html').symlink_to(exports/'admin/index.html');self.assertIsNone(resolve_asset(base,'/leak.html'))

if __name__=='__main__':unittest.main()
