import base64,hashlib,hmac,json
import unittest
from app.integrations.cashfree import verified_capture,verify_webhook,ProviderRejected,amount,reference
class Money(unittest.TestCase):
    def setUp(self):
        self.order={'order_id':'nt_123','order_amount':99,'order_currency':'INR','order_status':'PAID'}
        self.pay=[{'payment_status':'SUCCESS','payment_amount':99,'payment_currency':'INR','cf_payment_id':123}]
    def test_verified_capture_requires_both_sources(self):
        self.assertEqual(verified_capture(self.order,self.pay,'nt_123',9900),'123')
        self.assertIsNone(verified_capture({**self.order,'order_status':'ACTIVE'},self.pay,'nt_123',9900))
    def test_browser_return_is_not_evidence(self):
        self.assertIsNone(verified_capture({'status':'success','order_id':'nt_123'},[],'nt_123',9900))
    def test_wrong_amount_currency_reference_and_duplicate_success(self):
        for order in [{**self.order,'order_amount':98},{**self.order,'order_currency':'USD'},{**self.order,'order_id':'other'}]:
            self.assertIsNone(verified_capture(order,self.pay,'nt_123',9900))
        self.assertIsNone(verified_capture(self.order,self.pay*2,'nt_123',9900))
    def test_nonfinite_money_rejected(self):
        self.assertIsNone(verified_capture({**self.order,'order_amount':'NaN'},self.pay,'nt_123',9900))
        with self.assertRaises(ValueError):amount(True)
    def test_signature_uses_raw_bytes(self):
        body=b'{"x": 1}';stamp='1700000000000';key=b'synthetic'
        signature=base64.b64encode(hmac.new(key,stamp.encode()+body,hashlib.sha256).digest()).decode()
        self.assertEqual(verify_webhook(body,stamp,signature,key),{'x':1})
        with self.assertRaises(ProviderRejected):verify_webhook(b'{"x":1}',stamp,signature,key)
    def test_signature_limits(self):
        with self.assertRaises(ProviderRejected):verify_webhook(b'x'*262145,'1700000000000','x',b'key')
        with self.assertRaises(ValueError):reference('../orders/other')

class ExactSerialization(unittest.TestCase):
    def test_decimal_amount_has_no_float_round_trip(self):
        from app.integrations.cashfree import encode_payload
        from decimal import Decimal
        self.assertIsInstance(amount(9901),Decimal)
        self.assertEqual(encode_payload({'amount':amount(9901),'id':'x'}),'{"amount":99.01,"id":"x"}')
