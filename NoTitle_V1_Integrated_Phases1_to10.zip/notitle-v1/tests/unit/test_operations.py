"""Phase 9/10 unit checks; scripted SQL is not real PostgreSQL qualification."""
import hashlib,json,unittest
from contextlib import asynccontextmanager
from datetime import datetime,timezone,timedelta
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import AsyncMock,patch
from app.domain.errors import DomainError
from app.domain.metrics import IDS,Metrics
from app.services.analytics import Analytics,summary_metrics,percentile_bound,metric_definition
from ops.production import validate_evidence,REQUIRED

class AnalyticsTests(unittest.TestCase):
    def test_histogram_summary_reports_samples_and_mean_not_latency_sum_as_people(self):
        rows=[{'metric_id':IDS['api_latency_ms'],'samples':20,'total':1000,'complete':True}]
        result={row['name']:row for row in summary_metrics(rows)}
        self.assertEqual(result['api_latency_ms']['count']['value'],20)
        self.assertEqual(result['api_latency_ms']['mean'],50)
        self.assertEqual(result['api_latency_ms']['unit'],'milliseconds')
        self.assertFalse(result['registrations']['observed'])
        self.assertFalse(result['registrations']['complete'])
    def test_small_cohort_hides_derived_mean(self):
        row=summary_metrics([{'metric_id':IDS['api_latency_ms'],'samples':3,'total':200,'complete':True}])[14]
        self.assertTrue(row['count']['suppressed']);self.assertIsNone(row['mean'])
    def test_histogram_tail_is_finite_json(self):
        self.assertEqual(percentile_bound([0]*12+[100],.95),'>30000')
        self.assertEqual(percentile_bound([100]+[0]*12,.95),5)
        self.assertIsNone(percentile_bound([0]*13,.95))
    def test_catalog_rejects_user_dimension(self):
        for value in ('user-id',True,0,27):
            with self.assertRaises(DomainError):metric_definition(value)

class AnalyticsIO(unittest.IsolatedAsyncioTestCase):
    async def test_authorization_precedes_summary_cache(self):
        analytics=Analytics(None,Metrics(),None);analytics.cache['summary']=(datetime.now(timezone.utc),{'secret':'aggregate'})
        principal=SimpleNamespace(permission=lambda _:(_ for _ in ()).throw(DomainError('FORBIDDEN',403)))
        with self.assertRaises(DomainError):await analytics.summary(principal)
    async def test_failed_flush_preserves_same_batch_and_separates_new_samples(self):
        db=SimpleNamespace(transaction=None);connection=SimpleNamespace(execute=AsyncMock())
        @asynccontextmanager
        async def transaction(_):yield connection
        db.transaction=transaction;metrics=Metrics();metrics.add('text_accepted');analytics=Analytics(db,metrics,None)
        with patch('app.services.analytics.one',AsyncMock(side_effect=RuntimeError('database down'))):
            with self.assertRaises(RuntimeError):await analytics.flush()
        pending=analytics.pending;metrics.add('matches')
        with patch('app.services.analytics.one',AsyncMock(return_value=None)),patch('app.services.analytics.many',AsyncMock(return_value=[])):
            await analytics.flush()
        self.assertIsNone(analytics.pending)
        self.assertIn(IDS['matches'],metrics.values)
        self.assertNotIn(IDS['text_accepted'],metrics.values)
        insert=[call for call in connection.execute.call_args_list if 'INSERT INTO nt.aggregate_batches' in call.args[0]][0]
        self.assertEqual(insert.args[1][0],pending[0])
    async def test_series_range_and_permission_bound_before_sql(self):
        analytics=Analytics(None,Metrics(),None);principal=SimpleNamespace(permission=lambda _:None);end=datetime.now(timezone.utc)
        with self.assertRaises(DomainError):await analytics.series(principal,1,end-timedelta(days=100),end,'hour')
        with self.assertRaises(DomainError):await analytics.series(principal,1,end.replace(tzinfo=None)-timedelta(days=1),end,'day')

class QualificationTests(unittest.TestCase):
    def make(self,directory):
        artifact=directory/'pass.txt';artifact.write_text('real evidence bytes\n');report=directory/'report.json'
        report.write_text(json.dumps({'source_sha256':'source','source_unchanged':True,'recorded_at':datetime.now(timezone.utc).isoformat(),
          'checks':{key:{'status':'passed','artifact':'pass.txt','sha256':hashlib.sha256(artifact.read_bytes()).hexdigest()} for key in (*REQUIRED,'relay','merchant')}}))
        return report
    def test_release_evidence_is_source_and_artifact_bound(self):
        with TemporaryDirectory() as temporary:
            directory=Path(temporary);report=self.make(directory)
            with patch('ops.foundation.source_digest',return_value='source'):self.assertEqual(validate_evidence(report)['source_sha256'],'source')
            with patch('ops.foundation.source_digest',return_value='changed'):
                with self.assertRaises(ValueError):validate_evidence(report)
            (directory/'pass.txt').write_text('modified')
            with patch('ops.foundation.source_digest',return_value='source'):
                with self.assertRaises(ValueError):validate_evidence(report)
    def test_path_escape_and_missing_external_gate_refused(self):
        with TemporaryDirectory() as temporary:
            directory=Path(temporary);report=self.make(directory);value=json.loads(report.read_text());value['checks']['relay']['artifact']='../outside';report.write_text(json.dumps(value))
            with patch('ops.foundation.source_digest',return_value='source'):
                with self.assertRaises(ValueError):validate_evidence(report)
            report=self.make(directory);value=json.loads(report.read_text());value['checks']['merchant']['status']='not_run';report.write_text(json.dumps(value))
            with patch('ops.foundation.source_digest',return_value='source'):
                with self.assertRaises(ValueError):validate_evidence(report)
    def test_every_phase_is_explicit(self):
        from ops.release import PHASES
        self.assertEqual(set(PHASES),set(range(1,11)))

class DelayedAnalytics(unittest.IsolatedAsyncioTestCase):
    async def test_late_outbox_uses_original_time_and_amends_coarser_totals(self):
        current=datetime(2026,10,17,12,30,tzinfo=timezone.utc)
        created=current-timedelta(days=8)
        connection=SimpleNamespace(execute=AsyncMock());db=SimpleNamespace(transaction=None)
        @asynccontextmanager
        async def transaction(_):yield connection
        db.transaction=transaction;analytics=Analytics(db,Metrics(),None)
        with patch('app.services.analytics.now',return_value=current),patch('app.services.analytics.one',AsyncMock(return_value=None)),patch('app.services.analytics.many',AsyncMock(return_value=[{'id':'outbox','metric_id':1,'created_at':created}])):
            await analytics.flush()
        inserts=[call for call in connection.execute.call_args_list if 'INSERT INTO nt.aggregate_buckets' in call.args[0]]
        self.assertEqual(len(inserts),1);self.assertEqual(inserts[0].args[1][:2],('hour',created.replace(minute=0)))
        updates=[call.args[1][-3] for call in connection.execute.call_args_list if 'UPDATE nt.aggregate_buckets SET sample_count' in call.args[0]]
        self.assertEqual(updates,['day','month'])
    def test_retention_boundaries_keep_full_coarser_sources(self):
        from app.services.analytics import retained_resolution,truncate_bucket
        current=datetime(2026,10,17,12,30,tzinfo=timezone.utc)
        self.assertEqual(retained_resolution(current-timedelta(days=7,minutes=10),current),'minute')
        self.assertEqual(retained_resolution(current-timedelta(days=7,hours=1),current),'hour')
        self.assertEqual(retained_resolution(current-timedelta(days=40),current),'day')
        self.assertEqual(retained_resolution(current-timedelta(days=110),current),'month')
        self.assertIsNone(retained_resolution(current-timedelta(days=500),current))
        self.assertEqual(truncate_bucket(current,'month').day,1)
    async def test_rollup_deletes_whole_target_periods_only(self):
        connection=SimpleNamespace(execute=AsyncMock());db=SimpleNamespace(transaction=None)
        @asynccontextmanager
        async def transaction(_):yield connection
        db.transaction=transaction;analytics=Analytics(db,Metrics(),None)
        with patch('app.services.analytics.many',AsyncMock(return_value=[])),patch('app.services.analytics.one',AsyncMock(return_value={'size':1000})):
            await analytics.rollup()
        deletions=[call for call in connection.execute.call_args_list if 'DELETE FROM nt.aggregate_buckets b' in call.args[0]]
        self.assertEqual(len(deletions),3)
        self.assertEqual(deletions[0].args[1],('minute','hour',7,'hour','hour'))
        self.assertTrue(all('bucket<date_trunc' in call.args[0] for call in deletions))

class DeploymentJournal(unittest.TestCase):
    def test_actual_file_lock_prevents_two_operations_and_safe_state_is_atomic(self):
        from ops.production import operation
        with TemporaryDirectory() as temporary:
            directory=Path(temporary);manifest=directory/'manifest.json';manifest.write_text(json.dumps({'manifest':{'release_id':'release-1','secret':'do-not-store'}}));args=SimpleNamespace(manifest=manifest,release_dir=directory)
            def mapped(value):
                raw=str(value)
                return directory/raw.removeprefix('/var/lib/notitle/').removeprefix('/var/lib/notitle') if raw.startswith('/var/lib/notitle') else Path(value)
            with patch('ops.production.Path',side_effect=mapped):
                with operation(args,'deploy'):
                    with self.assertRaises(ValueError):
                        with operation(args,'rollback'):self.fail('Two operations entered')
            record=json.loads((directory/'deployment.json').read_text())
            self.assertEqual(record['status'],'healthy');self.assertEqual(record['release_id'],'release-1')
            self.assertNotIn('do-not-store',json.dumps(record))

class BackupAtomicity(unittest.TestCase):
    def test_failed_status_replace_preserves_previous_completed_point(self):
        from ops.backup import write_status
        with TemporaryDirectory() as temporary:
            path=Path(temporary)/'status.json';write_status(path,{'last_success':10,'snapshot_id':'old'})
            with patch('ops.backup.os.replace',side_effect=OSError('disk failure')):
                with self.assertRaises(OSError):write_status(path,{'last_success':20,'snapshot_id':'new'})
            self.assertEqual(json.loads(path.read_text())['snapshot_id'],'old')
            write_status(path,{'last_success':20,'snapshot_id':'new'})
            self.assertEqual(json.loads(path.read_text())['snapshot_id'],'new')
    def test_real_lock_rejects_concurrent_backup(self):
        from ops.backup import backup_lock
        with TemporaryDirectory() as temporary:
            with backup_lock(Path(temporary)):
                with self.assertRaises(ValueError):
                    with backup_lock(Path(temporary)):self.fail('Concurrent backup entered')

class MonitorChecks(unittest.TestCase):
    def test_fixed_alert_codes_include_stale_backup_disk_and_certificate(self):
        from ops.monitor import status_alerts
        current=1000000
        self.assertEqual(status_alerts({'last_success':current},current,.5,current+30*86400),[])
        self.assertEqual(set(status_alerts({'last_success':1},current,.95,current+86400)),{'BACKUP_OVERDUE','DISK_BUDGET_WARNING','TLS_CERTIFICATE_EXPIRING'})
        self.assertEqual(status_alerts(None,current,.5),['BACKUP_STATUS_UNAVAILABLE'])
    def test_webhook_requires_https_and_no_credentials(self):
        from ops.monitor import https_secret
        with TemporaryDirectory() as temporary:
            path=Path(temporary)/'secret'
            for value in ('http://example.test','https://person:secret@example.test/','https://example.test/#secret'):
                path.write_text(value)
                with self.assertRaises(ValueError):https_secret(path)
            path.write_text('https://example.test/private-hook')
            self.assertEqual(https_secret(path),'https://example.test/private-hook')

class MonitorDelivery(unittest.TestCase):
    def test_deadman_on_health_and_fixed_codes_on_failure(self):
        from ops.monitor import monitor
        import urllib.request
        current=1000000
        with TemporaryDirectory() as temporary:
            directory=Path(temporary);backup=directory/'backup.json';backup.write_text(json.dumps({'last_success':current}));alert=directory/'alert';alert.write_text('https://alerts.example.test/private-token');heartbeat=directory/'heartbeat';heartbeat.write_text('https://heartbeat.example.test/private-token');config=directory/'monitor.json';config.write_text(json.dumps({'health_url':'https://app.example.test/health/ready','backup_status_file':str(backup),'alert_webhook_file':str(alert),'heartbeat_url_file':str(heartbeat)}))
            calls=[]
            class Response:
                status=200
                def __enter__(self):return self
                def __exit__(self,*args):pass
                def read(self,*args):return b'{"data":{"status":"ready"}}'
            def urlopen(request,**kwargs):calls.append(request);return Response()
            with patch('ops.monitor.urllib.request.urlopen',side_effect=urlopen),patch('ops.monitor.certificate_expiry',return_value=current+90*86400),patch('ops.monitor.time.time',return_value=current),patch('ops.monitor.shutil.disk_usage',return_value=SimpleNamespace(total=100,free=60)):
                monitor(config)
                self.assertIn('https://heartbeat.example.test/private-token',calls)
                calls.clear();backup.write_text(json.dumps({'last_success':1}))
                with self.assertRaises(SystemExit):monitor(config)
            request=next(value for value in calls if isinstance(value,urllib.request.Request))
            body=json.loads(request.data)['text'];self.assertEqual(body,'NoTitle: BACKUP_OVERDUE');self.assertNotIn('private-token',body)
            self.assertNotIn('https://heartbeat.example.test/private-token',calls)
