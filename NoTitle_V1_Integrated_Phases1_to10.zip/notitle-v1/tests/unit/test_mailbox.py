import unittest
from app.coordinator.core import Coordinator
from app.coordinator.mailbox import Mailbox,MailboxFull
class Mailboxes(unittest.TestCase):
    def setUp(self):self.c=Coordinator(1);self.m=Mailbox(self.c)
    def test_ordinary_saturation_preserves_control(self):
        for _ in range(2048):self.m.submit(lambda:None)
        with self.assertRaises(MailboxFull):self.m.submit(lambda:None)
        events=[];self.m.submit(lambda:events.append('end'),control=True);self.m.drain_tick()
        self.assertEqual(events,['end']);self.assertEqual(len(self.m.ordinary),1984)
    def test_control_saturation_fences(self):
        for _ in range(256):self.m.submit(lambda:None,control=True)
        with self.assertRaises(MailboxFull):self.m.submit(lambda:None,control=True)
        self.assertFalse(self.c.alive)
    def test_async_transition_rejected(self):
        async def bad():pass
        with self.assertRaises(TypeError):self.m.submit(bad)
    def test_transition_error_fences_and_clears(self):
        def bad():raise ValueError('invalid transition')
        self.m.submit(bad,control=True);self.m.submit(lambda:None)
        with self.assertRaises(ValueError):self.m.drain_tick()
        self.assertFalse(self.c.alive);self.assertFalse(self.m.ordinary)
