"""Deterministic storage faults, not evidence of a real object-store deployment."""
import io,json,unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from uuid import uuid4
from app.domain.journal import Journal,JournalCorrupt,canonical,ZERO
from app.integrations.journal_store import LocalJournal,S3Journal

class FakeObjects:
    def __init__(self):self.objects={};self.fail_latest=False
    def get_object(self,*,Bucket,Key):
        body,version=self.objects[Key]
        return {'Body':io.BytesIO(body),'ETag':str(version)}
    def put_object(self,*,Bucket,Key,Body,IfNoneMatch=None,IfMatch=None,**kwargs):
        previous=self.objects.get(Key)
        if IfNoneMatch=='*' and previous:raise RuntimeError('precondition')
        if IfMatch is not None and (not previous or str(previous[1])!=IfMatch):raise RuntimeError('precondition')
        if Key.endswith('latest.json') and self.fail_latest:raise OSError('synthetic checkpoint outage')
        self.objects[Key]=(Body,previous[1]+1 if previous else 1)
        return {}

class StoreRecovery(unittest.TestCase):
    def setUp(self):
        self.tmp=TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
    def payload(self):return {'operation_id':str(uuid4()),'subject_ref':str(uuid4()),'action':'delete'}
    def store(self):
        store=S3Journal.__new__(S3Journal);store.root=self.root;store.bucket='synthetic';store.prefix='test/';store.client=FakeObjects()
        store.journal=Journal(self.root/'local',self.root/'verified-stage',b'a'*32,b'b'*32)
        store.client.put_object(Bucket='synthetic',Key='test/latest.json',Body=canonical(store.journal.anchor(0,ZERO)))
        return store
    def test_local_lost_anchor_ack_is_recovered_before_admission(self):
        store=LocalJournal(self.root,b'a'*32,b'b'*32);payload=self.payload()
        store.journal.append(payload)  # immutable replicas committed; checkpoint not advanced
        with self.assertRaises(JournalCorrupt):store.verified_state()
        store.recover_pending()
        self.assertTrue(store.verified_state()[payload['subject_ref']]['deleted'])
    def test_cloud_checkpoint_retry_preserves_one_immutable_operation(self):
        store=self.store();payload=self.payload();store.client.fail_latest=True
        with self.assertRaises(OSError):store.append(payload)
        with self.assertRaises(JournalCorrupt):store.verified_state()
        store.client.fail_latest=False;store.recover_pending()
        self.assertTrue(store.verified_state()[payload['subject_ref']]['deleted'])
        self.assertEqual(store.append(payload)['seq'],1)
        self.assertEqual(len([key for key in store.client.objects if '/records/' in key]),1)
    def test_remote_anchor_rollback_cannot_silently_admit_cached_state(self):
        store=self.store();store.append(self.payload())
        store.client.put_object(Bucket='synthetic',Key='test/latest.json',Body=canonical(store.journal.anchor(0,ZERO)))
        with self.assertRaises(JournalCorrupt):store.verified_state()
