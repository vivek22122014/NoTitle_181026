import {test,expect,type Page} from '@playwright/test';

async function choices(page:Page){
  if(await page.getByLabel('Display name',{exact:true}).isEnabled())await page.getByLabel('Display name',{exact:true}).fill('Synthetic person');
  await page.getByLabel('Declared gender').selectOption('other');
  await page.getByRole('checkbox',{name:/at least 18/}).check();
  await page.getByRole('checkbox',{name:/accept the Terms/}).check();
  await page.getByRole('checkbox',{name:/core processing/}).check();
}
test('desktop and mobile entry do not preselect consent or submit on mount',async({page})=>{
  const mutations:string[]=[];page.on('request',request=>{if(request.method()==='POST')mutations.push(request.url());});
  for(const width of [1280,390]){
    await page.setViewportSize({width,height:844});await page.goto('/join/');
    await expect(page.getByRole('heading',{name:'Show up as yourself.'})).toBeVisible();
    for(const box of await page.getByRole('checkbox').all())await expect(box).not.toBeChecked();
    expect(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth)).toBeTruthy();
  }
  expect(mutations).toEqual([]);
});
test('guest withdrawal keeps protected support and does not start chat',async({page})=>{
  await page.goto('/join/');await choices(page);await page.getByRole('button',{name:'Continue as guest',exact:true}).click();
  await expect(page.getByRole('heading',{name:/^Hello, Guest [0-9a-f]{8}\.$/})).toBeVisible();
  await page.getByRole('link',{name:'Privacy controls',exact:true}).click();
  await page.getByRole('button',{name:'Withdraw my participation consent.',exact:true}).click();
  await expect(page.getByRole('button',{name:'Allow core processing',exact:true})).toBeVisible();
  await page.getByRole('link',{name:'Chat with Moderator',exact:true}).first().click();
  await expect(page.getByRole('heading',{name:'Chat with Moderator.',exact:true})).toBeVisible();
  await expect(page.getByRole('button',{name:'Prepare private case receipt',exact:true})).toBeEnabled();
  expect(await page.evaluate(()=>Object.keys(localStorage).length+Object.keys(sessionStorage).length)).toEqual(0);
});
test('registration saves proof before commit and returns owner controls',async({page})=>{
  await page.goto('/register/');await choices(page);
  await page.getByLabel('Private username',{exact:true}).fill('test_'+Date.now().toString(36));
  await page.getByLabel('Password',{exact:true}).fill('Synthetic private passphrase!');
  await page.getByRole('button',{name:'Prepare recovery code',exact:true}).click();
  await expect(page.getByRole('button',{name:'Create account with saved code',exact:true})).toBeDisabled();
  await expect(page.getByText('Secret hidden',{exact:false})).toBeVisible();
  const saved=page.waitForEvent('download');await page.getByRole('button',{name:'Download',exact:true}).click();await saved;
  await page.getByRole('checkbox',{name:/I have saved the reference/}).check();
  await page.getByRole('button',{name:'Create account with saved code',exact:true}).click();
  await expect(page.getByRole('heading',{name:'Hello, Synthetic person.'})).toBeVisible();
  await page.getByRole('link',{name:'Privacy controls',exact:true}).click();
  await expect(page.getByRole('button',{name:'Prepare deletion receipt',exact:true})).toBeVisible();
  await page.getByRole('button',{name:'Withdraw my participation consent.',exact:true}).click();
  await expect(page.getByRole('button',{name:'Allow core processing',exact:true})).toBeVisible();
  await page.getByRole('link',{name:'Security and password verification',exact:true}).click();
  await page.getByRole('button',{name:'Sign out',exact:true}).click();
  await expect(page.getByRole('heading',{name:'Privacy access without an account.'})).toBeVisible();
  expect(new URL(page.url()).search).toEqual('');
});
