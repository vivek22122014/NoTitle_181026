import test from 'node:test';
import assert from 'node:assert/strict';
import {Client,money} from '../../web/shared/client.ts';
const response=(data,status=200)=>new Response(JSON.stringify(status===200?{data}:{error:{code:'AUTHENTICATION_REQUIRED'}}),{status,headers:{'Content-Type':'application/json'}});
function deferred(){let resolve;const promise=new Promise(done=>resolve=done);return {promise,resolve};}

test('staff remedy previews display every paise without rounding a partial amount to whole rupees',()=>{
 assert.equal(money(9950),'₹99.50');assert.equal(money(1),'₹0.01');assert.throws(()=>money(1.5));assert.throws(()=>money(NaN));
});

test('private adapter bounds input, keeps credentials out of URLs and never persists browser state',async()=>{
 const original=globalThis.fetch;let calls=0;globalThis.fetch=async()=>{calls++;return response({ok:true});};
 try{const client=new Client('/internal/v1');for(const path of ['//outside.invalid/x','/cases?secret=private','/cases#private','/cases\\x'])await assert.rejects(client.request(path));assert.equal(calls,0);assert.deepEqual(await client.request('/cases'),{ok:true});assert.equal(calls,1);}
 finally{globalThis.fetch=original;}
});
test('late private response cannot restore CSRF or content after authority clear',async()=>{
 const original=globalThis.fetch,waiting=deferred();globalThis.fetch=()=>waiting.promise;
 try{const client=new Client('/internal/v1');client.csrf='old';const pending=client.request('/cases');client.clear();waiting.resolve(response({csrf:'stale',items:[{body:'private'}]}));await assert.rejects(pending,error=>error.code==='STALE_AUTHORITY');assert.equal(client.csrf,'');}
 finally{globalThis.fetch=original;}
});
test('new staff login fences an earlier request and installs only its current CSRF',async()=>{
 const original=globalThis.fetch,waiting=deferred();globalThis.fetch=async path=>path.endsWith('/auth/login')?response({csrf:'current'}):waiting.promise;
 try{const client=new Client('/internal/v1'),old=client.request('/cases');await client.request('/auth/login','POST',{username:'staff',password:'private',code:'123456'});waiting.resolve(response({csrf:'old',items:[]}));await assert.rejects(old,error=>error.code==='STALE_AUTHORITY');assert.equal(client.csrf,'current');}
 finally{globalThis.fetch=original;}
});
test('uncertain private mutations are never replayed automatically',async()=>{
 const original=globalThis.fetch;let calls=0;globalThis.fetch=async()=>{calls++;throw new TypeError('synthetic transport loss');};
 try{await assert.rejects(new Client('/internal/v1').request('/cases/ref/messages','POST',{body:'private'}),error=>error.code==='ACTION_UNCONFIRMED');assert.equal(calls,1);}
 finally{globalThis.fetch=original;}
});
test('private adapter rejects advertised and streamed oversized replies',async()=>{
 const original=globalThis.fetch;
 try{for(const advertised of [false,true]){globalThis.fetch=async()=>new Response('x'.repeat(1048577),{headers:advertised?{'Content-Length':'1048577'}:{}});await assert.rejects(new Client('/internal/v1').request('/cases'),error=>error.code==='RESPONSE_LIMIT');}}
 finally{globalThis.fetch=original;}
});
test('unauthorized private reads revoke pending authority and clear scoped credentials',async()=>{
 const original=globalThis.fetch;globalThis.fetch=async()=>response({},401);
 try{const client=new Client('/internal/v1');client.csrf='old';client.scoped={case:'case'};await assert.rejects(client.request('/cases'),error=>error.status===401);assert.equal(client.csrf,'');assert.deepEqual(client.scoped,{});assert.equal(client.generation,1);}
 finally{globalThis.fetch=original;}
});
