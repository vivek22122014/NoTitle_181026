/** Real-browser smoke flows against the running disposable application.
 * No network interception, seeded production entitlements or fabricated replies.
 * Traces/screenshots/video stay disabled by the root Playwright configuration.
 */
import {test,expect,type Page,type Browser} from '@playwright/test';

type Receipt={reservation_id:string;secret:string};
async function guest(page:Page){
  await page.goto('/join/');
  await expect(page.getByLabel('Display name',{exact:true})).toBeDisabled();
  await page.getByLabel('Declared gender').selectOption('other');
  await page.getByRole('checkbox',{name:/at least 18/}).check();
  await page.getByRole('checkbox',{name:/accept the Terms/}).check();
  await page.getByRole('checkbox',{name:/core processing/}).check();
  await page.getByRole('button',{name:'Continue as guest',exact:true}).click();
  const heading=page.getByRole('heading',{name:/^Hello, Guest [0-9a-f]{8}\.$/});
  await expect(heading).toBeVisible();const name=(await heading.innerText()).slice(7,-1);
  await page.getByRole('link',{name:'Open conversation lobby',exact:true}).click();
  await expect(page.getByRole('button',{name:'Search',exact:true})).toBeEnabled();return name;
}
async function pair(browser:Browser){
  const a=await browser.newContext(),b=await browser.newContext({viewport:{width:390,height:844}});
  const left=await a.newPage(),right=await b.newPage();
  const starts={left:0,right:0};
  for(const [page,side] of [[left,'left'],[right,'right']] as const)page.on('websocket',socket=>socket.on('framereceived',frame=>{
    try{const event=JSON.parse(String(frame.payload));if(event.type==='interaction.started')starts[side]++;}catch{/* Ignore binary/non-JSON frames; do not retain payloads. */}
  }));
  const leftName=await guest(left),rightName=await guest(right);
  await left.getByRole('button',{name:'Search',exact:true}).click();
  await right.getByRole('button',{name:'Search',exact:true}).click();
  await expect(left.getByRole('heading',{name:rightName,exact:true})).toBeVisible();
  await expect(right.getByRole('heading',{name:leftName,exact:true})).toBeVisible();
  return {a,b,left,right,leftName,rightName,starts};
}
async function saveReceipt(page:Page){
  const download=page.waitForEvent('download');await page.getByRole('button',{name:'Download',exact:true}).click();
  const file=await download;expect(await file.failure()).toBeNull();await file.delete();
  await page.getByRole('checkbox',{name:/I have saved the reference and secret/}).check();
}
async function noBrowserPersistence(page:Page){
  expect(await page.evaluate(()=>Object.keys(localStorage).length+Object.keys(sessionStorage).length)).toBe(0);
  const url=new URL(page.url());expect(url.search).toBe('');expect(url.hash).toBe('');
}

test('free guest friendship requires acceptance; a named invitation requires fresh explicit acceptance',async({browser})=>{
  const {a,b,left,right,leftName,rightName,starts}=await pair(browser);
  try{
    await left.getByRole('button',{name:'Add friend',exact:true}).click();
    await expect(left.getByText('Friend request pending. Either person can end the conversation.',{exact:true})).toBeVisible();
    await expect(right.getByRole('button',{name:'Accept friendship',exact:true})).toBeVisible();
    await right.getByRole('button',{name:'Accept friendship',exact:true}).click();
    await expect(left.getByText('Friend request pending. Either person can end the conversation.',{exact:true})).toHaveCount(0);
    await expect(right.getByRole('button',{name:'Accept friendship',exact:true})).toHaveCount(0);
    await left.getByRole('button',{name:'End conversation',exact:true}).click();
    await expect(right.getByRole('button',{name:'Search',exact:true})).toBeEnabled();
    for(const page of [left,right])await page.locator('a[href="/friends/"]:visible').first().click();
    const leftFriend=left.locator('li').filter({has:left.getByText(rightName,{exact:true})});
    const rightFriend=right.locator('li').filter({has:right.getByText(leftName,{exact:true})});
    await expect(leftFriend.getByText('Temporary · Available',{exact:true})).toBeVisible();
    await expect(rightFriend.getByText('Temporary · Available',{exact:true})).toBeVisible();
    const before={...starts};
    await leftFriend.getByRole('button',{name:'Invite',exact:true}).click();
    await expect(right.getByRole('heading',{name:'Invitation from '+leftName,exact:true})).toBeVisible();
    await expect(right.getByRole('button',{name:'Accept invitation',exact:true})).toBeEnabled();
    // Receipt of an invitation must not create a second interaction by itself.
    expect(starts).toEqual(before);
    await right.getByRole('button',{name:'Accept invitation',exact:true}).click();
    await expect.poll(()=>starts.left).toBe(before.left+1);await expect.poll(()=>starts.right).toBe(before.right+1);
    for(const page of [left,right])await page.getByRole('link',{name:'Open conversation',exact:true}).click();
    await expect(left.getByRole('heading',{name:rightName,exact:true})).toBeVisible();
    await expect(right.getByRole('heading',{name:leftName,exact:true})).toBeVisible();
    await left.getByLabel('Message',{exact:true}).fill('Synthetic invited conversation');
    await left.getByRole('button',{name:'Send',exact:true}).click();
    await expect(right.getByText('Synthetic invited conversation',{exact:true})).toBeVisible();
    for(const page of [left,right])await noBrowserPersistence(page);
    await left.getByRole('button',{name:'End conversation',exact:true}).click();
  }finally{await a.close();await b.close();}
});

test('report-and-block ends contact before submission; selected evidence stays separate from saved support',async({browser})=>{
  const {a,b,left,right}=await pair(browser);
  try{
    const evidence='Synthetic selected evidence for a safety report';
    await right.getByLabel('Message',{exact:true}).fill(evidence);await right.getByRole('button',{name:'Send',exact:true}).click();
    await expect(left.getByTestId('transcript').getByText(evidence,{exact:true})).toBeVisible();
    const prepared=left.waitForResponse(response=>new URL(response.url()).pathname==='/api/v1/reports/prepare'&&response.request().method()==='POST');
    await left.getByRole('button',{name:'Report and block',exact:true}).click();
    const response=await prepared;expect(response.status()).toBe(200);const snapshot=(await response.json()).data;
    expect(snapshot.locally_blocked).toBe(true);expect(snapshot.messages.length).toBe(1);
    await expect(left.getByTestId('transcript').getByText(evidence,{exact:true})).toHaveCount(0);
    await expect(right.getByTestId('transcript').getByText(evidence,{exact:true})).toHaveCount(0);
    await expect(right.getByRole('button',{name:'Search',exact:true})).toBeEnabled();
    const panel=left.getByRole('region',{name:'Report and block',exact:true});
    await panel.getByRole('checkbox',{name:new RegExp(evidence)}).check();
    await panel.getByLabel('Reason',{exact:true}).selectOption('harassment');
    const allegation='Synthetic allegation for moderator qualification';await panel.getByLabel('What happened?',{exact:true}).fill(allegation);
    const preparation=left.waitForResponse(response=>new URL(response.url()).pathname==='/api/v1/operations/prepare'&&response.request().method()==='POST');
    await panel.getByRole('button',{name:'Prepare private case receipt',exact:true}).click();
    const receipt:Receipt=(await (await preparation).json()).data;
    await expect(panel.getByRole('button',{name:'Submit selected report',exact:true})).toBeDisabled();
    await saveReceipt(left);
    const submitted=left.waitForResponse(response=>new URL(response.url()).pathname==='/api/v1/reports'&&response.request().method()==='POST');
    await panel.getByRole('button',{name:'Submit selected report',exact:true}).click();
    const committed=await submitted;expect(committed.status()).toBe(201);const result=(await committed.json()).data;
    await expect(panel.getByText(/Report saved\. Case reference:/)).toBeVisible();
    expect(/^[0-9a-f]{32}$/.test(result.case_ref)).toBe(true);
    const submittedIds=committed.request().postDataJSON().selected_ids;
    expect(submittedIds).toEqual([snapshot.messages[0].id]);
    await panel.getByRole('link',{name:'Chat with Moderator',exact:true}).click();
    await left.getByLabel('Case receipt reference',{exact:true}).fill(receipt.reservation_id);
    await left.getByLabel('Case receipt secret',{exact:true}).fill(receipt.secret);
    await left.getByRole('button',{name:'Open saved case',exact:true}).click();
    await expect(left.getByRole('heading',{name:'Saved conversation',exact:true})).toBeVisible();
    await expect(left.locator('.thread-example .message').filter({hasText:allegation})).toBeVisible();
    await expect(left.getByText(evidence,{exact:true})).toHaveCount(0);
    await left.getByLabel('Your reply',{exact:true}).fill('Synthetic saved report follow-up');
    await left.getByRole('button',{name:'Send reply',exact:true}).click();
    await expect(left.locator('.thread-example .message').filter({hasText:'Synthetic saved report follow-up'})).toBeVisible();
    await noBrowserPersistence(left);await left.reload();
    await expect(left.locator('.thread-example .message').filter({hasText:'Synthetic saved report follow-up'})).toBeVisible();
    await expect(left.getByText(evidence,{exact:true})).toHaveCount(0);await noBrowserPersistence(left);
  }finally{await a.close();await b.close();}
});

test('unbound protected support publishes a saved receipt and restores durable history after reload',async({page})=>{
  await page.goto('/support/');await expect(page.getByRole('heading',{name:'Chat with Moderator.',exact:true})).toBeVisible();
  await page.getByLabel('Subject',{exact:true}).fill('Synthetic protected intake');
  await page.getByLabel('Message',{exact:true}).fill('Synthetic saved support question');
  await page.getByRole('button',{name:'Prepare private case receipt',exact:true}).click();
  await expect(page.getByRole('button',{name:'Save case',exact:true})).toBeDisabled();await saveReceipt(page);
  await page.getByRole('button',{name:'Save case',exact:true}).click();
  await expect(page.getByRole('heading',{name:'Saved conversation',exact:true})).toBeVisible();
  await expect(page.locator('.thread-example .message').filter({hasText:'Synthetic saved support question'})).toBeVisible();
  await page.getByLabel('Your reply',{exact:true}).fill('Synthetic durable follow-up');
  await page.getByRole('button',{name:'Send reply',exact:true}).click();
  await expect(page.locator('.thread-example .message').filter({hasText:'Synthetic durable follow-up'})).toBeVisible();
  await page.reload();await expect(page.locator('.thread-example .message').filter({hasText:'Synthetic durable follow-up'})).toBeVisible();
  await noBrowserPersistence(page);
});
