import {test,expect,type Page,type Browser} from '@playwright/test';
async function guest(page:Page,name:string){
  await page.goto('/join/');await expect(page.getByLabel('Display name',{exact:true})).toBeDisabled();await page.getByLabel('Declared gender').selectOption('other');
  await page.getByRole('checkbox',{name:/at least 18/}).check();await page.getByRole('checkbox',{name:/accept the Terms/}).check();await page.getByRole('checkbox',{name:/core processing/}).check();
  await page.getByRole('button',{name:'Continue as guest',exact:true}).click();await expect(page.getByRole('heading',{name:/^Hello, Guest [0-9a-f]{8}\.$/})).toBeVisible();const assigned=(await page.getByRole('heading',{name:/^Hello, Guest /}).innerText()).slice(7,-1);await page.getByRole('link',{name:'Open conversation lobby',exact:true}).click();
  await expect(page.getByRole('button',{name:'Search',exact:true})).toBeEnabled();return assigned;
}
async function pair(browser:Browser){
  const a=await browser.newContext(),b=await browser.newContext({viewport:{width:390,height:844}}),left=await a.newPage(),right=await b.newPage();
  const leftName=await guest(left,'Synthetic left'),rightName=await guest(right,'Synthetic right');await left.getByRole('button',{name:'Search',exact:true}).click();await right.getByRole('button',{name:'Search',exact:true}).click();
  await expect(left.getByRole('heading',{name:rightName,exact:true})).toBeVisible();await expect(right.getByRole('heading',{name:leftName,exact:true})).toBeVisible();return {a,b,left,right};
}
test('two independent identities match; plain text, delivery and End work on desktop and mobile',async({browser})=>{
  const {a,b,left,right}=await pair(browser);
  try{
    expect(await right.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy();
    const text='<img src=x onerror=alert(1)> Synthetic temporary text';await left.getByLabel('Message',{exact:true}).fill(text);await left.getByLabel('Message',{exact:true}).press('Enter');
    await expect(right.getByText(text,{exact:true})).toBeVisible();await expect(right.getByTestId('transcript').locator('img')).toHaveCount(0);await expect(left.getByText('Delivered to the other browser',{exact:true})).toBeVisible();
    for(const page of [left,right])expect(await page.evaluate(()=>Object.keys(localStorage).length+Object.keys(sessionStorage).length)).toEqual(0);
    await left.getByRole('button',{name:'End conversation',exact:true}).click();await expect(left.getByText(text,{exact:true})).toHaveCount(0);await expect(right.getByText(text,{exact:true})).toHaveCount(0);await expect(right.getByRole('button',{name:'Search',exact:true})).toBeEnabled();
    await expect(right.getByRole('link',{name:'Chat with Moderator',exact:true}).first()).toBeVisible();
  }finally{await a.close();await b.close();}
});
test('Next clears both transcripts and the peer remains idle until explicit Search',async({browser})=>{
  const {a,b,left,right}=await pair(browser);
  try{
    await left.getByLabel('Message',{exact:true}).fill('Synthetic previous conversation');await left.getByRole('button',{name:'Send',exact:true}).click();await expect(right.getByText('Synthetic previous conversation',{exact:true})).toBeVisible();
    await left.getByRole('button',{name:'Next conversation',exact:true}).click();await expect(right.getByText('Synthetic previous conversation',{exact:true})).toHaveCount(0);await expect(right.getByRole('button',{name:'Search',exact:true})).toBeEnabled();await expect(left.getByRole('button',{name:'Cancel search',exact:true})).toBeVisible();
    await left.getByRole('button',{name:'Cancel search',exact:true}).click();await expect(left.getByRole('button',{name:'Search',exact:true})).toBeEnabled();
  }finally{await a.close();await b.close();}
});
test('reload requires an explicit action; a current RAM conversation can resume without a second search',async({browser})=>{
  const {a,b,left,right}=await pair(browser);
  try{
    await right.getByLabel('Message',{exact:true}).fill('Synthetic bounded reconnect');await right.getByRole('button',{name:'Send',exact:true}).click();await expect(left.getByText('Synthetic bounded reconnect',{exact:true})).toBeVisible();
    await left.reload();await expect(left.getByRole('button',{name:'Search',exact:true})).toBeEnabled();await expect(left.getByText('Synthetic bounded reconnect',{exact:true})).toHaveCount(0);
    await left.getByRole('button',{name:'Search',exact:true}).click();await expect(left.getByText('Synthetic bounded reconnect',{exact:true})).toBeVisible();await expect(left.getByRole('button',{name:'End conversation',exact:true})).toBeEnabled();
    await left.getByRole('button',{name:'End conversation',exact:true}).click();
  }finally{await a.close();await b.close();}
});
test('another tab needs explicit takeover and the replaced tab clears temporary content',async({browser})=>{
  const {a,b,left,right}=await pair(browser);
  try{
    await right.getByLabel('Message',{exact:true}).fill('Synthetic takeover');await right.getByRole('button',{name:'Send',exact:true}).click();await expect(left.getByText('Synthetic takeover',{exact:true})).toBeVisible();
    const replacement=await a.newPage();await replacement.goto('/chat/');await replacement.getByRole('button',{name:'Search',exact:true}).click();await expect(replacement.getByRole('button',{name:'Take over chat explicitly',exact:true})).toBeVisible();await replacement.getByRole('button',{name:'Take over chat explicitly',exact:true}).click();
    await expect(replacement.getByText('Synthetic takeover',{exact:true})).toBeVisible();await expect(left.getByText('Synthetic takeover',{exact:true})).toHaveCount(0);await expect(left.getByRole('button',{name:'Take over chat explicitly',exact:true})).toBeVisible();await replacement.getByRole('button',{name:'End conversation',exact:true}).click();
  }finally{await a.close();await b.close();}
});
test('guest Block ends the chat and reports the actual temporary scope',async({browser})=>{
  const {a,b,left,right}=await pair(browser);
  try{
    await left.getByRole('button',{name:'Block person',exact:true}).click();await left.getByRole('button',{name:'Confirm block',exact:true}).click();await expect(left.getByText(/Blocked for this identity session/)).toBeVisible();await expect(right.getByRole('button',{name:'Search',exact:true})).toBeEnabled();
  }finally{await a.close();await b.close();}
});
