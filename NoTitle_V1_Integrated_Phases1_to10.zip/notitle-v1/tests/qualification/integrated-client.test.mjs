// Actual shared identity, conversation and relationship coordinators; not browser proof.
import test from 'node:test';
import assert from 'node:assert/strict';
import {ClientCoordinator} from '../../web/shared/identity.ts';
import {SocialClient} from '../../web/shared/social.ts';
import {AudioSession} from '../../web/shared/audio.ts';
const ref=letter=>letter.repeat(32),handle=ref('a'),peer=ref('b'),relationship=ref('c'),invite=ref('d');
const snapshot=()=>({state:'idle',interaction:null,queue:null,limits:{messages:30,ring_bytes:65536}});
const friend=()=>({relationship_handle:relationship,peer:{peer_handle:relationship,display_name:'Synthetic friend',gender:'other',topic_id:'career',bio:''},revision:1,persistence:'temporary',presence:'available'});
const interaction=()=>({interaction_handle:handle,search_command_id:null,peer:{peer_handle:peer,display_name:'Synthetic friend',gender:'other',topic_id:'career',bio:''},messages:[],interrupted:false,grace_expires_at:null});
class Socket{
 readyState=0;bufferedAmount=0;sent=[];onopen=null;onmessage=null;onclose=null;onerror=null;
 send(raw){this.sent.push(JSON.parse(raw));}open(){this.readyState=1;this.onopen?.();}
 close(code=1000){this.readyState=3;this.onclose?.({code});}
}
async function fixture(t){
 const api=new ClientCoordinator(),social=new SocialClient(api),chat=api.conversation,sockets=[],timers=new Map();let sequence=0,timer=0,epoch=1;
 api.state={...api.state,phase:'ready',boot:{gates:{admission:true}},owner:{identity_kind:'guest',ref:ref('e'),core_consent:true,policy_current:true,profile_revision:1,preference_revision:1}};
 api.request=async(path)=>path==='/ws/ticket'?{ticket:'s'.repeat(43),expires_in:60,owner_epoch:7,protocol_version:2}:{items:[friend()]};
 chat.io={socket:()=>{const socket=new Socket();sockets.push(socket);return socket;},origin:()=> 'https://notitle.test',now:()=>1800000000000,later:(fn,ms)=>{timers.set(++timer,{fn,ms});return timer;},cancel:id=>timers.delete(id)};
 const emit=(type,data,extra={})=>chat.receive({protocol_version:2,type,data,server_sequence:++sequence,server_time:1800000000,owner_epoch:7,socket_generation:1,interaction_epoch:epoch,...extra});
 const promise=chat.reconnect();await new Promise(resolve=>setImmediate(resolve));const socket=sockets[0];socket.open();emit('session.ready',snapshot());await promise;
 t.after(()=>api.clear());
 return {api,social,chat,socket,timers,sockets,emit,epoch:value=>epoch=value};
}

test('incoming invitation does not search, accept, reconnect or mutate a relationship',async t=>{
 const x=await fixture(t),before=x.socket.sent.length;
 x.emit('friend.invite.received',{invite_handle:invite,relationship_handle:relationship,peer:friend().peer,expires_at:1800000030,incoming:true});
 assert.equal(x.socket.sent.length,before);assert.equal(x.sockets.length,1);assert.equal(x.social.state.notices.length,1);
 assert.equal(x.chat.state.phase,'ready');assert.equal(x.social.state.items.length,0);
});

test('explicit mutual invitation reaches the conversation coordinator with a null random-search id',async t=>{
 const x=await fixture(t);await x.social.invite(friend());
 assert.equal(x.socket.sent.at(-1).type,'friend.invite');assert.deepEqual(x.socket.sent.at(-1).payload,{relationship_handle:relationship});
 x.emit('friend.invite.sent',{invite_handle:invite,relationship_handle:relationship,peer:friend().peer,expires_at:1800000030,incoming:false});
 x.emit('friend.invite.closed',{invite_handle:invite,reason:'accepted'});x.epoch(2);x.emit('interaction.started',interaction());
 assert.equal(x.chat.state.phase,'matched');assert.equal(x.chat.state.interaction.interaction_handle,handle);
 assert.equal(x.social.state.notices.length,0);assert.equal(x.chat.pendingFriend,false);
});

test('declining an invitation cannot authorize an unsolicited conversation start',async t=>{
 const x=await fixture(t);
 x.emit('friend.invite.received',{invite_handle:invite,relationship_handle:relationship,peer:friend().peer,expires_at:1800000030,incoming:true});
 await x.social.respond(x.social.state.notices[0],false);
 assert.deepEqual(x.socket.sent.at(-1).payload,{invite_handle:invite,accept:false});
 x.epoch(2);x.emit('interaction.started',interaction());assert.equal(x.chat.state.interaction,null);
});

test('identity clear tears down relationship state, pending invitations and transport together',async t=>{
 const x=await fixture(t);await x.social.load();await x.social.invite(friend());
 x.emit('friend.invite.sent',{invite_handle:invite,relationship_handle:relationship,peer:friend().peer,expires_at:1800000030,incoming:false});
 x.api.clear();assert.equal(x.social.state.items.length,0);assert.equal(x.social.state.notices.length,0);
 assert.equal(x.chat.pending.size,0);assert.equal(x.chat.pendingFriend,false);assert.equal(x.timers.size,0);assert.equal(x.socket.readyState,3);
});

test('strict wire validation rejects private peer fields before social subscribers can consume them',async t=>{
 const x=await fixture(t);
 assert.throws(()=>x.emit('friend.persisted',{relationship:{...friend(),peer:{...friend().peer,account_id:'private'}}}),/WIRE_CONTRACT/);
 assert.equal(x.social.state.items.length,0);
});

test('stale owner events cannot mutate relationships after a coordinator takeover',async t=>{
 const x=await fixture(t);
 assert.throws(()=>x.emit('friend.persisted',{relationship:friend()},{owner_epoch:6}),/STALE_AUTHORITY/);
 assert.equal(x.social.state.items.length,0);
});

test('conversation teardown is visible to feature subscribers before its server acknowledgment',async t=>{
 const x=await fixture(t);await x.social.invite(friend());x.epoch(2);x.emit('interaction.started',interaction());
 let observed=false;const unsubscribe=x.chat.subscribe(()=>{if(!x.chat.state.interaction)observed=true;});
 await x.chat.end();assert.equal(observed,true);assert.equal(x.chat.state.messages.length,0);
 assert.equal(x.socket.sent.at(-1).type,'interaction.end');unsubscribe();
});

test('audio signaling never opens a new socket or resumes microphone authority after disconnect',async t=>{
 const x=await fixture(t);x.socket.close(1000);
 await assert.rejects(x.chat.sendFeature('call.request',{interaction_handle:handle}),/CONNECTION_CLOSED/);
 assert.equal(x.sockets.length,1);assert.equal(x.chat.pending.size,0);
});

test('an inbound call request only reaches subscribers and never sends acceptance',async t=>{
 const x=await fixture(t);await x.social.invite(friend());x.epoch(2);x.emit('interaction.started',interaction());
 const before=x.socket.sent.length,seen=[];const unsubscribe=x.chat.subscribeEvents(event=>seen.push(event.type));
 x.emit('call.request',{interaction_handle:handle,call_id:ref('f'),expires_in:30});
 assert.equal(x.socket.sent.length,before);assert.deepEqual(seen,['call.request']);
 assert.equal(x.chat.state.phase,'matched');unsubscribe();
});

test('heartbeat only sends background liveness and never performs HTTP session renewal',async t=>{
 const x=await fixture(t),calls=[];x.api.request=async(...args)=>{calls.push(args);throw Error('unexpected background HTTP');};
 const timer=[...x.timers.values()].find(value=>value.ms===20000);assert.ok(timer);timer.fn();
 assert.equal(x.socket.sent.at(-1).type,'heartbeat');assert.deepEqual(calls,[]);
});

test('report protection synchronously clears text without sending End before the evidence freeze',async t=>{
 const x=await fixture(t);await x.social.invite(friend());x.epoch(2);x.emit('interaction.started',interaction());
 x.chat.draft('Synthetic temporary text');x.chat.text();x.chat.draft('Unsent draft');const before=x.socket.sent.length;
 x.chat.protect();assert.equal(x.chat.state.interaction,null);assert.deepEqual(x.chat.state.messages,[]);
 assert.equal(x.chat.state.draft,'');assert.equal(x.chat.state.pending,true);assert.equal(x.socket.sent.length,before);
 x.emit('state.snapshot',{...snapshot(),state:'matched',interaction:interaction()});
 assert.equal(x.chat.state.interaction,null);assert.equal(x.socket.sent.length,before);
 await x.chat.finishProtection(true);assert.equal(x.chat.state.pending,false);assert.equal(x.socket.sent.length,before);
});

test('report preparation failure sends the captured scoped End only after local protection',async t=>{
 const x=await fixture(t);await x.social.invite(friend());x.epoch(2);x.emit('interaction.started',interaction());
 const before=x.socket.sent.length;x.chat.protect();assert.equal(x.socket.sent.length,before);
 await x.chat.finishProtection(false);
 const stop=x.socket.sent.at(-1);assert.equal(stop.type,'interaction.end');assert.deepEqual(stop.payload,{interaction_handle:handle});
 assert.equal(x.socket.sent.length,before+1);assert.equal(x.chat.state.interaction,null);
});

test('late failed report preparation cannot end a newer interaction or clear its state',async t=>{
 const x=await fixture(t);await x.social.invite(friend());x.epoch(2);x.emit('interaction.started',interaction());
 x.chat.protect();await x.chat.search();const search=x.socket.sent.at(-1).command_id;
 x.epoch(3);x.emit('interaction.started',{...interaction(),interaction_handle:ref('f'),search_command_id:search});
 const before=x.socket.sent.length;await x.chat.finishProtection(false);
 assert.equal(x.socket.sent.length,before);assert.equal(x.chat.state.interaction.interaction_handle,ref('f'));assert.equal(x.chat.state.phase,'matched');
});

test('report protection fences a late microphone permission result before any HTTP response',async t=>{
 const x=await fixture(t);await x.social.invite(friend());x.epoch(2);x.emit('interaction.started',interaction());
 let resolve,stopped=0,peers=0;const permission=new Promise(done=>resolve=done),remote={srcObject:null};
 const audio=new AudioSession(()=>{},remote,()=>{}, {microphone:()=>permission,peer:()=>{peers++;throw Error('must not create peer');},later:()=>0,cancel:()=>{}});
 const unsubscribe=x.chat.subscribe(()=>{if(!x.chat.state.interaction)audio.stop();});
 const opening=audio.start(ref('f'),[{urls:['turn:turn.example.test:3478?transport=udp'],username:'synthetic',credential:'synthetic'}],true,2);
 x.chat.protect();resolve({getTracks:()=>[{stop:()=>stopped++}]});await opening;
 assert.equal(stopped,1);assert.equal(peers,0);assert.equal(audio.callId,'');unsubscribe();
});

test('late report preparation callback after identity teardown cannot send captured authority',async t=>{
 const x=await fixture(t);await x.social.invite(friend());x.epoch(2);x.emit('interaction.started',interaction());
 x.chat.protect();x.api.clear();const before=x.socket.sent.length;await x.chat.finishProtection(false);
 assert.equal(x.socket.sent.length,before);assert.equal(x.chat.state.phase,'idle');assert.equal(x.chat.state.interaction,null);
});
