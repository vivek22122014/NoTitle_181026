// Execute the actual shared TypeScript coordinator using Node 24 type erasure.
// These transport tests do not stand in for Next/React/browser qualification.
import test from 'node:test';
import assert from 'node:assert/strict';
import {ClientCoordinator,IdentityError,validateContract} from '../../web/shared/identity.ts';

const hash='a'.repeat(64);
function bootstrap(kind='bootstrap'){
  return {csrf:'bootstrap-csrf',scoped_csrf:{},scoped_subjects:{},identity_kind:kind,policy_version:'v1-test',policy_digest:hash,
    policy:{version:'v1-test',publication_digest:hash,state:'draft',effective_at:null,purposes:{core:{label:'Core choice',text_digest:hash,documents:['privacy']}}},
    gates:{identity:true,admission:false,audio:false,payments:false,payment_mode:'sandbox'},owner_epoch:1,server_time:'2026-10-17T00:00:00Z'};
}
function owner(ref='owner-a'){
  return {identity_kind:'account',ref,username:'owner_name',profile:{display_name:'Test owner',gender:'other',topic_id:'general',bio:''},preferences:{},professional:{},core_consent:true,professional_consent:false,profile_revision:1,preference_revision:1,consent_revision:1,account_status:'active',policy_current:true,entitlement:{available_seconds:0,premium_until:0,entitlement_revision:0}};
}
const response=(data,status=200)=>new Response(JSON.stringify({data,request_id:'test-request'}),{status,headers:{'Content-Type':'application/json'}});
function transport(context,handler){const original=globalThis.fetch;globalThis.fetch=handler;context.after(()=>{globalThis.fetch=original;});}

test('start coalesces bootstrap and does not mutate or read an account when unauthenticated',async context=>{
  const calls=[];transport(context,async(path,options)=>{calls.push([path,options]);return response(bootstrap());});
  const client=new ClientCoordinator();await Promise.all([client.start(),client.start(),client.start()]);
  assert.equal(calls.length,1);assert.equal(calls[0][1].method,'GET');assert.equal(client.state.owner,null);assert.equal(client.state.phase,'ready');
});
test('schema authority rejects sensitive extras, coercion and oversized arrays',()=>{
  assert.throws(()=>validateContract('OwnerResponse',{...owner(),password_hash:'secret'}));
  assert.throws(()=>validateContract('BootstrapView',{...bootstrap(),owner_epoch:true}));
  assert.throws(()=>validateContract('Preferences',{expected_revision:1,industry:['a','b','c','d','e','f']}));
  validateContract('OwnerResponse',owner());
});
test('unknown mutation result is never automatically retried and nonce stays in caller intent',async context=>{
  let calls=0;transport(context,async()=>{calls++;throw new TypeError('synthetic connection loss');});
  const client=new ClientCoordinator();client.csrf='csrf';const intent={client_nonce:crypto.randomUUID()};
  await assert.rejects(client.request('/privacy/exports','POST',intent),error=>error.code==='UNCONFIRMED_RESULT');
  assert.equal(calls,1);assert.ok(intent.client_nonce);
});
test('rotated cookies use response CSRF while scoped receipts keep their own CSRF',async context=>{
  const calls=[];transport(context,async(path,options)=>{calls.push(options);return response(path.endsWith('/support/access')?{csrf:'case-csrf',csrf_scope:'case'}:{csrf:'rotated-csrf'});});
  const client=new ClientCoordinator();client.csrf='old-csrf';
  await client.request('/me/password','POST',{password:'New private passphrase',client_nonce:crypto.randomUUID()});
  await client.request('/support/access','POST',{receipt_ref:'a'.repeat(32),secret:'s'.repeat(43)});
  await client.request('/support/cases/'+'b'.repeat(32)+'/messages','POST',{body:'Question',client_nonce:crypto.randomUUID()},undefined,'case');
  assert.equal(calls[0].headers['X-CSRF-Token'],'old-csrf');assert.equal(calls[1].headers['X-CSRF-Token'],'rotated-csrf');assert.equal(calls[2].headers['X-CSRF-Token'],'case-csrf');assert.equal(calls[2].headers['X-NT-Authority'],'case');
});
test('late response after clear cannot restore CSRF or private data',async context=>{
  let complete;transport(context,()=>new Promise(resolve=>{complete=resolve;}));
  const client=new ClientCoordinator();client.csrf='old';const pending=client.request('/me','GET',undefined,'OwnerResponse');
  client.clear();complete(response({...owner(),csrf:'late'}));
  await assert.rejects(pending);assert.equal(client.csrf,'');assert.equal(client.state.owner,null);assert.equal(client.controllers.size,0);
});
test('owner replacement clears private subscribers and releases the busy flag',async context=>{
  transport(context,async path=>response(path.endsWith('/bootstrap')?bootstrap('account'):owner('owner-b')));
  const client=new ClientCoordinator();client.state={...client.state,owner:owner(),busy:true};let cleared=0;client.teardowns.add(()=>cleared++);
  await client.refresh();assert.equal(cleared,1);assert.equal(client.state.generation,1);assert.equal(client.state.owner.ref,'owner-b');assert.equal(client.state.busy,false);
});
test('failed authority refresh clears owned data and scopes',async context=>{
  transport(context,async()=>response({...bootstrap(),database_password:'forbidden'}));
  const client=new ClientCoordinator();client.state={...client.state,owner:owner(),boot:bootstrap('account')};client.scoped={case:'old-case-csrf'};
  await client.refresh();assert.equal(client.state.phase,'unavailable');assert.equal(client.state.owner,null);assert.equal(client.state.boot,null);assert.deepEqual(client.scoped,{});assert.equal(client.csrf,'');
});
test('oversized response is cancelled rather than retained',async context=>{
  let cancelled=false;transport(context,async()=>new Response(new ReadableStream({start(controller){controller.enqueue(new Uint8Array(512*1024+1));},cancel(){cancelled=true;}})));
  const client=new ClientCoordinator();await assert.rejects(client.request('/bootstrap'),error=>error.code==='INVALID_RESPONSE');assert.equal(cancelled,true);
});
test('invalid inputs and credential URLs never reach fetch',async context=>{
  let calls=0;transport(context,async()=>{calls++;return response({});});const client=new ClientCoordinator();
  await assert.rejects(client.request('/auth/login','POST',{username:'owner',password:'too short'}),error=>error.code==='INVALID_INPUT');
  for(const path of ['https://other.test/','//other.test/','/auth?secret=private','/../me','/me#token'])await assert.rejects(client.request(path));
  assert.equal(calls,0);
});
test('server denials remain sanitized and release mutation ownership',async context=>{
  transport(context,async()=>new Response(JSON.stringify({error:{code:'REVISION_CONFLICT',message:'untrusted private text'},request_id:'x'}),{status:409}));
  const client=new ClientCoordinator();await client.perform(async()=>{await client.request('/me');});
  assert.equal(client.state.busy,false);assert.match(client.state.error,/Refresh/);assert.doesNotMatch(client.state.error,/untrusted/);
});
test('lost JSON after Set-Cookie can refresh CSRF without losing caller intent or retrying the mutation',async context=>{
  const calls=[];transport(context,async(path,options)=>{
    calls.push([path,options.method]);
    if(options.method==='POST')return new Response(JSON.stringify({error:{code:'CSRF_INVALID'},request_id:'x'}),{status:403});
    return response(path.endsWith('/bootstrap')?{...bootstrap('account'),csrf:'current-cookie-csrf'}:owner());
  });
  const client=new ClientCoordinator();client.state={...client.state,phase:'ready',boot:bootstrap('account'),owner:owner()};
  const intent={password:'Saved replacement passphrase',client_nonce:crypto.randomUUID()};
  await client.perform(async()=>{await client.request('/me/password','POST',intent);});
  assert.equal(calls.filter(([,method])=>method==='POST').length,1);assert.equal(client.csrf,'current-cookie-csrf');
  assert.equal(client.state.generation,0);assert.equal(client.state.phase,'ready');assert.equal(client.state.busy,false);assert.ok(intent.client_nonce);
});
