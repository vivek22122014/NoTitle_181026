import {test,expect,type Page} from '@playwright/test';
import routes from '../../web/public/route-data.json';
import privateRoutes from '../../web/admin/route-data.json';
import {boards} from '../../web/public/components/fixtures';
import {boards as staffBoards} from '../../web/admin/components/fixtures';
import {viewStates} from '../../web/shared/interface';

async function noOverflow(page:Page){expect(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth+1)).toBeTruthy();}
test('all exported routes have one heading, metadata and private/no-store boundaries',async({page})=>{
  for(const route of routes){
    const response=await page.goto(route.path);expect(response?.status()).toBe(200);
    await expect(page.locator('h1')).toHaveCount(1);await expect(page.locator('meta[name="description"]')).toHaveCount(1);
    await expect(page.locator('link[rel="canonical"]')).toHaveCount(1);
    expect(response?.headers()['cache-control']).toBe('no-store');expect(response?.headers()['content-security-policy']).toContain('sha256-');
    await expect(page.locator('[data-surface="private-workspace-v1"]')).toHaveCount(0);
  }
  for(const route of privateRoutes){const response=await page.goto('http://127.0.0.1:8081'+route.path);expect(response?.status()).toBe(200);expect(response?.headers()['x-robots-tag']).toContain('noindex');await expect(page.locator('h1')).toHaveCount(1);}
  for(const path of ['/missing-address/','/internal/v1/bootstrap','/admin/'])expect((await page.goto('http://127.0.0.1:8080'+path))?.status()).toBe(404);
});
for(const width of [320,390,1280]){
  test(`all public workflows and response states fit ${width}px`,async({page})=>{
    await page.setViewportSize({width,height:900});const requests:string[]=[];
    page.on('request',request=>{if(/\/(api|internal)\//.test(request.url()))requests.push(request.url());});
    await page.goto('/interface/');
    for(const board of boards){
      await page.getByLabel('Screen group',{exact:true}).selectOption(board.id);
      for(const stage of board.stages){await page.getByLabel('Workflow state',{exact:true}).selectOption(stage.id);await expect(page.locator('.screen-review h1')).toHaveCount(1);await noOverflow(page);}
      for(const state of viewStates){await page.getByLabel('Response state',{exact:true}).selectOption(state);await noOverflow(page);if(state!=='ready')await expect(page.locator(`[data-view-state="${state}"]`)).toBeVisible();}
      await page.getByLabel('Response state',{exact:true}).selectOption('ready');
    }
    expect(requests).toEqual([]);
  });
}
test('private screen groups and all generic states fit mobile',async({page})=>{
  await page.setViewportSize({width:320,height:900});await page.goto('http://127.0.0.1:8081/interface/');
  for(const board of staffBoards){await page.getByLabel('Screen group',{exact:true}).selectOption(board.id);
    for(const stage of board.stages){await page.getByLabel('Workflow state',{exact:true}).selectOption(stage.id);await noOverflow(page);}
    for(const state of viewStates){await page.getByLabel('Response state',{exact:true}).selectOption(state);await noOverflow(page);}
    await page.getByLabel('Response state',{exact:true}).selectOption('ready');
  }
});
test('entry has no assumed consent or gender, with no enabled service action',async({page})=>{
  await page.goto('/join/');const checks=page.getByRole('checkbox');await expect(checks).toHaveCount(4);
  for(const check of await checks.all())await expect(check).not.toBeChecked();
  await expect(page.getByLabel('Declared gender',{exact:true})).toHaveValue('');await expect(page.getByRole('button',{name:'Continue as guest'})).toBeDisabled();
  await checks.nth(0).check();const opened=page.waitForEvent('popup');await page.getByRole('link',{name:'Terms of Service',exact:true}).click();const policy=await opened;await policy.waitForLoadState();await expect(checks.nth(0)).toBeChecked();await policy.close();
  await expect(page.getByRole('button',{name:'Continue as guest'})).toBeDisabled();
});
test('keyboard skip, modal focus containment, Escape and focus restoration',async({page})=>{
  await page.goto('/interface/');await page.keyboard.press('Tab');await expect(page.getByRole('link',{name:'Skip to content',exact:true})).toBeFocused();
  const trigger=page.getByRole('button',{name:'Inspect confirmation sheet'});await trigger.focus();await page.keyboard.press('Enter');
  const dialog=page.getByRole('dialog',{name:'Review a sensitive action'});await expect(dialog).toBeVisible();
  for(let n=0;n<4;n++){await page.keyboard.press('Tab');expect(await dialog.evaluate(element=>element.contains(document.activeElement))).toBeTruthy();}
  await page.keyboard.press('Escape');await expect(dialog).not.toBeVisible();await expect(trigger).toBeFocused();
  await page.getByLabel('Response state',{exact:true}).selectOption('validation');await expect(page.getByLabel('Display name',{exact:true})).toBeFocused();
});
test('policies and information remain readable without JavaScript',async({browser})=>{
  const context=await browser.newContext({javaScriptEnabled:false});const page=await context.newPage();
  for(const path of ['/','/how-it-works/','/safety/','/legal/','/privacy/','/terms/','/cookies/','/data-retention/','/refund-policy/','/community-guidelines/','/your-rights/','/contact/','/processors/','/grievance/','/account-deletion/']){
    await page.goto('http://127.0.0.1:8080'+path);await expect(page.locator('h1')).toHaveCount(1);await expect(page.locator('main')).toBeVisible();
  }
  await page.goto('http://127.0.0.1:8080/refund-policy/');await expect(page.getByRole('heading',{name:'No voluntary refunds',exact:true})).toBeVisible();await expect(page.getByText('non-waivable statutory remedies',{exact:false})).toBeVisible();await context.close();
});
test('200 percent layout proxy and reduced motion stay usable',async({page})=>{
  // 640px layout viewport on a 1280px display approximates 200% layout reflow.
  // Native browser zoom, software keyboard and a screen reader still need manual review.
  await page.setViewportSize({width:640,height:480});await page.emulateMedia({reducedMotion:'reduce'});
  for(const path of ['/join/','/chat/','/friends/','/support/','/settings/','/premium/']){await page.goto(path);await noOverflow(page);await expect(page.locator('h1')).toBeVisible();}
});
