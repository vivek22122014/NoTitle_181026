// Exercise the actual shared social coordinator, not a duplicate state reducer.
import test from 'node:test';
import assert from 'node:assert/strict';
import {SocialClient,friend} from '../../web/shared/social.ts';
const handle='a'.repeat(32),request='b'.repeat(32),interaction='c'.repeat(32);
const row=()=>({relationship_handle:handle,peer:{peer_handle:handle,display_name:'Test friend',gender:'other',topic_id:'career',bio:''},revision:1,persistence:'temporary',presence:'available'});
function fixture(){
  const events=new Set(),calls=[],teardowns=new Set();
  const api={teardowns,request:async(...args)=>{calls.push(args);return {items:[row()]};},conversation:{state:{interaction:{interaction_handle:interaction}},subscribeEvents:listener=>{events.add(listener);return()=>events.delete(listener);},sendFeature:async(...args)=>{calls.push(args);return 'operation';}}};
  const client=new SocialClient(api);return {client,api,calls,emit:(type,data)=>{for(const listener of events)listener({type,data});}};
}
test('load coalesces requests and public projection rejects identity and money extras',async()=>{
  const {client,calls}=fixture();await Promise.all([client.load(),client.load()]);assert.equal(calls.length,1);assert.equal(client.state.items.length,1);
  assert.throws(()=>friend({...row(),account_id:'private'}));assert.throws(()=>friend({...row(),peer:{...row().peer,premium:true}}));assert.throws(()=>friend({...row(),presence:'last_seen_42s_ago'}));
});
test('temporary saving and saved reflect server persistence events only',()=>{
  const {client,emit}=fixture();emit('friend.accepted',{relationship:row()});assert.equal(client.state.items[0].persistence,'temporary');
  emit('friend.saving',{relationship:{...row(),persistence:'saving'}});assert.equal(client.state.items[0].persistence,'saving');
  emit('friend.persisted',{relationship:{...row(),persistence:'saved'}});assert.equal(client.state.items[0].persistence,'saved');assert.equal(client.state.items.length,1);
});
test('failed feature send is caught and never displays acceptance',async()=>{
  const {client,api}=fixture();api.conversation.sendFeature=async()=>{throw Error('connection closed');};await client.request();assert.match(client.state.error,/could not be sent/);assert.equal(client.state.items.length,0);
});
test('late relationship list cannot restore state after identity teardown',async()=>{
  const {client,api}=fixture();let resolve;api.request=()=>new Promise(done=>resolve=done);
  const pending=client.load();for(const teardown of api.teardowns)teardown();resolve({items:[row()]});await pending;assert.deepEqual(client.state.items,[]);assert.equal(client.state.loading,false);
});
test('request response uses only scoped request handle and clears after End',async()=>{
  const {client,api,calls,emit}=fixture();emit('friend.pending',{request_handle:request,interaction_handle:interaction,peer:row().peer,incoming:true});
  await client.respond(client.state.notices[0],true);assert.deepEqual(calls[0],['friend.respond',{request_handle:request,accept:true}]);
  api.conversation.state.interaction=null;client.expire();assert.deepEqual(client.state.notices,[]);
});
test('invitations expire without offline message history or implicit acceptance',async()=>{
  const {client,calls,emit}=fixture();emit('friend.invite.received',{invite_handle:request,relationship_handle:handle,peer:row().peer,expires_at:50,incoming:true});
  assert.equal(calls.length,0);client.expire(50001);assert.equal(client.state.notices.length,0);
});
test('remove waits for authoritative result and sends expected revision',async()=>{
  const {client,calls}=fixture();client.update({items:[row()]});await client.remove(row());assert.equal(client.state.items.length,0);
  assert.deepEqual(calls[0],['/friends/'+handle+'?expected_relationship_revision=1','DELETE']);
});
test('unconfirmed remove keeps row and refreshes instead of claiming success',async()=>{
  const {client,api}=fixture();client.update({items:[row()]});api.request=async(path,method)=>{if(method==='DELETE')throw Error('lost response');return {items:[row()]};};
  await client.remove(row());assert.equal(client.state.items.length,1);assert.match(client.state.error,/not confirmed/);assert.doesNotMatch(client.state.notice,/removed/);
});
