// Runs the actual memory-only coordinator under Node 24; not browser acceptance.
import test from 'node:test';
import assert from 'node:assert/strict';
import {ClientCoordinator} from '../../web/shared/identity.ts';
import {validateWire} from '../../web/shared/wire.ts';
const ref=letter=>letter.repeat(32),handle=ref('a'),peer=ref('b');
const snapshot=(interaction=null,queue=null)=>({state:interaction?'matched':queue?'searching':'idle',interaction,queue,limits:{messages:30,ring_bytes:65536}});
const interaction=(search=null,messages=[])=>({interaction_handle:handle,search_command_id:search,peer:{peer_handle:peer,display_name:'Synthetic peer',gender:'other',topic_id:'general',bio:''},messages,interrupted:false,grace_expires_at:null});
const message=(id=ref('c'),sender='peer',command_id=null)=>({id,sequence:1,sender,text:'<script>synthetic plain text</script>',sent_at:1800000000.,delivered:false,command_id});
class Socket{
  readyState=0;bufferedAmount=0;sent=[];onopen=null;onmessage=null;onclose=null;onerror=null;
  send(raw){this.sent.push(JSON.parse(raw));}open(){this.readyState=1;this.onopen?.();}
  close(code=1000){this.readyState=3;this.onclose?.({code});}
}
function setup(t){
  const api=new ClientCoordinator(),chat=api.conversation,sockets=[],timers=new Map(),calls=[];let now=1800000000000,timer=0,seq=0,generation=1,epoch=1;
  api.state={...api.state,phase:'ready',boot:{gates:{admission:true}},owner:{identity_kind:'guest',ref:ref('d'),core_consent:true,policy_current:true,profile_revision:1,preference_revision:1}};
  api.request=async(path,method,body)=>{calls.push({path,method,body});if(path==='/ws/ticket')return {ticket:'s'.repeat(43),expires_in:60,owner_epoch:7,protocol_version:2};if(path==='/interactions/end')return {command_id:body.command_id,ok:true,status:'ended'};return {persisted:false};};
  chat.io={socket:url=>{assert.equal(url,'wss://notitle.test/api/v1/ws');const socket=new Socket();sockets.push(socket);return socket;},origin:()=> 'https://notitle.test',now:()=>now,later:(fn,ms)=>{timers.set(++timer,{fn,ms});return timer;},cancel:id=>timers.delete(id)};
  const emit=(type,data,overrides={})=>chat.receive({protocol_version:2,type,data,server_sequence:++seq,server_time:now/1000,owner_epoch:7,socket_generation:generation,interaction_epoch:epoch,...overrides});
  const connect=async(data=snapshot())=>{const promise=chat.reconnect();await new Promise(r=>setImmediate(r));const socket=sockets.at(-1);socket.open();emit('session.ready',data);await promise;return socket;};
  t.after(()=>chat.stop());
  return {api,chat,sockets,timers,calls,emit,connect,advance:ms=>{now+=ms;},generation:value=>{generation=value;seq=0;},epoch:value=>{epoch=value;}};
}
async function matched(x){const socket=await x.connect();await x.chat.search();const search=socket.sent.at(-1).command_id;x.epoch(3);x.emit('interaction.started',interaction(search));return socket;}

test('initial lobby performs no search or transport mutation and uses no browser storage',t=>{
  const x=setup(t);assert.equal(x.chat.state.phase,'idle');assert.equal(x.calls.length,0);assert.equal(x.sockets.length,0);assert.equal(x.chat.state.messages.length,0);
});
test('ticket is in one hello frame, exact same-origin socket, never a query',async t=>{
  const x=setup(t),socket=await x.connect();assert.deepEqual(socket.sent,[{protocol_version:2,type:'session.hello',ticket:'s'.repeat(43)}]);assert.equal(x.chat.state.phase,'ready');
  assert.equal(x.calls[0].path,'/ws/ticket');assert.equal(socket.sent.filter(frame=>frame.type==='queue.join').length,0);
});
test('strict generated event and command schemas reject extras and stale wire versions',t=>{
  const x=setup(t);
  assert.throws(()=>validateWire('Hello',{protocol_version:1,type:'session.hello',ticket:'s'.repeat(43)}));
  assert.throws(()=>validateWire('Hello',{protocol_version:2,type:'session.hello',ticket:'s'.repeat(43),cookie:'private'}));
  assert.throws(()=>validateWire('Event',{protocol_version:2,type:'text.message',data:{text:'missing scopes'}}));
});
test('cancel while ticket request waits prevents late automatic search',async t=>{
  const x=setup(t);let finish;x.api.request=()=>new Promise(resolve=>{finish=resolve;});const pending=x.chat.search();await x.chat.cancel();finish({ticket:'s'.repeat(43),expires_in:60,owner_epoch:7,protocol_version:2});await pending;
  assert.equal(x.sockets.length,0);assert.equal(x.chat.state.interaction,null);assert.equal(x.chat.state.phase,'idle');
});
test('text rendering and explicit delivery receipt are distinct from Accepted',async t=>{
  const x=setup(t),socket=await matched(x);x.chat.draft('Synthetic hello');x.chat.text();const command=socket.sent.at(-1);assert.equal(command.type,'text.send');assert.equal(x.chat.state.messages[0].status,'pending');
  const own={...message(ref('c'),'me',command.command_id),text:'Synthetic hello'};x.emit('text.message',{interaction_handle:handle,message:own});assert.equal(x.chat.state.messages.length,1);assert.equal(x.chat.state.messages[0].status,'accepted');
  x.emit('text.delivered',{interaction_handle:handle,message_id:own.id,sequence:1});assert.equal(x.chat.state.messages[0].status,'delivered');
  x.emit('text.message',{interaction_handle:handle,message:{...message(ref('e')),sequence:2}});
  assert.equal(socket.sent.filter(c=>c.type==='text.delivered').length,0);x.chat.renderedMessages();x.chat.renderedMessages();assert.equal(socket.sent.filter(c=>c.type==='text.delivered').length,1);
});
test('composer bounds Unicode and bytes, ring is bounded with pending messages',async t=>{
  const x=setup(t);await matched(x);x.chat.draft('🙂'.repeat(2001));assert.ok(new TextEncoder().encode(x.chat.state.draft).length<=6144);assert.ok(Array.from(x.chat.state.draft).length<=2000);
  x.chat.draft('x\x00y');assert.throws(()=>x.chat.text());
  x.chat.boundMessages(Array.from({length:50},()=>({...message(),text:'文'.repeat(2000),status:'accepted'})));assert.ok(x.chat.state.messages.length<=30);assert.ok(x.chat.state.messages.reduce((sum,m)=>sum+new TextEncoder().encode(m.text).length,0)<=65536);
});
test('Next erases text before send and preserves its intent through End event',async t=>{
  const x=setup(t),socket=await matched(x);x.emit('text.message',{interaction_handle:handle,message:message()});x.chat.draft('unsent');x.chat.next();const next=socket.sent.at(-1);assert.equal(next.type,'interaction.next');assert.equal(x.chat.state.messages.length,0);assert.equal(x.chat.state.draft,'');
  x.epoch(4);x.emit('interaction.ended',{interaction_handle:handle,reason:'next'});x.epoch(5);x.emit('queue.waiting',{search_command_id:next.command_id,joined_at:1800000000,gender:'everyone',general_talk:true});assert.equal(x.chat.state.phase,'searching');
  x.epoch(6);x.emit('interaction.started',{...interaction(next.command_id),interaction_handle:ref('f')});assert.equal(x.chat.state.phase,'matched');assert.equal(x.chat.state.interaction.interaction_handle,ref('f'));
});
test('End uses identical operation id in HTTP fallback and clears local text immediately',async t=>{
  const x=setup(t),socket=await matched(x);x.emit('text.message',{interaction_handle:handle,message:message()});await x.chat.end();assert.equal(x.chat.state.messages.length,0);const end=socket.sent.at(-1);const timer=[...x.timers.values()].find(timer=>timer.ms===1000);timer.fn();await new Promise(r=>setImmediate(r));
  assert.equal(x.calls.at(-1).path,'/interactions/end');assert.deepEqual(x.calls.at(-1).body,end);assert.equal(x.chat.state.interaction,null);
});
test('late HTTP End acknowledgment cannot clear a newer search or conversation',async t=>{
  const x=setup(t),socket=await matched(x);let finish;x.api.request=()=>new Promise(resolve=>{finish=resolve;});socket.bufferedAmount=65537;const pending=x.chat.end();socket.bufferedAmount=0;
  await x.chat.search();const search=socket.sent.at(-1);x.epoch(8);x.emit('interaction.started',{...interaction(search.command_id),interaction_handle:ref('f')});finish({status:'already_ended'});await pending;
  assert.equal(x.chat.state.interaction.interaction_handle,ref('f'));assert.equal(x.chat.state.phase,'matched');
});
test('interruption disables text, explicit reconnect restores only the current bounded ring',async t=>{
  const x=setup(t),socket=await matched(x);x.emit('text.message',{interaction_handle:handle,message:message()});socket.close(1006);assert.equal(x.chat.state.phase,'interrupted');assert.throws(()=>x.chat.text());x.generation(2);
  const reconnect=x.chat.reconnect();await new Promise(r=>setImmediate(r));const next=x.sockets.at(-1);next.open();x.emit('session.ready',snapshot(interaction(null,[message()])));await reconnect;
  assert.equal(x.chat.state.phase,'matched');assert.equal(x.chat.state.messages.length,1);assert.equal(next.sent.filter(c=>['queue.join','text.send'].includes(c.type)).length,0);assert.equal([...x.timers.values()].filter(timer=>timer.ms===25000).length,0);
});
test('grace expiry clears all ordinary content, late old-handle frames cannot restore it',async t=>{
  const x=setup(t),socket=await matched(x);x.emit('text.message',{interaction_handle:handle,message:message()});socket.close(1006);const timer=[...x.timers.values()].find(item=>item.ms===25000);timer.fn();assert.equal(x.chat.state.messages.length,0);assert.equal(x.chat.state.interaction,null);
  x.emit('text.message',{interaction_handle:handle,message:message()});assert.equal(x.chat.state.messages.length,0);
});
test('owner identity clear tears down socket, timers, draft and transcript',async t=>{
  const x=setup(t),socket=await matched(x);x.chat.draft('Unsent private text');x.emit('text.message',{interaction_handle:handle,message:message()});x.api.clear();assert.equal(socket.readyState,3);assert.equal(x.chat.state.draft,'');assert.deepEqual(x.chat.state.messages,[]);assert.equal(x.timers.size,0);
});
test('takeover is explicit and a replaced socket never auto-searches',async t=>{
  const x=setup(t),socket=await matched(x);socket.close(4009);assert.equal(x.chat.state.phase,'replaced');assert.equal(x.chat.state.messages.length,0);assert.equal(x.sockets.length,1);
  x.chat.update({takeoverGeneration:9});const pending=x.chat.reconnect(true);await new Promise(r=>setImmediate(r));assert.equal(x.calls.at(-1).body.takeover,true);assert.equal(x.calls.at(-1).body.known_socket_generation,9);x.generation(10);x.sockets.at(-1).open();x.emit('session.ready',snapshot());await pending;assert.equal(x.chat.state.phase,'ready');
});
test('duplicate sequence and wrong interaction handle never add text',async t=>{
  const x=setup(t);await matched(x);x.emit('text.message',{interaction_handle:ref('f'),message:message()});assert.equal(x.chat.state.messages.length,0);
  x.emit('text.message',{interaction_handle:handle,message:message()});const last=x.chat.serverSequence;x.emit('text.message',{interaction_handle:handle,message:{...message(ref('e')),sequence:2}},{server_sequence:last});assert.equal(x.chat.state.messages.length,1);
});
test('bounded socket backpressure prevents additional text frames',async t=>{
  const x=setup(t),socket=await matched(x);socket.bufferedAmount=65537;x.chat.draft('Synthetic hello');assert.throws(()=>x.chat.text());assert.equal(socket.sent.filter(c=>c.type==='text.send').length,0);
});
test('a delayed snapshot cannot restore plaintext after local End',async t=>{
  const x=setup(t);await matched(x);await x.chat.end();x.emit('state.snapshot',snapshot(interaction(null,[message()])));assert.equal(x.chat.state.interaction,null);assert.deepEqual(x.chat.state.messages,[]);
});
test('a Search click that reconnects to an existing conversation restores it without sending queue.join',async t=>{
  const x=setup(t);const pending=x.chat.search();await new Promise(r=>setImmediate(r));const socket=x.sockets.at(-1);socket.open();x.emit('session.ready',snapshot(interaction(null,[message()])));await pending;
  assert.equal(x.chat.state.phase,'matched');assert.equal(socket.sent.filter(command=>command.type==='queue.join').length,0);
});
test('frame gap requests a bounded snapshot without automatic text replay or search',async t=>{
  const x=setup(t),socket=await matched(x);x.emit('heartbeat.ack',{client_time:1.},{server_sequence:100});assert.equal(socket.sent.at(-1).type,'session.resume');assert.equal(socket.sent.filter(c=>c.type==='queue.join').length,1);
});
test('an unbound HTTP acknowledgment fails closed instead of confirming End',async t=>{
  const x=setup(t),socket=await matched(x);socket.bufferedAmount=65537;x.api.request=async()=>({command_id:crypto.randomUUID(),ok:true,status:'ended'});await x.chat.end();assert.equal(x.chat.state.phase,'unavailable');assert.deepEqual(x.chat.state.messages,[]);assert.equal(x.chat.state.interaction,null);
});
