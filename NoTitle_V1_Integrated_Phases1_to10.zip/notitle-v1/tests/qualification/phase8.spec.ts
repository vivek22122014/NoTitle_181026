import {test,expect,type Page} from '@playwright/test';

// Real application HTTP/DOM tests. No provider response or ledger is mocked.
// Run against the isolated full product stack with sales disabled. Live gateway
// capture, merchant approval, chargebacks and refunds are separate release gates.
test.use({trace:'off',screenshot:'off',video:'off'});

async function account(page:Page){
  const boot=(await (await page.request.get('/api/v1/bootstrap')).json()).data;
  const headers={'Origin':new URL(page.url()).origin,'X-CSRF-Token':boot.csrf};
  const proof=(await (await page.request.post('/api/v1/operations/prepare',{headers,data:{kind:'recovery',client_nonce:crypto.randomUUID()}})).json()).data;
  const response=await page.request.post('/api/v1/auth/register',{headers,data:{username:'test_'+crypto.randomUUID().replaceAll('-','').slice(0,16),password:'Synthetic billing passphrase!',
    display_name:'Synthetic billing user',gender:'other',topic_id:'general',bio:'',client_nonce:crypto.randomUUID(),
    consents:{adult:true,terms:true,core:true,professional:false,policy_version:boot.policy_version,policy_digest:boot.policy_digest},
    proof:{reservation_id:proof.reservation_id,secret:proof.secret,saved:true}}});
  expect(response.status()).toBe(201);
}

test('closed sales are explicit and no checkout SDK loads on plans or mount',async({page})=>{
  const sdk:string[]=[],payments:string[]=[];
  page.on('request',request=>{if(request.url().includes('cashfree.com'))sdk.push(request.url());if(request.method()==='POST'&&request.url().includes('/billing/purchases'))payments.push(request.url());});
  await page.goto('/premium/');await expect(page.getByRole('heading',{name:'Choose a pass.'})).toBeVisible();
  await expect(page.getByText(/New sales are closed/)).toBeVisible();await expect(page.getByRole('button',{name:'Annual release gate pending'})).toBeDisabled();
  await page.getByRole('link',{name:'Checkout',exact:true}).click();await expect(page.getByRole('heading',{name:'Review and pay securely.'})).toBeVisible();
  await expect(page.getByText(/Guests cannot buy a pass/)).toBeVisible();expect(sdk).toEqual([]);expect(payments).toEqual([]);
});

test('a forged successful return cannot activate a pass or start another charge',async({page})=>{
  await page.goto('/');await account(page);const ref=crypto.randomUUID().replaceAll('-','');
  const created:string[]=[];page.on('request',request=>{if(request.method()==='POST'&&request.url().endsWith('/billing/purchases'))created.push(request.url());});
  await page.goto('/billing/status/?purchase_ref='+ref+'&status=success');await expect(page.getByRole('heading',{name:'Verify your payment.'})).toBeVisible();
  await expect(page.getByText(/Verified status could not be read/)).toBeVisible();
  const entitlement=(await (await page.request.get('/api/v1/billing/entitlement')).json()).data;
  expect(entitlement.available_seconds).toBe(0);expect(entitlement.premium_until).toBe(0);expect(created).toEqual([]);
  expect(await page.evaluate(()=>Object.keys(localStorage).length+Object.keys(sessionStorage).length)).toBe(0);
});

test('financial access must be saved before confirmation and billing is usable on mobile',async({page})=>{
  await page.setViewportSize({width:390,height:844});await page.goto('/');await account(page);await page.goto('/account/receipts/');
  await expect(page.getByRole('heading',{name:'Purchases and receipts.'})).toBeVisible();
  await page.getByRole('button',{name:'Load owned purchases, receipts and pass time'}).click();await expect(page.getByText('No active pass',{exact:true})).toBeVisible();
  await page.getByRole('button',{name:'Prepare financial access receipt',exact:true}).click();
  const confirm=page.getByRole('button',{name:'Confirm saved financial receipt',exact:true});await expect(confirm).toBeDisabled();
  await page.getByRole('checkbox',{name:/I have saved the reference and secret/}).check();await confirm.click();
  await expect(page.getByText(/Saved financial receipt confirmed/)).toBeVisible();
  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth)).toBeTruthy();
  expect(await page.evaluate(()=>Object.keys(localStorage).length+Object.keys(sessionStorage).length)).toBe(0);
});
