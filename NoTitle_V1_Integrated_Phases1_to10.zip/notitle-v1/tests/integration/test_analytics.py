"""Real PostgreSQL aggregate retry/late-event/retention/ACL tests, local only.
No mock SQL driver; requires normal dependency installation and local disposable DB.
"""
import os,unittest
from datetime import datetime,timezone,timedelta
from types import SimpleNamespace
from uuid import uuid4
import psycopg
from psycopg import sql
from psycopg.conninfo import make_conninfo
from app.domain.metrics import Metrics
from app.repositories.database import Pool,one
from app.repositories.migrations import migrate
from app.services.analytics import Analytics,truncate_bucket
from ops.nt import ROOT,secret

class AnalyticsPostgreSQL(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        if os.environ.get('NOTITLE_INTEGRATION')!='local-disposable':raise RuntimeError('Explicit disposable local target required')
        if 'host=127.0.0.1 port=55432 dbname=notitle ' not in secret('runtime_dsn'):raise RuntimeError('Unknown database refused')
        self.name='nt_analytics_'+uuid4().hex[:12];self.pools={}
        self.admin=await psycopg.AsyncConnection.connect(secret('admin_dsn'),autocommit=True)
        await self.admin.execute(sql.SQL('CREATE DATABASE {} OWNER nt_migrator').format(sql.Identifier(self.name)))
        await self.admin.execute(sql.SQL('GRANT CONNECT ON DATABASE {} TO nt_jobs,nt_analytics').format(sql.Identifier(self.name)))
        await migrate(make_conninfo(secret('migrator_dsn'),dbname=self.name),ROOT/'db/migrations')
        for role in ('jobs','analytics'):
            pool=Pool(make_conninfo(secret(role+'_dsn'),dbname=self.name),2);await pool.open();self.pools[role]=pool
        self.db=SimpleNamespace(transaction=lambda role:self.pools[role].transaction())
        self.metrics=Metrics();self.analytics=Analytics(self.db,self.metrics,SimpleNamespace(people={},clock=lambda:0))
    async def asyncTearDown(self):
        for pool in self.pools.values():await pool.close()
        await self.admin.execute(sql.SQL('DROP DATABASE {} WITH (FORCE)').format(sql.Identifier(self.name)));await self.admin.close()
    async def test_uncertain_commit_retry_does_not_double_add(self):
        self.metrics.add('matches',10)
        # Capture the real immutable pending batch before the successful transaction.
        from unittest.mock import patch
        original=self.db.transaction
        from contextlib import asynccontextmanager
        @asynccontextmanager
        async def uncertain(role):
            async with original(role) as connection:yield connection
            raise RuntimeError('Synthetic lost commit response')
        self.db.transaction=uncertain
        with self.assertRaises(RuntimeError):await self.analytics.flush()
        self.db.transaction=original
        await self.analytics.flush()
        async with original('analytics') as connection:
            result=await one(connection,"SELECT sum(total) total FROM nt.aggregate_buckets WHERE metric_id=2 AND resolution='minute'")
            self.assertEqual(result['total'],10)
    async def test_late_exact_event_preserves_time_and_amends_rollups(self):
        created=datetime.now(timezone.utc)-timedelta(days=8)
        async def enqueue():
            async with self.db.transaction('jobs') as connection:
                await connection.execute("INSERT INTO nt.outbox(id,kind,object_ref,metric_id,created_at) VALUES(%s,'metric','synthetic',1,%s)",(uuid4(),created))
        await enqueue();await self.analytics.flush();await self.analytics.rollup()
        await enqueue();await self.analytics.flush()
        async with self.db.transaction('analytics') as connection:
            for resolution in ('hour','day'):
                result=await one(connection,'SELECT total FROM nt.aggregate_buckets WHERE metric_id=1 AND resolution=%s AND bucket=%s',(resolution,truncate_bucket(created,resolution)))
                self.assertEqual(result['total'],2)
        await self.analytics.rollup()
        async with self.db.transaction('analytics') as connection:
            result=await one(connection,'SELECT total FROM nt.aggregate_buckets WHERE metric_id=1 AND resolution=%s AND bucket=%s',('day',truncate_bucket(created,'day')))
            self.assertEqual(result['total'],2)
    async def test_histogram_and_privacy_role(self):
        for _ in range(12):self.metrics.add('api_latency_ms',50)
        await self.analytics.flush()
        principal=SimpleNamespace(permission=lambda permission:self.assertEqual(permission,'analytics.read'))
        result=await self.analytics.summary(principal);metric=next(row for row in result['series'] if row['metric_id']==15)
        self.assertEqual(metric['count']['value'],12);self.assertEqual(metric['mean'],50)
        with self.assertRaises(psycopg.errors.InsufficientPrivilege):
            async with self.db.transaction('analytics') as connection:await connection.execute('SELECT body_ciphertext FROM nt.case_messages')
    async def test_registered_total_includes_restricted_and_excludes_deletion_rows(self):
        async with self.db.transaction('jobs') as connection:
            for status in ('active','restricted','deleting','deleted'):
                ref=uuid4().hex
                await connection.execute('''INSERT INTO nt.accounts(id,public_ref,username,password_hash,recovery_verifier,display_name,gender,core_consent,status)
                    VALUES(%s,%s,%s,'synthetic-unused-hash',%s,'Synthetic person','other',true,%s)''',
                    (uuid4(),ref,'test_'+ref[:15],uuid4().hex+uuid4().hex,status))
        principal=SimpleNamespace(permission=lambda permission:self.assertEqual(permission,'analytics.read'))
        result=await self.analytics.summary(principal)
        self.assertEqual(result['total_accounts'],2)
        self.assertEqual(result['current_accounts'],1)
        self.assertEqual(result['active_now'],0)
