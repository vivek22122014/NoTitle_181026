"""Real FastAPI/PostgreSQL social qualification; requires disposable local stack.

These tests are intentionally not substituted with in-memory SQL when unavailable.
"""
import unittest
from uuid import uuid4
from app.http.models import Ticket
from app.domain.conversation_contracts import COMMAND
from app.repositories.database import one
from tests.integration import test_application as application

class SocialPostgres(unittest.IsolatedAsyncioTestCase):
    asyncSetUp=application.Application.asyncSetUp
    asyncTearDown=application.Application.asyncTearDown
    make_client=application.Application.make_client
    headers=application.Application.headers
    register=application.Application.register

    async def bind(self,client,kind='account'):
        runtime=self.runtime;principal=await runtime.identity.resolve({kind:client.cookies.get(runtime.cookie_name(kind))})
        ticket=await runtime.conversation.prepare(principal,Ticket())
        binding=await runtime.conversation.connect(ticket['ticket'],{kind:principal.token});runtime.realtime.drain(principal.ref);return binding
    async def command(self,binding,kind,payload):
        rt=self.runtime.realtime
        command=COMMAND.validate_python({'protocol_version':2,'type':kind,'command_id':str(uuid4()),'owner_epoch':rt.authority.epoch,
            'socket_generation':binding.generation,'interaction_epoch':rt.people[binding.principal.ref].revision,'payload':payload})
        return await self.runtime.conversation.execute(binding,command,self.runtime.conversation.begin(binding,command))
    async def accept_pair(self):
        await self.register();other=self.make_client();await self.register(other)
        a,b=await self.bind(self.client),await self.bind(other);rt=self.runtime.realtime
        rt.start(a.principal.ref,b.principal.ref)
        for binding in (a,b):await self.command(binding,'friend.request',{'interaction_handle':rt.people[binding.principal.ref].interaction})
        return a,b,other
    async def test_mutual_registered_pair_commits_once_normalized_and_removes_by_relationship(self):
        a,b,other=await self.accept_pair();low,high=sorted((a.principal.account_id,b.principal.account_id))
        async with self.runtime.db.transaction() as connection:
            row=await one(connection,'SELECT count(*) AS n FROM nt.friendships WHERE low_account_id=%s AND high_account_id=%s',(low,high))
            self.assertEqual(row['n'],1)
        response=await self.client.get('/api/v1/friends');self.assertEqual(response.status_code,200,response.text)
        item=next(item for item in response.json()['data']['items'] if item['peer']['display_name']=='Synthetic user')
        self.assertEqual(item['persistence'],'saved');self.assertNotEqual(item['relationship_handle'],b.principal.ref)
        self.assertNotIn('username',item['peer']);self.assertNotIn('professional',item['peer'])
        removed=await self.client.delete('/api/v1/friends/'+item['relationship_handle'],params={'expected_relationship_revision':item['revision']},headers=self.headers())
        self.assertEqual(removed.status_code,200,removed.text)
        async with self.runtime.db.transaction() as connection:
            row=await one(connection,'SELECT count(*) AS n FROM nt.friendships WHERE low_account_id=%s AND high_account_id=%s',(low,high));self.assertEqual(row['n'],0)
        self.assertFalse(self.runtime.realtime.people[b.principal.ref].interaction)
    async def test_remove_stale_revision_does_not_delete_saved_relationship(self):
        await self.accept_pair();result=(await self.client.get('/api/v1/friends')).json()['data'];item=result['items'][0]
        result=await self.client.delete('/api/v1/friends/'+item['relationship_handle'],params={'expected_relationship_revision':item['revision']+1},headers=self.headers())
        self.assertEqual(result.status_code,409,result.text)
        self.assertEqual(len((await self.client.get('/api/v1/friends')).json()['data']['items']),1)
    async def test_guest_new_registration_promotes_same_mutual_pair_after_commit(self):
        boot=(await self.client.get('/api/v1/bootstrap')).json()['data']
        response=await self.client.post('/api/v1/auth/guest',headers=self.headers(boot['csrf']),json={
            'display_name':'Ignored guest input','gender':'other','topic_id':'career','bio':'',
            'consents':{'adult':True,'terms':True,'core':True,'professional':False,'policy_version':boot['policy_version'],'policy_digest':boot['policy_digest']}})
        self.assertEqual(response.status_code,201,response.text)
        other=self.make_client();await self.register(other)
        a,b=await self.bind(self.client,'guest'),await self.bind(other);ref=a.principal.ref
        self.runtime.realtime.start(a.principal.ref,b.principal.ref)
        for binding in (a,b):await self.command(binding,'friend.request',{'interaction_handle':self.runtime.realtime.people[binding.principal.ref].interaction})
        before=(await self.client.get('/api/v1/friends')).json()['data']['items'];self.assertEqual(before[0]['persistence'],'temporary')
        await self.register()
        owner=(await self.client.get('/api/v1/me')).json()['data'];self.assertEqual(owner['ref'],ref)
        after=(await self.client.get('/api/v1/friends')).json()['data']['items'];self.assertEqual(after[0]['persistence'],'saved')

    async def test_new_registration_imports_guest_private_choices_only_with_renewed_consent(self):
        for renewed in (False,True):
            client=self.make_client();boot=(await client.get('/api/v1/bootstrap')).json()['data']
            response=await client.post('/api/v1/auth/guest',headers=self.headers(boot['csrf']),json={
                'display_name':'Ignored guest input','gender':'other','topic_id':'career','bio':'',
                'consents':{'adult':True,'terms':True,'core':True,'professional':True,'policy_version':boot['policy_version'],'policy_digest':boot['policy_digest']}})
            self.assertEqual(response.status_code,201,response.text)
            csrf=response.json()['data']['csrf']
            response=await client.patch('/api/v1/me/preferences',headers=self.headers(csrf),json={
                'expected_revision':1,'gender':'everyone','professional_enabled':True,'industry':['technology'],'interests':['learning']})
            self.assertEqual(response.status_code,200,response.text)
            await self.register(client,professional=renewed)
            owner=(await client.get('/api/v1/me')).json()['data']
            self.assertEqual(owner['professional'].get('industry',[]),['technology'] if renewed else [])
