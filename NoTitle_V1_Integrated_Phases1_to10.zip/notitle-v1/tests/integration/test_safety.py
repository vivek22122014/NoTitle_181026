"""Real PostgreSQL/FastAPI safety persistence; requires the disposable local stack.

The actor is populated directly to isolate report persistence from the separately
qualified WebSocket/matching transport. HTTP, ACLs and encryption are real.
"""
import unittest
from uuid import uuid4
import tests.integration.test_application as fixtures
from app.repositories.database import one

class SafetyPersistence(unittest.IsolatedAsyncioTestCase):
    asyncSetUp=fixtures.Application.asyncSetUp
    asyncTearDown=fixtures.Application.asyncTearDown
    make_client=fixtures.Application.make_client
    headers=fixtures.Application.headers
    register=fixtures.Application.register

    async def test_selected_report_is_encrypted_idempotent_and_owner_scoped(self):
        await self.register();other=self.make_client();await self.register(other)
        me=(await self.client.get('/api/v1/me')).json()['data'];peer=(await other.get('/api/v1/me')).json()['data']
        rt=self.runtime.realtime
        for owner in (me,peer):rt.enter(owner['ref'],owner['profile'],True);rt.connect(owner['ref'])
        interaction=rt.start(me['ref'],peer['ref']);rt.text(peer['ref'],'Synthetic selected report evidence')
        handle=rt.describe(me['ref'])['peer']['peer_handle']
        prepared=await self.client.post('/api/v1/reports/prepare',headers=self.headers(),json={'peer_handle':handle,'interaction_handle':interaction.id,'block':True})
        self.assertEqual(prepared.status_code,200,prepared.text);snapshot=prepared.json()['data']
        self.assertNotIn(peer['ref'],prepared.text);self.assertIsNone(rt.people[me['ref']].interaction)
        payload={'category':'safety','subject':'Synthetic report','body':'Synthetic allegation for qualification','reason':'harassment','snapshot_ref':snapshot['snapshot_ref'],
                 'selected_ids':[snapshot['messages'][0]['id']],'block':True,'client_nonce':str(uuid4())}
        first=await self.client.post('/api/v1/reports',headers=self.headers(),json=payload)
        self.assertEqual(first.status_code,201,first.text);ref=first.json()['data']['case_ref']
        rt.snapshots.clear() # A committed retry must not depend on retained temporary evidence.
        retry=await self.client.post('/api/v1/reports',headers=self.headers(),json=payload)
        self.assertEqual(retry.status_code,201,retry.text);self.assertEqual(retry.json()['data']['case_ref'],ref)
        outsider=await other.get('/api/v1/support/cases/'+ref,headers={'X-NT-Authority':'account'})
        self.assertEqual(outsider.status_code,404)
        async with self.runtime.db.transaction('private') as connection:
            evidence=await one(connection,'SELECT e.* FROM nt.report_evidence e JOIN nt.reports r ON r.id=e.report_id JOIN nt.support_cases c ON c.id=r.case_id WHERE c.public_ref=%s',(ref,))
            self.assertNotIn(b'Synthetic selected report evidence',bytes(evidence['body_ciphertext']))
            self.assertEqual(evidence['sender_scoped_ref'],'subject')
        # Public history is allegation/support only: selected peer evidence is private.
        public=await self.client.get('/api/v1/support/cases/'+ref+'/messages',headers={'X-NT-Authority':'account'})
        self.assertNotIn('Synthetic selected report evidence',public.text)

    async def test_account_cannot_read_private_notes_or_internal_routes(self):
        await self.register()
        result=await self.client.post('/api/v1/support/cases',headers=self.headers(),json={'category':'appeal','subject':'Review request','body':'Please independently review this decision.','client_nonce':str(uuid4())})
        self.assertEqual(result.status_code,201,result.text);ref=result.json()['data']['case_ref']
        self.assertEqual((await self.client.get('/api/v1/support/cases/'+ref+'/notes')).status_code,404)
        self.assertEqual((await self.client.get('/internal/v1/cases/'+ref+'/notes')).status_code,404)
        self.assertNotIn('assigned_staff_id',(await self.client.get('/api/v1/support/cases/'+ref)).json()['data'])

    async def test_guest_restriction_survives_registration_with_same_subject(self):
        from app.http.models import Decision
        from app.domain.errors import DomainError
        from app.domain.security import token
        # Guest intake and case ownership use actual HTTP cookies/CSRF.
        boot=(await self.client.get('/api/v1/bootstrap')).json()['data']
        profile={'display_name':'Synthetic guest','gender':'other','topic_id':'general','bio':'',
            'consents':{'adult':True,'terms':True,'core':True,'professional':False,'policy_version':boot['policy_version'],'policy_digest':boot['policy_digest']}}
        response=await self.client.post('/api/v1/auth/guest',headers=self.headers(),json=profile)
        self.assertEqual(response.status_code,201,response.text);self.csrf=response.json()['data']['csrf']
        guest=(await self.client.get('/api/v1/me')).json()['data']
        proof=(await self.client.post('/api/v1/operations/prepare',headers=self.headers(),json={'kind':'case','client_nonce':str(uuid4())})).json()['data']
        case=await self.client.post('/api/v1/support/cases',headers=self.headers(),json={'category':'appeal','subject':'Synthetic independent review','body':'Review this current guest subject.',
            'client_nonce':str(uuid4()),'proof':{'reservation_id':proof['reservation_id'],'secret':proof['secret'],'saved':True}})
        self.assertEqual(case.status_code,201,case.text)
        case_ref=case.json()['data']['case_ref']
        # Seed real staff/session records; authorization resolves the real session.
        staff_id=uuid4();staff_secret=token();password_hash=await self.runtime.identity.passwords.hash('Synthetic staff password 123!')
        async with self.runtime.db.transaction('private') as connection:
            await connection.execute('INSERT INTO nt.staff_accounts(id,username,password_hash,totp_ciphertext) VALUES(%s,%s,%s,%s)',
                (staff_id,'staff_'+uuid4().hex[:15],password_hash,self.runtime.security.encrypt('staff:'+str(staff_id),'JBSWY3DPEHPK3PXP')))
            for grant in ('safety.decide','cases.triage','cases.read'):
                await connection.execute('INSERT INTO nt.staff_roles(staff_id,permission) VALUES(%s,%s)',(staff_id,grant))
            await connection.execute("INSERT INTO nt.staff_sessions(token_hmac,staff_id,role_version,mfa_at,expires_at,absolute_expires,key_version) VALUES(%s,%s,1,now(),now()+interval '15 minutes',now()+interval '4 hours',%s)",
                (self.runtime.security.digest('staff_session',staff_secret),staff_id,self.runtime.security.key_version))
            # An appeal needs a different original reviewer; use a general safety
            # category here to test restriction/conversion rather than self-review.
            await connection.execute("UPDATE nt.support_cases SET category='safety' WHERE public_ref=%s",(case_ref,))
        staff=await self.runtime.identity.resolve({'admin':staff_secret},private=True)
        dto=Decision(case_ref=case_ref,subject_ref=guest['ref'],action='restrict',reason_code='harassment',duration_hours=24,reason='Synthetic reviewed safety evidence')
        preview=await self.runtime.moderation.preview(staff,dto)
        self.assertEqual(preview['target_kind'],'guest')
        await self.runtime.moderation.confirm(staff,preview['preview'],'qualification')
        async with self.runtime.db.transaction('private') as connection:
            restriction=await one(connection,'SELECT subject_ref FROM nt.restrictions WHERE subject_ref=%s AND ends_at>now()',(guest['ref'],))
        self.assertEqual(restriction['subject_ref'],guest['ref'])
        # Registration is permitted; it preserves the subject reference and restriction.
        recovery=(await self.client.post('/api/v1/operations/prepare',headers=self.headers(),json={'kind':'recovery','client_nonce':str(uuid4())})).json()['data']
        registration={**profile,'username':'convert_'+uuid4().hex[:12],'password':'Synthetic conversion password 123!',
            'proof':{'reservation_id':recovery['reservation_id'],'secret':recovery['secret'],'saved':True},'client_nonce':str(uuid4())}
        converted=await self.client.post('/api/v1/auth/register',headers=self.headers(),json=registration)
        self.assertEqual(converted.status_code,201,converted.text);self.csrf=converted.json()['data']['csrf']
        account=(await self.client.get('/api/v1/me')).json()['data'];self.assertEqual(account['ref'],guest['ref'])
        denied=await self.client.post('/api/v1/ws/ticket',headers=self.headers(),json={})
        self.assertEqual(denied.status_code,403,denied.text)
        self.assertEqual((await self.client.get('/api/v1/support/cases')).status_code,200)
