"""Destructive failure injection against fixed .local database only; no silent skips."""
import asyncio,json,os,signal,subprocess,sys,tempfile,time,unittest
from pathlib import Path
import urllib.request
import psycopg
from app.repositories.ownership import OwnerLease,OwnerBusy
from app.repositories.migrations import migrate
from ops.nt import ROOT,secret

class PostgreSQL(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        if os.environ.get('NOTITLE_INTEGRATION')!='local-disposable':
            raise RuntimeError('Use ops test --suite integration against disposable local DB')
        self.dsn=secret('runtime_dsn')
        if 'host=127.0.0.1 port=55432 dbname=notitle ' not in self.dsn:
            raise RuntimeError('Refusing unknown integration target')
    async def test_second_owner_rejected_and_restart_epoch_increases(self):
        first=await OwnerLease.acquire(self.dsn)
        try:
            with self.assertRaises(OwnerBusy):await OwnerLease.acquire(self.dsn)
            epoch=first.epoch
        finally:await first.close()
        second=await OwnerLease.acquire(self.dsn)
        try:self.assertGreater(second.epoch,epoch)
        finally:await second.close()
    async def test_backend_loss_revokes_lock(self):
        first=await OwnerLease.acquire(self.dsn)
        try:
            async with await psycopg.AsyncConnection.connect(secret('admin_dsn'),autocommit=True) as admin:
                await admin.execute('SELECT pg_terminate_backend(%s)',(first.conn.info.backend_pid,))
            with self.assertRaises(Exception):await first.prove()
        finally:await first.close()
    async def test_runtime_has_no_ddl_or_history_write(self):
        async with await psycopg.AsyncConnection.connect(self.dsn,autocommit=True) as conn:
            for query in ['CREATE TABLE public.unauthorized(id integer)',
                          "DELETE FROM nt_system.schema_migrations"]:
                with self.assertRaises(psycopg.errors.InsufficientPrivilege):await conn.execute(query)
    async def test_runtime_can_verify_required_migration_identity_before_startup(self):
        from app.domain.migration_contract import packaged_inventory,verify_applied
        async with await psycopg.AsyncConnection.connect(self.dsn,autocommit=True) as conn:
            rows=await (await conn.execute('SELECT name,sha256 FROM nt_system.schema_migrations ORDER BY name')).fetchall()
            self.assertTrue(verify_applied(packaged_inventory(),rows))
            with self.assertRaises(psycopg.errors.InsufficientPrivilege):
                await conn.execute('UPDATE nt_system.schema_migrations SET sha256=sha256')
    async def test_foundation_schema_can_be_applied_before_the_product_schema(self):
        from uuid import uuid4
        from psycopg import sql
        from psycopg.conninfo import make_conninfo
        name='notitle_foundation_'+uuid4().hex[:12]
        async with await psycopg.AsyncConnection.connect(secret('admin_dsn'),autocommit=True) as admin:
            await admin.execute(sql.SQL('CREATE DATABASE {} OWNER nt_migrator').format(sql.Identifier(name)))
            try:
                dsn=make_conninfo(secret('migrator_dsn'),dbname=name)
                await migrate(dsn,ROOT/'db/migrations',through=1)
                async with await psycopg.AsyncConnection.connect(dsn,autocommit=True) as check:
                    row=await (await check.execute('SELECT schema_version FROM nt_system.foundation_metadata WHERE singleton')).fetchone()
                    self.assertEqual(row[0],1)
                    self.assertIsNone((await (await check.execute("SELECT to_regclass('nt.accounts')")).fetchone())[0])
                await migrate(dsn,ROOT/'db/migrations')
                async with await psycopg.AsyncConnection.connect(dsn,autocommit=True) as check:
                    self.assertEqual((await (await check.execute('SELECT schema_version FROM nt_system.foundation_metadata WHERE singleton')).fetchone())[0],3)
            finally:
                await admin.execute(sql.SQL('DROP DATABASE {} WITH (FORCE)').format(sql.Identifier(name)))

    async def test_migration_checksum_drift_rejected(self):
        await migrate(secret('migrator_dsn'),ROOT/'db/migrations',through=1)
        with tempfile.TemporaryDirectory() as path:
            target=Path(path)/'0001_foundation.sql'
            target.write_text((ROOT/'db/migrations/0001_foundation.sql').read_text()+'\n-- tamper')
            with self.assertRaisesRegex(RuntimeError,'MIGRATION_HISTORY_MISMATCH'):
                await migrate(secret('migrator_dsn'),Path(path))
    async def test_migration_refuses_running_owner(self):
        lease=await OwnerLease.acquire(self.dsn)
        try:
            with self.assertRaisesRegex(RuntimeError,'STOP_OWNER_BEFORE_MIGRATION'):
                await migrate(secret('migrator_dsn'),ROOT/'db/migrations',through=1)
        finally:await lease.close()

class RunnerProcesses(unittest.TestCase):
    def setUp(self):
        if os.environ.get('NOTITLE_INTEGRATION')!='local-disposable':raise RuntimeError('Local-only tests')
        self.processes=[]
        self.env=dict(os.environ,APP_ENV='local',DATABASE_DSN_FILE=str(ROOT/'.local/secrets/runtime_dsn'),
                      APP_MODE='foundation',PUBLIC_PORT='18000',PRIVATE_PORT='18001',PYTHONPATH=str(ROOT/'api'))
    def tearDown(self):
        for process in self.processes:
            if process.poll() is None:
                process.terminate()
                try:process.wait(timeout=6)
                except subprocess.TimeoutExpired:process.kill();process.wait(timeout=2)
    def start(self):
        p=subprocess.Popen([sys.executable,'-m','app.runner'],cwd=ROOT,env=self.env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        self.processes.append(p);return p
    def wait_ready(self,p):
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        for _ in range(50):
            if p.poll() is not None:self.fail('Runner terminated before readiness')
            try:
                with opener.open('http://127.0.0.1:18000/health/ready',timeout=.2) as r:
                    self.assertIn(json.load(r)['data']['status'],('maintenance','ready'));return
            except OSError:time.sleep(.1)
        self.fail('Runner readiness deadline')
    def test_two_runners_and_sigkill_restart(self):
        first=self.start();self.wait_ready(first)
        second=self.start();self.assertNotEqual(second.wait(timeout=6),0)
        first.kill();first.wait(timeout=3)
        third=self.start();self.wait_ready(third)
        third.terminate();self.assertEqual(third.wait(timeout=6),0)
    def test_database_loss_stops_both_listeners(self):
        p=self.start();self.wait_ready(p)
        with psycopg.connect(secret('admin_dsn'),autocommit=True) as conn:
            conn.execute("SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE application_name='notitle-owner'")
        self.assertNotEqual(p.wait(timeout=6),0)
        import socket
        for port in (18000,18001):
            with socket.socket() as s:self.assertNotEqual(s.connect_ex(('127.0.0.1',port)),0)

    def test_missing_product_configuration_does_not_block_foundation(self):
        self.env.update(NT_CONFIG_FILE='/notitle-intentionally-missing/application.json',NT_SECRETS_DIR='/notitle-intentionally-missing/secrets')
        process=self.start();self.wait_ready(process)
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open('http://127.0.0.1:18000/health/ready',timeout=1) as response:
            data=json.load(response)['data']
            self.assertEqual(data['mode'],'foundation');self.assertFalse(data['admission'])

    def test_second_listener_collision_releases_owner_and_first_port(self):
        import socket
        with socket.socket() as occupied:
            occupied.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
            occupied.bind(('127.0.0.1',18001));occupied.listen(1)
            process=self.start();self.assertNotEqual(process.wait(timeout=8),0)
            with socket.socket() as public:self.assertNotEqual(public.connect_ex(('127.0.0.1',18000)),0)
            async def reacquire():
                lease=await OwnerLease.acquire(secret('runtime_dsn'));await lease.close()
            asyncio.run(reacquire())
