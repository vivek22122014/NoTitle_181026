"""Real PostgreSQL + FastAPI integration. Never runs against a remote database."""
import asyncio,json,os,unittest
from uuid import uuid4
import httpx
from app.coordinator.core import Coordinator
from app.runtime import Runtime,ProductSettings
from app.http.product import create_product_apps
from app.repositories.database import one
from ops.nt import ROOT,secret

class Application(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        if os.environ.get('NOTITLE_INTEGRATION')!='local-disposable':raise RuntimeError('Explicit disposable target required')
        dsn=secret('runtime_dsn')
        if 'host=127.0.0.1 port=55432 dbname=notitle ' not in dsn:raise RuntimeError('Refusing unknown target')
        self.coordinator=Coordinator(1)
        async def heartbeat():
            while True:self.coordinator.heartbeat();await asyncio.sleep(.25)
        self.beat=asyncio.create_task(heartbeat())
        self.runtime=Runtime(ProductSettings.load(dsn),self.coordinator)
        await self.runtime.open()
        public,private=create_product_apps(self.runtime)
        self.public=public;self.private=private
        self.clients=[]
        self.client=self.make_client()
        self.csrf=(await self.client.get('/api/v1/bootstrap')).json()['data']['csrf']
    def make_client(self,private=False):
        client=httpx.AsyncClient(transport=httpx.ASGITransport(app=self.private if private else self.public),base_url='http://127.0.0.1:8081' if private else 'http://127.0.0.1:8080')
        self.clients.append(client);return client
    async def asyncTearDown(self):
        for client in self.clients:await client.aclose()
        await self.runtime.close();self.beat.cancel();await asyncio.gather(self.beat,return_exceptions=True)
    def headers(self,csrf=None):return {'Origin':'http://127.0.0.1:8080','X-CSRF-Token':csrf or self.csrf}
    async def register(self,client=None,professional=False):
        client=client or self.client
        boot=(await client.get('/api/v1/bootstrap')).json()['data'];csrf=boot['csrf'];headers=self.headers(csrf)
        receipt=(await client.post('/api/v1/operations/prepare',headers=headers,json={'kind':'recovery','client_nonce':str(uuid4())})).json()['data']
        payload={'display_name':'Synthetic user','gender':'other','topic_id':'general','bio':'',
                 'consents':{'adult':True,'terms':True,'core':True,'professional':professional,'policy_version':boot['policy_version'],'policy_digest':boot['policy_digest']},
                 'username':'test_'+uuid4().hex[:15],'password':'Synthetic password 123!',
                 'proof':{'reservation_id':receipt['reservation_id'],'secret':receipt['secret'],'saved':True},'client_nonce':str(uuid4())}
        response=await client.post('/api/v1/auth/register',headers=headers,json=payload)
        self.assertEqual(response.status_code,201,response.text)
        csrf=response.json()['data']['csrf']
        if client is self.client:self.csrf=csrf
        return payload,csrf
    async def test_registration_me_csrf_and_private_boundary(self):
        await self.register()
        response=await self.client.get('/api/v1/me');self.assertEqual(response.status_code,200)
        self.assertNotIn('password_hash',response.text);self.assertNotIn('recovery_verifier',response.text)
        response=await self.client.post('/api/v1/interactions/end',json={});self.assertEqual(response.status_code,403)
        self.assertEqual((await self.client.get('/internal/v1/cases')).status_code,404)
        self.assertEqual((await self.client.get('/api/v1/me')).headers['cache-control'],'no-store')
    async def test_support_idempotency_owner_isolation_and_seen(self):
        await self.register()
        payload={'category':'general','subject':'Synthetic support','body':'A test question','client_nonce':str(uuid4())}
        first=await self.client.post('/api/v1/support/cases',headers=self.headers(),json=payload);self.assertEqual(first.status_code,201,first.text)
        result=first.json()['data'];ref=result['case_ref']
        second=await self.client.post('/api/v1/support/cases',headers=self.headers(),json=payload);self.assertEqual(second.json()['data']['case_ref'],ref)
        outsider=self.make_client();await self.register(outsider)
        self.assertEqual((await outsider.get('/api/v1/support/cases/'+ref,headers={'X-NT-Authority':'account'})).status_code,404)
        message={'body':'Follow-up','client_nonce':str(uuid4())}
        first=await self.client.post('/api/v1/support/cases/'+ref+'/messages',headers=self.headers(),json=message)
        self.assertEqual(first.status_code,201,first.text)
        second=await self.client.post('/api/v1/support/cases/'+ref+'/messages',headers=self.headers(),json=message)
        self.assertEqual(first.json()['data']['sequence'],second.json()['data']['sequence'])
        conflict=await self.client.post('/api/v1/support/cases/'+ref+'/messages',headers=self.headers(),json={**message,'body':'different'})
        self.assertEqual(conflict.status_code,409)
        future=await self.client.post('/api/v1/support/cases/'+ref+'/seen',headers=self.headers(),json={'seen_through':999})
        self.assertEqual(future.status_code,422)
    async def test_scoped_case_receipt_cannot_authenticate_an_account(self):
        receipt=(await self.client.post('/api/v1/operations/prepare',headers=self.headers(),json={'kind':'case','client_nonce':str(uuid4())})).json()['data']
        payload={'category':'general','subject':'Guest support','body':'Synthetic question','client_nonce':str(uuid4()),
                 'proof':{'reservation_id':receipt['reservation_id'],'secret':receipt['secret'],'saved':True}}
        response=await self.client.post('/api/v1/support/cases',headers=self.headers(),json=payload);self.assertEqual(response.status_code,201,response.text)
        ref=response.json()['data']['case_ref']
        access=await self.client.post('/api/v1/support/access',headers=self.headers(),json={'receipt_ref':receipt['reservation_id'],'secret':receipt['secret']})
        self.assertEqual(access.status_code,200,access.text)
        self.assertEqual((await self.client.get('/api/v1/support/cases/'+ref)).status_code,200)
        self.assertEqual((await self.client.get('/api/v1/me')).status_code,401)
        self.assertEqual((await self.client.get('/api/v1/billing/receipts')).status_code,401)
    async def test_consent_withdrawal_disables_tickets_but_keeps_support(self):
        await self.register()
        boot=(await self.client.get('/api/v1/bootstrap')).json()['data']
        result=await self.client.post('/api/v1/me/consents',headers=self.headers(),json={'purpose':'core','choice':False,'policy_version':boot['policy_version'],'policy_digest':boot['policy_digest'],'text_digest':boot['policy']['purposes']['core']['withdrawal_digest'],'expected_revision':1,'client_nonce':str(uuid4())})
        self.assertEqual(result.status_code,200,result.text)
        ticket=await self.client.post('/api/v1/ws/ticket',headers=self.headers(),json={'takeover':False,'known_socket_generation':0})
        self.assertEqual(ticket.status_code,403)
        self.assertEqual((await self.client.get('/api/v1/support/cases')).status_code,200)
    async def test_body_boundary_and_duplicate_cookie(self):
        response=await self.client.post('/api/v1/auth/guest',headers=self.headers(),content=b'x'*9000)
        self.assertEqual(response.status_code,413)
        response=await self.client.get('/api/v1/bootstrap',headers={'Cookie':'nt_local_bootstrap=one; nt_local_bootstrap=two'})
        self.assertEqual(response.status_code,400)
        self.assertEqual((await self.client.get('/api/v1/bootstrap',headers={'Host':'untrusted.test'})).status_code,400)
        self.assertEqual((await self.client.get('/health/ready',headers={'Host':'127.0.0.1:8000'})).status_code,200)
    async def test_analytics_role_cannot_read_saved_content(self):
        async with self.runtime.db.transaction('analytics') as connection:
            import psycopg
            with self.assertRaises(psycopg.errors.InsufficientPrivilege):await connection.execute('SELECT body_ciphertext FROM nt.case_messages')
    async def test_payment_catalog_defaults_closed(self):
        response=await self.client.get('/api/v1/billing/plans');self.assertEqual(response.status_code,200)
        self.assertTrue(all(not row['enabled'] for row in response.json()['data']['items']))

    async def test_registration_exact_retry_survives_new_bootstrap_without_extra_session(self):
        payload,_=await self.register();original=self.client.cookies.get(self.runtime.cookie_name('account'))
        self.runtime.identity.reservations.items.clear()
        retry=self.make_client();csrf=(await retry.get('/api/v1/bootstrap')).json()['data']['csrf']
        result=await retry.post('/api/v1/auth/register',headers=self.headers(csrf),json=payload)
        self.assertEqual(result.status_code,201,result.text);self.assertEqual(retry.cookies.get(self.runtime.cookie_name('account')),original)
        async with self.runtime.db.transaction() as connection:
            count=await one(connection,'SELECT count(*) AS n FROM nt.account_sessions s JOIN nt.accounts a ON a.id=s.account_id WHERE a.username=%s AND revoked_at IS NULL',(payload['username'],))
            self.assertEqual(count['n'],1)
            op=await one(connection,"SELECT result FROM nt.operation_results WHERE kind='registration' AND client_nonce=%s",(payload['client_nonce'],))
            self.assertNotIn(payload['proof']['secret'],json.dumps(op['result']));self.assertNotIn(payload['password'],json.dumps(op['result']))
        changed=await retry.post('/api/v1/auth/register',headers=self.headers(result.json()['data']['csrf']),json=payload|{'bio':'different intent'})
        self.assertEqual(changed.status_code,409)

    async def test_five_session_challenge_is_single_use_and_database_cap_is_authoritative(self):
        import psycopg
        payload,_=await self.register()
        for _ in range(4):
            client=self.make_client();csrf=(await client.get('/api/v1/bootstrap')).json()['data']['csrf']
            login=await client.post('/api/v1/auth/login',headers=self.headers(csrf),json={'username':payload['username'],'password':payload['password']})
            self.assertEqual(login.status_code,200,login.text)
        sixth=self.make_client();csrf=(await sixth.get('/api/v1/bootstrap')).json()['data']['csrf']
        login=await sixth.post('/api/v1/auth/login',headers=self.headers(csrf),json={'username':payload['username'],'password':payload['password']})
        self.assertEqual(login.status_code,409);self.assertNotIn(self.runtime.cookie_name('account'),sixth.cookies)
        sessions=(await sixth.get('/api/v1/auth/session-limit')).json()['data']['sessions'];self.assertEqual(len(sessions),5)
        replaced=await sixth.post('/api/v1/auth/session-limit/'+sessions[0]['id'],headers=self.headers(csrf),json={})
        self.assertEqual(replaced.status_code,200,replaced.text)
        again=await sixth.post('/api/v1/auth/session-limit/'+sessions[1]['id'],headers=self.headers(replaced.json()['data']['csrf']),json={})
        self.assertEqual(again.status_code,401)
        async with await psycopg.AsyncConnection.connect(secret('admin_dsn'),autocommit=True) as connection:
            aid,generation=await (await connection.execute('SELECT id,auth_generation FROM nt.accounts WHERE username=%s',(payload['username'],))).fetchone()
            with self.assertRaises(psycopg.errors.CheckViolation):
                await connection.execute("INSERT INTO nt.account_sessions(id,account_id,token_hmac,auth_generation,expires_at,absolute_expires) VALUES(%s,%s,%s,%s,now()+interval '1 day',now()+interval '2 days')",(uuid4(),aid,uuid4().hex,generation))

    async def test_password_rotation_lost_cookie_ack_replays_only_original_target(self):
        payload,_=await self.register();old_cookie=self.client.cookies.get(self.runtime.cookie_name('account'));old_csrf=self.csrf
        body={'password':'Replacement synthetic passphrase!','client_nonce':str(uuid4())}
        changed=await self.client.post('/api/v1/me/password',headers=self.headers(),json=body)
        self.assertEqual(changed.status_code,200,changed.text);new_cookie=self.client.cookies.get(self.runtime.cookie_name('account'))
        self.assertNotEqual(old_cookie,new_cookie)
        self.client.cookies.clear();self.client.cookies.set(self.runtime.cookie_name('account'),old_cookie,domain='127.0.0.1',path='/')
        self.assertEqual((await self.client.get('/api/v1/me')).status_code,401)
        retry=await self.client.post('/api/v1/me/password',headers=self.headers(old_csrf),json=body)
        self.assertEqual(retry.status_code,200,retry.text);self.assertEqual(self.client.cookies.get(self.runtime.cookie_name('account')),new_cookie)
        conflict=await self.client.post('/api/v1/me/password',headers=self.headers(retry.json()['data']['csrf']),json=body|{'password':'Another synthetic passphrase!'})
        self.assertEqual(conflict.status_code,409)

    async def test_optional_withdrawal_erases_choices_and_proof_is_immutable(self):
        import psycopg
        await self.register();boot=(await self.client.get('/api/v1/bootstrap')).json()['data']
        def consent(choice,revision):return {'purpose':'professional','choice':choice,'policy_version':boot['policy_version'] if choice else 'retired','policy_digest':boot['policy_digest'] if choice else '0'*64,'text_digest':boot['policy']['purposes']['professional']['text_digest' if choice else 'withdrawal_digest'],'expected_revision':revision,'client_nonce':str(uuid4())}
        grant=await self.client.post('/api/v1/me/consents',headers=self.headers(),json=consent(True,1));self.assertEqual(grant.status_code,200,grant.text)
        preferences={'expected_revision':2,'gender':'everyone','professional_enabled':True,'industry':['technology'],'role':['student'],'experience':[],'interests':[],'topics':[]}
        result=await self.client.patch('/api/v1/me/preferences',headers=self.headers(),json=preferences);self.assertEqual(result.status_code,200,result.text)
        withdraw=consent(False,2)
        result=await self.client.post('/api/v1/me/consents',headers=self.headers(),json=withdraw);self.assertEqual(result.status_code,200,result.text)
        self.assertEqual((await self.client.post('/api/v1/me/consents',headers=self.headers(),json=withdraw)).status_code,200)
        me=(await self.client.get('/api/v1/me')).json()['data'];self.assertEqual(me['professional'],{});self.assertFalse(me['professional_consent']);self.assertTrue(me['core_consent'])
        self.assertEqual(me['preferences']['industry'],[]);self.assertFalse(me['preferences']['professional_enabled'])
        proof=(await self.client.get('/api/v1/me/consent-proof')).json()['data']['items'];self.assertEqual(len(proof),6)
        self.assertTrue(all(row['proof_format']==2 and row['decision_text'] for row in proof))
        with self.assertRaises(psycopg.errors.InsufficientPrivilege):
            async with self.runtime.db.transaction() as connection:await connection.execute('UPDATE nt.consent_records SET choice=false WHERE id=%s',(uuid4(),))
        with self.assertRaises(psycopg.errors.InsufficientPrivilege):
            async with self.runtime.db.transaction('support') as connection:await connection.execute('SELECT password_hash FROM nt.accounts')

    async def test_recovery_replaces_secret_and_exact_retry_survives_ram_loss(self):
        payload,_=await self.register();recovery=self.make_client();boot=(await recovery.get('/api/v1/bootstrap')).json()['data'];headers=self.headers(boot['csrf'])
        proof=(await recovery.post('/api/v1/operations/prepare',headers=headers,json={'kind':'recovery','client_nonce':str(uuid4())})).json()['data']
        body={'username':payload['username'],'password':'Replacement synthetic password','recovery_secret':payload['proof']['secret'],'proof':{'reservation_id':proof['reservation_id'],'secret':proof['secret'],'saved':True},'client_nonce':str(uuid4())}
        result=await recovery.post('/api/v1/auth/recover',headers=headers,json=body);self.assertEqual(result.status_code,200,result.text)
        self.runtime.identity.reservations.items.clear()
        result=await recovery.post('/api/v1/auth/recover',headers=headers,json=body);self.assertEqual(result.status_code,200,result.text)
        self.assertEqual((await recovery.get('/api/v1/me')).status_code,401);self.assertEqual((await self.client.get('/api/v1/me')).status_code,401)
        login=await recovery.post('/api/v1/auth/login',headers=headers,json={'username':payload['username'],'password':body['password']});self.assertEqual(login.status_code,200,login.text)

    async def test_deletion_replay_fences_rows_restored_to_pre_request_state(self):
        # This is a real-DB row restore simulation; full backup/host-loss restore is a separate gate.
        await self.register();cookie=self.client.cookies.get(self.runtime.cookie_name('account'))
        principal=await self.runtime.identity.resolve({'account':cookie})
        async with self.runtime.db.transaction() as connection:
            original=await one(connection,'SELECT * FROM nt.accounts WHERE id=%s',(principal.account_id,))
            subject=await one(connection,'SELECT * FROM nt.subject_controls WHERE account_id=%s',(principal.account_id,))
        shown=(await self.client.post('/api/v1/operations/prepare',headers=self.headers(),json={'kind':'deletion','client_nonce':str(uuid4())})).json()['data']
        result=await self.client.post('/api/v1/privacy/delete',headers=self.headers(),json={'confirmation':'DELETE MY ACCOUNT','proof':{'reservation_id':shown['reservation_id'],'secret':shown['secret'],'saved':True}})
        self.assertEqual(result.status_code,202,result.text);self.assertTrue(result.json()['data']['durably_accepted'])
        self.runtime.tasks[0].cancel();await asyncio.gather(self.runtime.tasks[0],return_exceptions=True)
        async with self.runtime.db.transaction('jobs') as connection:
            await connection.execute("UPDATE nt.accounts SET status='active',username=%s,password_hash=%s,recovery_verifier=%s,auth_generation=%s WHERE id=%s",(original['username'],original['password_hash'],original['recovery_verifier'],original['auth_generation'],principal.account_id))
            await connection.execute("UPDATE nt.subject_controls SET deletion_state='active' WHERE subject_id=%s",(subject['subject_id'],))
            await connection.execute('DELETE FROM nt.scoped_receipts WHERE public_ref=%s',(shown['reservation_id'],))
            await connection.execute("""INSERT INTO nt.account_sessions(id,account_id,token_hmac,auth_generation,expires_at,absolute_expires)
              VALUES(%s,%s,%s,%s,now()+interval '7 days',now()+interval '30 days') ON CONFLICT(id) DO UPDATE
              SET revoked_at=NULL,auth_generation=EXCLUDED.auth_generation,expires_at=EXCLUDED.expires_at,absolute_expires=EXCLUDED.absolute_expires""",
              (principal.session_id,principal.account_id,self.runtime.security.digest('account_session',cookie),original['auth_generation']))
            await connection.execute("INSERT INTO nt.privacy_exports(public_ref,subject_id,expires_at) VALUES(%s,%s,now()+interval '1 day')",(uuid4().hex,subject['subject_id']))
        self.runtime.identity.fenced_subjects.clear()
        self.assertEqual((await self.runtime.identity.resolve({'account':cookie})).kind,'account')
        await self.runtime.privacy.replay()
        self.assertIsNone(await self.runtime.identity.resolve({'account':cookie}))
        async with self.runtime.db.transaction('jobs') as connection:
            self.assertIsNotNone(await one(connection,'SELECT 1 FROM nt.scoped_receipts WHERE public_ref=%s',(shown['reservation_id'],)))
            self.assertIsNone(await one(connection,'SELECT 1 FROM nt.privacy_exports WHERE subject_id=%s',(subject['subject_id'],)))
        unbound=self.make_client();csrf=(await unbound.get('/api/v1/bootstrap')).json()['data']['csrf']
        opened=await unbound.post('/api/v1/privacy/status/access',headers=self.headers(csrf),json={'receipt_ref':shown['reservation_id'],'secret':shown['secret']})
        self.assertEqual(opened.status_code,200,opened.text);self.assertEqual((await unbound.get('/api/v1/privacy/status')).status_code,200)
        self.assertEqual((await unbound.get('/api/v1/me')).status_code,401)

    async def test_identity_mode_filters_unqualified_endpoints(self):
        self.runtime.scope='identity';public,private=create_product_apps(self.runtime)
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=public),base_url='http://127.0.0.1:8080') as client:
            bootstrap=await client.get('/api/v1/bootstrap');self.assertEqual(bootstrap.status_code,200)
            self.assertFalse(bootstrap.json()['data']['gates']['admission'])
            for path in ('/api/v1/ws/ticket','/api/v1/billing/purchases'):
                self.assertEqual((await client.post(path,json={})).status_code,404)
            self.assertEqual((await client.get('/api/v1/privacy/retention')).status_code,200)
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=private),base_url='http://127.0.0.1:8081') as client:
            self.assertEqual((await client.get('/internal/v1/cases')).status_code,404)

    async def test_two_competing_fifth_logins_never_create_six_sessions(self):
        payload,_=await self.register();clients=[]
        for _ in range(5):
            client=self.make_client();csrf=(await client.get('/api/v1/bootstrap')).json()['data']['csrf'];clients.append((client,csrf))
        credentials={'username':payload['username'],'password':payload['password']}
        for client,csrf in clients[:3]:self.assertEqual((await client.post('/api/v1/auth/login',headers=self.headers(csrf),json=credentials)).status_code,200)
        results=await asyncio.gather(*(client.post('/api/v1/auth/login',headers=self.headers(csrf),json=credentials) for client,csrf in clients[3:]))
        self.assertEqual(sorted(response.status_code for response in results),[200,409])
        async with self.runtime.db.transaction() as connection:
            row=await one(connection,'SELECT count(*) AS n FROM nt.account_sessions s JOIN nt.accounts a ON a.id=s.account_id WHERE a.username=%s AND revoked_at IS NULL AND expires_at>now() AND absolute_expires>now()',(payload['username'],))
            self.assertEqual(row['n'],5)

    async def test_maintenance_preserves_existing_login_and_privacy(self):
        payload,_=await self.register();self.runtime.settings.admission=False
        client=self.make_client();boot=(await client.get('/api/v1/bootstrap')).json()['data']
        login=await client.post('/api/v1/auth/login',headers=self.headers(boot['csrf']),json={'username':payload['username'],'password':payload['password']})
        self.assertEqual(login.status_code,200,login.text)
        self.assertEqual((await client.get('/api/v1/me/consent-proof')).status_code,200)
        self.assertEqual((await client.get('/api/v1/support/cases')).status_code,200)

    async def test_public_bootstrap_cannot_authorize_private_mutation(self):
        client=self.make_client(private=True)
        client.cookies.set(self.runtime.cookie_name('bootstrap'),self.client.cookies.get(self.runtime.cookie_name('bootstrap')),domain='127.0.0.1',path='/')
        response=await client.post('/internal/v1/auth/login',headers={'Origin':'http://127.0.0.1:8081','X-CSRF-Token':self.csrf},json={'username':'unknown_staff','password':'Synthetic private passphrase','code':'000000'})
        self.assertEqual(response.status_code,401)
