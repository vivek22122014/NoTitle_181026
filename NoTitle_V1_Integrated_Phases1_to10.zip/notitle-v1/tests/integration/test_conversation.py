"""Real PostgreSQL + real Uvicorn/WebSocket transport, fixed local target only.

No external server, fake entitlement route, database mock or browser is involved.
Install the hash-locked runtime first. This suite is not skipped when unavailable.
"""
import asyncio,json,os,socket,unittest
from contextlib import contextmanager
from uuid import uuid4
import httpx,uvicorn
from websockets.asyncio.client import connect
from websockets.exceptions import ConnectionClosed,InvalidStatus
from app.coordinator.core import Coordinator
from app.runtime import Runtime,ProductSettings
from app.http.product import create_product_apps
from ops.nt import ROOT,secret

class Server(uvicorn.Server):
    @contextmanager
    def capture_signals(self):yield

class Peer:
    def __init__(self,ws,ready):self.ws=ws;self.ready=ready;self.last=ready
    def command(self,kind,payload):
        return {'protocol_version':2,'command_id':str(uuid4()),'type':kind,'owner_epoch':self.last['owner_epoch'],
            'socket_generation':self.last['socket_generation'],'interaction_epoch':self.last['interaction_epoch'],'payload':payload}
    async def send(self,kind,payload):
        command=self.command(kind,payload);await self.ws.send(json.dumps(command));return command
    async def until(self,kind):
        async with asyncio.timeout(7):
            while True:
                self.last=json.loads(await self.ws.recv())
                if self.last['type']==kind:return self.last['data']

class ConversationNetwork(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        if os.environ.get('NOTITLE_INTEGRATION')!='local-disposable':raise RuntimeError('Disposable local target required')
        dsn=secret('runtime_dsn')
        if 'host=127.0.0.1 port=55432 dbname=notitle ' not in dsn:raise RuntimeError('Unknown database refused')
        self.coordinator=Coordinator(1)
        async def beat():
            while True:self.coordinator.heartbeat();await asyncio.sleep(.2)
        self.beat=asyncio.create_task(beat());self.runtime=Runtime(ProductSettings.load(dsn),self.coordinator,scope='realtime');await self.runtime.open()
        self.public,_=create_product_apps(self.runtime);self.clients=[];self.sockets=[]
        sock=socket.socket();sock.bind(('127.0.0.1',0));sock.listen(64);sock.setblocking(False);self.port=sock.getsockname()[1];self.listener=sock
        self.server=Server(uvicorn.Config(self.public,lifespan='off',log_level='critical',access_log=False,proxy_headers=False,ws_max_size=65536,ws_max_queue=8,ws_per_message_deflate=False))
        self.server_task=asyncio.create_task(self.server.serve(sockets=[sock]))
        async with asyncio.timeout(5):
            while not self.server.started:
                if self.server_task.done():self.server_task.result()
                await asyncio.sleep(.02)

    async def asyncTearDown(self):
        for ws in self.sockets:await ws.close()
        self.server.should_exit=True
        try:await asyncio.wait_for(self.server_task,5)
        except TimeoutError:self.server_task.cancel();await asyncio.gather(self.server_task,return_exceptions=True)
        self.listener.close()
        for client in self.clients:await client.aclose()
        await self.runtime.close();self.beat.cancel();await asyncio.gather(self.beat,return_exceptions=True)

    async def identity(self,name='Synthetic peer',account=False):
        client=httpx.AsyncClient(transport=httpx.ASGITransport(app=self.public),base_url='http://127.0.0.1:8080');self.clients.append(client)
        boot=(await client.get('/api/v1/bootstrap')).json()['data'];headers={'Origin':'http://127.0.0.1:8080','X-CSRF-Token':boot['csrf']}
        payload={'display_name':name,'gender':'other','topic_id':'general','bio':'','consents':{'adult':True,'terms':True,'core':True,'professional':False,'policy_version':boot['policy_version'],'policy_digest':boot['policy_digest']}}
        path='/api/v1/auth/guest'
        if account:
            receipt=(await client.post('/api/v1/operations/prepare',headers=headers,json={'kind':'recovery','client_nonce':str(uuid4())})).json()['data']
            payload.update(username='test_'+uuid4().hex[:15],password='Synthetic private password!',client_nonce=str(uuid4()),proof={'reservation_id':receipt['reservation_id'],'secret':receipt['secret'],'saved':True});path='/api/v1/auth/register'
        response=await client.post(path,headers=headers,json=payload);self.assertEqual(response.status_code,201)
        boot=(await client.get('/api/v1/bootstrap')).json()['data'];return client,{'Origin':'http://127.0.0.1:8080','X-CSRF-Token':boot['csrf']}

    async def ticket(self,client,headers,**body):
        response=await client.post('/api/v1/ws/ticket',headers=headers,json=body);self.assertEqual(response.status_code,200);return response.json()['data']

    async def transport(self,client,origin='http://127.0.0.1:8080',query=''):
        cookie='; '.join(name+'='+value for name,value in client.cookies.items())
        ws=await connect('ws://127.0.0.1:8080/api/v1/ws'+query,host='127.0.0.1',port=self.port,origin=origin,additional_headers={'Cookie':cookie},compression=None,proxy=None)
        self.sockets.append(ws);return ws

    async def peer(self,client,headers,**body):
        ticket=await self.ticket(client,headers,**body);ws=await self.transport(client);await ws.send(json.dumps({'protocol_version':2,'type':'session.hello','ticket':ticket['ticket']}))
        ready=json.loads(await asyncio.wait_for(ws.recv(),5));self.assertEqual(ready['type'],'session.ready');return Peer(ws,ready)

    async def pair(self):
        ca,ha=await self.identity('Synthetic left',account=True);cb,hb=await self.identity('Synthetic right')
        a,b=await self.peer(ca,ha),await self.peer(cb,hb)
        await a.send('queue.join',{'profile_revision':1,'preference_revision':1});await a.until('queue.waiting')
        await b.send('queue.join',{'profile_revision':1,'preference_revision':1});left=await a.until('interaction.started');right=await b.until('interaction.started')
        self.assertEqual(left['interaction_handle'],right['interaction_handle']);return a,b,left,ca,ha

    async def test_account_guest_match_text_rendered_delivery_and_http_end(self):
        a,b,current,ca,ha=await self.pair();handle=current['interaction_handle']
        sent=await a.send('text.send',{'interaction_handle':handle,'text':'Synthetic ephemeral network message'})
        incoming=(await b.until('text.message'))['message'];own=(await a.until('text.message'))['message']
        self.assertEqual(incoming['sender'],'peer');self.assertIsNone(incoming['command_id']);self.assertEqual(own['command_id'],sent['command_id'])
        await b.send('text.delivered',{'interaction_handle':handle,'message_id':incoming['id'],'sequence':incoming['sequence']});delivered=await a.until('text.delivered');self.assertEqual(delivered['message_id'],incoming['id'])
        end=a.command('interaction.end',{'interaction_handle':handle});response=await ca.post('/api/v1/interactions/end',headers=ha,json=end);self.assertEqual(response.status_code,200)
        await b.until('interaction.ended');self.assertFalse(self.runtime.realtime.interactions)
        await a.ws.send(json.dumps(end));ack=await a.until('command.ack');self.assertEqual(ack['command_id'],end['command_id'])

    async def test_ticket_replay_bad_origin_and_query_are_rejected(self):
        client,headers=await self.identity();ticket=await self.ticket(client,headers);ws=await self.transport(client)
        hello=json.dumps({'protocol_version':2,'type':'session.hello','ticket':ticket['ticket']});await ws.send(hello);await ws.recv();await ws.close()
        replay=await self.transport(client);await replay.send(hello)
        with self.assertRaises(ConnectionClosed):await asyncio.wait_for(replay.recv(),3)
        for origin,query in [('https://wrong.test',''),('http://127.0.0.1:8080','?ticket=not-allowed')]:
            with self.assertRaises(InvalidStatus):await self.transport(client,origin,query)

    async def test_explicit_takeover_and_text_resume_without_search(self):
        a,b,current,client,headers=await self.pair();handle=current['interaction_handle'];await a.send('text.send',{'interaction_handle':handle,'text':'Synthetic retained in RAM'});await b.until('text.message')
        response=await client.post('/api/v1/ws/ticket',headers=headers,json={});self.assertEqual(response.status_code,409);generation=response.json()['data']['socket_generation']
        replacement=await self.peer(client,headers,takeover=True,known_socket_generation=generation);self.assertEqual(replacement.ready['data']['state'],'matched');self.assertEqual(len(replacement.ready['data']['interaction']['messages']),1)
        async with asyncio.timeout(4):
            with self.assertRaises(ConnectionClosed):
                while True:await a.ws.recv()
        self.assertFalse(self.runtime.realtime.waiters)

    async def test_ws_end_remains_responsive_while_text_authorization_waits(self):
        a,b,current,_,_=await self.pair();handle=current['interaction_handle'];original=self.runtime.conversation.authorize;entered=asyncio.Event();release=asyncio.Event()
        async def delayed(principal,**kwargs):entered.set();await release.wait();return await original(principal,**kwargs)
        self.runtime.conversation.authorize=delayed
        await a.send('text.send',{'interaction_handle':handle,'text':'Synthetic cancelled pending text'});await asyncio.wait_for(entered.wait(),2)
        await a.send('interaction.end',{'interaction_handle':handle})
        async with asyncio.timeout(1):await b.until('interaction.ended')
        release.set();self.runtime.conversation.authorize=original;self.assertFalse(self.runtime.realtime.interactions)

    async def test_handshake_capacity_and_first_frame_deadline(self):
        client,_=await self.identity()
        for _ in range(32):await self.transport(client)
        with self.assertRaises(InvalidStatus):await self.transport(client)
        self.assertEqual(self.runtime.conversation.handshakes,32)
        with self.assertRaises(ConnectionClosed):await asyncio.wait_for(self.sockets[0].recv(),6)
