"""Real PostgreSQL ledger/read-authority qualification, using disposable fixtures.

These tests do not assert real Cashfree capture, merchant onboarding, or refunds.
The only synthetic grant is inserted directly into the disposable database.
"""
import asyncio
import base64,hashlib,hmac,json,time
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock
from uuid import uuid4
import tests.integration.test_application as application_module
from app.repositories.database import one


class BillingLedger(unittest.IsolatedAsyncioTestCase):
    asyncSetUp=application_module.Application.asyncSetUp
    asyncTearDown=application_module.Application.asyncTearDown
    make_client=application_module.Application.make_client
    headers=application_module.Application.headers
    register=application_module.Application.register

    async def grant_fixture(self):
        await self.register()
        principal=await self.runtime.identity.resolve({'account':self.client.cookies.get(self.runtime.cookie_name('account'))})
        purchase_id,ref=uuid4(),uuid4().hex
        async with self.runtime.db.transaction('jobs') as connection:
            subject=await one(connection,'SELECT * FROM nt.financial_subjects WHERE account_id=%s FOR UPDATE',(principal.account_id,))
            await connection.execute('''INSERT INTO nt.purchases(id,public_ref,financial_subject_id,plan_code,plan_version,
                amount_paise,duration_seconds,merchant_order_id,idempotency_key,state,environment,policy_version,policy_digest,policy_accepted_at,tax_rule)
                VALUES(%s,%s,%s,'Short3','1',9900,100,%s,%s,'captured','sandbox','disposable-test',%s,now(),'disposable-test')''',
                (purchase_id,ref,subject['id'],'nt_'+ref,uuid4(),'0'*64))
            await connection.execute('''INSERT INTO nt.entitlement_lots(purchase_id,subject_id,grant_seq,granted_seconds,available_seconds)
                VALUES(%s,%s,1,100,100)''',(purchase_id,subject['id']))
            await connection.execute("UPDATE nt.financial_subjects SET last_accounted_at=now()-interval '10 seconds',ledger_revision=ledger_revision+1 WHERE id=%s",(subject['id'],))
            saved=await one(connection,'SELECT * FROM nt.financial_subjects WHERE id=%s',(subject['id'],))
        return principal,purchase_id,ref,saved

    async def test_matching_reads_are_stable_under_concurrency_and_do_not_write(self):
        principal,purchase_id,_,before=await self.grant_fixture()
        snapshots=await asyncio.gather(*(self.runtime.billing.matching_entitlement(principal) for _ in range(6)))
        self.assertEqual({r['entitlement_revision'] for r in snapshots},{before['ledger_revision']})
        self.assertEqual(len({r['premium_until'] for r in snapshots}),1)
        self.assertTrue(all(85<=r['available_seconds']<=90 for r in snapshots))
        async with self.runtime.db.transaction('jobs') as connection:
            after=await one(connection,'SELECT * FROM nt.financial_subjects WHERE id=%s',(before['id'],))
            lot=await one(connection,'SELECT * FROM nt.entitlement_lots WHERE purchase_id=%s',(purchase_id,))
        self.assertEqual(before['last_accounted_at'],after['last_accounted_at'])
        self.assertEqual(before['ledger_revision'],after['ledger_revision'])
        self.assertEqual(lot['consumed_seconds'],0);self.assertEqual(lot['available_seconds'],100)

    async def test_hold_and_accounting_are_visible_atomically(self):
        principal,purchase_id,_,before=await self.grant_fixture()
        prior=await self.runtime.billing.matching_entitlement(principal)
        async with self.runtime.db.transaction('jobs') as connection:
            await one(connection,'SELECT * FROM nt.subject_controls WHERE financial_subject_id=%s FOR UPDATE',(before['id'],))
            subject=await one(connection,'SELECT * FROM nt.financial_subjects WHERE id=%s FOR UPDATE',(before['id'],))
            lots=await self.runtime.billing.account_lots(connection,subject)
            from app.domain.ledger import hold
            hold(lots[0],20,'statutory_remedy')
            await connection.execute('UPDATE nt.entitlement_lots SET available_seconds=%s,held_seconds=%s,revision=revision+1 WHERE purchase_id=%s',(lots[0].available,lots[0].held,purchase_id))
        after=await self.runtime.billing.matching_entitlement(principal)
        self.assertGreater(after['entitlement_revision'],prior['entitlement_revision'])
        self.assertEqual(after['premium_until'],prior['premium_until']-20)

    async def test_owned_purchase_recovery_does_not_expose_other_subjects(self):
        _,_,ref,_=await self.grant_fixture()
        result=await self.client.get('/api/v1/billing/purchases');self.assertEqual(result.status_code,200,result.text)
        self.assertIn(ref,[row['public_ref'] for row in result.json()['data']['items']])
        outsider=self.make_client();await self.register(outsider)
        result=await outsider.get('/api/v1/billing/purchases');self.assertEqual(result.json()['data']['items'],[])
        self.assertEqual((await outsider.get('/api/v1/billing/purchases/'+ref)).status_code,404)

    async def test_external_refund_holds_once_and_excludes_origin_from_matching(self):
        principal,purchase_id,ref,subject=await self.grant_fixture()
        facts=[{'provider_id':'123456','merchant_id':'external_fixture','amount_paise':4950,'status':'SUCCESS'}]
        async with self.runtime.db.transaction('jobs') as connection:
            await one(connection,'SELECT * FROM nt.subject_controls WHERE financial_subject_id=%s FOR UPDATE',(subject['id'],))
            subject=await one(connection,'SELECT * FROM nt.financial_subjects WHERE id=%s FOR UPDATE',(subject['id'],))
            purchase=await one(connection,'SELECT * FROM nt.purchases WHERE id=%s FOR UPDATE',(purchase_id,))
            await self.runtime.billing.hold_external_refunds(connection,purchase,subject,facts)
            await self.runtime.billing.hold_external_refunds(connection,purchase,subject,facts)
            lot=await one(connection,'SELECT * FROM nt.entitlement_lots WHERE purchase_id=%s',(purchase_id,))
            adjustments=await one(connection,'SELECT count(*) AS n FROM nt.ledger_adjustments WHERE lot_id=%s',(purchase_id,))
            receipts=await one(connection,'SELECT count(*) AS n FROM nt.receipts WHERE purchase_id=%s',(purchase_id,))
            review=await one(connection,'SELECT state FROM nt.purchases WHERE id=%s',(purchase_id,))
        self.assertEqual(lot['available_seconds'],0);self.assertGreater(lot['held_seconds'],0)
        self.assertEqual(lot['granted_seconds'],lot['consumed_seconds']+lot['available_seconds']+lot['held_seconds']+lot['revoked_seconds'])
        self.assertEqual(adjustments['n'],1);self.assertEqual(receipts['n'],1);self.assertEqual(review['state'],'financial_review')
        projection=await self.runtime.billing.matching_entitlement(principal)
        self.assertEqual(projection['available_seconds'],0);self.assertEqual(projection['premium_until'],0)

    async def test_reviewed_origin_stays_excluded_if_an_internal_failure_restores_time(self):
        # A later failed internal refund must not reactivate a disputed/refunded
        # origin while its independent financial review is still outstanding.
        principal,purchase_id,ref,subject=await self.grant_fixture()
        async with self.runtime.db.transaction('jobs') as connection:
            await connection.execute("UPDATE nt.purchases SET state='financial_review' WHERE id=%s",(purchase_id,))
        projection=await self.runtime.billing.matching_entitlement(principal)
        self.assertEqual(projection['available_seconds'],0);self.assertEqual(projection['premium_until'],0)

    async def review_fixture(self):
        from app.domain.security import token
        principal,purchase_id,ref,subject=await self.grant_fixture()
        payment_id,refund_id=str(uuid4().int),str(uuid4().int)
        merchant_refund='external_'+uuid4().hex
        async with self.runtime.db.transaction('jobs') as c:
            await c.execute("INSERT INTO nt.payment_attempts(provider_payment_id,purchase_id,amount_paise,currency,environment,status) VALUES(%s,%s,9900,'INR','sandbox','SUCCESS')",(payment_id,purchase_id))
            await one(c,'SELECT * FROM nt.subject_controls WHERE financial_subject_id=%s FOR UPDATE',(subject['id'],))
            subject=await one(c,'SELECT * FROM nt.financial_subjects WHERE id=%s FOR UPDATE',(subject['id'],))
            purchase=await one(c,'SELECT * FROM nt.purchases WHERE id=%s FOR UPDATE',(purchase_id,))
            await self.runtime.billing.hold_external_refunds(c,purchase,subject,[{'provider_id':refund_id,'merchant_id':merchant_refund,'amount_paise':4950,'status':'SUCCESS'}])
        raw={'order_id':purchase['merchant_order_id'],'cf_payment_id':payment_id,'cf_refund_id':refund_id,'refund_id':merchant_refund,'refund_amount':'49.50','refund_currency':'INR','refund_status':'SUCCESS'}
        provider=SimpleNamespace(fetch_order=AsyncMock(return_value={'order_id':purchase['merchant_order_id'],'order_amount':99,'order_currency':'INR'}),fetch_refunds=AsyncMock(return_value=[raw]),fetch_disputes=AsyncMock(return_value=[]))
        self.runtime.billing.provider=provider
        staff_id,secret=uuid4(),token();password_hash=await self.runtime.identity.passwords.hash('Synthetic billing reviewer passphrase!')
        async with self.runtime.db.transaction('private') as c:
            await c.execute('INSERT INTO nt.staff_accounts(id,username,password_hash,totp_ciphertext) VALUES(%s,%s,%s,%s)',(staff_id,'review_'+uuid4().hex[:15],password_hash,self.runtime.security.encrypt('staff:'+str(staff_id),'JBSWY3DPEHPK3PXP')))
            await c.execute("INSERT INTO nt.staff_roles(staff_id,permission) VALUES(%s,'billing.remedies')",(staff_id,))
            await c.execute("INSERT INTO nt.staff_sessions(token_hmac,staff_id,role_version,mfa_at,expires_at,absolute_expires,key_version) VALUES(%s,%s,1,now(),now()+interval '15 minutes',now()+interval '4 hours',%s)",(self.runtime.security.digest('staff_session',secret),staff_id,self.runtime.security.key_version))
        reviewer=self.make_client(True);reviewer.cookies.set(self.runtime.cookie_name('admin'),secret,domain='127.0.0.1',path='/')
        headers={'Origin':self.runtime.settings.private_origin,'X-CSRF-Token':self.runtime.security.csrf(secret)}
        return principal,purchase_id,ref,reviewer,headers,provider,raw

    async def test_private_verified_resolution_revokes_minimum_once(self):
        principal,purchase_id,ref,reviewer,headers,provider,raw=await self.review_fixture()
        body={'action':'revoke','seconds_to_revoke':None,'reason':'Synthetic independently verified provider loss','client_nonce':str(uuid4())}
        response=await reviewer.post('/internal/v1/billing/reviews/'+ref+'/preview',headers=headers,json=body)
        self.assertEqual(response.status_code,200,response.text);preview=response.json()['data'];self.assertEqual(preview['payload']['minimum_revoke_seconds'],50)
        first=await reviewer.post('/internal/v1/billing/reviews/confirm',headers=headers,json={'preview':preview['preview']})
        self.assertEqual(first.status_code,200,first.text);self.assertEqual(first.json()['data']['seconds_to_revoke'],50)
        second=await reviewer.post('/internal/v1/billing/reviews/confirm',headers=headers,json={'preview':preview['preview']})
        self.assertEqual(second.status_code,200,second.text);self.assertEqual(first.json()['data'],second.json()['data'])
        async with self.runtime.db.transaction('jobs') as c:
            lot=await one(c,'SELECT * FROM nt.entitlement_lots WHERE purchase_id=%s',(purchase_id,))
            review=await one(c,'SELECT * FROM nt.external_financial_reviews WHERE purchase_id=%s',(purchase_id,))
        self.assertEqual(lot['revoked_seconds'],50);self.assertEqual(lot['held_seconds'],0);self.assertEqual(review['state'],'revoked')
        self.assertEqual(lot['granted_seconds'],sum(lot[key] for key in ('consumed_seconds','available_seconds','held_seconds','revoked_seconds')))

    async def test_changed_provider_snapshot_invalidates_confirmation_without_releasing(self):
        _,purchase_id,ref,reviewer,headers,provider,raw=await self.review_fixture()
        response=await reviewer.post('/internal/v1/billing/reviews/'+ref+'/preview',headers=headers,json={'action':'revoke','seconds_to_revoke':None,'reason':'Synthetic provider outcome under review','client_nonce':str(uuid4())})
        self.assertEqual(response.status_code,200,response.text);preview=response.json()['data']['preview']
        provider.fetch_refunds.return_value=[raw|{'refund_status':'PENDING'}]
        response=await reviewer.post('/internal/v1/billing/reviews/confirm',headers=headers,json={'preview':preview})
        self.assertEqual(response.status_code,409,response.text)
        async with self.runtime.db.transaction('jobs') as c:
            lot=await one(c,'SELECT * FROM nt.entitlement_lots WHERE purchase_id=%s',(purchase_id,))
            review=await one(c,'SELECT * FROM nt.external_financial_reviews WHERE purchase_id=%s',(purchase_id,))
        self.assertGreater(lot['held_seconds'],0);self.assertEqual(lot['revoked_seconds'],0);self.assertEqual(review['state'],'open')

    async def test_new_signed_notice_fences_preview_even_if_provider_list_is_unchanged(self):
        _,purchase_id,ref,reviewer,headers,provider,raw=await self.review_fixture()
        response=await reviewer.post('/internal/v1/billing/reviews/'+ref+'/preview',headers=headers,json={'action':'revoke','seconds_to_revoke':None,'reason':'Synthetic preview before new signed notice','client_nonce':str(uuid4())})
        self.assertEqual(response.status_code,200,response.text);preview=response.json()['data']['preview']
        secret=b'synthetic-not-a-merchant-secret';self.runtime.webhook_secret=secret
        body=json.dumps({'type':'REFUND_STATUS_WEBHOOK','data':{'refund':raw}},separators=(',',':')).encode();stamp=str(int(time.time()*1000))
        signature=base64.b64encode(hmac.new(secret,stamp.encode()+body,hashlib.sha256).digest()).decode()
        notice=await self.client.post('/api/v1/webhooks/cashfree',content=body,headers={'Content-Type':'application/json','X-Webhook-Timestamp':stamp,'X-Webhook-Signature':signature})
        self.assertEqual(notice.status_code,200,notice.text)
        response=await reviewer.post('/internal/v1/billing/reviews/confirm',headers=headers,json={'preview':preview})
        self.assertEqual(response.status_code,409,response.text)
        async with self.runtime.db.transaction('jobs') as c:
            lot=await one(c,'SELECT * FROM nt.entitlement_lots WHERE purchase_id=%s',(purchase_id,))
        self.assertGreater(lot['held_seconds'],0);self.assertEqual(lot['revoked_seconds'],0)
