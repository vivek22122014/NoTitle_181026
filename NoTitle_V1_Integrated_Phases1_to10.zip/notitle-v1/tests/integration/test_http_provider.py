import base64,hashlib,hmac,json,unittest
from uuid import uuid4
import httpx
from app.coordinator.core import Coordinator
from app.http.factory import create_apps
from app.integrations.cashfree import CashfreeSandbox,ProviderUnknown
class HTTP(unittest.IsolatedAsyncioTestCase):
    async def test_private_routes_not_public_and_staff_auth_denied(self):
        public,private=create_apps(Coordinator(1))
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=public),base_url='http://test') as client:
            response=await client.get('/internal/v1/health');self.assertEqual(response.status_code,404)
            response=await client.get('/health/ready');self.assertEqual(response.json()['data']['status'],'maintenance')
            self.assertEqual(response.headers['cache-control'],'no-store')
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=private),base_url='http://test') as client:
            self.assertEqual((await client.get('/internal/v1/health')).status_code,401)
    async def test_foundation_never_mounts_product_or_payment_routes(self):
        public,private=create_apps(Coordinator(1))
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=public),base_url='http://test') as client:
            data=(await client.get('/health/ready')).json()['data']
            self.assertEqual(data['mode'],'foundation');self.assertIs(data['admission'],False)
            for path in ('/api/v1/me','/api/v1/bootstrap','/api/v1/billing/plans','/internal/v1/cases'):
                self.assertEqual((await client.get(path)).status_code,404)

    async def test_unknown_provider_outcome_never_retries_new_charge(self):
        requests=[]
        def handler(request):
            requests.append(request)
            return httpx.Response(504,json={'message':'unknown'})
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            api=CashfreeSandbox('synthetic','synthetic',client)
            nonce=uuid4()
            with self.assertRaises(ProviderUnknown):await api.create_order('test_123',9900,'test_customer','9999999999',nonce)
            self.assertEqual(len(requests),1)
            self.assertEqual(requests[0].headers['x-idempotency-key'],str(nonce))
            self.assertEqual(requests[0].url.host,'sandbox.cashfree.com')
    async def test_voluntary_refund_rejected_before_provider(self):
        async with httpx.AsyncClient(transport=httpx.MockTransport(lambda r:self.fail('Unexpected provider call'))) as client:
            api=CashfreeSandbox('synthetic','synthetic',client)
            with self.assertRaises(ValueError):await api.create_required_refund('test_123','refund_123',9900,'change_of_mind',uuid4())
