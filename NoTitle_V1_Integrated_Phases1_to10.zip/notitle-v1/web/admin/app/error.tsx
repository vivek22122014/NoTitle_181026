'use client';
export default function ErrorPage({reset}:{reset:()=>void}){return <main className="wrap content"><h1>Workspace unavailable.</h1><p role="alert">The result is unknown. Do not repeat a sensitive confirmation until its current status is checked.</p><button type="button" onClick={()=>reset()}>Reload workspace</button></main>;}
