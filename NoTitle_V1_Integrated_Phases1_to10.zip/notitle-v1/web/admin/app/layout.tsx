import type { Metadata } from 'next';
import '@notitle/shared/tokens.css';
export const metadata: Metadata = {title:'NoTitle · Moderator workspace',description:'NoTitle V1',robots:{index:false,follow:false}};
export const viewport={width:'device-width',initialScale:1,viewportFit:'cover'};
export default function Layout({children}:Readonly<{children:React.ReactNode}>){return <html lang="en"><body data-surface="private-workspace-v1">{children}</body></html>}
