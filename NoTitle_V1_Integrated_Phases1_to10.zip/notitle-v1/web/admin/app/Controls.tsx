'use client';
import React,{useEffect,useState} from 'react';
import {Client,Data} from '@notitle/shared/client';
type Run=(work:()=>Promise<void>)=>Promise<void>;
type Common={api:Client;run:Run;grants:string[]};

export function StepUp({api,run}:{api:Client;run:Run}){
 const [password,setPassword]=useState(''),[code,setCode]=useState(''),[done,setDone]=useState(false);
 return <details className="card" style={{marginBottom:24}}><summary>Verify again for sensitive actions</summary>
  <p className="small-text muted">Payment remedies, safety decisions and legal holds require MFA verified within the last five minutes.</p>
  <form method="post" onSubmit={e=>{e.preventDefault();void run(async()=>{await api.request('/auth/step-up','POST',{password,code});setPassword('');setCode('');setDone(true);});}}>
   <label>Staff password<input type="password" autoComplete="current-password" value={password} required onChange={e=>setPassword(e.target.value)}/></label>
   <label>New authenticator code<input inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" value={code} required onChange={e=>setCode(e.target.value)}/></label>
   <button className="secondary">Verify MFA</button>{done&&<p role="status">Verified. Complete the sensitive action within five minutes.</p>}
  </form></details>;
}

export function CaseControls({api,run,grants,active,refresh}:{api:Client;run:Run;grants:string[];active:Data;refresh:()=>Promise<void>}){
 const [report,setReport]=useState<Data|null>(null),[rules,setRules]=useState<Data[]>([]),[rule,setRule]=useState(''),[evidence,setEvidence]=useState('');
 const [decision,setDecision]=useState({subject_ref:'',action:'restrict',duration_hours:24,reason_code:'harassment',reason:''}),[preview,setPreview]=useState<Data|null>(null);
 const [assignee,setAssignee]=useState('');
 useEffect(()=>{setReport(null);setPreview(null);setEvidence('');},[active.public_ref]);
 const allowed=(name:string)=>grants.includes(name);
 return <div className="stack" style={{marginTop:24}}>
  {allowed('cases.assign')&&<details><summary>Assign this case</summary><form method="post" onSubmit={e=>{e.preventDefault();void run(async()=>{await api.request('/cases/'+active.public_ref+'/assignment','POST',{staff_ref:assignee||null,expected_version:active.version,reason:'Authorized case assignment',client_nonce:crypto.randomUUID()});await refresh();});}}><label>Authorized staff ID (blank to unassign)<input value={assignee} onChange={e=>setAssignee(e.target.value)}/></label><button className="secondary">Save assignment</button></form></details>}
  {allowed('cases.legal')&&<details><summary>Legal classification and independent deadlines</summary><p>State: {active.legal_state}. Classify the root case using the reviewed rule pack. A continuation never restarts its clocks.</p>
   <button className="small secondary" onClick={()=>void run(async()=>setRules((await api.request('/legal/rules')).rules))}>Load reviewed rules</button>
   <label>Additional reviewed rule<select value={rule} onChange={e=>setRule(e.target.value)}><option value="">Automatic category rules only</option>{rules.map(item=><option key={item.id} value={item.id}>{item.id} · {item.version}</option>)}</select></label>
   <button className="secondary" onClick={()=>void run(async()=>{await api.request('/cases/'+active.public_ref+'/classification','POST',{rule_id:rule||null,expected_version:active.version});await refresh();})}>Apply classification</button>
   <label>Completion evidence reference<input value={evidence} minLength={4} maxLength={100} onChange={e=>setEvidence(e.target.value)}/></label>
   {active.obligations?.filter((item:Data)=>item.status!=='completed').map((item:Data)=><div className="notice" key={item.id}><p>{item.escalation} · Due {new Date(item.act_by).toLocaleString()}</p><button className="small secondary" disabled={evidence.length<4} onClick={()=>void run(async()=>{await api.request('/cases/'+active.public_ref+'/obligations/complete','POST',{obligation_ref:item.id,evidence_ref:evidence,expected_version:active.version});await refresh();})}>Record completion</button></div>)}
  </details>}
  {allowed('reports.read')&&active.reports?.length>0&&<details><summary>Selected safety evidence — audited access</summary>{active.reports.map((item:Data)=><button className="small secondary" key={item.public_ref} onClick={()=>void run(async()=>{const result=await api.request('/reports/'+item.public_ref+'?purpose=safety_review');setReport(result);setDecision({...decision,subject_ref:result.subject_ref});})}>{item.reason} · read report</button>)}
   {report&&<><p>{report.allegation}</p>{report.evidence.map((item:Data)=><blockquote key={item.message_id}><p>{item.body}</p><small>Server-selected evidence · {new Date(item.sent_at).toLocaleString()}</small></blockquote>)}</>}
  </details>}
  {allowed('safety.decide')&&<details><summary>Safety decision or independent appeal</summary><p className="small-text muted">Fresh MFA and reviewed evidence are required. An appeal reviewer must differ from the original decision maker.</p>
   <form method="post" onSubmit={e=>{e.preventDefault();void run(async()=>setPreview(await api.request('/decisions/preview','POST',{case_ref:active.public_ref,...decision})));}}>
    <label>Subject reference<input value={decision.subject_ref} required minLength={32} maxLength={32} onChange={e=>setDecision({...decision,subject_ref:e.target.value})}/></label>
    <label>Action<select value={decision.action} onChange={e=>setDecision({...decision,action:e.target.value})}><option value="restrict">Restrict participation</option><option value="release">Release restriction</option></select></label>
    <label>Duration in hours<input type="number" min={1} max={8760} value={decision.duration_hours} onChange={e=>setDecision({...decision,duration_hours:Number(e.target.value)})}/></label>
    <label>Reason code<select value={decision.reason_code} onChange={e=>setDecision({...decision,reason_code:e.target.value})}>{['harassment','threats','doxxing','underage','scam','impersonation','appeal_upheld','other'].map(value=><option key={value}>{value}</option>)}</select></label>
    <label>Evidence-based decision reason<textarea value={decision.reason} required minLength={10} maxLength={300} onChange={e=>setDecision({...decision,reason:e.target.value})}/></label><button className="secondary">Preview decision</button>
   </form>{preview&&<div className="notice"><p>{preview.payload.action} · {preview.payload.duration_hours} hours · {preview.payload.reason}</p><button className="danger" onClick={()=>void run(async()=>{await api.request('/decisions/confirm','POST',{preview:preview.preview});setPreview(null);await refresh();})}>Confirm reviewed decision</button></div>}
  </details>}
 </div>;
}

export function PrivacyControls({api,run,grants}:Common){
 const [requests,setRequests]=useState<Data[]>([]),[holds,setHolds]=useState<Data[]>([]),[preview,setPreview]=useState<Data|null>(null),[kind,setKind]=useState('hold');
 const [form,setForm]=useState({subject_ref:'',scope:'',basis:'',review_days:30,expires_days:90}),[releaseReason,setReleaseReason]=useState('');
 async function load(){setRequests((await api.request('/privacy/requests')).items);if(grants.includes('privacy.holds'))setHolds((await api.request('/privacy/holds')).items);}
 useEffect(()=>{void run(load);},[]);
 return <><h1>Privacy operations.</h1><button className="secondary" onClick={()=>void run(load)}>Refresh</button><div className="two" style={{marginTop:24}}><section className="card"><h2>Rights requests</h2>{requests.map(item=><p key={item.id}>{item.kind} · {item.status} · {item.deadline?new Date(item.deadline).toLocaleString():'Review applicable deadline'}<br/><small>{item.id}</small></p>)}</section>
  {grants.includes('privacy.holds')&&<section className="card"><h2>Scoped legal holds</h2><p className="small-text muted">Use the case or subject reference from the authorized workflow. A hold needs a specific legal basis, review date and expiry.</p>
   <form method="post" onSubmit={e=>{e.preventDefault();void run(async()=>{setKind('hold');setPreview(await api.request('/privacy/holds/preview','POST',form));});}}>
    <label>Subject UUID<input required value={form.subject_ref} onChange={e=>setForm({...form,subject_ref:e.target.value})}/></label>
    <label>Exact scope<input required minLength={4} value={form.scope} onChange={e=>setForm({...form,scope:e.target.value})}/></label>
    <label>Legal basis<textarea required minLength={10} maxLength={500} value={form.basis} onChange={e=>setForm({...form,basis:e.target.value})}/></label>
    <label>Review after days<input type="number" min={1} max={180} value={form.review_days} onChange={e=>setForm({...form,review_days:Number(e.target.value)})}/></label>
    <label>Expires after days<input type="number" min={1} max={365} value={form.expires_days} onChange={e=>setForm({...form,expires_days:Number(e.target.value)})}/></label><button className="secondary">Preview hold</button>
   </form><label>Reason to release a selected hold<textarea value={releaseReason} minLength={10} maxLength={300} onChange={e=>setReleaseReason(e.target.value)}/></label>
   {holds.map(item=><div className="notice" key={item.id}><p>{item.scope} · {item.state}<br/>Review {new Date(item.review_at).toLocaleString()}</p><button className="small secondary" disabled={releaseReason.length<10||item.state!=='active'} onClick={()=>void run(async()=>{setKind('release');setPreview(await api.request('/privacy/holds/'+item.id+'/release/preview','POST',{reason:releaseReason}));})}>Preview release</button></div>)}
   {preview&&<div className="notice"><h3>Confirm {kind}</h3><pre>{JSON.stringify(preview.payload,null,2)}</pre><button className="danger" onClick={()=>void run(async()=>{await api.request(kind==='hold'?'/privacy/holds/confirm':'/privacy/holds/release/confirm','POST',{preview:preview.preview});setPreview(null);await load();})}>Confirm reviewed {kind}</button></div>}
  </section>}</div></>;
}
