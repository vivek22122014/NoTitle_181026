export default function Loading(){return <main className="wrap content" aria-busy="true"><h1>Loading workspace</h1><p role="status">Waiting for the current authorized state.</p></main>;}
