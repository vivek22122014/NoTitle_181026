import {StaffShell} from '../components/Shell';
export default function NotFound(){return <StaffShell><h1>Page not found</h1><p>This private workspace address is unavailable.</p><a href="/">Return to staff access</a></StaffShell>;}
