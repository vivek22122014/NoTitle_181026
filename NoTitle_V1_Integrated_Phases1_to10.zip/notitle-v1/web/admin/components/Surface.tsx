import site from '@notitle/shared/site';
import type {StaffScreen} from '@notitle/shared/interface';
import routes from '../route-data.json';
import {StaffShell} from './Shell';
import {StaffScreenView} from './Screens';
import Workbench from './Workbench';
export default async function Surface({path}:{path:string}){
  const route=routes.find(item=>item.path===path);if(!route)throw new Error('Unknown private route');
  if((site.mode==='candidate'||site.mode==='realtime')&&route.kind!=='review'){
    const {default:Candidate}=await import('../app/Candidate');
    const stages:Record<string,string>={login:'cases',cases:'cases',reports:'cases',privacy:'privacy',analytics:'analytics',billing:'billing',audit:'audit',settings:'operations',release:'operations'};
    return <Candidate initialPage={stages[route.stage]}/>;
  }
  return <StaffShell current={path}>{route.kind==='review'?<Workbench/>:<StaffScreenView screen={route.screen as StaffScreen} stage={route.stage}/>}</StaffShell>;
}
