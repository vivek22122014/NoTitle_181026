import type {Metadata} from 'next';
import routes from '../route-data.json';
export function pageMetadata(path:string):Metadata{const route=routes.find(item=>item.path===path);if(!route)throw new Error('Unknown private route');return {title:`${route.title} · NoTitle private workspace`,description:route.description,robots:{index:false,follow:false,noarchive:true}};}
