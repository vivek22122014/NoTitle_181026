import type {Board,StaffScreen,MetricFixture} from '@notitle/shared/interface';
/** NT_PRIVATE_BUNDLE: this module may never enter the public application graph. */
export const boards=[
  {id:'A01',label:'Staff cases, safety & privacy',route:'/cases/',stages:[{id:'login',label:'Password + MFA',description:'Separate staff credentials; tunnel access does not replace authentication.'},{id:'cases',label:'Case queue',description:'Assignment and status changes require grants and expected versions.'},{id:'reports',label:'Safety evidence',description:'A committed access audit precedes plaintext release.'},{id:'privacy',label:'Rights and appeals',description:'Independent obligation clocks survive status and assignment changes.'}]},
  {id:'A02',label:'Private operations',route:'/analytics/',stages:[{id:'analytics',label:'Aggregate analytics',description:'UTC intervals, units, suppression and completeness are explicit.'},{id:'billing',label:'Required remedies',description:'No goodwill refunds; fresh MFA and a single-use preview precede provider action.'},{id:'audit',label:'Access audit',description:'Metadata only; no message bodies or secrets.'},{id:'settings',label:'Staff grants',description:'No runtime secret values are exposed in the browser.'},{id:'release',label:'Release evidence',description:'The signed CLI remains the deployment entry point.'}]},
] as const satisfies readonly Board<StaffScreen>[];
export const metrics:readonly MetricFixture[]=[
  {label:'Current accounts',value:'420',unit:'accounts · illustrative',complete:true},
  {label:'Active now',value:'18',unit:'admitted identities, including guests · illustrative',complete:true},
  {label:'New registrations',value:'Suppressed (<5)',unit:'count · UTC interval · illustrative',complete:true},
  {label:'Conversations started',value:'Not available',unit:'count · collection gap · illustrative',complete:false},
  {label:'Request latency p95',value:'84',unit:'milliseconds · histogram estimate · illustrative',complete:true},
  {label:'Server errors',value:'0',unit:'responses · illustrative',complete:true},
];
