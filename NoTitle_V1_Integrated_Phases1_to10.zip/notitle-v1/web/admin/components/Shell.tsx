import type {ReactNode} from 'react';
import site from '@notitle/shared/site';
export function StaffShell({children,current=''}:{children:ReactNode;current?:string}){
  return <><a className="skip" href="#main">Skip to workspace</a><header className="top"><div className="wrap"><a className="brand" href="/">NO<span>Title</span></a><span className="pill">Private workspace</span><a href="/">Staff access</a></div></header>
    {site.mode==='interface'&&<div className="preview-banner"><div className="wrap"><strong>Private interface preview.</strong> All records are illustrative; actions require qualified staff authentication and grants. <a href="/interface/">Review private screen states</a></div></div>}
    <div className="wrap staff-shell"><nav className="staff-navigation" aria-label="Private workspace">{[['/cases/','Cases'],['/reports/','Safety'],['/privacy/','Privacy'],['/analytics/','Analytics'],['/billing/','Billing'],['/audit/','Audit'],['/settings/','Staff settings'],['/release/','Release']].map(([href,label])=><a href={href} key={href} aria-current={href===current?'page':undefined}>{label}</a>)}</nav><main className="content" id="main" tabIndex={-1}>{children}</main></div></>;
}
