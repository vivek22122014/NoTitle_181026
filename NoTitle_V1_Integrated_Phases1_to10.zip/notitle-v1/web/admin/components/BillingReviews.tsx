'use client';
import {useEffect,useRef,useState} from 'react';

type Data=Record<string,any>;
type API={request:(path:string,method?:string,body?:any)=>Promise<any>};
type Props={api:API;run:(task:()=>Promise<void>)=>Promise<void>};
type Intent={action:'restore'|'revoke';seconds_to_revoke:number|null;reason:string;client_nonce:string};
type Phase='editing'|'previewing'|'preview-unknown'|'review'|'confirming'|'confirm-unknown'|'complete';
const reference=(value:unknown)=>typeof value==='string'&&/^[0-9a-f]{32}$/.test(value);
const seconds=(value:unknown)=>typeof value==='number'&&Number.isSafeInteger(value)&&value>=0;
function explanation(error:unknown){
 const code=error&&typeof error==='object'&&'code' in error?String(error.code):'';
 const messages:Record<string,string>={PROVIDER_VERIFICATION_UNAVAILABLE:'Provider verification is unavailable. The hold remains in place.',PROVIDER_OUTCOME_PENDING:'The provider outcome is pending or unaccounted for. The hold remains in place.',FRESH_MFA_REQUIRED:'Verify MFA again, then retry this exact action.',PREVIEW_STALE:'Provider facts or ledger revisions changed. No release was authorized by this stale preview.',PREVIEW_EXPIRED:'The preview expired. A new verified preview is required.',FORBIDDEN:'Your current permissions do not authorize this action.'};
 return messages[code]||'The result was not confirmed. Do not assume held time was released. Retry the exact action to recover its result.';
}
export default function BillingReviews({api,run}:Props){
 const [items,setItems]=useState<Data[]>([]),[cursor,setCursor]=useState<string|null>(null),[selected,setSelected]=useState<Data|null>(null),[action,setAction]=useState<'restore'|'revoke'>('restore'),[requestedSeconds,setRequestedSeconds]=useState(''),[reason,setReason]=useState(''),[preview,setPreview]=useState<Data|null>(null),[result,setResult]=useState<Data|null>(null),[phase,setPhase]=useState<Phase>('editing'),[busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
 const intent=useRef<Intent|null>(null),generation=useRef(0);
 const locked=phase!=='editing'&&phase!=='complete';
 async function operation(task:(valid:()=>boolean)=>Promise<void>){
  const id=generation.current;setBusy(true);setError('');
  await run(async()=>{try{await task(()=>id===generation.current);}catch(error){if(id===generation.current)setError(explanation(error));throw error;}finally{if(id===generation.current)setBusy(false);}});
 }
 async function load(after:string|null=null){
  await operation(async valid=>{const response=await api.request('/billing/reviews'+(after?'?cursor='+encodeURIComponent(after):''));if(!valid())return;
   if(!Array.isArray(response.items)||response.items.some((row:Data)=>!reference(row.purchase_ref)||!seconds(row.held_seconds)))throw new Error('INVALID_RESPONSE');
   setItems(response.items);setCursor(typeof response.next_cursor==='string'?response.next_cursor:null);
  });
 }
 useEffect(()=>{void load();return()=>{generation.current++;intent.current=null;};},[api]);
 function choose(item:Data){if(busy||locked)return;generation.current++;setSelected(item);setPreview(null);setResult(null);intent.current=null;setPhase('editing');setAction('restore');setRequestedSeconds('');setReason('');setError('');setNotice('');}
 async function refreshFacts(){if(!selected)return;const purchase=selected.purchase_ref;
  await operation(async valid=>{await api.request('/billing/reviews/'+purchase+'/refresh','POST',{});if(!valid())return;setNotice('Provider facts were checked. Any unresolved or new exposure remains held. Create a fresh preview to review a disposition.');
   const response=await api.request('/billing/reviews');if(!valid())return;setItems(response.items||[]);setCursor(response.next_cursor||null);const current=(response.items||[]).find((row:Data)=>row.purchase_ref===purchase);if(current)setSelected(current);
  });
 }
 async function prepare(){if(!selected)return;
  if(!intent.current){const count=requestedSeconds===''?null:Number(requestedSeconds);if(count!==null&&!seconds(count)){setError('Enter a whole number of seconds, or leave the field blank.');return;}intent.current={action,seconds_to_revoke:action==='revoke'?count:null,reason,client_nonce:crypto.randomUUID()};}
  const purchase=selected.purchase_ref,payload=intent.current;setPhase('previewing');
  await operation(async valid=>{try{const response=await api.request('/billing/reviews/'+purchase+'/preview','POST',payload);if(!valid())return;
    if(!reference(response.preview)||!response.payload||!seconds(response.payload.held_seconds)||!seconds(response.payload.seconds_to_revoke)||!seconds(response.payload.seconds_to_restore)||!seconds(response.payload.minimum_revoke_seconds))throw new Error('INVALID_RESPONSE');
    setPreview(response);setPhase('review');setNotice('Review the server-computed disposition. No held time has been released by creating this preview.');
   }catch(error){if(valid())setPhase('preview-unknown');throw error;}
  });
 }
 async function confirm(){if(!preview)return;const exactPreview=preview.preview;setPhase('confirming');
  await operation(async valid=>{try{const response=await api.request('/billing/reviews/confirm','POST',{preview:exactPreview});if(!valid())return;
    if(!['restored','revoked'].includes(response.state))throw new Error('INVALID_RESPONSE');
    setResult(response);setPhase('complete');setNotice('The service confirmed this disposition. Review the refreshed ledger before any further action.');setItems(old=>old.filter(item=>item.purchase_ref!==selected?.purchase_ref));intent.current=null;
   }catch(error){if(valid()){const code=error&&typeof error==='object'&&'code' in error?String(error.code):'';setPhase(['PREVIEW_STALE','PREVIEW_EXPIRED','PREVIEW_INVALID'].includes(code)?'review':'confirm-unknown');}throw error;}
  });
 }
 function discard(){if(busy||phase==='confirm-unknown')return;intent.current=null;setPreview(null);setResult(null);setPhase('editing');setError('');setNotice('Preview discarded locally. No confirmation was sent for it. Create a fresh verified preview.');}
 return <section className="card below" aria-label="External financial holds"><h2>External refund and dispute holds</h2><p>Resolve held subscription time using verified provider facts. This workflow does not initiate a refund, transfer money, or change the no-voluntary-refund policy.</p>
  <p className="field-hint">Access is audited. Current billing permission and fresh MFA are required. Unknown, pending, or changed provider outcomes remain held.</p>
  {error&&<p className="notice error" role="alert">{error}</p>}{notice&&<p className="notice" role="status">{notice}</p>}
  <div className="row"><button className="secondary" disabled={busy||locked} onClick={()=>void load()}>Reload open holds</button>{cursor&&<button className="secondary" disabled={busy||locked} onClick={()=>void load(cursor)}>Next holds page</button>}</div>
  <ul className="list">{items.map(item=><li key={item.purchase_ref}><button className="secondary" disabled={busy||locked} aria-pressed={selected?.purchase_ref===item.purchase_ref} onClick={()=>choose(item)}>Review {item.purchase_ref}</button><p>{item.held_seconds} seconds held · revision {item.revision} · {item.created_at?new Date(item.created_at).toLocaleString():'Creation time unavailable'}</p></li>)}</ul>{!items.length&&!busy&&<p>No open holds were returned for this page.</p>}
  {selected&&<div className="below"><h3>Purchase {selected.purchase_ref}</h3><p>Currently listed hold: {selected.held_seconds} seconds. Provider and ledger facts are revalidated on the server.</p>
   <button className="secondary" disabled={busy||locked} onClick={()=>void refreshFacts()}>Refresh verified provider facts</button>
   {!preview&&phase!=='complete'&&<form onSubmit={event=>{event.preventDefault();void prepare();}}><fieldset disabled={busy||locked}><legend>Requested disposition</legend><label>Action<select value={action} onChange={event=>setAction(event.target.value as Intent['action'])}><option value="restore">Restore eligible held time</option><option value="revoke">Revoke verified lost-principal time</option></select></label>
    {action==='revoke'&&<label>Requested seconds to revoke (blank uses the verified minimum)<input type="number" min={0} step={1} value={requestedSeconds} onChange={event=>setRequestedSeconds(event.target.value)}/></label>}
    <label>Evidence-based reason<textarea required minLength={10} maxLength={500} value={reason} onChange={event=>setReason(event.target.value)}/></label></fieldset>
    <button disabled={busy||reason.trim().length<10}>{phase==='preview-unknown'?'Retry exact preview request':'Create verified disposition preview'}</button>{phase==='preview-unknown'&&<button type="button" className="secondary" disabled={busy} onClick={discard}>Discard unconfirmed preview and edit</button>}
   </form>}
   {preview&&phase!=='complete'&&<div className="notice"><h3>Review server-computed time disposition</h3><dl><dt>Held seconds</dt><dd>{preview.payload.held_seconds}</dd><dt>Verified minimum revocation</dt><dd>{preview.payload.minimum_revoke_seconds} seconds</dd><dt>Seconds to revoke</dt><dd>{preview.payload.seconds_to_revoke}</dd><dt>Seconds to restore</dt><dd>{preview.payload.seconds_to_restore}</dd></dl><p>Action: {preview.payload.action}. Preview lifetime: {preview.expires_in} seconds. Confirm checks fresh MFA, current grants, provider facts and exact ledger revisions again.</p>
    <details><summary>Verified provider state summary</summary><pre>{JSON.stringify(preview.payload.provider_state_summary,null,2)}</pre></details>
    <p>{preview.payload.reason}</p><button className="danger" disabled={busy} onClick={()=>void confirm()}>{phase==='confirm-unknown'?'Retry exact confirmation':'Confirm verified time disposition'}</button>{phase!=='confirm-unknown'&&<button className="secondary" disabled={busy} onClick={discard}>Discard preview</button>}
    {phase==='confirm-unknown'&&<p>Confirmation is uncertain. Keep this preview and retry it unchanged to recover the recorded result. Do not start another disposition.</p>}
   </div>}
   {result&&<div className="notice" role="status"><h3>Confirmed: {result.state}</h3><p>Revoked {result.seconds_to_revoke} seconds; restored {result.seconds_to_restore} seconds.</p><button className="secondary" disabled={busy} onClick={()=>{setSelected(null);setPreview(null);setResult(null);setPhase('editing');void load();}}>Return to open holds</button></div>}
  </div>}
 </section>;
}
