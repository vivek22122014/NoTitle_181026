'use client';
import {useState} from 'react';
import type {StaffScreen,ViewState} from '@notitle/shared/interface';
import {viewStates} from '@notitle/shared/interface';
import {RouteState} from '@notitle/shared/primitives';
import {boards} from './fixtures';
import {StaffScreenView} from './Screens';
export default function Workbench(){
  const [screen,setScreen]=useState<StaffScreen>('A01'),[stage,setStage]=useState('login'),[state,setState]=useState<ViewState>('ready');
  const board=boards.find(item=>item.id===screen)!;
  return <><div className="card review-controls"><h2>Private interface review</h2><p>Read-only private examples. This bundle must never be served by the public listener. A fixture does not grant permissions.</p><div className="review-selects"><label>Screen group<select value={screen} onChange={event=>{const next=boards.find(item=>item.id===event.target.value)!;setScreen(next.id);setStage(next.stages[0].id);}}>{boards.map(item=><option key={item.id} value={item.id}>{item.id} · {item.label}</option>)}</select></label><label>Workflow state<select value={stage} onChange={event=>setStage(event.target.value)}>{board.stages.map(item=><option key={item.id} value={item.id}>{item.label}</option>)}</select></label><label>Response state<select value={state} onChange={event=>setState(event.target.value as ViewState)}>{viewStates.map(value=><option key={value}>{value}</option>)}</select></label></div><p>{board.stages.find(item=>item.id===stage)?.description}</p></div><div data-screen={screen} className="screen-review">{state==='ready'?<StaffScreenView screen={screen} stage={stage}/>:<><h1>{board.label}</h1><RouteState state={state}/></>}</div></>;
}
