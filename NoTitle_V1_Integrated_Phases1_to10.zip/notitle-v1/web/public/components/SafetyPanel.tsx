'use client';
import {useEffect,useRef,useState,useSyncExternalStore} from 'react';
import Link from 'next/link';
import {identityClient as api,list,object,textValue} from '@notitle/shared/identity';
import type {PreparedView} from '@notitle/shared/identity.generated';
import {CodePanel} from './IdentityApplication';

type Peer={peer_handle:string;display_name:string};
type Snapshot={snapshot_ref:string;expires_in:number;attribution_only:boolean;locally_blocked:boolean;messages:Record<string,unknown>[]};
/** Keep this mounted after End so a prepared report survives teardown in memory. */
export default function SafetyPanel({peer,interactionHandle,onProtected,onPrepared}:{peer:Peer|null;interactionHandle:string|null;onProtected:()=>void;onPrepared:(confirmed:boolean)=>void|Promise<void>}){
 const identity=useSyncExternalStore(api.subscribe,api.snapshot,api.serverSnapshot);
 const [open,setOpen]=useState(false),[snapshot,setSnapshot]=useState<Snapshot|null>(null),[selected,setSelected]=useState<string[]>([]),[reason,setReason]=useState('harassment'),[body,setBody]=useState(''),[proof,setProof]=useState<PreparedView|null>(null),[saved,setSaved]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState(''),[caseRef,setCaseRef]=useState(''),[attributionAccepted,setAttributionAccepted]=useState(false),[expires,setExpires]=useState(0),[remaining,setRemaining]=useState(0);
 const target=useRef<{peer:Peer;interaction:string}|null>(null),payload=useRef<Record<string,unknown>|null>(null);
 useEffect(()=>{setSnapshot(null);setSelected([]);setBody('');setProof(null);setSaved(false);setCaseRef('');setOpen(false);payload.current=null;target.current=null;},[identity.generation]);
 useEffect(()=>{if(!expires)return;const update=()=>setRemaining(Math.max(0,Math.ceil((expires-Date.now())/1000)));update();const id=setInterval(update,1000);return()=>clearInterval(id);},[expires]);
 async function prepare(){
  if(!target.current){if(!peer||!interactionHandle)return;target.current={peer,interaction:interactionHandle};}
  onProtected();setOpen(true);setBusy(true);setError('');let confirmed=false;
  try{const value=await api.request('/reports/prepare','POST',{peer_handle:target.current.peer.peer_handle,interaction_handle:target.current.interaction,block:true});
   if(value.locally_blocked!==true)throw new Error('PROTECTION_UNCONFIRMED');
   setSnapshot({...value,messages:list(value.messages).map(object)} as unknown as Snapshot);setSelected([]);setRemaining(Number(value.expires_in));setExpires(Date.now()+Number(value.expires_in)*1000);setAttributionAccepted(false);payload.current=null;setOpen(true);
   confirmed=true;
  }catch{setError('Report preparation was not confirmed. Contact is ended locally. Retry can retain attribution, but messages may already be erased.');setOpen(true);}
  finally{await onPrepared(confirmed);setBusy(false);}
 }
 async function submit(){if(!snapshot)return;setBusy(true);setError('');
  try{
   if(identity.owner?.identity_kind!=='account'&&!proof){setProof(await api.prepare('case'));return;}
   if(!payload.current)payload.current={category:'safety',subject:'Safety report: '+reason,body,reason,snapshot_ref:snapshot.snapshot_ref,selected_ids:selected,block:true,attribution_only_accepted:attributionAccepted,client_nonce:crypto.randomUUID(),...(proof?{proof:{reservation_id:proof.reservation_id,secret:proof.secret,saved}}:{})};
   const result=await api.request('/reports','POST',payload.current);setCaseRef(textValue(result.case_ref));setBody('');setSelected([]);setSnapshot(null);payload.current=null;
   if(proof)await api.request('/support/access','POST',{receipt_ref:proof.reservation_id,secret:proof.secret});
  }catch{setError('Not submitted or confirmation unavailable. Local protection remains. Retry the same submission while evidence is available. Never assume evidence was saved without a case reference.');}
  finally{setBusy(false);}
 }
 return <section className="below" aria-label="Report and block">
  {!open&&<button className="secondary" disabled={busy||!peer||!interactionHandle} onClick={()=>void prepare()}>Report and block</button>}
  {open&&<div className="notice"><h3>Report and block</h3><p>Contact is stopped locally. Preparation requests a block for this identity. A report is saved only after a case reference is confirmed. Selected evidence is retained separately from temporary chat.</p>
   {error&&<p role="alert" className="error">{error}</p>}
   {caseRef?<><p role="status">Report saved. Case reference: <code>{caseRef}</code></p><Link href="/support/">Chat with Moderator</Link><button className="secondary" onClick={()=>{setOpen(false);setCaseRef('');target.current=null;}}>Close report</button></>:!snapshot?<button disabled={busy} onClick={()=>void prepare()}>Retry preparation with available attribution</button>:<>
    <p>{snapshot.attribution_only?'Only server attribution remains. No chat text is attached.':'Select only the messages needed to explain the report.'} Snapshot expires in {remaining} seconds.</p>
    {remaining===0?<><p role="alert">Evidence snapshot expired. It has not been submitted.</p><button disabled={busy} onClick={()=>void prepare()}>Prepare attribution-only report</button></>:<form onSubmit={event=>{event.preventDefault();void submit();}}>
     <fieldset disabled={busy||!!payload.current}><legend>Selected server evidence</legend>{snapshot.messages.map(item=><label key={textValue(item.id)}><input type="checkbox" checked={selected.includes(textValue(item.id))} onChange={event=>setSelected(old=>event.target.checked?[...old,textValue(item.id)]:old.filter(id=>id!==item.id))}/><strong>{item.sender==='me'?'You':'Peer'}</strong>: {textValue(item.text)}</label>)}
      <label>Reason<select value={reason} onChange={event=>setReason(event.target.value)}>{['harassment','threats','doxxing','confidentiality','false_accusations','scams','impersonation','underage','sexual_misconduct','spam','other'].map(value=><option key={value}>{value}</option>)}</select></label>
      <label>What happened?<textarea required minLength={reason==='other'?10:1} maxLength={4000} value={body} onChange={event=>setBody(event.target.value)}/></label>
      {snapshot.attribution_only&&<label><input type="checkbox" checked={attributionAccepted} required onChange={event=>setAttributionAccepted(event.target.checked)}/> I understand that no messages are retained with this attribution-only report.</label>}
     </fieldset>
     {proof&&<CodePanel proof={proof} saved={saved} setSaved={setSaved} kind="case access receipt"/>}
     <button disabled={busy||!!proof&&!saved||snapshot.attribution_only&&!attributionAccepted}>{busy?'Saving…':proof||identity.owner?.identity_kind==='account'?'Submit selected report':'Prepare private case receipt'}</button>
    </form>}
    <p className="field-hint">For immediate danger contact local emergency services. This service does not promise continuous staffing or emergency response. Never include passwords, recovery codes or payment secrets.</p>
   </>}
  </div>}
 </section>;
}
