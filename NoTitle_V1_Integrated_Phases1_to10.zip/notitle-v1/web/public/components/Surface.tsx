import site from '@notitle/shared/site';
import type {PublicScreen} from '@notitle/shared/interface';
import {RouteState} from '@notitle/shared/primitives';
import routes from '../route-data.json';
import {PublicShell} from './Shell';
import {Home,HowItWorks,SafetyGuide,DeletionGuide} from './Information';
import {ContactPage,GrievancePage,PolicyIndex,PolicyPage,ProcessorsPage} from './PolicyPages';
import {PublicScreenView} from './Screens';
import Workbench from './Workbench';

export default async function Surface({path}:{path:string}){
  const route=routes.find(item=>item.path===path);if(!route)throw new Error('Unknown public route');
  if(site.mode==='candidate'&&path==='/friends/'){
    const {default:Friends}=await import('./Friends');return <PublicShell current={path}><Friends/></PublicShell>;
  }
  const billingPaths:Record<string,string>={'/premium/':'/premium/','/checkout/':'/checkout/','/billing/':'/billing/','/billing/status/':'/billing/status/','/payment/status/':'/billing/status/','/account/receipts/':'/account/receipts/','/account/premium/':'/account/entitlement/','/account/entitlement/':'/account/entitlement/'};
  if(site.mode==='candidate'&&billingPaths[path]){
    const {default:Billing}=await import('./Billing');return <PublicShell current={path}><Billing path={billingPaths[path]}/></PublicShell>;
  }
  if((site.mode==='realtime'||site.mode==='candidate')&&['/chat/','/talk/'].includes(path)){
    const {default:Conversation}=await import('./Conversation');return <PublicShell current="/chat/"><Conversation/></PublicShell>;
  }
  if((site.mode==='identity'||site.mode==='realtime'||site.mode==='candidate')&&['/join/','/register/','/login/','/recovery/','/profile/','/preferences/','/settings/','/account/privacy/',...(['identity','realtime','candidate'].includes(site.mode)?['/support/','/support/status/']:[])].includes(path)){
    const body=path.startsWith('/support/')&&['identity','realtime','candidate'].includes(site.mode)?<>{await import('./IdentitySupport').then(({default:Support})=><Support/>)}</>:<>{await import('./IdentityApplication').then(({default:Identity})=><Identity path={path}/>)}</>;
    return <PublicShell current={path}>{body}</PublicShell>;
  }
  if(site.mode==='candidate'&&'legacy' in route&&route.legacy){
    const {default:Application}=await import('../app/Application');
    return <Application page={route.legacy} initialIdentityMode={'identity_mode' in route?route.identity_mode:undefined}/>;
  }
  let body;
  switch(route.kind){
    case'home':body=<Home/>;break;case'how':body=<HowItWorks/>;break;case'safety':body=<SafetyGuide/>;break;
    case'deletion':body=<DeletionGuide/>;break;case'legal':body=<PolicyIndex/>;break;case'contact':body=<ContactPage/>;break;
    case'grievance':body=<GrievancePage/>;break;case'processors':body=<ProcessorsPage/>;break;
    case'policy':body=<PolicyPage id={route.policy as Parameters<typeof PolicyPage>[0]['id']}/>;break;
    case'review':body=<Workbench/>;break;case'maintenance':body=<><h1>Service temporarily unavailable.</h1><RouteState state="maintenance"/></>;break;
    default:body=<PublicScreenView screen={route.screen as PublicScreen} stage={route.stage}/>;
  }
  return <PublicShell current={path}>{body}</PublicShell>;
}
