'use client';
import {useEffect,useRef,useState,useSyncExternalStore} from 'react';
import {identityClient as api,list,object,textValue} from '@notitle/shared/identity';
import type {PreparedView} from '@notitle/shared/identity.generated';
import {CodePanel} from './IdentityApplication';
import {Field,StatusNotice} from '@notitle/shared/primitives';
import {PageHeading} from './Shell';
export default function IdentitySupport(){
  const state=useSyncExternalStore(api.subscribe,api.snapshot,api.serverSnapshot);
  const [category,setCategory]=useState('general'),[subject,setSubject]=useState(''),[body,setBody]=useState(''),[proof,setProof]=useState<PreparedView|null>(null),[saved,setSaved]=useState(false),[cases,setCases]=useState<Record<string,unknown>[]>([]),[active,setActive]=useState(''),[caseData,setCaseData]=useState<Record<string,unknown>>({}),[messages,setMessages]=useState<Record<string,unknown>[]>([]),[access,setAccess]=useState({receipt_ref:'',secret:''});
  const viewSequence=useRef(0),requestedView=useRef('');
  const nonce=useRef(''),[authority,setAuthority]=useState<'account'|'case'>('account'),[parentRef,setParentRef]=useState('');
  useEffect(()=>{if(api.state.phase==='idle')void api.start();},[]);
  useEffect(()=>{if(active&&messages.length&&document.visibilityState==='visible')void api.request('/support/cases/'+active+'/seen','POST',{seen_through:Number(messages[messages.length-1].sequence)},undefined,authority).catch(()=>{});},[active,messages.length,authority]);
  useEffect(()=>{viewSequence.current++;requestedView.current='';setMessages([]);setActive('');setCases([]);setProof(null);setSaved(false);setBody('');setAccess({receipt_ref:'',secret:''});setParentRef('');setCaseData({});nonce.current='';},[state.generation]);
  async function loadCases(){setCases(list((await api.request('/support/cases')).items).map(object));}
  async function open(ref:string,scope:'account'|'case',background=false){
    // A poll may refresh only the requested view; it must not replace an explicit selection.
    if(background&&requestedView.current!==ref)return;
    const sequence=++viewSequence.current,generation=api.state.generation;requestedView.current=ref;
    const current=()=>sequence===viewSequence.current&&generation===api.state.generation&&requestedView.current===ref;
    const meta=await api.request('/support/cases/'+ref,'GET',undefined,undefined,scope);
    if(!current())return;
    const history=await api.request('/support/cases/'+ref+'/messages?after_sequence='+String(Math.max(0,Number(meta.last_sequence)-50)),'GET',undefined,undefined,scope);
    if(!current())return;
    // Metadata and plaintext history become visible together, only for this view.
    setCaseData(meta);setMessages(old=>ref===active?[...new Map([...old,...list(history.items).map(object)].map(item=>[Number(item.sequence),item])).values()].sort((a,b)=>Number(a.sequence)-Number(b.sequence)).slice(-1000):list(history.items).map(object));setActive(ref);setAuthority(scope);if(ref!==active)nonce.current='';
  }
  async function loadOlder(){
    const sequence=viewSequence.current,generation=api.state.generation,ref=active;
    const older=await api.request('/support/cases/'+ref+'/messages?before_sequence='+String(messages[0].sequence),'GET',undefined,undefined,authority);
    if(sequence!==viewSequence.current||generation!==api.state.generation||requestedView.current!==ref)return;
    setMessages(old=>[...list(older.items).map(object),...old].slice(-1000));
  }
  useEffect(()=>()=>{viewSequence.current++;requestedView.current='';},[]);
  useEffect(()=>{if(!active)return;const timer=setInterval(()=>{if(document.visibilityState==='visible'&&!nonce.current)void open(active,authority,true).catch(()=>{});},15000);return ()=>clearInterval(timer);},[active,authority]);
  useEffect(()=>{const ref=state.boot?.scoped_subjects.case;if(ref&&!active)void open(ref,'case').catch(()=>{});},[state.boot?.scoped_subjects.case]);
  if(!state.boot)return <><h1>Chat with Moderator</h1><p>Saved support remains available independently of conversation consent. Load the local service to use protected intake.</p>{state.error&&<StatusNotice>{state.error}</StatusNotice>}<button className="secondary" onClick={()=>void api.start()}>Load protected intake</button></>;
  return <div key={state.generation}><PageHeading eyebrow="Saved support and privacy intake" title="Chat with Moderator.">Support is saved and reviewed by authorized staff. It is separate from temporary peer chat and has no support email.</PageHeading>
    {state.error&&<div className="notice error" role="alert">{state.error}</div>}{state.notice&&<StatusNotice>{state.notice}</StatusNotice>}<StatusNotice>Do not send passwords, recovery or receipt secrets, card details or banking credentials. No emergency response or continuous live staffing is promised. Replies are asynchronous. Status and delivered history are shown only after the service confirms saved data.</StatusNotice>
    <div className="two"><section className="card"><h2>{active?'Saved conversation':parentRef?'Case continuation':'New saved case'}</h2>{active?<><p role="status">Status: {textValue(caseData.status)} · {textValue(caseData.subject)}</p><div className="thread-example">{messages.map(item=><p className="message" key={String(item.sequence)}><strong>{textValue(item.display_role)}</strong><br/>{textValue(item.body)}<small>Saved · sequence {String(item.sequence)}{item.sender_kind==='user'&&Number(caseData.seen_staff_sequence)>=Number(item.sequence)?' · Seen by moderator':''}</small></p>)}</div><button className="secondary" disabled={state.busy} onClick={()=>void api.perform(()=>open(active,authority))}>Refresh history</button>{Number(messages[0]?.sequence)>1&&<button className="secondary" disabled={state.busy} onClick={()=>void api.perform(loadOlder)}>Load older messages</button>}<button className="secondary" disabled={state.busy} onClick={()=>{viewSequence.current++;requestedView.current='';setActive('');setParentRef('');setMessages([]);setBody('');nonce.current='';}}>New case</button><button className="secondary" disabled={state.busy} onClick={()=>{viewSequence.current++;requestedView.current='';setParentRef(active);setActive('');setSubject((textValue(caseData.subject)||'Support')+' continuation');setCategory(textValue(caseData.category)||'general');setMessages([]);setBody('');nonce.current='';}}>Continue in a linked case</button>{caseData.status==='closed'&&<button className="secondary" disabled={state.busy} onClick={()=>void api.perform(async()=>{await api.request('/support/cases/'+active+'/reopen','POST',{expected_version:Number(caseData.version),client_nonce:crypto.randomUUID(),reason:'User requested case reopening'},undefined,authority);await open(active,authority);})}>Reopen within 30 days</button>}</>:null}
      <form method="post" onSubmit={event=>{event.preventDefault();void api.perform(async()=>{
        if(!nonce.current)nonce.current=crypto.randomUUID();
        if(active){await api.request('/support/cases/'+active+'/messages','POST',{body,client_nonce:nonce.current},undefined,authority);setBody('');nonce.current='';await open(active,authority);return;}
        if(state.owner?.identity_kind!=='account'&&!proof){setProof(parentRef?await api.request('/support/cases/'+parentRef+'/continuations/prepare','POST',{kind:'case',client_nonce:crypto.randomUUID()},'PreparedView',authority) as unknown as PreparedView:await api.prepare('case'));return;}
        const result=await api.request(parentRef?'/support/cases/'+parentRef+'/continuations':'/support/cases','POST',{category,subject:subject.slice(0,120),body,client_nonce:nonce.current,...(proof?{proof:{reservation_id:proof.reservation_id,secret:proof.secret,saved}}:{})},undefined,parentRef?authority:undefined);
        const ref=textValue(result.case_ref);
        if(proof)await api.request('/support/access','POST',{receipt_ref:proof.reservation_id,secret:proof.secret});
        setBody('');nonce.current='';await open(ref,proof?'case':'account');setParentRef('');setProof(null);setSaved(false);api.update({notice:'Case saved. Keep its receipt where required. No legal outcome is implied.'});
      });}}>
        {!active&&<><label>Category<select value={category} disabled={!!proof||!!nonce.current} onChange={event=>setCategory(event.target.value)}>{['general','privacy','safety','security','appeal','payment'].map(value=><option key={value}>{value}</option>)}</select></label><Field label="Subject" value={subject} required disabled={!!proof||!!nonce.current} maxLength={120} onChange={event=>setSubject(event.target.value)}/></>}
        <label>{active?'Your reply':'Message'}<textarea required maxLength={4000} value={body} disabled={!!proof&&!active||!!nonce.current} onChange={event=>setBody(event.target.value)}/></label>{proof&&!active&&<CodePanel proof={proof} saved={saved} setSaved={setSaved} kind="case access receipt"/>}<button disabled={state.busy||!!proof&&!saved||!!active&&caseData.status==='closed'}>{active?'Send reply':state.owner?.identity_kind!=='account'&&!proof?'Prepare private case receipt':'Save case'}</button>
      </form></section>
      <aside className="stack"><section className="card"><h2>Your account cases</h2><button className="secondary" disabled={state.busy||state.owner?.identity_kind!=='account'} onClick={()=>void api.perform(loadCases)}>Load account cases</button><ul className="list">{cases.map(item=><li key={textValue(item.public_ref)}><p>{textValue(item.category)} · {textValue(item.status)}</p><button className="secondary" disabled={state.busy} onClick={()=>void api.perform(()=>open(textValue(item.public_ref),'account'))}>Open case {textValue(item.public_ref).slice(0,8)}</button></li>)}</ul></section>
      <section className="card"><h2>Open with a saved case receipt</h2><form method="post" onSubmit={event=>{event.preventDefault();void api.perform(async()=>{const result=await api.request('/support/access','POST',access);setAccess({receipt_ref:'',secret:''});await open(textValue(result.case_ref),'case');});}}><Field label="Case receipt reference" value={access.receipt_ref} minLength={32} maxLength={32} required onChange={event=>setAccess({...access,receipt_ref:event.target.value})}/><Field label="Case receipt secret" type="password" autoComplete="off" value={access.secret} minLength={43} maxLength={43} required onChange={event=>setAccess({...access,secret:event.target.value})}/><button disabled={state.busy}>Open saved case</button></form><p className="field-hint">A case receipt opens only that case. It cannot reset an account or open finance/deletion status.</p></section></aside></div>
  </div>;
}
