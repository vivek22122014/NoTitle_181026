import type {ReactNode} from 'react';
import Link from 'next/link';
import site from '@notitle/shared/site';
const appLinks=[['/chat/','Chat'],['/friends/','Friends'],['/support/','Support'],['/settings/','Account']] as const;
export function PublicShell({children,current=''}:{children:ReactNode;current?:string}){
  return <><Link className="skip" href="#main">Skip to content</Link>
    <header className="top"><div className="wrap"><Link className="brand" href="/" aria-label="NoTitle home">NO<span>Title</span></Link>
      <nav aria-label="Information"><Link href="/how-it-works/">How it works</Link><Link href="/safety/">Safety</Link><Link href="/premium/">Premium</Link></nav>
      <Link className="button secondary" href="/login/">Log in</Link></div></header>
    {site.mode==='interface'&&<div className="preview-banner"><div className="wrap"><strong>Read-only interface preview.</strong> Examples are illustrative. Conversations, sign-in and purchases are disabled. <Link href="/interface/">Review screen states</Link></div></div>}
    {site.mode==='identity'&&<div className="preview-banner"><div className="wrap"><strong>Identity and privacy qualification.</strong> Accounts, purpose choices and saved privacy requests use the local service. Matching, audio and sales remain disabled.</div></div>}
    {site.mode==='realtime'&&<div className="preview-banner"><div className="wrap"><strong>Local conversation qualification.</strong> Text matching is connected. Audio, friend invitations, sales and report submission await later phases. No production launch is implied.</div></div>}
    <div className="wrap app-shell"><nav className="desktop-app-nav" aria-label="Application">{appLinks.map(([url,label])=><Link key={url} href={url} aria-current={current===url?'page':undefined}>{label}</Link>)}</nav>
      <main id="main" className="content" tabIndex={-1}>{children}</main></div>
    <footer className="footer"><div className="wrap"><span>People before titles. Adults 18+.</span><nav aria-label="Policies and help"><Link href="/legal/">Privacy & policies</Link><Link href="/contact/">Contact</Link><Link href="/support/">Chat with Moderator</Link></nav></div></footer>
    <nav className="mobile-app-nav" aria-label="Mobile application">{appLinks.map(([url,label])=><Link key={url} href={url} aria-current={current===url?'page':undefined}>{label}</Link>)}</nav>
  </>;
}
export function PageHeading({eyebrow,title,children}:{eyebrow:string;title:string;children?:ReactNode}){
  return <div className="page-heading"><p className="eyebrow">{eyebrow}</p><h1>{title}</h1>{children&&<p className="lead">{children}</p>}</div>;
}
