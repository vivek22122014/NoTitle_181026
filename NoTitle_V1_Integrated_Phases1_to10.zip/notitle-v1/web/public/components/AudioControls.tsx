'use client';
import {useEffect,useRef,useState,useSyncExternalStore} from 'react';
import type {ConversationClient} from '@notitle/shared/conversation';
import {AudioSession} from '@notitle/shared/audio';

type Call={id:string;handle:string;revision:number;state:'incoming'|'ringing'|'connecting'|'connected';expires:number};
export default function AudioControls({client,enabled}:{client:ConversationClient;enabled:boolean}){
 const state=useSyncExternalStore(client.subscribe,client.snapshot,client.serverSnapshot);
 const remote=useRef<HTMLAudioElement>(null),session=useRef<AudioSession|null>(null),current=useRef<Call|null>(null);
 const [call,setCall]=useState<Call|null>(null),[error,setError]=useState(''),[muted,setMuted]=useState(false);
 const update=(value:Call|null)=>{current.current=value;setCall(value);};
 const handle=state.interaction?.interaction_handle;
 function send(type:string,payload:Record<string,unknown>){const scope=current.current?.handle??client.state.interaction?.interaction_handle;if(!scope||client.state.phase!=='matched'||scope!==client.state.interaction?.interaction_handle)return;void client.sendFeature(type,{interaction_handle:scope,...payload}).catch(()=>{session.current?.stop();update(null);setError('Audio signaling interrupted. Text remains available.');});}
 useEffect(()=>{
  if(!remote.current)return;
  session.current=new AudioSession(send,remote.current,setError);
  // Subscribe directly to the coordinator: End must fence pending permission
  // promises synchronously, without waiting for a React effect to commit.
  const unsubscribeState=client.subscribe(()=>{const active=current.current;if(active&&(client.state.phase!=='matched'||client.state.interaction?.interaction_handle!==active.handle)){session.current?.stop();update(null);setMuted(false);}});
  const unsubscribe=client.subscribeEvents(event=>{
   if(!event.type.startsWith('call.'))return;
   const data=event.data as unknown as {interaction_handle:string;call_id:string;negotiation_revision?:number;expires_in?:number;offerer?:boolean;ice_servers?:RTCIceServer[];description_type?:RTCSdpType;sdp?:string;candidate?:string;reason?:string};
   if(data.interaction_handle!==client.state.interaction?.interaction_handle)return;
   const active=current.current;
   if(event.type==='call.request'||event.type==='call.ringing'){
    session.current?.stop();setError('');setMuted(false);update({id:data.call_id,handle:data.interaction_handle,revision:1,state:event.type==='call.request'?'incoming':'ringing',expires:Date.now()+(data.expires_in??30)*1000});
   }else if(event.type==='call.connect'){
    if(active&&active.id!==data.call_id)return;
    update({id:data.call_id,handle:data.interaction_handle,revision:data.negotiation_revision!,state:'connecting',expires:Date.now()+20000});
    void session.current?.start(data.call_id,data.ice_servers!,!!data.offerer,data.negotiation_revision!);
   }else if(!active||active.id!==data.call_id)return;
   else if(event.type==='call.refresh'){update({...active,revision:data.negotiation_revision!,state:'connecting',expires:Date.now()+20000});void session.current?.refresh(data.call_id,data.ice_servers!,!!data.offerer,data.negotiation_revision!);}
   else if(event.type==='call.sdp')void session.current?.description(data.description_type!,data.sdp!,data.call_id,data.negotiation_revision!);
   else if(event.type==='call.ice')void session.current?.candidate(data.candidate!,data.call_id,data.negotiation_revision!);
   else if(event.type==='call.connected')update({...active,state:'connected',revision:data.negotiation_revision!,expires:0});
   else if(event.type==='call.ended'){session.current?.stop();update(null);setMuted(false);setError(data.reason==='declined'?'Audio request declined.':'Audio ended.');}
  });
  const expire=setInterval(()=>{const active=current.current;if(active?.expires&&active.expires<Date.now()){session.current?.stop();send('call.end',{call_id:active.id});update(null);setError('Audio request or connection timed out.');}},1000);
  return()=>{const active=current.current;if(active)send('call.end',{call_id:active.id});clearInterval(expire);unsubscribe();unsubscribeState();session.current?.stop();session.current=null;};
 },[client]);
 useEffect(()=>{
  if(!enabled||state.phase!=='matched'||!handle||current.current&&current.current.handle!==handle){session.current?.stop();update(null);setMuted(false);}
 },[enabled,state.phase,handle]);
 const available=enabled&&state.phase==='matched'&&!!handle;
 function request(){setError('');if(handle)void client.sendFeature('call.request',{interaction_handle:handle}).catch(()=>setError('Audio is unavailable. Text remains available.'));}
 function respond(accept:boolean){const active=current.current;if(!active)return;if(!accept){session.current?.stop();update(null);}send('call.respond',{call_id:active.id,accept});}
 function end(){const active=current.current;if(!active)return;session.current?.stop();send(active.state==='ringing'?'call.cancel':'call.end',{call_id:active.id});update(null);setMuted(false);}
 return <section aria-label="Free audio" className="audio-controls"><h3>Free audio</h3>
  {!enabled?<p className="field-hint">Audio stays unavailable until the enforced relay has passed production qualification. Text chat remains available.</p>:<p className="field-hint">Both participants must agree. Microphone access starts only after acceptance. Audio is not recorded by this service.</p>}
  {error&&<p role="status">{error}</p>}
  {!call?<button disabled={!available} onClick={request}>Request audio call</button>:<>
   <p role="status">{call.state==='incoming'?'Your peer requests an audio call.':call.state==='ringing'?'Waiting for your peer to accept.':call.state==='connecting'?'Connecting audio…':'Audio connected'}</p>
   {call.state==='incoming'?<div className="row"><button disabled={!available} onClick={()=>respond(true)}>Accept audio</button><button className="secondary" onClick={()=>respond(false)}>Decline</button></div>:null}
   {call.state==='connected'?<button className="secondary" onClick={()=>{session.current?.mute(!muted);setMuted(!muted);}}>{muted?'Unmute microphone':'Mute microphone'}</button>:null}
   <button className="secondary" onClick={end}>{call.state==='ringing'?'Cancel audio request':'End audio'}</button>
  </>}
  <audio ref={remote} autoPlay controls aria-label="Peer audio" style={{width:'100%',display:call?.state==='connected'?'block':'none'}}/>
 </section>;
}
