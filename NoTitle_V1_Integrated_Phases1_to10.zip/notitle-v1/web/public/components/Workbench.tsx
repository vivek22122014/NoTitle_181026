'use client';
import {useEffect,useState} from 'react';
import {Dialog} from '@notitle/shared/Dialog';
import {DisabledAction,RouteState} from '@notitle/shared/primitives';
import {viewStates,type ViewState,type PublicScreen} from '@notitle/shared/interface';
import {boards} from './fixtures';
import {PublicScreenView} from './Screens';

export default function Workbench(){
  const [screen,setScreen]=useState<PublicScreen>('U01'),[state,setState]=useState<ViewState>('ready'),[stage,setStage]=useState('entry'),[open,setOpen]=useState(false);
  const board=boards.find(item=>item.id===screen)!;
  useEffect(()=>{if(state==='validation')document.querySelector<HTMLInputElement>('[aria-invalid="true"]')?.focus();},[state]);
  return <><div className="review-controls card"><h2>Public interface review</h2><p>Read-only, typed examples for all nine public screen groups. These controls change examples in memory and make no API requests. Review at desktop, 320px mobile and 200% zoom.</p>
    <div className="review-selects"><label>Screen group<select value={screen} onChange={event=>{const next=boards.find(item=>item.id===event.target.value)!;setScreen(next.id);setStage(next.stages[0].id);}}>{boards.map(item=><option key={item.id} value={item.id}>{item.id} · {item.label}</option>)}</select></label>
      <label>Workflow state<select value={stage} onChange={event=>setStage(event.target.value)}>{board.stages.map(item=><option key={item.id} value={item.id}>{item.label}</option>)}</select></label>
      <label>Response state<select value={state} onChange={event=>setState(event.target.value as ViewState)}>{viewStates.map(item=><option key={item} value={item}>{item}</option>)}</select></label></div>
    <p>{board.stages.find(item=>item.id===stage)?.description}</p><div className="row"><a href={board.route}>Open the route</a><button type="button" className="secondary" onClick={()=>setOpen(true)}>Inspect confirmation sheet</button></div>
  </div><div className="screen-review" data-screen={screen} data-stage={stage}>{state==='ready'?<PublicScreenView screen={screen} stage={stage}/>:<><h1>{board.label}</h1><RouteState state={state}/></>}</div>
    <Dialog open={open} title="Review a sensitive action" sheet onClose={()=>setOpen(false)}><p>This confirmation example traps keyboard focus, closes with Escape and restores focus to its trigger. It cannot authorize an action.</p><DisabledAction reason="A current authorized server preview is required.">Confirm action</DisabledAction></Dialog></>;
}
