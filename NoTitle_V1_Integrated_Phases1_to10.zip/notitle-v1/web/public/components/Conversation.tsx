'use client';
import {useEffect,useRef,useState,useSyncExternalStore} from 'react';
import Link from 'next/link';
import {identityClient as api} from '@notitle/shared/identity';
import {message} from '@notitle/shared/conversation';
import {PageHeading} from './Shell';
import {FriendActions} from './Friends';
import SafetyPanel from './SafetyPanel';
import AudioControls from './AudioControls';
import site from '@notitle/shared/site';

const chat=api.conversation;
export default function Conversation(){
  const identity=useSyncExternalStore(api.subscribe,api.snapshot,api.serverSnapshot);
  const state=useSyncExternalStore(chat.subscribe,chat.snapshot,chat.serverSnapshot);
  const [seconds,setSeconds]=useState(0),[confirmBlock,setConfirmBlock]=useState(false),[localError,setLocalError]=useState('');
  const composing=useRef(false),bottom=useRef<HTMLDivElement>(null);
  useEffect(()=>{if(api.state.phase==='idle')void api.start();},[]);
  // A rendered receipt is sent after React commits the plain-text bubbles.
  useEffect(()=>{chat.renderedMessages();bottom.current?.scrollIntoView({block:'nearest'});},[state.messages,state.phase]);
  useEffect(()=>{if(!state.graceUntil)return;const refresh=()=>setSeconds(Math.max(0,Math.ceil((state.graceUntil!-Date.now())/1000)));refresh();const id=setInterval(refresh,1000);return ()=>clearInterval(id);},[state.graceUntil]);
  const owner=identity.owner,interaction=state.interaction;
  const searching=state.phase==='searching'||state.phase==='connecting'||state.pending&&!interaction;
  const active=!!interaction,canSend=state.phase==='matched'&&!!interaction&&!interaction.interrupted;
  const unavailable=!owner||!owner.core_consent||!owner.policy_current||!identity.boot?.gates.admission;
  const paid=owner?.identity_kind==='account'&&owner.entitlement.premium_until>Date.now()/1000;
  function send(){setLocalError('');try{chat.text();}catch(error){setLocalError(message(error instanceof Error?error.message:'SERVICE_UNAVAILABLE'));}}
  return <><PageHeading eyebrow="One shared queue · adults 18+" title="A conversation, without the titles.">Text is temporary. Ending clears the ordinary conversation from this service. A peer can still copy or record what you share.</PageHeading>
    {identity.phase==='loading'||identity.phase==='idle'?<p role="status">Loading your identity. Search starts only when you choose it.</p>:!owner?<section className="card"><h2>Choose how to join</h2><p>No conversation starts on this page automatically.</p><div className="row"><Link className="button" href="/join/">Continue as guest</Link><Link href="/login/">Log in</Link></div></section>:<>
    <div className="conversation-layout">
      <aside className="card conversation-details"><h2>{owner.profile.display_name}</h2><p>{owner.identity_kind==='guest'?'Guest':'Member'} · {owner.profile.topic_id.replaceAll('_',' ')}</p><p>{state.genderPreference==='everyone'?'Everyone':state.genderPreference} · {state.generalTalk||owner.profile.topic_id==='general'?'General Talk':'Selected topic'}</p><label><input type="checkbox" checked={state.generalTalk||owner.profile.topic_id==='general'} disabled={active||searching||owner.profile.topic_id==='general'} onChange={event=>chat.update({generalTalk:event.target.checked})}/> General Talk</label><p className="field-hint">One shared pool. Specific gender choices require a current pass; payment gives no queue priority. Professional relevance is disabled in General Talk. Change talk mode before searching.</p><Link href="/profile/">Edit profile for the next conversation</Link><p><Link href="/preferences/">Private matching choices</Link></p>
      {!owner.core_consent||!owner.policy_current?<p><Link href="/account/privacy/">Review participation and policy choices</Link></p>:null}
      <label>Declared gender preference<select value={state.genderPreference} disabled={active||searching} onChange={event=>chat.update({genderPreference:event.target.value as 'everyone'|'male'|'female'|'other'})}><option value="everyone">Everyone · free</option>{['male','female','other'].map(gender=><option key={gender} value={gender} disabled={!paid}>{gender} · active Premium required</option>)}</select></label><p className="field-hint">Expiry pauses a strict search. Choose Everyone explicitly to continue free. All people share the same pool.</p><hr/><h3>Stay in control</h3><p>Do not share payment details, workplace secrets or identifying information.</p><p><Link href="/support/">Chat with Moderator</Link></p><p className="field-hint">Support messages are retained separately. Moderators cannot retrieve an ordinary chat transcript after it ends. Use Report and block to submit selected server evidence separately.</p><p><Link href="/account/privacy/">Privacy controls</Link></p>
      {site.mode==='candidate'?<AudioControls client={chat} enabled={!!identity.boot?.gates.audio}/>:<button disabled title="Audio requires the full qualified relay profile">Audio unavailable</button>}
      </aside>
      <section className="card conversation-panel" aria-label="Temporary text conversation">
        <header className="conversation-heading"><div><h2>{interaction?interaction.peer.display_name:'Conversation lobby'}</h2>{interaction?<p>{interaction.peer.gender} · {interaction.peer.topic_id}<br/>{interaction.peer.bio}</p>:<p>No microphone starts here.</p>}</div><span className="pill" role="status">{state.phase}</span></header>
        {(state.error||localError||identity.error)&&<p className="notice error" role="alert">{localError||state.error||identity.error}</p>}
        {state.notice&&<p className="notice" role="status">{state.notice}</p>}
        {state.phase==='interrupted'&&<div className="notice" role="status">Connection interrupted · up to {seconds} seconds remain. Sending is paused. <button className="secondary" onClick={()=>void chat.reconnect()}>Reconnect conversation</button></div>}
        {state.phase==='replaced'&&<div className="notice"><p>Another tab owns chat. Taking over ends that tab’s connection.</p><button onClick={()=>void chat.reconnect(true)}>Take over chat explicitly</button></div>}
        {state.phase==='unavailable'&&!active&&<button className="secondary" onClick={()=>void chat.reconnect()}>Reconnect to lobby</button>}
        <div className="temporary-transcript" aria-label="Messages" aria-live="polite" aria-relevant="additions text" data-testid="transcript">
          {!state.messages.length&&<p className="muted">{searching?'Looking for a compatible person. You can cancel at any time.':active?'Connected. Say hello when you are ready.':'Choose Search when you are ready. Nothing is sent automatically.'}</p>}
          {state.messages.map(item=><div key={item.id} className={'temporary-message '+(item.sender==='me'?'own':'peer')} data-testid="chat-message"><span className="field-hint">{item.sender==='me'?'You':interaction?.peer.display_name||'Peer'}</span><p>{item.text}</p>{item.sender==='me'&&<span className="field-hint">{item.status==='accepted'?'Accepted in temporary memory':item.status==='delivered'?'Delivered to the other browser':item.status==='unconfirmed'?'Delivery unconfirmed':'Sending…'}</span>}</div>)}<div ref={bottom}/>
        </div>
        <form onSubmit={event=>{event.preventDefault();send();}}><label htmlFor="temporary-message">Message<textarea id="temporary-message" value={state.draft} rows={3} disabled={!canSend} autoComplete="off" spellCheck={false} onChange={event=>chat.draft(event.target.value)} onCompositionStart={()=>{composing.current=true;}} onCompositionEnd={()=>{composing.current=false;}} onKeyDown={event=>{if(event.key==='Enter'&&!event.shiftKey&&!event.nativeEvent.isComposing&&!composing.current){event.preventDefault();send();}}}/></label><div className="conversation-actions"><small>{Array.from(state.draft).length}/2,000 · {new TextEncoder().encode(state.draft).length}/6,144 bytes · Enter sends, Shift+Enter adds a line</small><button type="submit" disabled={!canSend||!state.draft}>Send</button></div></form>
        <div className="conversation-actions below" aria-label="Conversation controls">
          {!active&&!searching&&<button disabled={unavailable||state.phase==='maintenance'||state.phase==='replaced'} onClick={()=>void chat.search()}>Search</button>}
          {!active&&searching&&<button className="secondary" onClick={()=>void chat.cancel()}>Cancel search</button>}
          {active&&<><button className="danger" onClick={()=>void chat.end()}>End conversation</button><button className="secondary" disabled={!canSend} onClick={()=>chat.next()}>Next conversation</button><button className="secondary" onClick={()=>setConfirmBlock(true)}>Block person</button></>}
          <Link href="/support/">Chat with Moderator</Link>
        </div>
        {site.mode==='candidate'&&<><FriendActions/><SafetyPanel peer={interaction?.peer||null} interactionHandle={interaction?.interaction_handle||null} onProtected={()=>chat.protect()} onPrepared={confirmed=>chat.finishProtection(confirmed)}/></>}
        {confirmBlock&&active&&<div className="notice" role="group" aria-label="Confirm block"><p>End this conversation and block this person? Guest blocks last only for this temporary identity. A new identity can evade a block.</p><button className="danger" onClick={()=>{setConfirmBlock(false);void chat.block();}}>Confirm block</button> <button className="secondary" onClick={()=>setConfirmBlock(false)}>Keep conversation</button></div>}
        <p className="field-hint below">At most 30 messages / 64 KiB are kept in temporary service memory. Delivered means the peer’s browser confirmed rendering; it does not mean a person read the message. Reconnect never restarts Search automatically.</p>
      </section>
    </div></>}
    <noscript><p>Live conversations need JavaScript. <a href="/legal/">Policies remain readable</a>.</p></noscript>
  </>;
}
