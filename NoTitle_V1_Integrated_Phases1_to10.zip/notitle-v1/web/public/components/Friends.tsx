'use client';
import {useEffect,useState,useSyncExternalStore} from 'react';
import Link from 'next/link';
import {identityClient as api} from '@notitle/shared/identity';
import {SocialClient} from '../../shared/social';
import type {Friend} from '../../shared/social';
import {PageHeading} from './Shell';

export const social=new SocialClient(api);
export function FriendActions(){
  const state=useSyncExternalStore(social.subscribe,social.snapshot,social.serverSnapshot);
  const chat=useSyncExternalStore(api.conversation.subscribe,api.conversation.snapshot,api.conversation.serverSnapshot);
  useEffect(()=>{social.expire();},[chat.interaction]);
  return <><button className="secondary" disabled={!chat.interaction||chat.phase!=='matched'} onClick={()=>void social.request()}>Add friend</button>{state.notices.filter(item=>item.kind==='request'&&item.interaction===chat.interaction?.interaction_handle).map(item=><div className="notice" key={item.handle} role="status">{item.incoming?<><p>{item.name} wants to become friends.</p><button onClick={()=>void social.respond(item,true)}>Accept friendship</button> <button className="secondary" onClick={()=>void social.respond(item,false)}>Close request</button></>:<p>Friend request pending. Either person can end the conversation.</p>}</div>)}{state.error&&<p role="alert">{state.error}</p>}</>;
}
export default function Friends(){
  const identity=useSyncExternalStore(api.subscribe,api.snapshot,api.serverSnapshot),state=useSyncExternalStore(social.subscribe,social.snapshot,social.serverSnapshot);
  const chat=useSyncExternalStore(api.conversation.subscribe,api.conversation.snapshot,api.conversation.serverSnapshot);
  const [confirmation,setConfirmation]=useState<{action:'remove'|'block';item:Friend}|null>(null),[now,setNow]=useState(Date.now());
  useEffect(()=>{if(api.state.phase==='idle')void api.start();},[]);
  useEffect(()=>{if(!identity.owner)return;void social.load();const timer=setInterval(()=>{if(!document.hidden)void social.load();},30000);return ()=>clearInterval(timer);},[identity.owner?.ref]);
  useEffect(()=>{const timer=setInterval(()=>{setNow(Date.now());social.expire();},1000);return ()=>clearInterval(timer);},[]);
  const incoming=state.notices.filter(item=>item.kind==='invite'&&item.incoming&&item.expires!==null&&item.expires>now);
  return <><PageHeading eyebrow="Free mutual connections" title="Continue a good conversation.">Friends are mutual. Invitations last 30 seconds and never interrupt an existing conversation. There are no offline peer messages.</PageHeading>
    {!identity.owner?<section className="card"><p>Join before viewing your relationships.</p><Link href="/join/">Continue as guest</Link> · <Link href="/login/">Log in</Link></section>:<>
    {(state.error||chat.error)&&<p role="alert" className="notice error">{state.error||chat.error}</p>}{state.notice&&<p className="notice" role="status">{state.notice}</p>}
    <div className="row below"><button className="secondary" disabled={state.loading} onClick={()=>void social.load()}>Refresh friends</button><button className="secondary" disabled={chat.phase==='replaced'} onClick={()=>void api.conversation.reconnect()}>Connect for invitations</button><Link href="/chat/">Open conversation</Link></div>
    {incoming.map(item=><section className="card below" key={item.handle}><h2>Invitation from {item.name}</h2><p>Expires in {Math.max(0,Math.ceil((item.expires!-now)/1000))} seconds.</p><button disabled={!!chat.interaction} onClick={()=>void social.respond(item,true)}>Accept invitation</button> <button className="secondary" onClick={()=>void social.respond(item,false)}>Decline invitation</button>{chat.interaction&&<p>End your current conversation before accepting.</p>}</section>)}
    <section className="card below"><h2>Your friends · {state.items.length}/100</h2>{!state.items.length&&<p>{state.loading?'Loading…':'No friendships yet. Add a friend during a conversation and wait for their acceptance.'}</p>}<ul className="list">{state.items.map(item=><li className="row spread" key={item.relationship_handle}><div><strong>{item.peer.display_name}</strong><p>{item.peer.gender} · {item.peer.topic_id}</p><p className="field-hint">{item.persistence==='saved'?'Saved':item.persistence==='saving'?'Saving…':'Temporary'} · {item.presence==='available'?'Available':item.presence==='busy'?'Busy':'Offline'}</p></div><div className="row"><button disabled={item.presence!=='available'||!!chat.interaction} onClick={()=>void social.invite(item)}>Invite</button><button className="secondary" onClick={()=>setConfirmation({action:'remove',item})}>Remove</button><button className="danger" onClick={()=>setConfirmation({action:'block',item})}>Block</button></div></li>)}</ul></section>
    {confirmation&&<section className="notice below" role="group" aria-label="Confirm relationship change"><p>{confirmation.action==='remove'?'Remove':'Block'} {confirmation.item.peer.display_name}? Any shared conversation ends. Guest blocks last only for this identity.</p><button className="danger" onClick={()=>{const selected=confirmation;setConfirmation(null);void (selected.action==='remove'?social.remove(selected.item):social.block(selected.item));}}>Confirm {confirmation.action}</button> <button className="secondary" onClick={()=>setConfirmation(null)}>Cancel</button></section>}
    <p className="field-hint below">Temporary friendships remain in service memory until both identities register. Saved appears only after a successful database commit. Logging into an existing account does not import guest friendships. Presence is a coarse current state and may change before you invite.</p>
    </>}
  </>;
}
