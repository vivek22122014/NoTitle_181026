'use client';
import {useEffect,useRef,useState,useSyncExternalStore} from 'react';
import Link from 'next/link';
import {identityClient as api,object,list,textValue,IdentityError} from '@notitle/shared/identity';
import type {PreparedView} from '@notitle/shared/identity.generated';
import {Checkbox,Field,StatusNotice} from '@notitle/shared/primitives';
import {saveText} from '@notitle/shared/client';
import {CodePanel} from './IdentityApplication';
import {PageHeading} from './Shell';

type Plan={code:string;version:string;gross_paise:number;duration_seconds:number;currency:string;enabled:boolean;tax_rule:string;policy_version:string;receipt_preview:Record<string,unknown>|null};
type Purchase={public_ref:string;plan_code:string;amount_paise:number;state:string;created_at:string;captured_at:string|null;remedies:Record<string,unknown>[]};
type Receipt={public_ref:string;receipt_number:string;facts:Record<string,unknown>;created_at:string};
type CheckoutBody={plan_code:string;plan_version:string;policy_version:string;policy_accepted:boolean;client_nonce:string;payment_phone:string};
type CashfreeFactory=(options:{mode:'sandbox'|'production'})=>{checkout:(options:{paymentSessionId:string;redirectTarget:'_self'})=>Promise<unknown>};
declare global{interface Window{Cashfree?:CashfreeFactory;}}

let sdk:Promise<CashfreeFactory>|null=null;
function loadSdk():Promise<CashfreeFactory>{
  if(window.Cashfree)return Promise.resolve(window.Cashfree);
  if(sdk)return sdk;
  sdk=new Promise((resolve,reject)=>{
    const script=document.createElement('script');script.src='https://sdk.cashfree.com/js/v3/cashfree.js';script.async=true;script.referrerPolicy='no-referrer';
    const timer=setTimeout(()=>{script.remove();sdk=null;reject(new Error('CHECKOUT_UNAVAILABLE'));},10000);
    script.onload=()=>{clearTimeout(timer);if(window.Cashfree)resolve(window.Cashfree);else{sdk=null;reject(new Error('CHECKOUT_UNAVAILABLE'));}};
    script.onerror=()=>{clearTimeout(timer);script.remove();sdk=null;reject(new Error('CHECKOUT_UNAVAILABLE'));};document.head.appendChild(script);
  });return sdk;
}
const money=(paise:number)=>new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR'}).format(paise/100);
function amount(value:unknown){if(typeof value!=='number'||!Number.isSafeInteger(value)||value<0)throw new Error('INVALID_RESPONSE');return value;}
function readPlan(raw:unknown):Plan{const r=object(raw);if(typeof r.enabled!=='boolean'||r.currency!=='INR')throw new Error('INVALID_RESPONSE');return {code:textValue(r.code),version:textValue(r.version),gross_paise:amount(r.gross_paise),duration_seconds:amount(r.duration_seconds),currency:r.currency,enabled:r.enabled,tax_rule:textValue(r.tax_rule),policy_version:textValue(r.policy_version),receipt_preview:r.receipt_preview===null?null:object(r.receipt_preview)};}
function readPurchase(raw:unknown):Purchase{const r=object(raw),ref=textValue(r.public_ref);if(!/^[0-9a-f]{32}$/.test(ref))throw new Error('INVALID_RESPONSE');return {public_ref:ref,plan_code:textValue(r.plan_code),amount_paise:amount(r.amount_paise),state:textValue(r.state),created_at:textValue(r.created_at),captured_at:r.captured_at===null?null:textValue(r.captured_at),remedies:r.remedies===undefined?[]:list(r.remedies).map(object)};}
function readReceipt(raw:unknown):Receipt{const r=object(raw);return {public_ref:textValue(r.public_ref),receipt_number:String(amount(r.receipt_number)),facts:object(r.facts),created_at:textValue(r.created_at)};}

export default function Billing({path}:{path:string}){
  const state=useSyncExternalStore(api.subscribe,api.snapshot,api.serverSnapshot);
  const [plans,setPlans]=useState<Plan[]>([]),[selected,setSelected]=useState('Month30'),[phone,setPhone]=useState(''),[accepted,setAccepted]=useState(false);
  const [purchases,setPurchases]=useState<Purchase[]>([]),[receipts,setReceipts]=useState<Receipt[]>([]),[receiptCursor,setReceiptCursor]=useState<number|null>(null),[purchaseRef,setPurchaseRef]=useState(''),[verified,setVerified]=useState<Purchase|null>(null);
  const [entitlement,setEntitlement]=useState<{available_seconds:number;premium_until:number}|null>(null),[uncertain,setUncertain]=useState(false),[notice,setNotice]=useState('');
  const [proof,setProof]=useState<PreparedView|null>(null),[saved,setSaved]=useState(false),[accessRef,setAccessRef]=useState(''),[accessSecret,setAccessSecret]=useState('');
  const activated=useRef(''),[recordsLoaded,setRecordsLoaded]=useState(false);
  const intent=useRef<CheckoutBody|null>(null),generation=useRef(state.generation),poll=useRef<ReturnType<typeof setTimeout>|null>(null),mounted=useRef(true);
  const financial=state.owner?.identity_kind==='account'?'account':state.boot?.scoped_subjects.financial?'financial':undefined;
  const checkout=path==='/checkout/',status=path==='/billing/status/',receiptPage=path==='/account/receipts/'||path==='/billing/',entitlementPage=path==='/account/entitlement/';
  const clear=()=>{intent.current=null;setPhone('');setAccepted(false);setProof(null);setSaved(false);setAccessSecret('');setPurchases([]);setReceipts([]);setVerified(null);setEntitlement(null);setPurchaseRef('');setUncertain(false);activated.current='';setRecordsLoaded(false);setReceiptCursor(null);};
  useEffect(()=>{mounted.current=true;void api.start();const teardown=()=>{if(poll.current)clearTimeout(poll.current);clear();};api.teardowns.add(teardown);return()=>{mounted.current=false;api.teardowns.delete(teardown);if(poll.current)clearTimeout(poll.current);intent.current=null;};},[]);
  useEffect(()=>{
    if(!checkout)return;
    // A loaded payment SDK must never survive a same-document navigation into
    // temporary chat. Checkout exits always create a fresh document and CSP.
    const exit=(event:MouseEvent)=>{const anchor=(event.target as Element|null)?.closest('a');if(!anchor||!anchor.href||anchor.target==='_blank'||anchor.hash&&anchor.pathname===location.pathname)return;event.preventDefault();event.stopPropagation();location.assign(anchor.href);};
    const back=()=>location.reload();document.addEventListener('click',exit,true);window.addEventListener('popstate',back);return()=>{document.removeEventListener('click',exit,true);window.removeEventListener('popstate',back);};
  },[checkout]);
  useEffect(()=>{if(generation.current!==state.generation){generation.current=state.generation;clear();}},[state.generation]);
  useEffect(()=>{if(state.phase!=='ready')return;const current=state.generation;void api.request('/billing/plans').then(data=>{if(mounted.current&&current===api.state.generation)setPlans(list(data.items).map(readPlan));}).catch(()=>api.update({error:'Plans could not be loaded. Checkout is unavailable.'}));},[state.phase,state.generation]);
  useEffect(()=>{if(status||checkout){const ref=new URLSearchParams(location.search).get('purchase_ref');if(ref&&/^[0-9a-f]{32}$/.test(ref))setPurchaseRef(ref);}},[status,checkout]);
  async function loadOwned(){
    if(!financial)throw new IdentityError('ACCOUNT_REQUIRED',401);
    const results=await Promise.all([api.request('/billing/purchases','GET',undefined,undefined,financial),api.request('/billing/receipts','GET',undefined,undefined,financial)]);
    setPurchases(list(results[0].items).map(readPurchase));setReceipts(list(results[1].items).map(readReceipt));setRecordsLoaded(true);setReceiptCursor(results[1].next_cursor===null?null:amount(results[1].next_cursor));
    if(state.owner?.identity_kind==='account'){const data=await api.request('/billing/entitlement');setEntitlement({available_seconds:amount(data.available_seconds),premium_until:amount(data.premium_until)});}
  }
  async function moreReceipts(){const data=await api.request('/billing/receipts?cursor='+receiptCursor,'GET',undefined,undefined,financial);setReceipts(current=>[...current,...list(data.items).map(readReceipt)]);setReceiptCursor(data.next_cursor===null?null:amount(data.next_cursor));}
  async function check(ref=purchaseRef){
    if(!/^[0-9a-f]{32}$/.test(ref))throw new IdentityError('INVALID_INPUT',422);
    const row=readPurchase(await api.request('/billing/purchases/'+ref,'GET',undefined,undefined,financial));setVerified(row);setPurchaseRef(ref);
    if(row.state==='captured'){intent.current=null;setUncertain(false);setNotice('Payment capture was independently verified by the server. Your pass is active.');await loadOwned();if(activated.current!==ref){activated.current=ref;await api.refresh();}}
    else setNotice('Payment has not been verified as captured. Do not pay again while this purchase is pending or unknown.');
    return row;
  }
  useEffect(()=>{
    if(!status||!purchaseRef||state.phase!=='ready'||!financial)return;
    let cancelled=false,attempts=0;const run=async()=>{try{const row=await check(purchaseRef);if(!cancelled&&mounted.current&&row.state!=='captured'&&++attempts<12)poll.current=setTimeout(()=>void run(),5000);}catch{if(!cancelled)api.update({error:'Verified status could not be read. Sign in or restore financial receipt access, then check this reference.'});}};void run();
    return()=>{cancelled=true;if(poll.current)clearTimeout(poll.current);};
  },[status,purchaseRef,state.phase,financial]);
  useEffect(()=>{if(checkout&&state.phase==='ready'&&financial&&!recordsLoaded)void api.perform(loadOwned);},[checkout,state.phase,financial,recordsLoaded]);
  async function launch(session:string){
    await api.conversation.end();api.conversation.stop();const factory=await loadSdk();if(!mounted.current||generation.current!==api.state.generation)return;
    const mode=api.state.boot?.gates.payment_mode;if(mode!=='sandbox'&&mode!=='production')throw new Error('CHECKOUT_UNAVAILABLE');
    await factory({mode}).checkout({paymentSessionId:session,redirectTarget:'_self'});
    setNotice('Checkout returned without verified capture. Check the server status; a browser return does not activate a pass.');
  }
  async function resume(ref:string){
    if(!checkout||!/^([0-9a-f]{32})$/.test(ref))throw new IdentityError('INVALID_INPUT',422);
    const result=await api.request('/billing/purchases/'+ref+'/resume','POST',{});setPurchaseRef(ref);
    if(result.state==='captured'){await check(ref);return;}
    if(result.state==='checkout'&&typeof result.payment_session_id==='string'){setUncertain(true);await launch(result.payment_session_id);return;}
    if(result.state==='expired'||result.state==='cancelled'){intent.current=null;setUncertain(false);setPhone('');setAccepted(false);}
    setNotice(result.state==='expired'||result.state==='cancelled'?'The provider reports this checkout closed. Refresh owned records before choosing another pass.':'The existing order is pending or unknown. No new order was created.');await loadOwned();
  }
  async function pay(){
    const plan=plans.find(item=>item.code===selected);if(!plan?.enabled||!state.boot?.gates.payments||state.owner?.identity_kind!=='account')throw new IdentityError('PAYMENTS_UNAVAILABLE',503);
    if(!recordsLoaded||!intent.current&&purchases.some(item=>['created','checkout','unknown'].includes(item.state)))throw new IdentityError('PURCHASE_PENDING',409);
    if(!intent.current&&(!accepted||!/^[0-9]{10}$/.test(phone)))throw new IdentityError('INVALID_INPUT',422);
    if(!intent.current)intent.current={plan_code:plan.code,plan_version:plan.version,policy_version:state.boot.policy_version,policy_accepted:true,client_nonce:crypto.randomUUID(),payment_phone:phone};
    const body=intent.current;setUncertain(true);setNotice('Creating or checking this exact purchase. Do not start a second payment.');
    // The intent and phone remain in RAM until a result is known; no localStorage.
    const result=await api.request('/billing/purchases','POST',body);const ref=textValue(result.purchase_ref);if(!/^[0-9a-f]{32}$/.test(ref))throw new Error('INVALID_RESPONSE');setPurchaseRef(ref);setPhone('');
    if(result.state==='captured'){await check(ref);return;}
    if(result.state!=='checkout'||typeof result.payment_session_id!=='string'){setNotice('Purchase recorded; payment outcome is pending. Check verified status before making another payment.');return;}
    // Third-party checkout code is loaded only on the checkout route, after an
    // explicit payment action. End temporary chat before exposing the page.
    await launch(result.payment_session_id);
  }
  if(state.phase==='idle'||state.phase==='loading')return <p role="status">Loading billing authority…</p>;
  if(state.phase==='unavailable')return <section className="card"><h1>Billing unavailable</h1><p>{state.error}</p><button onClick={()=>void api.refresh()}>Retry connection</button></section>;
  return <><PageHeading eyebrow="One-off Premium passes" title={status?'Verify your payment.':receiptPage?'Purchases and receipts.':entitlementPage?'Your remaining pass time.':checkout?'Review and pay securely.':'Choose a pass.'}>Free text and audio remain free. Premium adds eligible matching preferences, without queue priority.</PageHeading>
    {state.error&&<StatusNotice tone="warning">{state.error}</StatusNotice>}{notice&&<StatusNotice>{notice}</StatusNotice>}
    <StatusNotice><strong>No voluntary refunds after payment.</strong> Required statutory remedies, verified payment errors and binding provider or bank directions remain available through <Link href="/support/">Chat with Moderator</Link>. Pass time runs continuously after server-verified capture, including while signed out. No automatic renewal or recurring debit is created.</StatusNotice>
    <nav className="row below" aria-label="Billing"><Link href="/premium/">Plans</Link><a href="/checkout/">Checkout</a><Link href="/billing/status/">Payment status</Link><Link href="/account/receipts/">Receipts</Link><Link href="/account/entitlement/">Pass time</Link><Link href="/refund-policy/">Payment policy</Link></nav>
    {!state.boot?.gates.payments&&<p className="notice">New sales are closed until merchant, receipt, legal and payment release checks pass. Existing financial records remain accessible to their owner.</p>}
    {!checkout&&!status&&!receiptPage&&!entitlementPage&&<div className="grid plans">{plans.map(plan=><section className="card" key={plan.code}><h2>{plan.code}</h2><p className="price">{money(plan.gross_paise)}</p><p>{plan.duration_seconds/86400} continuous days · no renewal</p><p>Strict gender preference, optional professional relevance, and the same shared queue.</p>{plan.enabled?<a className="button" href="/checkout/">Review this pass</a>:<button disabled>{plan.code==='Annual365'?'Annual release gate pending':'Sales unavailable'}</button>}</section>)}</div>}
    {checkout&&<section className="card form"><h2>Review the approved total</h2>{state.owner?.identity_kind!=='account'?<p><Link href="/login/">Sign in</Link> or <Link href="/register/">create an account</Link> to purchase. Guests cannot buy a pass.</p>:<form method="post" onSubmit={event=>{event.preventDefault();void api.perform(pay);}}><fieldset disabled={state.busy||!!intent.current} className="form-fields"><label>Pass<select value={selected} onChange={event=>setSelected(event.target.value)}>{plans.filter(plan=>plan.code!=='Annual365').map(plan=><option key={plan.code} value={plan.code} disabled={!plan.enabled}>{plan.code} · {money(plan.gross_paise)} · {plan.duration_seconds/86400} days{!plan.enabled?' · unavailable':''}</option>)}</select></label>{plans.find(plan=>plan.code===selected)?.receipt_preview&&<dl><dt>Net amount</dt><dd>{money(amount(plans.find(plan=>plan.code===selected)!.receipt_preview!.net_paise))}</dd>{list(plans.find(plan=>plan.code===selected)!.receipt_preview!.taxes).map((tax,index)=>{const row=object(tax);return <div key={index}><dt>{textValue(row.name)}</dt><dd>{money(amount(row.paise))}</dd></div>;})}<dt>Total</dt><dd>{money(plans.find(plan=>plan.code===selected)!.gross_paise)}</dd><dt>Merchant</dt><dd>{textValue(object(plans.find(plan=>plan.code===selected)!.receipt_preview!.merchant).legal_name)} · {textValue(object(plans.find(plan=>plan.code===selected)!.receipt_preview!.merchant).postal_address)}</dd></dl>}<p>The displayed INR total includes the reviewed tax treatment. The receipt will show the approved breakdown. Your card, UPI credentials and OTP are entered only on Cashfree's hosted page.</p><Field label="Payment phone (provider requirement)" type="tel" required pattern="[0-9]{10}" maxLength={10} autoComplete="tel-national" value={phone} onChange={event=>setPhone(event.target.value)}/><p className="field-hint">Sent to Cashfree for this payment; never added to your conversation profile.</p><Checkbox checked={accepted} required onChange={event=>setAccepted(event.target.checked)}>I accept the <Link href="/refund-policy/">payment terms</Link>, continuous pass time, no automatic renewal, and no voluntary refunds. Payment opens third-party hosted checkout.</Checkbox></fieldset><button disabled={state.busy||!recordsLoaded||!intent.current&&purchases.some(item=>['created','checkout','unknown'].includes(item.state))||!accepted||!state.boot?.gates.payments||!plans.find(plan=>plan.code===selected)?.enabled}>{state.busy?'Checking purchase…':intent.current?'Retry this exact purchase':'Continue to secure payment'}</button></form>}{uncertain&&<p role="status">A purchase action is in progress or unconfirmed. Keep the reference below; do not pay a second time. Reloading never automatically creates another purchase.</p>}{purchaseRef&&<p>Purchase reference: <code>{purchaseRef}</code> · <Link href={'/billing/status/?purchase_ref='+purchaseRef}>Check verified status</Link></p>}<div className="stack">{purchases.filter(item=>['created','checkout','unknown'].includes(item.state)).map(item=><section className="notice" key={item.public_ref}><h3>Existing unresolved purchase</h3><p>{item.plan_code} · {item.state} · <code>{item.public_ref}</code></p><button type="button" disabled={state.busy} onClick={()=>void api.perform(()=>resume(item.public_ref))}>Check and reopen this existing order</button><p><a href={'/billing/status/?purchase_ref='+item.public_ref}>Check verified capture status</a></p></section>)}</div><p><Link href="/account/receipts/">Recover recent purchase references</Link></p></section>}
    {status&&<section className="card form"><h2>Only server verification activates a pass</h2><form method="get" onSubmit={event=>{event.preventDefault();void api.perform(()=>check().then(()=>{}));}}><Field label="Purchase reference" required pattern="[0-9a-f]{32}" minLength={32} maxLength={32} value={purchaseRef} onChange={event=>{setVerified(null);setPurchaseRef(event.target.value);}}/><button disabled={state.busy||!financial}>Refresh verified status</button></form>{verified&&<dl><dt>Server state</dt><dd>{verified.state}</dd><dt>Amount</dt><dd>{money(verified.amount_paise)}</dd><dt>Plan</dt><dd>{verified.plan_code}</dd><dt>Verified capture time</dt><dd>{verified.captured_at||'Not verified'}</dd></dl>}{verified?.remedies.map((remedy,index)=><p key={index}>Required remedy: {textValue(remedy.state)} · {money(amount(remedy.amount_paise))} · {textValue(remedy.remedy_basis)}</p>)}<p>Polling stops after one minute. You can check again manually. A return parameter, screenshot or payment success message is never proof of capture.</p></section>}
    {(receiptPage||entitlementPage||status)&&<section className="card"><h2>Your authorized financial records</h2><button className="secondary" disabled={state.busy||!financial} onClick={()=>void api.perform(loadOwned)}>Load owned purchases, receipts and pass time</button>{entitlement&&<dl><dt>Available time (server snapshot)</dt><dd>{entitlement.available_seconds} seconds</dd><dt>Projected end</dt><dd>{entitlement.premium_until?new Date(entitlement.premium_until*1000).toLocaleString():'No active pass'}</dd></dl>}<ul className="list">{purchases.map(purchase=><li key={purchase.public_ref}><strong>{purchase.plan_code}</strong> · {money(purchase.amount_paise)} · {purchase.state}<p><Link href={'/billing/status/?purchase_ref='+purchase.public_ref}>{purchase.public_ref}</Link></p></li>)}</ul><ul className="list">{receipts.map(receipt=><li key={receipt.public_ref}><h3>{receipt.receipt_number}</h3><p>{String(receipt.facts.document_kind)} · {receipt.created_at}</p><button className="secondary" onClick={()=>saveText('NoTitle-receipt-'+receipt.receipt_number+'.json',JSON.stringify(receipt,null,2))}>Download verified receipt</button><details><summary>Receipt facts</summary><pre style={{whiteSpace:'pre-wrap',overflowWrap:'anywhere'}}>{JSON.stringify(receipt.facts,null,2)}</pre></details></li>)}</ul>{receiptCursor!==null&&<button className="secondary" disabled={state.busy} onClick={()=>void api.perform(moreReceipts)}>Load older receipts</button>}</section>}
    {(receiptPage||status)&&<section className="card form"><h2>Saved financial receipt access</h2><p>Financial access is separate from account recovery and moderator case access. Save its secret before confirming. It grants financial records only and cannot recover your account.</p>{state.owner?.identity_kind==='account'&&!proof&&<button disabled={state.busy} onClick={()=>void api.perform(async()=>{setProof(await api.prepare('financial'));setSaved(false);})}>Prepare financial access receipt</button>}{proof&&<><CodePanel proof={proof} saved={saved} setSaved={setSaved} kind="financial access receipt"/><button disabled={state.busy||!saved} onClick={()=>void api.perform(async()=>{await api.request('/billing/receipts/access/confirm','POST',{reservation_id:proof.reservation_id,secret:proof.secret,saved});setProof(null);setSaved(false);setNotice('Saved financial receipt confirmed. Keep it private.');})}>Confirm saved financial receipt</button></>}<form method="post" onSubmit={event=>{event.preventDefault();void api.perform(async()=>{await api.request('/billing/receipts/access','POST',{receipt_ref:accessRef,secret:accessSecret});setAccessSecret('');await api.syncAuthority();setNotice('Financial-only access restored. Load your owned records.');});}}><Field label="Saved financial receipt reference" required value={accessRef} onChange={event=>setAccessRef(event.target.value)} autoComplete="off"/><Field label="Saved financial receipt secret" type="password" required value={accessSecret} onChange={event=>setAccessSecret(event.target.value)} autoComplete="off"/><button disabled={state.busy}>Restore financial-only access</button></form><p><Link href="/settings/">Verify your password</Link> before issuing a financial receipt if recent verification is required.</p></section>}
  </>;
}
