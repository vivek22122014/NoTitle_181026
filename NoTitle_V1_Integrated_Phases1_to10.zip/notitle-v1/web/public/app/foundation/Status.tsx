'use client';
import {useEffect,useState} from 'react';
export default function Status(){
 const [state,setState]=useState('Checking owner readiness…');
 useEffect(()=>{
  const abort=new AbortController();
  fetch('/health/ready',{cache:'no-store',signal:abort.signal}).then(async response=>{
   const body=await response.json();
   if(!response.ok||body.data?.mode!=='foundation'||body.data?.admission!==false)throw new Error();
   setState('Owner verified · Foundation mode · Product admission closed');
  }).catch(()=>{if(!abort.signal.aborted)setState('Owner unavailable. Check the local runner and database.');});
  return()=>abort.abort();
 },[]);
 return <p className="notice" role="status">{state}</p>;
}
