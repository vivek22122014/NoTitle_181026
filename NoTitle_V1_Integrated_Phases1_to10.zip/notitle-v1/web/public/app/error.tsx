'use client';
export default function ErrorPage({reset}:{reset:()=>void}){return <main className="wrap content"><h1>This page could not be shown.</h1><p role="alert">No successful action is assumed. Refresh status before repeating a payment or saved request.</p><button type="button" onClick={()=>reset()}>Try loading the page again</button><p><a href="/legal/">Read policies</a></p></main>;}
