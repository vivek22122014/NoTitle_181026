export {Publication as default} from '../../components/PolicyPages';
