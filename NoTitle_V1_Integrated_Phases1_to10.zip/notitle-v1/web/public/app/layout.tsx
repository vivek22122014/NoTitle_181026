import type { Metadata } from 'next';
import '@notitle/shared/tokens.css';
import site from '@notitle/shared/site';
export const metadata: Metadata = {metadataBase:new URL(site.public_origin),title:'NoTitle · Conversations without titles',description:'Pseudonymous one-to-one conversations for adults.',robots:{index:false,follow:false}};
export const viewport={width:'device-width',initialScale:1,viewportFit:'cover'};
export default function Layout({children}:Readonly<{children:React.ReactNode}>){return <html lang="en"><body>{children}<noscript><p className="noscript-note">Information and policies are readable without JavaScript. Interactive service actions require JavaScript and qualified service availability.</p></noscript></body></html>}
