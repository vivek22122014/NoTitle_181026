import {PublicShell} from '../components/Shell';
export default function NotFound(){return <PublicShell><section className="card"><h1>Page not found</h1><p>The address is unavailable. No action has been performed.</p><div className="row"><a href="/">Return to start</a><a href="/legal/">Read policies</a></div></section></PublicShell>;}
