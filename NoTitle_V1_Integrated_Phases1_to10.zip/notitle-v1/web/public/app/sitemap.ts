import type {MetadataRoute} from 'next';
import routes from '../route-data.json';
import site from '@notitle/shared/site';
export const dynamic='force-static';
export default function sitemap():MetadataRoute.Sitemap{return site.indexable?routes.filter(route=>route.indexable).map(route=>({url:site.public_origin+route.path})):[];}
