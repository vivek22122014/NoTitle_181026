import {useId, type InputHTMLAttributes, type ReactNode} from 'react';
import type {ViewState} from './interface';

export function Field({label,hint,error,id:providedId,...props}:InputHTMLAttributes<HTMLInputElement>&{label:string;hint?:string;error?:string}){
  const generatedId=useId(),id=providedId||generatedId;
  return <div className="field"><label htmlFor={id}>{label}</label><input id={id} aria-invalid={!!error} aria-describedby={[hint&&`${id}-hint`,error&&`${id}-error`].filter(Boolean).join(' ')||undefined} {...props}/>{hint&&<p className="field-hint" id={`${id}-hint`}>{hint}</p>}{error&&<p className="field-error" id={`${id}-error`}>{error}</p>}</div>;
}
export function Checkbox({children,...props}:InputHTMLAttributes<HTMLInputElement>&{children:ReactNode}){
  return <label className="check"><input type="checkbox" {...props}/><span>{children}</span></label>;
}
export function DisabledAction({children,reason,danger=false}:{children:ReactNode;reason:string;danger?:boolean}){
  const id=useId();
  return <span className="action-with-reason"><button type="button" disabled aria-describedby={id} className={danger?'danger':''}>{children}</button><span id={id} className="field-hint">{reason}</span></span>;
}
export function StatusNotice({children,tone='info'}:{children:ReactNode;tone?:'info'|'error'|'success'}){
  return <div className={`notice ${tone==='info'?'':tone}`} role={tone==='error'?'alert':'status'}>{children}</div>;
}
export function EmptyState({title,children}:{title:string;children:ReactNode}){
  return <section className="empty"><h2>{title}</h2><p>{children}</p></section>;
}
const statuses:Record<Exclude<ViewState,'ready'>,{title:string;body:string}>={
  loading:{title:'Loading',body:'Please wait for the latest authorized state. No action has been submitted.'},
  empty:{title:'Nothing here yet',body:'There are no records to show. Use the available next step when the service is enabled.'},
  validation:{title:'Check the highlighted field',body:'Review your input before trying again. Safe form values stay on this page.'},
  error:{title:'We could not confirm the result',body:'No success is assumed. Check the current status before repeating a payment or saved request.'},
  forbidden:{title:'Access required',body:'This view needs the appropriate session and permission. A reference alone does not grant access.'},
  stale:{title:'This view has changed',body:'Refresh the current state before confirming. Old revisions cannot authorize an action.'},
  'rate-limited':{title:'Please wait before trying again',body:'The service supplies the safe retry time. This preview does not start a retry timer.'},
  maintenance:{title:'Temporarily unavailable',body:'New actions are paused. Read the policy and safety guidance while the service is unavailable.'},
};
export function RouteState({state}:{state:Exclude<ViewState,'ready'>}){
  const item=statuses[state];
  return <section className="card state-panel" aria-busy={state==='loading'} data-view-state={state}>
    <StatusNotice tone={state==='error'||state==='validation'?'error':'info'}><strong>{item.title}</strong><p>{item.body}</p></StatusNotice>
    {state==='validation'&&<Field label="Display name" defaultValue="" error="Enter a display name between 2 and 24 characters." required minLength={2} maxLength={24}/>}
    <p>Interface example only. No request, cookie, payment or message is created.</p>
  </section>;
}
export function Pager({label='Load more'}:{label?:string}){
  return <DisabledAction reason="A server-issued cursor is required.">{label}</DisabledAction>;
}
