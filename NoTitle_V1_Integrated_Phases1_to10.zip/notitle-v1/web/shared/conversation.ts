import type {ClientCoordinator} from './identity';
import type {Command,Event,MessageView,InteractionView,QueueView,Snapshot,TicketView} from './conversation.generated';
import {validateWire} from './wire.ts';

type SocketLike={readyState:number;bufferedAmount:number;send:(data:string)=>void;close:(code?:number)=>void;onopen:((event?:unknown)=>void)|null;onmessage:((event:{data:unknown})=>void)|null;onclose:((event:{code:number})=>void)|null;onerror:((event?:unknown)=>void)|null};
type IO={socket:(url:string)=>SocketLike;origin:()=>string;now:()=>number;later:(fn:()=>void,ms:number)=>ReturnType<typeof setTimeout>;cancel:(id:ReturnType<typeof setTimeout>)=>void};
export type Transcript=MessageView&{status:'pending'|'accepted'|'delivered'|'unconfirmed'};
export type ConversationState={phase:'idle'|'connecting'|'ready'|'searching'|'matched'|'interrupted'|'replaced'|'unavailable'|'maintenance';interaction:InteractionView|null;messages:Transcript[];queue:QueueView|null;error:string;notice:string;draft:string;pending:boolean;graceUntil:number|null;takeoverGeneration:number;generalTalk:boolean;genderPreference:'everyone'|'male'|'female'|'other';revision:number};
const initial=():ConversationState=>({phase:'idle',interaction:null,messages:[],queue:null,error:'',notice:'',draft:'',pending:false,graceUntil:null,takeoverGeneration:0,generalTalk:true,genderPreference:'everyone',revision:0});
const defaults:IO={socket:url=>new WebSocket(url) as unknown as SocketLike,origin:()=>location.origin,now:()=>Date.now(),later:(fn,ms)=>setTimeout(fn,ms),cancel:id=>clearTimeout(id)};

export class ConversationClient{
  state=initial();listeners=new Set<()=>void>();ws:SocketLike|null=null;opening:Promise<void>|null=null;
  io:IO;serial=0;intent=0;ownerEpoch=0;socketGeneration=0;interactionEpoch=1;serverSequence=0;searchId='';
  pending=new Map<string,Command>();rendered=new Set<string>();heartbeat:ReturnType<typeof setTimeout>|null=null;grace:ReturnType<typeof setTimeout>|null=null;endTimer:ReturnType<typeof setTimeout>|null=null;
  endedHandles=new Set<string>();
  private pendingSafety:{command:Command;serial:number;intent:number;authority:number}|null=null;
  eventListeners=new Set<(event:Event)=>void>();pendingFriend=false;
  openResolve:(()=>void)|null=null;openReject:((error:Error)=>void)|null=null;lastFrame=0;pageHide:(()=>void)|null=null;
  api:ClientCoordinator;
  constructor(api:ClientCoordinator,io:Partial<IO>={}){this.api=api;this.io={...defaults,...io};api.teardowns.add(()=>this.stop());}
  subscribe=(listener:()=>void)=>{this.listeners.add(listener);return ()=>{this.listeners.delete(listener);};};
  subscribeEvents=(listener:(event:Event)=>void)=>{this.eventListeners.add(listener);return ()=>{this.eventListeners.delete(listener);};};
  snapshot=()=>this.state;serverSnapshot=()=>serverState;
  update(change:Partial<ConversationState>){this.state={...this.state,...change,revision:this.state.revision+1};for(const listener of this.listeners)listener();}
  clearContent(){if(this.grace)this.io.cancel(this.grace);this.grace=null;if(this.endTimer)this.io.cancel(this.endTimer);this.endTimer=null;this.pending.clear();this.rendered.clear();this.searchId='';this.pendingFriend=false;this.update({messages:[],interaction:null,queue:null,draft:'',pending:false,graceUntil:null});}
  timers(){for(const key of ['heartbeat','grace','endTimer'] as const){if(this[key])this.io.cancel(this[key]!);this[key]=null;}}
  stop(){this.serial++;this.intent++;this.pendingSafety=null;this.timers();this.openReject?.(new Error('AUTHORITY_CHANGED'));this.openResolve=null;this.openReject=null;this.opening=null;const socket=this.ws;this.ws=null;if(socket){socket.onclose=null;socket.onmessage=null;socket.close(1000);}this.clearContent();this.endedHandles.clear();this.update({...initial(),revision:this.state.revision});this.serverSequence=0;this.ownerEpoch=0;this.socketGeneration=0;if(this.pageHide&&typeof window!=='undefined')window.removeEventListener('pagehide',this.pageHide);this.pageHide=null;}
  rememberEnd(handle:string){this.endedHandles.add(handle);while(this.endedHandles.size>128)this.endedHandles.delete(this.endedHandles.values().next().value!);}
  fail(code:string){this.pendingSafety=null;this.timers();this.clearContent();this.update({phase:'unavailable',error:message(code)});const socket=this.ws;this.ws=null;if(socket){socket.onclose=null;socket.close(1008);}this.openReject?.(new Error(code));this.openReject=null;this.openResolve=null;}
  async open(takeover=false):Promise<void>{
    if(this.opening)return this.opening;
    if(this.ws?.readyState===1&&['ready','searching','matched'].includes(this.state.phase))return;
    const owner=this.api.state.owner; if(!owner||!owner.core_consent||!this.api.state.boot?.gates.admission)throw new Error('PARTICIPATION_UNAVAILABLE');
    const serial=++this.serial,authority=this.api.state.generation;this.update({phase:'connecting',error:'',pending:true});
    this.opening=(async()=>{
      try{
        const value=await this.api.request('/ws/ticket','POST',{takeover,known_socket_generation:takeover?this.state.takeoverGeneration:0});validateWire('TicketView',value);
        const ticket=value as unknown as TicketView;if(serial!==this.serial||authority!==this.api.state.generation)return;
        if(this.ownerEpoch&&ticket.owner_epoch!==this.ownerEpoch){this.clearContent();this.update({notice:'The service restarted. The previous temporary conversation is no longer available.'});}
        this.ownerEpoch=ticket.owner_epoch;this.serverSequence=0;this.socketGeneration=0;
        const url=new URL('/api/v1/ws',this.io.origin());url.protocol=url.protocol==='https:'?'wss:':'ws:';
        const socket=this.io.socket(url.href);this.ws=socket;
        await new Promise<void>((resolve,reject)=>{
          this.openResolve=resolve;this.openReject=reject;
          const timeout=this.io.later(()=>{if(serial===this.serial)this.fail('CONNECT_TIMEOUT');},10000);
          const complete=()=>{this.io.cancel(timeout);resolve();};this.openResolve=complete;
          socket.onopen=()=>{if(serial!==this.serial){socket.close(1000);return;}const hello={protocol_version:2,type:'session.hello',ticket:ticket.ticket};validateWire('Hello',hello);socket.send(JSON.stringify(hello));};
          socket.onmessage=event=>{if(serial!==this.serial||authority!==this.api.state.generation)return;try{if(typeof event.data!=='string'||new TextEncoder().encode(event.data).length>196608)throw new Error('WIRE_CONTRACT');this.receive(JSON.parse(event.data));}catch{this.fail('WIRE_CONTRACT');}};
          socket.onerror=()=>{};
          socket.onclose=event=>{this.io.cancel(timeout);if(serial!==this.serial)return;this.ws=null;this.openReject?.(new Error('CONNECTION_CLOSED'));this.openResolve=null;this.openReject=null;this.closed(event.code);};
        });
        if(!this.pageHide&&typeof window!=='undefined'){this.pageHide=()=>this.stop();window.addEventListener('pagehide',this.pageHide);}
      }catch(error){
        if(serial===this.serial){
          const failure=error as {code?:string;data?:Record<string,unknown>};
          if(failure.code==='SOCKET_EXISTS'){this.clearContent();this.update({phase:'replaced',takeoverGeneration:Number(failure.data?.socket_generation)||0,error:'Another tab owns chat. Choose an explicit takeover to replace it.'});}
          else if(error instanceof Error&&error.message==='WIRE_CONTRACT')this.fail('WIRE_CONTRACT');
          else if(this.state.phase==='connecting'){this.update({phase:'unavailable',pending:false,error:message(failure.code||'CONNECTION_CLOSED')});}
        }
        throw error;
      }finally{if(serial===this.serial)this.opening=null;}
    })();return this.opening;
  }
  frame(type:Command['type'],payload:unknown,id=crypto.randomUUID()):Command{
    const command={protocol_version:2,command_id:id,type,owner_epoch:this.ownerEpoch,socket_generation:this.socketGeneration,interaction_epoch:this.interactionEpoch,payload};validateWire('Command',command);return command as Command;
  }
  send(command:Command){
    if(this.ws?.readyState!==1||this.ws.bufferedAmount>65536)throw new Error('SOCKET_BACKPRESSURE');
    validateWire('Command',command);if(this.pending.size>=16)throw new Error('COMMAND_CAPACITY');
    this.pending.set(command.command_id,command);this.ws.send(JSON.stringify(command));
  }
  async sendFeature(type:string,payload:unknown):Promise<string>{
    if(!type.startsWith('friend.')&&!type.startsWith('call.'))throw new Error('INVALID_COMMAND');
    const serial=this.serial,authority=this.api.state.generation;
    // Audio effects never reconnect or recapture media on their own.
    if(type.startsWith('call.')){if(this.ws?.readyState!==1)throw new Error('CONNECTION_CLOSED');}
    else await this.open();
    if(authority!==this.api.state.generation||type.startsWith('call.')&&serial!==this.serial)throw new Error('STALE_AUTHORITY');
    const command=this.frame(type as Command['type'],payload);
    if(type==='friend.invite'||type==='friend.invite.respond'&&!!(payload as {accept?:boolean})?.accept)this.pendingFriend=true;
    try{this.send(command);}catch(error){if(type.startsWith('friend.invite'))this.pendingFriend=false;throw error;}
    return command.command_id;
  }
  command=(type:string,payload:unknown)=>this.sendFeature(type,payload);
  preferences(){const owner=this.api.state.owner!;return {gender:this.state.genderPreference,general_talk:this.state.generalTalk||owner.profile?.topic_id==='general',profile_revision:owner.profile_revision,preference_revision:owner.preference_revision};}
  async search(){
    const intent=++this.intent,id=crypto.randomUUID();this.searchId=id;this.update({error:'',pending:true});
    try{await this.open();if(intent!==this.intent)return;if(this.state.interaction){this.update({pending:false,notice:'The current temporary conversation was restored. End it before searching again.'});return;}this.searchId=id;this.send(this.frame('queue.join',this.preferences(),id));}
    catch(error){if(intent===this.intent)this.update({pending:false,error:message((error as {code?:string}).code||'CONNECTION_CLOSED')});}
  }
  async reconnect(takeover=false){try{await this.open(takeover);}catch{/* open publishes a safe error; reconnect never searches. */}}
  draft(text:string){const chars=Array.from(text).slice(0,2000);while(new TextEncoder().encode(chars.join('')).length>6144)chars.pop();this.update({draft:chars.join('')});}
  text(){
    const interaction=this.state.interaction,text=this.state.draft;
    if(this.state.phase!=='matched'||!interaction||interaction.interrupted)throw new Error('PEER_INTERRUPTED');
    if(!text||Array.from(text).length>2000||new TextEncoder().encode(text).length>6144||/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f]/.test(text)||Array.from(text).some(c=>{const n=c.codePointAt(0)!;return n>=0xd800&&n<=0xdfff;}))throw new Error('TEXT_LIMIT');
    if([...this.pending.values()].filter(c=>c.type==='text.send').length>=10)throw new Error('COMMAND_CAPACITY');
    const command=this.frame('text.send',{interaction_handle:interaction.interaction_handle,text});this.send(command);
    this.update({draft:''});this.boundMessages([...this.state.messages,{id:'pending:'+command.command_id,sequence:0,sender:'me',text,sent_at:this.io.now()/1000,delivered:false,command_id:command.command_id,status:'pending'}]);
  }
  renderedMessages(){
    if(this.state.phase!=='matched'||!this.state.interaction)return;
    const live=new Set(this.state.messages.filter(m=>m.sender==='peer').map(m=>m.id));this.rendered=new Set([...this.rendered].filter(id=>live.has(id)));
    for(const item of this.state.messages){if(item.sender!=='peer'||this.rendered.has(item.id))continue;try{this.send(this.frame('text.delivered',{interaction_handle:this.state.interaction.interaction_handle,message_id:item.id,sequence:item.sequence}));this.rendered.add(item.id);}catch{return;}}
  }
  async cancel(){
    ++this.intent;const connecting=this.state.phase==='connecting',target=this.searchId||this.state.queue?.search_command_id;this.clearContent();this.update({phase:this.ws?.readyState===1?'ready':'idle',pending:true,notice:'Search cancellation requested.'});
    if(!target){if(connecting)this.stop();return;}
    if(!this.socketGeneration){this.stop();return;}
    const command=this.frame('queue.cancel',{search_command_id:target});await this.teardown(command);
  }
  async end(){
    ++this.intent;const handle=this.state.interaction?.interaction_handle;
    if(!handle){await this.cancel();return;}
    const command=this.frame('interaction.end',{interaction_handle:handle});this.clearContent();this.update({phase:'ready',pending:true,notice:'Ending the conversation…'});await this.teardown(command);
  }
  protect(){
    const handle=this.state.interaction?.interaction_handle;if(!handle)return;
    // Fence rendering and microphone callbacks immediately. The HTTP report
    // preparation must freeze selected evidence before a server End erases it.
    const command=this.frame('interaction.end',{interaction_handle:handle});
    this.rememberEnd(handle);++this.intent;
    this.pendingSafety={command,serial:this.serial,intent:this.intent,authority:this.api.state.generation};
    this.clearContent();this.update({phase:this.ws?.readyState===1?'ready':'unavailable',pending:true,notice:'Contact stopped locally. Preparing a protected report…'});
  }
  async finishProtection(confirmed:boolean){
    const protection=this.pendingSafety;this.pendingSafety=null;
    if(!protection||protection.serial!==this.serial||protection.intent!==this.intent||protection.authority!==this.api.state.generation)return;
    if(confirmed){this.update({pending:false,notice:'Contact ended and blocked for this identity. The report is saved only after a case reference is confirmed.'});return;}
    this.update({notice:'Report preparation was not confirmed. Requesting conversation teardown…'});
    await this.teardown(protection.command);
  }
  async teardown(command:Command){
    if(command.type==='interaction.end')this.rememberEnd(command.payload.interaction_handle);
    try{this.send(command);this.endTimer=this.io.later(()=>{if(this.pending.has(command.command_id))void this.httpControl(command);},1000);}
    catch{await this.httpControl(command);}
  }
  async httpControl(command:Command){
    const serial=this.serial,intent=this.intent;
    try{const result=await this.api.request('/interactions/end','POST',command);if(serial!==this.serial||intent!==this.intent)return;validateWire('Ack',result);if(result.ok!==true||result.command_id!==command.command_id)throw new Error('WIRE_CONTRACT');this.pending.delete(command.command_id);this.clearContent();this.update({phase:this.ws?.readyState===1?'ready':'idle',pending:false,notice:'Stopped. Choose Search explicitly to find another conversation.'});}
    catch{if(serial===this.serial&&intent===this.intent)this.fail('END_UNCONFIRMED');}
  }
  next(){
    const interaction=this.state.interaction;if(!interaction)return;
    const command=this.frame('interaction.next',{...this.preferences(),interaction_handle:interaction.interaction_handle});this.rememberEnd(interaction.interaction_handle);++this.intent;this.clearContent();this.searchId=command.command_id;
    this.update({phase:'ready',pending:true});try{this.send(command);}catch{void this.httpControl(this.frame('interaction.end',{interaction_handle:interaction.interaction_handle}));}
  }
  async block(){
    const interaction=this.state.interaction;if(!interaction)return;
    const fallback=this.frame('interaction.end',{interaction_handle:interaction.interaction_handle});this.rememberEnd(interaction.interaction_handle);++this.intent;this.clearContent();this.update({phase:'ready',pending:true});
    const serial=this.serial,intent=this.intent;
    try{const result=await this.api.request('/blocks','POST',{peer_handle:interaction.peer.peer_handle});if(serial===this.serial&&intent===this.intent)this.update({pending:false,notice:result.persisted?'Blocked for your account.':'Blocked for this identity session. A new identity can evade this protection.'});}
    catch{if(serial!==this.serial||intent!==this.intent)return;await this.teardown(fallback);this.update({error:'Block could not be confirmed. Conversation teardown was requested; check support before relying on a saved block.'});}
  }
  receive(value:unknown){
    validateWire('Event',value);const event=value as Event;
    if(event.owner_epoch!==this.ownerEpoch||this.socketGeneration&&event.socket_generation!==this.socketGeneration)throw new Error('STALE_AUTHORITY');
    if(event.server_sequence<=this.serverSequence)return;
    const gap=this.serverSequence>0&&event.server_sequence!==this.serverSequence+1;this.serverSequence=event.server_sequence;
    if(event.interaction_epoch<this.interactionEpoch&&event.type!=='session.ready')return;
    this.interactionEpoch=event.interaction_epoch;
    switch(event.type){
      case'session.ready':this.socketGeneration=event.socket_generation;this.applySnapshot(event.data);this.openResolve?.();this.openResolve=null;this.openReject=null;this.lastFrame=this.io.now();this.armHeartbeat();break;
      case'state.snapshot':this.applySnapshot(event.data);break;
      case'queue.waiting':if(event.data.search_command_id===this.searchId){this.update({phase:'searching',queue:event.data,pending:false});}break;
      case'queue.cancelled':this.clearContent();this.update({phase:'ready',pending:false});break;
      case'queue.paused':this.clearContent();this.update({phase:'ready',error:message(event.data.reason)});break;
      case'interaction.started':if(event.data.search_command_id===this.searchId||event.data.search_command_id===null&&this.pendingFriend){this.applyInteraction(event.data);this.pendingFriend=false;}break;
      case'interaction.ended':if(!this.state.interaction||event.data.interaction_handle===this.state.interaction.interaction_handle){const next=[...this.pending.values()].find(command=>command.type==='interaction.next');this.clearContent();if(next){this.pending.set(next.command_id,next);this.searchId=next.command_id;}this.update({phase:'ready',pending:!!next||!!this.pendingSafety,notice:'Conversation ended. Temporary text was cleared.'});}break;
      case'interaction.interrupted':if(event.data.interaction_handle===this.state.interaction?.interaction_handle){this.update({phase:'interrupted',graceUntil:event.data.grace_expires_at*1000,draft:''});this.armGrace();}break;
      case'text.message':{
        if(event.data.interaction_handle!==this.state.interaction?.interaction_handle||this.state.phase!=='matched')break;
        const item=event.data.message;if(item.sender==='peer'&&item.command_id!==null)throw new Error('WIRE_CONTRACT');
        const messages=this.state.messages.filter(m=>m.id!==item.id&&(!item.command_id||m.command_id!==item.command_id));
        this.boundMessages([...messages,{...item,status:item.delivered?'delivered':'accepted'}]);break;
      }
      case'text.delivered':if(event.data.interaction_handle===this.state.interaction?.interaction_handle)this.update({messages:this.state.messages.map(m=>m.id===event.data.message_id&&m.sequence===event.data.sequence?{...m,delivered:true,status:'delivered'}:m)});break;
      case'command.ack':{
        const command=this.pending.get(event.data.command_id);this.pending.delete(event.data.command_id);
        if(command?.type==='interaction.end'||command?.type==='queue.cancel'){if(this.endTimer)this.io.cancel(this.endTimer);this.endTimer=null;this.update({pending:false});}
        break;
      }
      case'command.error':{
        const command=event.data.command_id?this.pending.get(event.data.command_id):null;if(event.data.command_id)this.pending.delete(event.data.command_id);
        if(command?.type==='text.send')this.update({messages:this.state.messages.map(m=>m.command_id===command.command_id?{...m,status:'unconfirmed'}:m)});
        this.update({pending:false,error:message(event.data.code)});break;
      }
      case'friend.invite.closed':if(event.data.reason!=='accepted')this.pendingFriend=false;break;
      case'heartbeat.ack':break;
      case'service.draining':this.clearContent();this.update({phase:'maintenance',notice:'Conversation admission is paused. Support and privacy remain separate.'});break;
      case'service.unavailable':this.fail(event.data.code);break;
    }
    for(const listener of this.eventListeners){try{listener(event);}catch{this.update({error:'A feature could not update. End remains available.'});}}
    this.lastFrame=this.io.now();if(gap&&event.type!=='state.snapshot'&&event.type!=='session.ready'&&this.ws?.readyState===1){try{this.send(this.frame('session.resume',{last_server_sequence:this.serverSequence}));}catch{this.fail('SOCKET_BACKPRESSURE');}}
  }
  boundMessages(messages:Transcript[]){let bytes=messages.reduce((sum,item)=>sum+new TextEncoder().encode(item.text).length,0);while(messages.length>30||bytes>65536){bytes-=new TextEncoder().encode(messages.shift()!.text).length;}this.update({messages});}
  applyInteraction(interaction:InteractionView){if(this.endedHandles.has(interaction.interaction_handle))return;if(this.grace)this.io.cancel(this.grace);this.grace=null;this.update({interaction,queue:null,phase:interaction.interrupted?'interrupted':'matched',pending:false,graceUntil:interaction.grace_expires_at?interaction.grace_expires_at*1000:null});this.boundMessages(interaction.messages.map(item=>({...item,status:item.delivered?'delivered':'accepted'})));if(interaction.interrupted)this.armGrace();}
  applySnapshot(snapshot:Snapshot){
    if(snapshot.interaction&&this.endedHandles.has(snapshot.interaction.interaction_handle)){
      // A delayed snapshot cannot undo the user's End, Next or Block boundary.
      if(this.pendingSafety?.command.type==='interaction.end'&&this.pendingSafety.command.payload.interaction_handle===snapshot.interaction.interaction_handle&&this.pendingSafety.serial===this.serial&&this.pendingSafety.intent===this.intent)return;
      if(!this.state.interaction){this.update({phase:'ready',pending:true});void this.teardown(this.frame('interaction.end',{interaction_handle:snapshot.interaction.interaction_handle}));}return;
    }
    if(snapshot.interaction)this.applyInteraction(snapshot.interaction);
    else{this.clearContent();this.update({phase:snapshot.state==='maintenance'?'maintenance':snapshot.queue?'searching':'ready',queue:snapshot.queue,pending:false});this.searchId=snapshot.queue?.search_command_id||'';}
  }
  armHeartbeat(){if(this.heartbeat)this.io.cancel(this.heartbeat);this.heartbeat=this.io.later(()=>{if(this.io.now()-this.lastFrame>=45000){this.ws?.close(1000);return;}try{this.send(this.frame('heartbeat',{client_time:this.io.now()}));}catch{this.ws?.close(1000);}this.armHeartbeat();},20000);}
  armGrace(){if(this.grace)this.io.cancel(this.grace);const until=this.state.graceUntil;if(until)this.grace=this.io.later(()=>{this.clearContent();this.update({phase:this.ws?.readyState===1?'ready':'unavailable',notice:'Reconnect time expired. Temporary text was cleared.'});},Math.max(0,until-this.io.now()));}
  closed(code:number){
    this.timers();this.pending.clear();this.rendered.clear();this.searchId='';
    if(code===4009){this.clearContent();this.update({phase:'replaced',error:'Chat was taken over by another tab. Reconnect requires an explicit takeover.'});return;}
    if(code===4001||code===1008||code===1013){this.clearContent();this.update({phase:'unavailable',error:message(code===4001?'SESSION_EXPIRED':'SERVICE_UNAVAILABLE')});return;}
    if(this.state.interaction){this.update({phase:'interrupted',draft:'',queue:null,pending:false,messages:this.state.messages.map(item=>item.status==='pending'?{...item,status:'unconfirmed'}:item),graceUntil:this.state.graceUntil||this.io.now()+25000});this.armGrace();}
    else{this.clearContent();this.update({phase:'unavailable',error:'Connection interrupted. Reconnect returns to idle and never searches automatically.'});}
  }
}
const serverState=initial();
export function message(code:string){const messages:Record<string,string>={TEXT_LIMIT:'Use 1–2,000 characters within 6 KiB; unsupported control characters are not allowed.',PEER_INTERRUPTED:'Sending is paused while the connection is interrupted.',SESSION_EXPIRED:'Your chat authority expired. Sign in again; saved support and privacy access are separate.',PREMIUM_REQUIRED:'This filter requires an active pass. Choose Everyone explicitly to continue.',premium_expired:'Your strict filter expired. Search is paused; Everyone requires your explicit choice.',preferences_changed:'Your preferences changed. Review them, then search explicitly; your wait age is preserved.',END_UNCONFIRMED:'Text was cleared locally. The server could not confirm teardown; reconnect to check state before searching again.',WIRE_CONTRACT:'The service returned an unexpected conversation state. Temporary content was cleared.',PARTICIPATION_UNAVAILABLE:'Participation is unavailable. You can still use privacy controls and saved support.',SERVICE_UNAVAILABLE:'Conversation service is unavailable. Temporary text was cleared; reconnect does not resume a search.',SOCKET_BACKPRESSURE:'The connection is too slow. End remains available through the protected HTTP fallback.'};return messages[code]||code.replaceAll('_',' ').toLowerCase()+'.';}
