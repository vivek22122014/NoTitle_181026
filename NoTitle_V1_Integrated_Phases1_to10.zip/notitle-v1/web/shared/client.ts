export type Data = Record<string, any>;
export class ApiError extends Error { code:string;status:number;data?:Data;constructor(code:string,status:number,data?:Data){super(code.replaceAll('_',' ').toLowerCase());this.code=code;this.status=status;this.data=data;} }
const MAX_RESPONSE=1048576;
async function boundedJSON(response:Response):Promise<Data>{
 const length=response.headers.get('content-length');
 if(length&&Number(length)>MAX_RESPONSE){await response.body?.cancel();throw new ApiError('RESPONSE_LIMIT',502);}
 if(!response.body)throw new ApiError('INVALID_RESPONSE',502);
 const reader=response.body.getReader(),decoder=new TextDecoder('utf-8',{fatal:true});let bytes=0,text='';
 try{while(true){const chunk=await reader.read();if(chunk.done)break;bytes+=chunk.value.byteLength;if(bytes>MAX_RESPONSE){await reader.cancel();throw new ApiError('RESPONSE_LIMIT',502);}text+=decoder.decode(chunk.value,{stream:true});}text+=decoder.decode();}
 finally{reader.releaseLock();}
 try{const value=JSON.parse(text);if(!value||typeof value!=='object'||Array.isArray(value))throw new Error();return value;}
 catch{throw new ApiError('INVALID_RESPONSE',502);}
}
/** Private/legacy HTTP adapter. Current public participation uses identity.ts.
 * No retries, credentials in URLs, unbounded response buffers or browser storage.
 */
export class Client {
 csrf=''; scoped:Record<string,string>={}; caseRef=''; account=false; financialAccess=false;generation=0;
 base:string;
 constructor(base='/api/v1'){if(typeof base!=='string'||!/^\/[a-z][a-z0-9-]*\/v1$/.test(base))throw new Error('INVALID_API_BASE');this.base=base;}
 clear(){this.generation++;this.csrf='';this.scoped={};this.caseRef='';this.account=false;this.financialAccess=false;}
 async request(path:string,method='GET',body?:unknown):Promise<Data>{
  if(!path.startsWith('/')||path.startsWith('//')||path.includes('\\')||path.length>2048||/[\u0000-\u001f\u007f]/.test(path)||!['GET','POST','PUT','PATCH','DELETE'].includes(method)||method==='GET'&&body!==undefined)throw new ApiError('INVALID_REQUEST',400);
  const url=new URL(path,'https://notitle.invalid');
  if(url.hash||url.origin!=='https://notitle.invalid'||[...url.searchParams.keys()].some(key=>['secret','password','token','csrf','recovery_secret','code'].includes(key.toLowerCase())))throw new ApiError('CREDENTIALS_IN_URL',400);
  const generation=this.generation;
  const scopedRoute=path.startsWith('/support/cases/')||path==='/privacy/status'||path.startsWith('/billing/receipts')&&!path.includes('/access')||path.startsWith('/billing/purchases/');
  const scope=path.startsWith('/support/cases/'+this.caseRef)&&!!this.caseRef?'case':path==='/privacy/status'?'deletion':scopedRoute&&path.startsWith('/billing/')&&(this.financialAccess||!this.account)?'financial':null;
  const csrf=scope&&this.scoped[scope]?this.scoped[scope]:this.csrf;
  const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),15000);
  try{
   const result=await fetch(this.base+path,{method,credentials:'same-origin',cache:'no-store',signal:controller.signal,headers:{...(scopedRoute?{'X-NT-Authority':scope||'account'}:{}),...(body!==undefined?{'Content-Type':'application/json'}:{}),...(method!=='GET'?{'X-CSRF-Token':csrf}:{})},...(body!==undefined?{body:JSON.stringify(body)}:{})});
   const payload=await boundedJSON(result);
   if(generation!==this.generation)throw new ApiError('STALE_AUTHORITY',409);
   if(!result.ok){if(result.status===401)this.clear();const code=typeof payload.error?.code==='string'&&/^[A-Z0-9_]{1,80}$/.test(payload.error.code)?payload.error.code:'REQUEST_FAILED';throw new ApiError(code,result.status,payload.data);}
   const value=payload.data;if(!value||typeof value!=='object'||Array.isArray(value))throw new ApiError('INVALID_RESPONSE',502);
   if(['/auth/login','/auth/recovery','/auth/recover','/auth/register','/auth/logout','/auth/logout-all','/me/password','/me/recovery/rotate'].includes(url.pathname))this.clear();
   if(value.csrf){if(typeof value.csrf!=='string'||value.csrf.length>128)throw new ApiError('INVALID_RESPONSE',502);if(value.csrf_scope)this.scoped[value.csrf_scope]=value.csrf;else this.csrf=value.csrf;}
   if(value.scoped_csrf)this.scoped=value.scoped_csrf;
   if(value.identity_kind)this.account=value.identity_kind==='account';
   if(value.scoped_subjects)this.caseRef=value.scoped_subjects.case||'';
   if(value.case_ref&&value.csrf_scope==='case')this.caseRef=value.case_ref;
   if(value.csrf_scope==='financial')this.financialAccess=true;
   return value;
  }catch(error){if(error instanceof ApiError)throw error;throw new ApiError(method==='GET'?'READ_UNAVAILABLE':'ACTION_UNCONFIRMED',503);}
  finally{clearTimeout(timeout);}
 }
 prepare(kind:string){return this.request('/operations/prepare','POST',{kind,client_nonce:crypto.randomUUID()});}
}
export function saveText(name:string,content:string){const url=URL.createObjectURL(new Blob([content],{type:'text/plain'}));const link=document.createElement('a');link.href=url;link.download=name;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
export function money(paise:number){if(!Number.isSafeInteger(paise)||paise<0)throw new Error('INVALID_AMOUNT');return new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',minimumFractionDigits:2,maximumFractionDigits:2}).format(paise/100);}
