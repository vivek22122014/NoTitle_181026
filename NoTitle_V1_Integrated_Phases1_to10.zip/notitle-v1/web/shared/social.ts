import type {ClientCoordinator} from './identity';
import {object,textValue,list} from './identity.ts';

export type Friend={relationship_handle:string;peer:{peer_handle:string;display_name:string;gender:string;topic_id:string;bio:string};revision:number;persistence:'temporary'|'saving'|'saved';presence:'available'|'busy'|'offline'};
export type SocialNotice={kind:'request'|'invite';handle:string;relationship?:string;interaction?:string;name:string;incoming:boolean;expires:number|null};
export type SocialState={items:Friend[];notices:SocialNotice[];loading:boolean;error:string;notice:string;revision:number};
const blank=():SocialState=>({items:[],notices:[],loading:false,error:'',notice:'',revision:0});
const ref=(value:unknown)=>{if(typeof value!=='string'||! /^[0-9a-f]{32}$/.test(value))throw new Error('INVALID_RESPONSE');return value;};
export function friend(value:unknown):Friend{
  const item=object(value),peer=object(item.peer);ref(item.relationship_handle);ref(peer.peer_handle);
  if(Object.keys(item).some(key=>!['relationship_handle','peer','revision','persistence','presence'].includes(key))||Object.keys(peer).some(key=>!['peer_handle','display_name','gender','topic_id','bio'].includes(key)))throw new Error('INVALID_RESPONSE');
  if(!Number.isInteger(item.revision)||Number(item.revision)<1||!['temporary','saving','saved'].includes(String(item.persistence))||!['available','busy','offline'].includes(String(item.presence)))throw new Error('INVALID_RESPONSE');
  for(const key of ['display_name','gender','topic_id','bio'])textValue(peer[key]);
  if(Array.from(String(peer.display_name)).length<2||Array.from(String(peer.display_name)).length>24||Array.from(String(peer.bio)).length>160||!['male','female','other'].includes(String(peer.gender)))throw new Error('INVALID_RESPONSE');
  return {relationship_handle:String(item.relationship_handle),peer:{peer_handle:String(peer.peer_handle),display_name:String(peer.display_name),gender:String(peer.gender),topic_id:String(peer.topic_id),bio:String(peer.bio)},revision:Number(item.revision),persistence:item.persistence as Friend['persistence'],presence:item.presence as Friend['presence']};
}
export class SocialClient{
  api:ClientCoordinator;state=blank();listeners=new Set<()=>void>();loading:Promise<void>|null=null;serial=0;
  constructor(api:ClientCoordinator){this.api=api;api.teardowns.add(()=>this.clear());api.conversation.subscribeEvents(event=>this.event(event));}
  subscribe=(listener:()=>void)=>{this.listeners.add(listener);return ()=>{this.listeners.delete(listener);};};
  snapshot=()=>this.state;serverSnapshot=()=>serverState;
  update(change:Partial<SocialState>){this.state={...this.state,...change,revision:this.state.revision+1};for(const listener of this.listeners)listener();}
  clear(){this.serial++;this.loading=null;this.update(blank());}
  async load(){
    if(this.loading)return this.loading;
    const serial=this.serial;this.update({loading:true,error:''});
    this.loading=(async()=>{try{const result=await this.api.request('/friends');if(serial===this.serial)this.update({items:list(result.items).slice(0,100).map(friend)});}catch{if(serial===this.serial)this.update({error:'Friends could not be loaded. Retry when connected.'});}finally{if(serial===this.serial){this.loading=null;this.update({loading:false});}}})();return this.loading;
  }
  async command(type:string,payload:unknown){
    this.update({error:''});
    try{await this.api.conversation.sendFeature(type,payload);}
    catch{this.update({error:'This action could not be sent. Check your connection and try again.'});}
  }
  request(){const interaction=this.api.conversation.state.interaction;if(interaction)return this.command('friend.request',{interaction_handle:interaction.interaction_handle});}
  respond(notice:SocialNotice,accept:boolean){return this.command(notice.kind==='request'?'friend.respond':'friend.invite.respond',notice.kind==='request'?{request_handle:notice.handle,accept}:{invite_handle:notice.handle,accept});}
  invite(item:Friend){return this.command('friend.invite',{relationship_handle:item.relationship_handle});}
  async remove(item:Friend){
    const serial=this.serial;this.update({error:''});
    try{await this.api.request('/friends/'+item.relationship_handle+'?expected_relationship_revision='+item.revision,'DELETE');if(serial===this.serial)this.update({items:this.state.items.filter(row=>row.relationship_handle!==item.relationship_handle),notice:'Friend removed. Any shared conversation has ended.'});}
    catch{if(serial===this.serial){await this.load();if(serial===this.serial)this.update({error:'Removal was not confirmed. Reload to check the current relationship.'});}}
  }
  async block(item:Friend){
    const serial=this.serial;this.update({error:''});
    try{const result=await this.api.request('/blocks','POST',{peer_handle:item.relationship_handle});if(serial===this.serial)this.update({items:this.state.items.filter(row=>row.relationship_handle!==item.relationship_handle),notice:result.persisted===true?'Blocked for this account.':'Blocked for this temporary identity.'});}
    catch{if(serial===this.serial)this.update({error:'Block persistence could not be confirmed. End the conversation and retry.'});}
  }
  event(input:unknown){
    const event=object(input);if(typeof event.type!=='string'||!event.type.startsWith('friend.'))return;
    const data=object(event.data);
    if(['friend.accepted','friend.saving','friend.persisted'].includes(event.type)){
      const item=friend(data.relationship);this.update({items:[...this.state.items.filter(row=>row.relationship_handle!==item.relationship_handle),item].slice(-100),notice:item.persistence==='saved'?'Friendship saved.':item.persistence==='saving'?'Saving friendship…':'Friendship is temporary until both people register.'});
    }else if(['friend.removed','friend.expired'].includes(event.type))this.update({items:this.state.items.filter(item=>item.relationship_handle!==data.relationship_handle)});
    else if(event.type==='friend.pending'){
      const peer=object(data.peer),notice:SocialNotice={kind:'request',handle:ref(data.request_handle),interaction:ref(data.interaction_handle),name:textValue(peer.display_name),incoming:data.incoming===true,expires:null};
      this.update({notices:[...this.state.notices.filter(item=>item.handle!==notice.handle),notice].slice(-100)});
    }else if(event.type==='friend.invite.sent'||event.type==='friend.invite.received'){
      const peer=object(data.peer);if(typeof data.expires_at!=='number'||!Number.isFinite(data.expires_at))return;
      const notice:SocialNotice={kind:'invite',handle:ref(data.invite_handle),relationship:ref(data.relationship_handle),name:textValue(peer.display_name),incoming:data.incoming===true,expires:data.expires_at*1000};
      this.update({notices:[...this.state.notices.filter(item=>item.handle!==notice.handle),notice].slice(-100)});
    }else if(event.type==='friend.request_closed'||event.type==='friend.invite.closed')this.update({notices:this.state.notices.filter(item=>item.handle!==(data.request_handle||data.invite_handle)),notice:'Request closed.'});
  }
  expire(now=Date.now()){
    const interaction=this.api.conversation.state.interaction?.interaction_handle;
    const notices=this.state.notices.filter(item=>item.kind==='request'?item.interaction===interaction:item.expires!==null&&item.expires>now);
    if(notices.length!==this.state.notices.length)this.update({notices});
  }
}
const serverState=blank();
