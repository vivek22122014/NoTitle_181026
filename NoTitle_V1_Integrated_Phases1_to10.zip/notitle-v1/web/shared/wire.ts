import schemas from './conversation.schema.json' with {type:'json'};
type Rule={type?:string;$ref?:string;$defs?:Record<string,Rule>;oneOf?:Rule[];anyOf?:Rule[];allOf?:Rule[];const?:unknown;enum?:unknown[];required?:string[];properties?:Record<string,Rule>;additionalProperties?:boolean|Rule;items?:Rule;minItems?:number;maxItems?:number;minLength?:number;maxLength?:number;pattern?:string;minimum?:number;maximum?:number};
export function validateWire(kind:'Command'|'Event'|'Hello'|'TicketView'|'Ack',input:unknown):void{
  const root=schemas[kind] as Rule;
  function check(rule:Rule,value:unknown):boolean{
    if(rule.$ref)return check(root.$defs![rule.$ref.split('/').at(-1)!],value);
    if(rule.oneOf)return rule.oneOf.filter(item=>check(item,value)).length===1;
    if(rule.anyOf)return rule.anyOf.some(item=>check(item,value));
    if(rule.allOf)return rule.allOf.every(item=>check(item,value));
    if('const'in rule&&rule.const!==value||rule.enum&&!rule.enum.includes(value))return false;
    switch(rule.type){
      case'null':return value===null;
      case'boolean':return typeof value==='boolean';
      case'integer':case'number':return typeof value==='number'&&Number.isFinite(value)&&(rule.type!=='integer'||Number.isSafeInteger(value))&&value>=(rule.minimum??-Infinity)&&value<=(rule.maximum??Infinity);
      case'string':return typeof value==='string'&&Array.from(value).length>=(rule.minLength||0)&&Array.from(value).length<=(rule.maxLength??Infinity)&&(!rule.pattern||new RegExp(rule.pattern).test(value));
      case'array':return Array.isArray(value)&&value.length>=(rule.minItems||0)&&value.length<=(rule.maxItems??Infinity)&&value.every(item=>check(rule.items||{},item));
      case'object':{
        if(!value||typeof value!=='object'||Array.isArray(value))return false;
        const record=value as Record<string,unknown>;
        return !rule.required?.some(key=>!Object.hasOwn(record,key))&&Object.entries(record).every(([key,item])=>rule.properties?.[key]?check(rule.properties[key],item):rule.additionalProperties===false?false:typeof rule.additionalProperties==='object'?check(rule.additionalProperties,item):true);
      }
      default:return true;
    }
  }
  if(!check(root,input))throw new Error('WIRE_CONTRACT');
}
