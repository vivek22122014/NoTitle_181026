/* One call owns its microphone, relay-only connection, and generation fences. */
export type AudioTransport=(type:string,payload:Record<string,unknown>)=>void;
export interface AudioIO { microphone:()=>Promise<MediaStream>; peer:(config:RTCConfiguration)=>RTCPeerConnection; later:(run:()=>void,ms:number)=>ReturnType<typeof setInterval>; cancel:(timer:ReturnType<typeof setInterval>)=>void }
const browser:AudioIO={microphone:()=>navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true},video:false}),peer:config=>new RTCPeerConnection(config),later:(run,ms)=>setInterval(run,ms),cancel:timer=>clearInterval(timer)};
export class AudioSession {
 private generation=0;private negotiation=0;
 private pc:RTCPeerConnection|null=null;private stream:MediaStream|null=null;
 private pending:RTCIceCandidateInit[]=[];
 private pendingDescription:{type:RTCSdpType;sdp:string;callId:string;revision:number}|null=null;
 private renewal:ReturnType<typeof setInterval>|null=null;
 callId='';private send:AudioTransport;private remote:HTMLAudioElement;private onError:(message:string)=>void;private io:AudioIO;
 constructor(send:AudioTransport,remote:HTMLAudioElement,onError:(message:string)=>void,io:AudioIO=browser){this.send=send;this.remote=remote;this.onError=onError;this.io=io;}
 private current(generation:number,callId:string,revision:number){return generation===this.generation&&this.callId===callId&&this.negotiation===revision;}
 private signal(type:string,payload:Record<string,unknown>={}){this.send(type,{call_id:this.callId,negotiation_revision:this.negotiation,...payload});}
 private failure(message:string){const callId=this.callId;this.stop();try{if(callId)this.send('call.end',{call_id:callId});}catch{}this.onError(message);}
 async start(callId:string,servers:RTCIceServer[],offerer:boolean,revision=2){
  this.stop();const generation=++this.generation;this.callId=callId;this.negotiation=revision;
  try{
   // This method is called only for a server mutual-consent call.connect event.
   const stream=await this.io.microphone();
   if(!this.current(generation,callId,revision)){stream.getTracks().forEach(track=>track.stop());return;}
   this.stream=stream;
   const pc=this.io.peer({iceServers:servers,iceTransportPolicy:'relay',bundlePolicy:'max-bundle',rtcpMuxPolicy:'require'});this.pc=pc;
   stream.getTracks().forEach(track=>pc.addTrack(track,stream));
   const codecs=typeof RTCRtpSender==='undefined'?[]:RTCRtpSender.getCapabilities('audio')?.codecs.filter(codec=>codec.mimeType.toLowerCase()==='audio/opus');
   if(codecs?.length)pc.getTransceivers()[0]?.setCodecPreferences(codecs);
   pc.onicecandidate=event=>{if(generation!==this.generation||!event.candidate)return;if(event.candidate.type==='relay')try{this.signal('call.ice',{candidate:event.candidate.candidate});}catch{this.failure('Audio signaling interrupted.');}};
   pc.ontrack=event=>{if(generation===this.generation){this.remote.srcObject=event.streams[0]??new MediaStream([event.track]);void this.remote.play().catch(()=>this.onError('Tap the audio player to enable sound.'));}};
   pc.onconnectionstatechange=()=>{if(generation!==this.generation)return;try{if(pc.connectionState==='connected')this.signal('call.connected');else if(['failed','disconnected','closed'].includes(pc.connectionState))this.failure('Audio interrupted. Start a fresh call when available.');}catch{this.failure('Audio signaling interrupted.');}};
   const description=this.pendingDescription;this.pendingDescription=null;
   if(description)await this.description(description.type,description.sdp,description.callId,description.revision);
   if(!this.current(generation,callId,revision))return;
   if(offerer)this.renewal=this.io.later(()=>{if(this.callId===callId)try{this.signal('call.refresh');}catch{this.failure('Audio renewal interrupted.');}},300000);
   if(offerer){const offer=await pc.createOffer();if(!this.current(generation,callId,revision))return;await pc.setLocalDescription(offer);if(this.current(generation,callId,revision))this.signal('call.sdp',{description_type:'offer',sdp:pc.localDescription!.sdp});}
  }catch{if(this.current(generation,callId,revision))this.failure('Microphone access or audio connection failed. Text remains available.');}
 }
 async description(type:RTCSdpType,sdp:string,callId:string,revision=this.negotiation){
  const pc=this.pc,generation=this.generation;if(this.callId!==callId||revision!==this.negotiation)return;
  if(!pc){this.pendingDescription={type,sdp,callId,revision};return;}
  try{
   await pc.setRemoteDescription({type,sdp});if(!this.current(generation,callId,revision))return;
   const candidates=this.pending;this.pending=[];
   for(const candidate of candidates){await pc.addIceCandidate(candidate);if(!this.current(generation,callId,revision))return;}
   if(type==='offer'){const answer=await pc.createAnswer();if(!this.current(generation,callId,revision))return;await pc.setLocalDescription(answer);if(this.current(generation,callId,revision))this.signal('call.sdp',{description_type:'answer',sdp:pc.localDescription!.sdp});}
  }catch{if(this.current(generation,callId,revision))this.failure('Audio negotiation failed.');}
 }
 async candidate(value:string,callId:string,revision=this.negotiation){
  const generation=this.generation;if(this.callId!==callId||revision!==this.negotiation)return;
  const candidate={candidate:value,sdpMid:'0',sdpMLineIndex:0};
  if(!this.pc?.remoteDescription){if(this.pending.length<64)this.pending.push(candidate);else this.failure('Audio candidate limit reached.');return;}
  try{await this.pc.addIceCandidate(candidate);}catch{if(this.current(generation,callId,revision))this.failure('Audio candidate failed.');}
 }
 async refresh(callId:string,servers:RTCIceServer[],offerer:boolean,revision=this.negotiation+1){
  const pc=this.pc,generation=this.generation;if(!pc||this.callId!==callId||revision<=this.negotiation)return;
  this.negotiation=revision;this.pending=[];this.pendingDescription=null;
  try{pc.setConfiguration({...pc.getConfiguration(),iceServers:servers,iceTransportPolicy:'relay'});if(offerer){const offer=await pc.createOffer({iceRestart:true});if(!this.current(generation,callId,revision))return;await pc.setLocalDescription(offer);if(this.current(generation,callId,revision))this.signal('call.sdp',{description_type:'offer',sdp:pc.localDescription!.sdp});}}
  catch{if(this.current(generation,callId,revision))this.failure('Audio renewal failed. Start a fresh call when available.');}
 }
 mute(value:boolean){this.stream?.getAudioTracks().forEach(track=>track.enabled=!value);}
 stop(){
  if(this.renewal)this.io.cancel(this.renewal);this.renewal=null;this.pendingDescription=null;
  this.generation++;this.callId='';this.negotiation=0;this.pending=[];
  if(this.pc){this.pc.onconnectionstatechange=null;this.pc.ontrack=null;this.pc.onicecandidate=null;this.pc.close();this.pc=null;}
  this.stream?.getTracks().forEach(track=>track.stop());this.stream=null;this.remote.srcObject=null;
 }
}
