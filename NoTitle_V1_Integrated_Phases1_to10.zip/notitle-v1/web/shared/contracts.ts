// V1 peer projection; schemas in contracts/generated are the validation authority.
export type Peer = {peer_handle: string; display_name: string; gender: "male"|"female"|"other"; topic_id: string; bio: string};
export type Result<T> = {data:T;request_id:string}|{error:{code:string;message:string;retryable:boolean};request_id:string};
