import schemas from './identity.schema.json' with {type:'json'};
import {ConversationClient} from './conversation.ts';
import type {BootstrapView,OwnerResponse,PreparedView} from './identity.generated';

type Schema={type?:string;properties?:Record<string,Schema>;required?:string[];additionalProperties?:boolean|Schema;items?:Schema;$defs?:Record<string,Schema>;$ref?:string;anyOf?:Schema[];enum?:unknown[];const?:unknown;minLength?:number;maxLength?:number;minItems?:number;maxItems?:number;minimum?:number;maximum?:number;pattern?:string};
type ObjectValue=Record<string,unknown>;
export function object(value:unknown):ObjectValue{if(!value||typeof value!=='object'||Array.isArray(value))throw new Error('INVALID_RESPONSE');return value as ObjectValue;}
export function textValue(value:unknown):string{if(typeof value!=='string')throw new Error('INVALID_RESPONSE');return value;}
export function list(value:unknown):unknown[]{if(!Array.isArray(value))throw new Error('INVALID_RESPONSE');return value;}
export function validateContract(name:string,value:unknown):void{
  const schema=(schemas as unknown as Record<string,Schema>)[name];if(!schema)throw new Error('UNKNOWN_CONTRACT');
  function check(rule:Schema,input:unknown):boolean{
    if(rule.$ref)return check(schema.$defs![rule.$ref.split('/').at(-1)!],input);
    if(rule.anyOf)return rule.anyOf.some(item=>check(item,input));
    if('const' in rule&&rule.const!==input)return false;
    if(rule.enum&&!rule.enum.includes(input))return false;
    switch(rule.type){
      case'null':return input===null;
      case'string':return typeof input==='string'&&Array.from(input).length>=(rule.minLength||0)&&Array.from(input).length<=(rule.maxLength??Infinity)&&(!rule.pattern||new RegExp(rule.pattern).test(input));
      case'number':case'integer':return typeof input==='number'&&Number.isFinite(input)&&(rule.type!=='integer'||Number.isInteger(input))&&input>=(rule.minimum??-Infinity)&&input<=(rule.maximum??Infinity);
      case'boolean':return typeof input==='boolean';
      case'array':return Array.isArray(input)&&input.length>=(rule.minItems||0)&&input.length<=(rule.maxItems??Infinity)&&input.every(item=>check(rule.items||{},item));
      case'object':{
        if(!input||typeof input!=='object'||Array.isArray(input))return false;
        const data=input as ObjectValue;
        if(rule.required?.some(key=>!(key in data)))return false;
        return Object.entries(data).every(([key,item])=>rule.properties?.[key]?check(rule.properties[key],item):rule.additionalProperties===false?false:typeof rule.additionalProperties==='object'?check(rule.additionalProperties,item):true);
      }
      default:return true;
    }
  }
  if(!check(schema,value))throw new Error('INVALID_RESPONSE');
}
const inputs:Record<string,string>={'POST /auth/guest':'Guest','POST /auth/register':'Register','POST /auth/login':'Login','POST /auth/recover':'Recover','POST /auth/reauth':'Reauth','POST /operations/prepare':'Prepare','POST /me/password':'PasswordChange','POST /me/recovery/rotate':'RotateRecovery','PATCH /me/profile':'ProfileUpdate','PATCH /me/preferences':'Preferences','POST /me/consents':'ConsentChange','POST /me/policy-acceptance':'PolicyAcceptance','POST /privacy/requests':'PrivacyRequest','POST /privacy/exports':'ExportRequest','POST /privacy/delete':'Delete','POST /privacy/status/access':'Access','POST /support/access':'Access','POST /support/cases':'CaseCreate'};
export class IdentityError extends Error{
  code:string;status:number;data:ObjectValue;
  constructor(code:string,status:number,data:ObjectValue={}){super(code);this.code=code;this.status=status;this.data=data;}
}
export type IdentityState={phase:'idle'|'loading'|'ready'|'unavailable';boot:BootstrapView|null;owner:OwnerResponse|null;busy:boolean;error:string;notice:string;generation:number};
export class ClientCoordinator{
  state:IdentityState={phase:'idle',boot:null,owner:null,busy:false,error:'',notice:'',generation:0};
  listeners=new Set<()=>void>();controllers=new Set<AbortController>();starting:Promise<void>|null=null;
  csrf='';scoped:Record<string,string>={};teardowns=new Set<()=>void>();
  conversation:ConversationClient;
  constructor(){this.conversation=new ConversationClient(this);}
  subscribe=(listener:()=>void)=>{this.listeners.add(listener);return ()=>{this.listeners.delete(listener);};};
  snapshot=()=>this.state;
  serverSnapshot=()=>serverState;
  update(change:Partial<IdentityState>){this.state={...this.state,...change};for(const listener of this.listeners)listener();}
  clear(){for(const controller of this.controllers)controller.abort();this.controllers.clear();for(const teardown of this.teardowns)teardown();this.csrf='';this.scoped={};this.update({owner:null,boot:null,generation:this.state.generation+1,error:'',notice:'',busy:false});}
  async request(path:string,method='GET',body?:unknown,contract?:string,authority?:'account'|'case'|'financial'|'deletion'):Promise<ObjectValue>{
    if(!path.startsWith('/')||path.startsWith('//')||path.includes('..')||path.includes('://')||path.includes('#')||/[\u0000-\u001f\\]/.test(path)||/[?&](?:secret|token|password|code|recovery_secret|csrf)=/i.test(path))throw new Error('INVALID_ROUTE');
    const input=inputs[method+' '+path]||(method==='POST'&&/^\/support\/cases\/[0-9a-f]{32}\/messages$/.test(path)?'CaseMessage':null);
    if(input)try{validateContract(input,body);}catch{throw new IdentityError('INVALID_INPUT',422);}
    const generation=this.state.generation,controller=new AbortController();this.controllers.add(controller);
    const timer=setTimeout(()=>controller.abort(),15000);
    const csrf=authority&&authority!=='account'?this.scoped[authority]||'':this.csrf;
    try{
      const response=await fetch('/api/v1'+path,{method,credentials:'same-origin',cache:'no-store',redirect:'error',signal:controller.signal,
        headers:{...(authority?{'X-NT-Authority':authority}:{}),...(method!=='GET'?{'X-CSRF-Token':csrf}:{}),...(body===undefined?{}:{'Content-Type':'application/json'})},...(body===undefined?{}:{body:JSON.stringify(body)})});
      const reader=response.body?.getReader();if(!reader)throw new Error('INVALID_RESPONSE');
      const chunks:Uint8Array[]=[];let length=0;
      while(true){const part=await reader.read();if(part.done)break;length+=part.value.byteLength;if(length>512*1024){await reader.cancel();throw new Error('INVALID_RESPONSE');}chunks.push(part.value);}
      const bytes=new Uint8Array(length);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
      const envelope=object(JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes)));if(generation!==this.state.generation)throw new Error('STALE_RESPONSE');
      if(!response.ok){const failure=object(envelope.error||{});throw new IdentityError(typeof failure.code==='string'?failure.code:'REQUEST_DENIED',response.status,envelope.data?object(envelope.data):{});}
      const data=object(envelope.data);if(contract)validateContract(contract,data);
      if(typeof data.csrf==='string'){
        if(data.csrf_scope==='case'||data.csrf_scope==='financial'||data.csrf_scope==='deletion')this.scoped[data.csrf_scope]=data.csrf;
        else this.csrf=data.csrf;
      }
      return data;
    }catch(error){if(error instanceof IdentityError)throw error;throw new IdentityError(error instanceof Error&&error.message==='INVALID_RESPONSE'?'INVALID_RESPONSE':'UNCONFIRMED_RESULT',0);}
    finally{clearTimeout(timer);this.controllers.delete(controller);}
  }
  async start():Promise<void>{
    if(this.starting)return this.starting;
    this.starting=this.refresh().finally(()=>{this.starting=null;});return this.starting;
  }
  async refresh():Promise<void>{
    const generation=this.state.generation;
    this.update({phase:'loading',error:''});
    try{
      const boot=await this.request('/bootstrap','GET',undefined,'BootstrapView') as unknown as BootstrapView;
      const previous=this.state.owner;
      const owner=boot.identity_kind==='account'||boot.identity_kind==='guest'?await this.request('/me','GET',undefined,'OwnerResponse') as unknown as OwnerResponse:null;
      if(generation!==this.state.generation)return;
      if(previous&&(!owner||previous.ref!==owner.ref)){for(const controller of this.controllers)controller.abort();for(const teardown of this.teardowns)teardown();this.update({generation:generation+1,busy:false});}
      this.scoped=boot.scoped_csrf;this.update({phase:'ready',boot,owner});
    }catch(error){if(generation===this.state.generation){this.clear();this.update({phase:'unavailable',error:describe(error)});}}
  }
  async prepare(kind:'recovery'|'case'|'deletion'|'financial'):Promise<PreparedView>{
    return await this.request('/operations/prepare','POST',{kind,client_nonce:crypto.randomUUID()},'PreparedView') as unknown as PreparedView;
  }
  async syncAuthority():Promise<void>{
    // A Set-Cookie header may arrive even if its JSON acknowledgment is lost.
    // Refresh read authority without unmounting the caller's exact RAM intent.
    const generation=this.state.generation,previous=this.state.owner;
    const boot=await this.request('/bootstrap','GET',undefined,'BootstrapView') as unknown as BootstrapView;
    const owner=boot.identity_kind==='account'||boot.identity_kind==='guest'?await this.request('/me','GET',undefined,'OwnerResponse') as unknown as OwnerResponse:null;
    if(generation!==this.state.generation)return;
    if(previous&&(!owner||previous.ref!==owner.ref||previous.identity_kind!==owner.identity_kind))this.clear();
    this.csrf=boot.csrf;this.scoped=boot.scoped_csrf;this.update({phase:'ready',boot,owner});
  }
  async perform(task:()=>Promise<void>){
    if(this.state.busy)return;
    this.update({busy:true,error:'',notice:''});
    const generation=this.state.generation;
    try{await task();}catch(error){if(generation===this.state.generation){this.update({error:describe(error)});if(error instanceof IdentityError&&error.code==='POLICY_CHANGED'){await this.refresh();this.update({error:'Policy text changed. Review the new version and make fresh choices.'});}else if(error instanceof IdentityError&&error.code==='CSRF_INVALID'){try{await this.syncAuthority();this.update({error:'Session proof refreshed. Retry the same saved action to check its result. No mutation was automatically retried.'});}catch{this.update({error:'Session proof could not be refreshed. Keep saved proofs and check account access before changing the action.'});}}}}
    finally{if(generation===this.state.generation)this.update({busy:false});}
  }
  async logout(all=false){await this.request(all?'/auth/logout-all':'/auth/logout','POST',{});this.clear();await this.refresh();}
}
const serverState:IdentityState={phase:'idle',boot:null,owner:null,busy:false,error:'',notice:'',generation:0};
export const identityClient=new ClientCoordinator();
export function describe(error:unknown):string{
  const code=error instanceof IdentityError?error.code:'UNCONFIRMED_RESULT';
  const messages:Record<string,string>={CREDENTIALS_INVALID:'The username or credential could not be verified.',CURRENT_CONSENTS_REQUIRED:'Confirm adulthood, Terms and core processing before entering.',POLICY_CHANGED:'The policy changed. Review it and make fresh choices.',REVISION_CONFLICT:'Your account changed. Refresh before confirming again.',REAUTH_REQUIRED:'Verify your current password before this sensitive action.',AUTHENTICATION_REQUIRED:'Your account authority expired. Sign in again.',INVALID_RESPONSE:'The service returned an unexpected response. Nothing is assumed successful.',UNCONFIRMED_RESULT:'The result could not be confirmed. Keep the saved code or receipt and retry the same action or check status before submitting again.',OPERATION_AUTHORITY_CHANGED:'A later credential change replaced this action. Use your current credentials.',SESSION_LIMIT:'Choose one owned session to revoke before continuing.',PREPARATION_REQUIRED:'The prepared credential expired or does not match. Keep saved proofs and prepare a new action only after checking the previous outcome.',RATE_LIMITED:'Please wait before trying again.',AUTH_BUSY:'Authentication is busy. Please retry shortly.'};
  return messages[code]||code.replaceAll('_',' ').toLowerCase()+'.';
}
