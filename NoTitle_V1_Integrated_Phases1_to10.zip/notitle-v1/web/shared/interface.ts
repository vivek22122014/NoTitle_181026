/** Read-only presentation contracts. These are not backend DTOs or authorization. */
export type PublicScreen = 'U01'|'U02'|'U03'|'U04'|'U05'|'U06'|'U07'|'U08'|'U09';
export type StaffScreen = 'A01'|'A02';
export type ViewState = 'ready'|'loading'|'empty'|'validation'|'error'|'forbidden'|'stale'|'rate-limited'|'maintenance';
export const viewStates: readonly ViewState[] = ['ready','loading','empty','validation','error','forbidden','stale','rate-limited','maintenance'];
export type Stage = {id:string;label:string;description:string};
export type Board<S extends string> = {id:S;label:string;route:string;stages:readonly Stage[]};
export type MessageFixture = {id:string;sender:'you'|'peer'|'moderator';body:string;status:'Accepted in memory'|'Delivered'|'Sent'|'Seen by Moderator'};
export type FriendFixture = {id:string;name:string;persistence:'Temporary'|'Saving'|'Saved';presence:'Available'|'Busy'|'Offline'};
export type CaseFixture = {id:string;subject:string;category:'general'|'privacy'|'payment'|'safety';status:'open'|'waiting_user'|'closed';unread:number};
export type MetricFixture = {label:string;value:string;unit:string;complete:boolean};
