'use client';
import {useEffect,useId,useRef,type ReactNode} from 'react';

/** Native modal focus containment, Escape, inert background and focus restoration. */
export function Dialog({open,title,onClose,children,sheet=false}:{open:boolean;title:string;onClose:()=>void;children:ReactNode;sheet?:boolean}){
  const ref=useRef<HTMLDialogElement>(null),heading=useId(),close=useRef(onClose);close.current=onClose;
  useEffect(()=>{
    if(!open)return;
    const dialog=ref.current;if(!dialog)return;
    const trigger=document.activeElement instanceof HTMLElement?document.activeElement:null;
    dialog.showModal();
    return ()=>{if(dialog.open)dialog.close();trigger?.focus();};
  },[open]);
  return <dialog ref={ref} aria-labelledby={heading} className={`nt-dialog ${sheet?'sheet':''}`} onCancel={event=>{event.preventDefault();close.current();}}>
    <div className="row spread"><h2 id={heading}>{title}</h2><button type="button" className="secondary" autoFocus onClick={onClose}>Close</button></div>{children}
  </dialog>;
}
