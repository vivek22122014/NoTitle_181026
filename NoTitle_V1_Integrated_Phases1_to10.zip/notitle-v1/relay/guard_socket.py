"""Local feasibility helper: fixed-schema JSON over SO_PEERCRED Unix socket.
It owns an isolated table only. Run only on a disposable relay host after review.
One request replaces the short-lived allowed pairs; arbitrary nft input is rejected.
"""
import argparse
import json
import os
import pwd
from pathlib import Path
import socket
import struct
import subprocess
from relay.guard import ruleset


def transaction(request):
    if set(request)!={"pairs"} or not isinstance(request["pairs"],list) or len(request["pairs"])>800:
        raise ValueError("SCHEMA")
    lines=["flush set inet notitle_guard pairs"]
    seen=set()
    for pair in request["pairs"]:
        if not isinstance(pair,list) or len(pair)!=3 or any(type(x) is not int for x in pair): raise ValueError("PAIR")
        a,b,ttl=pair
        if not 49152<=a<=50175 or not 49152<=b<=50175 or a==b or not 1<=ttl<=5000 or (a,b) in seen:
            raise ValueError("BOUNDARY")
        seen.add((a,b))
        lines.append(f"add element inet notitle_guard pairs {{ {a} . {b} timeout {ttl}ms }}")
    return "\n".join(lines)+"\n"

def apply(script):
    subprocess.run(["nft","-f","-"],input=script,text=True,check=True,capture_output=True,timeout=2)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--relay-ip",required=True)
    parser.add_argument("--controller-uid",type=int,required=True)
    parser.add_argument("--socket",type=Path,default=Path("/run/notitle-relay/guard.sock"))
    args=parser.parse_args()
    if os.geteuid()!=0: raise SystemExit("Helper requires isolated host root/CAP_NET_ADMIN")
    if args.socket.exists(): raise SystemExit("Existing socket: inspect prior helper before cleanup")
    # Existing table is never flushed globally. Reject startup until operator inspects it.
    apply(ruleset(args.relay_ip))
    args.socket.parent.mkdir(mode=0o750,parents=True,exist_ok=True)
    controller_gid=pwd.getpwuid(args.controller_uid).pw_gid
    os.chown(args.socket.parent,0,controller_gid)
    sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
    sock.bind(str(args.socket)); os.chmod(args.socket,0o660); os.chown(args.socket,0,controller_gid)
    sock.listen(8)
    try:
        while True:
            conn,_=sock.accept()
            with conn:
                conn.settimeout(1)
                _,uid,_=struct.unpack("3i",conn.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,12))
                if uid!=args.controller_uid: continue
                data=b""
                try:
                    while not data.endswith(b"\n"):
                        chunk=conn.recv(65537-len(data))
                        if not chunk: raise ValueError("TRUNCATED")
                        data+=chunk
                        if len(data)>65536: raise ValueError("LIMIT")
                    apply(transaction(json.loads(data)))
                    conn.sendall(b'{"ok":true}\n')
                except Exception:
                    # Kernel timeouts expire existing permissions even if helper failure persists.
                    try: apply("flush set inet notitle_guard pairs\n")
                    except Exception: pass
                    try: conn.sendall(b'{"ok":false}\n')
                    except OSError: pass
    finally:
        sock.close(); args.socket.unlink(missing_ok=True)
        apply("flush set inet notitle_guard pairs\n")

if __name__=="__main__": main()
