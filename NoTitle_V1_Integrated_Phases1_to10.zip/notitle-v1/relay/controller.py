"""mTLS relay control plane. All calls remain unavailable until packet qualification.

Run one process per clean coturn boot. A controller fault removes permissions and
cannot be recovered by silently reusing old ports or credentials.
"""
import asyncio
import base64
import hashlib
import hmac
import json
import math
import re
import ssl
import time
from pathlib import Path
from uuid import uuid4
from relay.guard import Guard,parse_sessions,RelayDenied
from relay.control_spike import listing,send_guard


class Controller:
    def __init__(self,config):
        self.config=config;self.guard=Guard(config['relay_ip'])
        self.calls={};self.sequence=0;self.revoked={};self.owner_last=0
        self.boot=uuid4().hex;self.lock=asyncio.Lock()
        self.history_path=Path(config['history_file'])
        if self.history_path.exists():
            history=json.loads(self.history_path.read_text())
            self.guard.history={int(port):tuple(value) for port,value in history['ports'].items()}
            self.guard.revoked=set(history['revoked'])
            # A controller restart requires an operator-verified clean relay restart.
            self.guard.contained=True
        self.password=Path(config['cli_password_file']).read_text().strip()
        self.secret=Path(config['turn_secret_file']).read_bytes().strip()
        self.pending=False

    async def command(self,value):
        # Only exact validated session cancellation is accepted; no user CLI command passthrough.
        if not re.fullmatch(r'cs [0-9]{18}',value):raise RelayDenied('COMMAND_INVALID')
        reader,writer=await asyncio.wait_for(asyncio.open_connection('127.0.0.1',self.config['cli_port'],limit=262145),2)
        try:
            async with asyncio.timeout(2):
                await reader.readuntil(b'Enter password:');writer.write(self.password.encode()+b'\n');await writer.drain()
                await reader.readuntil(b'> ');writer.write(value.encode()+b'\n');await writer.drain();await reader.readuntil(b'> ')
        finally:writer.close();await writer.wait_closed()

    async def allocations(self,username):
        return parse_sessions(await listing(self.config['cli_port'],self.password,username),username,self.config['relay_ip'])

    async def apply(self):
        self.guard.transaction()  # Enforces owner expiry and aggregate entry bound.
        pairs=[];now=time.monotonic()
        for allowed,until in self.guard.calls.values():
            ttl=math.floor((until-now)*1000)
            if ttl>0:pairs.extend([a,b,min(ttl,5000)] for a,b in sorted(allowed))
        temporary=self.history_path.with_suffix('.next')
        temporary.parent.mkdir(parents=True,exist_ok=True)
        import os
        fd=os.open(temporary,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
        with os.fdopen(fd,'w') as file:
            json.dump({'ports':self.guard.history,'revoked':sorted(self.guard.revoked)},file);file.flush();os.fsync(file.fileno())
        os.replace(temporary,self.history_path)
        await asyncio.to_thread(send_guard,self.config['guard_socket'],pairs)

    def credentials(self,ref):
        expiry=int(time.time())+600
        users=[f'{expiry}:{self.guard.epoch}:{ref}:{side}:{uuid4().hex}' for side in (0,1)]
        self.calls[ref]={'users':users,'until':time.monotonic()+20,'ended':False,'connected':False,'guard_ref':uuid4().hex}
        host=self.config['turn_domain']
        servers={str(index):[{'urls':[f'turn:{host}:3478?transport=udp',f'turn:{host}:3478?transport=tcp',f'turns:{host}:443?transport=tcp'],
            'username':username,'credential':base64.b64encode(hmac.new(self.secret,username.encode(),hashlib.sha1).digest()).decode()}] for index,username in enumerate(users)}
        return {'ice_servers':servers,'expires_at':expiry}

    async def end(self,ref):
        call=self.calls.get(ref)
        self.guard.end(call['guard_ref'] if call else ref);await self.apply()  # Deny packets before attempting cancellation.
        if not call:return {'allocations_absent':True}
        call['ended']=True
        for username in call['users']:
            self.revoked[username]=int(username.split(':')[0])+60
            for allocation in await self.allocations(username):await self.command('cs '+allocation.session)
        remaining=[]
        for username in call['users']:remaining.extend(await self.allocations(username))
        if remaining:return {'allocations_absent':False}
        self.calls.pop(ref,None)
        return {'allocations_absent':True}

    async def request(self,path,payload):
        async with self.lock:
            epoch=payload.get('owner_epoch')
            if type(epoch) is not int or epoch<1:raise RelayDenied('OWNER_INVALID')
            if path=='/heartbeat':
                if set(payload)!={'owner_epoch','calls'} or not isinstance(payload['calls'],list) or len(payload['calls'])>25:raise RelayDenied('SCHEMA')
                self.sequence+=1;self.guard.owner_lease(epoch,self.sequence);self.owner_last=time.monotonic()
                live=set(payload['calls'])
                if not all(re.fullmatch(r'[a-f0-9]{32}',ref) for ref in live):raise RelayDenied('CALL_REFERENCE')
                for ref,call in self.calls.items():
                    if ref in live and not call['ended']:call['until']=time.monotonic()+20
                return {'connected':[ref for ref,call in self.calls.items() if call['connected'] and not call['ended']]}
            if epoch!=self.guard.epoch or time.monotonic()>=self.guard.owner_until or self.guard.contained:raise RelayDenied('NO_OWNER')
            if path=='/calls':
                if set(payload)!={'owner_epoch','call_id','members'} or not re.fullmatch(r'[a-f0-9]{32}',payload['call_id']):raise RelayDenied('SCHEMA')
                ref=payload['call_id']
                if ref in self.calls or ref in self.guard.revoked or len(self.calls)>=25:raise RelayDenied('CALL_UNAVAILABLE')
                return self.credentials(ref)
            candidate=re.fullmatch(r'/calls/([a-f0-9]{32})/candidate',path)
            if candidate and set(payload)=={'owner_epoch','side','port'}:
                ref=candidate[1];call=self.calls.get(ref)
                if not call or call['ended'] or type(payload['side']) is not int or payload['side'] not in (0,1) or type(payload['port']) is not int:raise RelayDenied('CALL_EXPIRED')
                allocations=await self.allocations(call['users'][payload['side']])
                # Listing is pinned to the exact issued participant username.
                return {'authorized':any(allocation.port==payload['port'] for allocation in allocations)}
            refresh=re.fullmatch(r'/calls/([a-f0-9]{32})/refresh',path)
            if refresh and set(payload)=={'owner_epoch'}:
                ref=refresh[1]
                if ref not in self.calls or self.calls[ref]['ended']:raise RelayDenied('CALL_EXPIRED')
                result=await self.end(ref)
                if not result['allocations_absent']:raise RelayDenied('TEARDOWN_PENDING')
                return self.credentials(ref)
            match=re.fullmatch(r'/calls/([a-f0-9]{32})/end',path)
            if match and set(payload)=={'owner_epoch'}:return await self.end(match[1])
            raise RelayDenied('NOT_FOUND')

    async def tick(self):
        while True:
            async with self.lock:
                try:
                    current=time.monotonic()
                    if self.guard.epoch and current>=self.guard.owner_until:self.guard.deny_all()
                    for ref,call in tuple(self.calls.items()):
                        if self.guard.contained or call['ended'] or current>=call['until']:
                            await self.end(ref);continue
                        left,right=await asyncio.gather(*(self.allocations(user) for user in call['users']))
                        if left and right:
                            self.guard.authorize(call['guard_ref'],left,right,call['until'],self.guard.epoch)
                            call['connected']=True
                    # Revoked credentials may still authenticate until their REST expiry;
                    # they never regain packet permission, and fresh allocations are cancelled.
                    for user,until in tuple(self.revoked.items()):
                        if until<time.time():self.revoked.pop(user,None);continue
                        for allocation in await self.allocations(user):await self.command('cs '+allocation.session)
                    if len(self.revoked)>1024:raise RelayDenied('REVOCATION_BUDGET')
                    await self.apply()
                except Exception:
                    self.guard.deny_all()
                    try:await asyncio.to_thread(send_guard,self.config['guard_socket'],[])
                    except Exception:pass
            await asyncio.sleep(.5)


async def serve(config):
    controller=Controller(config)
    context=ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    context.load_cert_chain(config['certificate'],config['key']);context.load_verify_locations(config['ca'])
    context.verify_mode=ssl.CERT_REQUIRED;context.minimum_version=ssl.TLSVersion.TLSv1_2
    async def client(reader,writer):
        try:
            async with asyncio.timeout(3):
                raw=await reader.readuntil(b'\r\n\r\n')
                if len(raw)>8192:raise RelayDenied('HEADER_LIMIT')
                lines=raw.decode('ascii').split('\r\n');method,path,version=lines[0].split(' ')
                pairs=[line.split(':',1) for line in lines[1:] if line]
                names=[name.lower() for name,_ in pairs]
                if len(names)!=len(set(names)) or 'transfer-encoding' in names or method!='POST' or version!='HTTP/1.1':raise RelayDenied('HTTP_BOUNDARY')
                headers={name.lower():value.strip() for name,value in pairs}
                length=int(headers.get('content-length','0'))
                if not 0<length<=8192 or headers.get('content-type')!='application/json':raise RelayDenied('BODY_LIMIT')
                body=await reader.readexactly(length);result=await controller.request(path,json.loads(body))
                response=json.dumps(result).encode();status=b'200 OK'
        except Exception:response=b'{"error":"relay_unavailable"}';status=b'503 Service Unavailable'
        try:
            writer.write(b'HTTP/1.1 '+status+b'\r\nContent-Type: application/json\r\nConnection: close\r\nContent-Length: '+str(len(response)).encode()+b'\r\n\r\n'+response)
            await writer.drain()
        finally:writer.close();await writer.wait_closed()
    server=await asyncio.start_server(client,config['control_bind'],config.get('control_port',9443),ssl=context,limit=8193)
    ticker=asyncio.create_task(controller.tick())
    try:
        async with server:await server.serve_forever()
    finally:
        ticker.cancel();await asyncio.gather(ticker,return_exceptions=True)
        await asyncio.to_thread(send_guard,config['guard_socket'],[])

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--config',required=True,type=Path)
    args=parser.parse_args()
    if args.config.stat().st_mode&0o077:raise SystemExit('Private controller configuration required')
    asyncio.run(serve(json.loads(args.config.read_text())))
