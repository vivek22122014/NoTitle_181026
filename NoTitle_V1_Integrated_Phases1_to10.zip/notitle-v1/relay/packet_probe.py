"""Kernel self-relay UDP probe; NOT a substitute for browser/coturn RTP evidence.
Run with coturn stopped on an isolated relay, after guard_socket is running.
"""
import argparse,json,socket,time
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--relay-ip',required=True);p.add_argument('--socket',default='/run/notitle-relay/guard.sock')
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    def permission(pairs):
        with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as control:
            control.settimeout(2);control.connect(args.socket)
            control.sendall(json.dumps({'pairs':pairs}).encode()+b'\n')
            if control.recv(1024)!=b'{"ok":true}\n':raise RuntimeError('Guard rejected request')
    with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as sender,socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as receiver:
        sender.bind((args.relay_ip,49152));receiver.bind((args.relay_ip,49153));receiver.settimeout(.15)
        def received():
            token=str(time.monotonic_ns()).encode()
            sender.sendto(token,(args.relay_ip,49153))
            deadline=time.monotonic()+.2
            while time.monotonic()<deadline:
                try:
                    if receiver.recv(1024)==token:return True
                except TimeoutError:return False
            return False
        try:
            permission([])
            if received():raise RuntimeError('Default deny failed')
            permission([[49152,49153,1500],[49153,49152,1500]])
            if not received():raise RuntimeError('Positive self-relay path failed; do not weaken firewall')
            start=time.monotonic();last_received=start
            while time.monotonic()-start<3:
                if received():last_received=time.monotonic()
                time.sleep(.03)
            if last_received-start>1.7:raise RuntimeError('Permission expiry exceeded probe bound')
            permission([[49152,49153,5000],[49153,49152,5000]])
            if not received():raise RuntimeError('Reauthorization positive control failed')
            permission([])
            if received():raise RuntimeError('Explicit deny failed')
            result={'kind':'kernel_udp_only','expiry_last_received_seconds':round(last_received-start,3),
                    'default_deny':True,'explicit_deny':True,'browser_rtp_qualified':False}
            args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,indent=2))
            print(json.dumps(result))
        finally:permission([])
if __name__=='__main__':main()
