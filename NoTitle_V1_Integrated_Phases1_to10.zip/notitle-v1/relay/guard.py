"""Pure authorization core plus nftables transaction generator.
Production controller/mTLS integration is gated until kernel/browser evidence exists.
"""
from dataclasses import dataclass
import ipaddress
import math
import re
import time

class RelayDenied(RuntimeError): pass

@dataclass(frozen=True)
class Allocation:
    session: str
    username: str
    address: str
    port: int

def parse_sessions(raw: str, username: str, relay_ip: str) -> list[Allocation]:
    """Parse exact-user coturn 'ps' records. Format qualification remains build-specific."""
    if len(raw.encode())>262144 or not re.fullmatch(r"[A-Za-z0-9:_-]{1,200}",username):
        raise RelayDenied("SNAPSHOT_LIMIT")
    ipaddress.IPv4Address(relay_ip)
    headers=list(re.finditer(r"(?m)^\s*([0-9]+)\) id=([0-9]{18}), user <([^<>\r\n]+)>:\s*$",raw))
    # Require a complete count footer, not a truncated administration response.
    total=re.findall(r"(?m)^\s*Total sessions: ([0-9]+)\s*$",raw)
    if len(total)!=1 or int(total[0])!=len(headers) or len(headers)>4:
        raise RelayDenied("INCOMPLETE_SNAPSHOT")
    out=[]
    for n,head in enumerate(headers):
        body=raw[head.end():headers[n+1].start() if n+1<len(headers) else len(raw)]
        if head.group(3)!=username or int(head.group(1))!=n+1:
            raise RelayDenied("EXACT_USER_MISMATCH")
        if not re.search(r"client protocol (UDP|TCP|TLS), relay protocol UDP",body):
            raise RelayDenied("UNSUPPORTED_PROTOCOL")
        addresses=re.findall(r"(?m)^\s*relay addr ([^\s]+)\s*$",body)
        if len(addresses)!=1 or not re.fullmatch(r"[0-9.]+:[0-9]+",addresses[0]):
            raise RelayDenied("AMBIGUOUS_ALLOCATION")
        address,port=addresses[0].split(":")
        if address!=relay_ip or not 49152<=int(port)<=50175:
            raise RelayDenied("FOREIGN_ALLOCATION")
        out.append(Allocation(head.group(2),username,address,int(port)))
    if len({a.port for a in out})!=len(out) or len({a.session for a in out})!=len(out):
        raise RelayDenied("DUPLICATE_ALLOCATION")
    return out

class Guard:
    def __init__(self, relay_ip: str, clock=time.monotonic):
        self.ip=str(ipaddress.IPv4Address(relay_ip))
        self.clock=clock
        self.epoch=0; self.owner_seq=0; self.owner_until=0.0
        self.history={}; self.calls={}; self.revoked=set(); self.contained=False

    def deny_all(self):
        self.calls.clear(); self.contained=True

    def owner_lease(self, epoch: int, sequence: int):
        if self.contained or type(epoch) is not int or type(sequence) is not int or epoch<1:
            raise RelayDenied("OWNER_INVALID")
        if epoch<self.epoch or (epoch==self.epoch and sequence<=self.owner_seq):
            raise RelayDenied("OWNER_REPLAY")
        if epoch!=self.epoch:
            if self.epoch: # New owner requires clean relay boot/secret, not resurrected allocations.
                self.deny_all(); raise RelayDenied("NEW_OWNER_RESTART_REQUIRED")
            self.epoch=epoch
        elif self.clock()>=self.owner_until:
            self.deny_all(); raise RelayDenied("OWNER_EXPIRED_RESTART_REQUIRED")
        self.owner_seq=sequence; self.owner_until=self.clock()+30

    def authorize(self, call_id, left, right, call_until, epoch):
        now=self.clock()
        if self.contained or epoch!=self.epoch or now>=self.owner_until or call_id in self.revoked:
            raise RelayDenied("NO_AUTHORITY")
        if not re.fullmatch(r"[a-f0-9]{32}",call_id) or not 0<call_until-now<=30:
            raise RelayDenied("CALL_BOUNDARY")
        if not 1<=len(left)<=4 or not 1<=len(right)<=4 or left[0].username==right[0].username:
            raise RelayDenied("PAIR_BOUNDARY")
        if call_id not in self.calls and len(self.calls)>=25: raise RelayDenied("CAPACITY")
        ports=set()
        for side in (left,right):
            for a in side:
                if a.username!=side[0].username or a.address!=self.ip or not 49152<=a.port<=50175 or a.port in ports:
                    self.deny_all(); raise RelayDenied("AMBIGUOUS_PORT")
                ports.add(a.port)
                owner=(call_id,a.username,a.session)
                if a.port in self.history and self.history[a.port]!=owner:
                    self.deny_all(); raise RelayDenied("PORT_REUSE_RESTART_REQUIRED")
                self.history[a.port]=owner
        until=min(now+5,call_until,self.owner_until)
        pairs={(a.port,b.port) for a in left for b in right}|{(b.port,a.port) for a in left for b in right}
        self.calls[call_id]=(pairs,until)

    def end(self,call_id):
        self.calls.pop(call_id,None); self.revoked.add(call_id)
        # Bounded by port budget; exhausted history/revocations require a clean restart.
        if len(self.revoked)>1024: self.deny_all()

    def transaction(self):
        now=self.clock()
        if now>=self.owner_until: self.deny_all()
        lines=["flush set inet notitle_guard pairs"]
        count=0
        for pairs,until in self.calls.values():
            ttl=math.floor((until-now)*1000)
            if ttl<=0: continue
            for source,destination in sorted(pairs):
                count+=1
                lines.append(f"add element inet notitle_guard pairs {{ {source} . {destination} timeout {ttl}ms }}")
        if count>800: self.deny_all(); raise RelayDenied("ENTRY_LIMIT")
        return "\n".join(lines)+"\n"

def ruleset(relay_ip):
    ip=str(ipaddress.IPv4Address(relay_ip))
    return f"""table inet notitle_guard {{
 set pairs {{ type inet_service . inet_service; flags timeout; timeout 5s; size 800; }}
 chain output {{
  type filter hook output priority -200; policy accept;
  ip saddr {ip} ip daddr {ip} udp sport . udp dport @pairs accept
  udp sport 49152-50175 drop
 }}
 chain input {{
  type filter hook input priority -200; policy accept;
  iifname "lo" ip saddr {ip} ip daddr {ip} udp sport . udp dport @pairs accept
  udp dport 49152-50175 drop
 }}
}}
"""
