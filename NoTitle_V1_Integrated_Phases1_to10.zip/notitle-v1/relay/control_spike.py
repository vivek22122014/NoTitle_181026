"""One-call isolated controller bench with live exact-user coturn polling.
No production RPC. Commands arrive only on local stdin; kernel entries expire if this
process stalls. Start a clean coturn/guard boot for each session of this bench.
"""
import argparse,asyncio,json,socket,time,sys
from pathlib import Path
from relay.guard import Guard,parse_sessions

async def listing(port, password, username):
    reader,writer=await asyncio.wait_for(asyncio.open_connection('127.0.0.1',port),2)
    try:
        async with asyncio.timeout(2):
            prompt=await reader.readuntil(b'Enter password:')
            writer.write(password.encode()+b'\n');await writer.drain()
            await reader.readuntil(b'> ')
            writer.write(('ps '+username+'\n').encode());await writer.drain()
            raw=await reader.readuntil(b'> ')
            if len(raw)>262144:raise ValueError('CLI limit')
            return raw.decode('ascii')
    finally:writer.close();await writer.wait_closed()

def send_guard(path,pairs):
    with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as sock:
        sock.settimeout(1);sock.connect(path);sock.sendall(json.dumps({'pairs':pairs}).encode()+b'\n')
        if sock.recv(1024)!=b'{"ok":true}\n':raise RuntimeError('Kernel guard rejected update')

async def bench(args):
    # Validate usernames using parser boundary BEFORE writing into an administration command.
    for name in (args.left,args.right):parse_sessions('Total sessions: 0\n',name,args.relay_ip)
    if args.password_file.stat().st_mode&0o077:raise ValueError('Private CLI password file required')
    password=args.password_file.read_text().strip()
    guard=Guard(args.relay_ip);guard.owner_lease(1,1)
    stop=asyncio.Event();owner_seq=1;started=time.monotonic();last_renew=started
    loop=asyncio.get_running_loop()
    def end_input():
        sys.stdin.readline()
        stop.set()
    print('Press ENTER to revoke the test call',flush=True)
    loop.add_reader(sys.stdin.fileno(),end_input)
    try:
        while not stop.is_set() and time.monotonic()-started<120:
            now=time.monotonic()
            if now-last_renew>=10:
                owner_seq+=1;guard.owner_lease(1,owner_seq);last_renew=now
            left_raw,right_raw=await asyncio.gather(listing(args.cli_port,password,args.left),listing(args.cli_port,password,args.right))
            left=parse_sessions(left_raw,args.left,args.relay_ip);right=parse_sessions(right_raw,args.right,args.relay_ip)
            if left and right:
                guard.authorize('a'*32,left,right,time.monotonic()+20,1)
                pairs,until=guard.calls['a'*32]
                ttl=max(0,min(5000,int((until-time.monotonic())*1000)))
                if ttl<=0:raise RuntimeError('Expired lease')
                await asyncio.to_thread(send_guard,args.socket,[[a,b,ttl] for a,b in pairs])
            else:
                await asyncio.to_thread(send_guard,args.socket,[])
            try:await asyncio.wait_for(stop.wait(),.5)
            except TimeoutError:pass
    finally:
        guard.end('a'*32)
        await asyncio.to_thread(send_guard,args.socket,[])
        loop.remove_reader(sys.stdin.fileno())
        # CLI allocation cancellation and absence proof remain a qualification requirement;
        # this bench revokes packets and does not release a production call slot.
        print('Permissions removed. Capture packet tail; stop coturn before reusing this bench.')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--relay-ip',required=True);p.add_argument('--left',required=True);p.add_argument('--right',required=True)
    p.add_argument('--password-file',required=True,type=Path);p.add_argument('--cli-port',type=int,default=5766)
    p.add_argument('--socket',default='/run/notitle-relay/guard.sock')
    asyncio.run(bench(p.parse_args()))
