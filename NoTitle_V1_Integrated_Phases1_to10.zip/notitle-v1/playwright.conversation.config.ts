import {defineConfig} from '@playwright/test';
export default defineConfig({
  testDir:'tests/qualification',testMatch:'phase4.spec.ts',timeout:60000,expect:{timeout:10000},fullyParallel:false,workers:1,
  use:{baseURL:'http://127.0.0.1:8080',trace:'off',screenshot:'off',video:'off'},
  reporter:[['list'],['json',{outputFile:'evidence/phase4/browser-results.json'}]],
  projects:[{name:'conversation-chromium',use:{browserName:'chromium'}}],
});
// Start the fixed local realtime stack first. Never capture ordinary text or
// identity credentials in automatic traces, video or screenshot artifacts.
