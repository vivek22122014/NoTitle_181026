import {defineConfig} from '@playwright/test';
export default defineConfig({
  testDir:'tests/qualification',testMatch:'phase2.spec.ts',timeout:60000,fullyParallel:false,
  use:{baseURL:'http://127.0.0.1:8080',trace:'retain-on-failure',screenshot:'only-on-failure'},
  reporter:[['list'],['json',{outputFile:'evidence/phase2/browser-results.json'}]],
  projects:[{name:'interface-chromium',use:{browserName:'chromium'}}],
  webServer:{command:`${process.env.NT_PYTHON||'python3'} ops/nt.py interface serve`,url:'http://127.0.0.1:8080',reuseExistingServer:false,timeout:15000},
});
