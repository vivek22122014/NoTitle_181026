# Phase 4 acceptance and handoff

Source implementation is delivered. Core evidence is in `../evidence/phase4/latest.json` and its hashed per-check logs. **Phase 4 is not accepted for production.** Use `PHASE4.md` for the design and commands. Earlier evidence is historical and does not qualify changed source.

| Requirement / risk | Implemented evidence | Remaining qualification |
|---|---|---|
| Shared queue / mutual exclusion | Actual actor tests, seeded random tie coverage, randomized one-interaction invariant, oldest-feasible head skipping, bilateral blocks | Real account/guest network suite; long-running mixed-state load and starvation review |
| Score / entitlement | Exact interest fraction, General Talk suppression, five-second fade, four-second exclusion, 60-second penalty, five-minute expiry, strict-filter pause | Stable read-only paid ledger adapter and paid end-to-end tests in Phase 8; no synthetic grants in deployment |
| Queue age / stale effects | Reservation invalidation on edits/disconnect/expiry; Cancel during authorization; End during a pending send; Next ends before failed authorization | Real DB contention, reconnect/edit/withdrawal and worker/pool failure injection |
| Ownership / authorization | Lease/generation/revision fences, single-use cookie-bound ticket, explicit takeover, reserved control, ordinary/control saturation tests | Real PostgreSQL/runner failure suite and origin/hello/replay network tests |
| Text / delivery | Unicode/byte/frame validation; generated schemas; sequences; sender-only command IDs; render-triggered receipt; duplicate result cache and nonce conflict | Real browser IME, Unicode, keyboard, native zoom and assistive-technology review |
| Temporary retention | Bounded server/browser rings, pending limits, no transcript tables, End erases ring/outbox, grace and owner-loss cleanup, ended-handle snapshot fence | Process/RSS/heap/log/backups inspection under load; no raw message capture; host core/swap/hibernation review |
| Reconnect | No automatic Search/text replay; 25-second authoritative server grace; old timers cancelled on successful resume | Browser reload/offline/takeover, clock skew/background suspension, delayed packets and real edge timeout tests |
| HTTP teardown | Scoped same-operation fallback, known old End cannot end a new match, late browser response cannot clear a newer intent | Real CSRF/Origin/Host/cookie and concurrent socket/HTTP teardown scenarios |
| UX / support | Connected Chat/Talk, desktop/mobile layout, explicit Search/Cancel/End/Next/Block, retained-case Support link, truthful later-phase controls | Real exported desktop/mobile browser suite and manual accessibility checks; Phase 5 private support/report operations |
| Setup / release | Shared one-command local setup, verified build reuse, fixed disposable DB, CI/evidence collector, no new DDL or service | Actual reviewed dependency locks, Next/typecheck/Caddy build, clean-machine rehearsal and combined release gates |

Run these from `notitle-v1` after installing the real reviewed dependencies:

```bash
.venv/bin/python ops/nt.py conversation verify --level core
.venv/bin/python ops/nt.py dev down
.venv/bin/python ops/nt.py conversation verify --level integration
npm ci --ignore-scripts
npx playwright install --with-deps chromium
.venv/bin/python ops/nt.py conversation verify --level stack
```

The integration suite must use `127.0.0.1:55432`, database `notitle`, and the explicit disposable-target guard. Never run process-loss/destructive tests on production. Five browser scenarios test two independent identities and a same-cookie takeover tab. They record no automatic traces, screenshots or video.

Before acceptance, collect whole-system soak/load evidence at the proposed cap: 200 admitted identities, 100 waiters, reconnect grace included; reject a 101st waiter and excess connection attempts without displacing valid sessions. Measure full authorization-to-match latency, control latency, real loop/pool/mailbox pressure, CPU/RSS headroom, slow readers, database/owner loss and stale-command behavior. The included 100-incompatible-waiter scan benchmark measures only synchronous actor work and cannot establish those targets.

Record remaining issues, environment, exact source/build/lock hashes and reviewer decisions. `phase4_accepted=false` and `production_ready=false` are intentional defaults. Legal/operator facts, reviewed published policies, infrastructure security/restore, paid/provider and relay/media work remain separate gates. Never make a green core collector satisfy an unexecuted gate.
