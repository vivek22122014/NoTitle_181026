# Phase 1 — Foundation and feasibility

Updated 17 October 2026. Specification: Master Blueprint V6, chapter 55. This update builds on the current saved implementation and preserves the later-phase source.

**Foundation source is implemented and locally checked. Phase 1 acceptance is still open.** Real dependency resolution, database/process integration, Next.js exports, relay packets, independent host-loss recovery and merchant behavior require the environments identified below. A command or test fixture is not a substitute for that evidence.

## Deliverables and boundaries

| Deliverable | Implementation |
|---|---|
| Repository and CLI | Existing Next.js/FastAPI monorepo; `ops/nt.py foundation setup/verify`, `doctor`, `lock`, `db`, `build`, `dev`, `test` |
| Isolated foundation runtime | `APP_MODE=foundation`, local only; one real PostgreSQL owner lease and two loopback FastAPI listeners; product construction/jobs/integrations excluded |
| Static interfaces | Separate public/private `/foundation/` Next routes, served as their respective homepages by the foundation Caddy configuration |
| Ownership and shutdown | Dedicated advisory lock, increasing epoch, bounded proof deadline, synchronous fencing, heartbeat during startup, constructor/port-failure cleanup |
| Database framework | Checksummed forward migrations; `--foundation` stops new application at migration 0001; existing later migrations are validated and preserved |
| Bounded primitives | 200 identities; 2,048 ordinary and 256 reserved control mailbox entries; bounded synchronous drains and stale-result fencing |
| Role pools | Product-mode pools remain 6/2/2/2/2. Closed role connections repair within their existing slot. The owner connection never silently reconnects |
| Dependency integrity | Real Python hash lock, npm integrity lock and image digests must be resolved; checks bind artifacts to current requirements/workspaces/image candidates |
| Build integrity | Fresh static export directory; input/output hash manifest; `--skip-build` rejects stale/tampered exports rather than rebuilding tested artifacts |
| Local safety | Fixed disposable database binding, generated credentials, serialized local start/stop, PID identity and optional expected-PID guard |
| Feasibility spikes | Existing encrypted-journal, coturn/kernel/browser and Cashfree sandbox tools retained; actual external execution remains gated |
| Evidence | `evidence/phase1/latest.json`, `stack-attempt.json`, timestamped logs, registry probe record and current source digest |
| CI | Hash-pinned checkout action, locked dependencies, immutable-image Node setup, real PostgreSQL/process checks, types/build/browser workflow |

## Architecture

```mermaid
flowchart TD
  CLI[Operator CLI] --> DB[Local disposable PostgreSQL]
  CLI --> Runner[One supervised runner]
  Public[Public static export] --> PubAPI[Public loopback listener]
  Private[Private static export] --> PrivAPI[Private loopback listener]
  PubAPI --> Runner
  PrivAPI --> Runner
  Runner --> DB
  Runner --> Lease[Advisory lock and epoch]
  Lease --> DB
```

Caddy exposes the two local interfaces at 127.0.0.1:8080 and 127.0.0.1:8081. It forwards APIs to 127.0.0.1:8000/8001. Foundation mode mounts only public liveness/readiness and an authentication-denied private health route. It never starts the product runtime, saved-data jobs, payment provider, relay client or privacy journal. Existing later-phase services remain available under the separate product mode.

A healthy foundation readiness response is HTTP 200 with `status: maintenance`, `mode: foundation`, `admission: false`. This means the owner proof is current and product entry is closed. Lost authority returns 503 and fences both listeners. Public `/internal/...` and product routes return 404. Private health returns 401 until later-phase authentication is selected. Unknown static paths are true 404 responses.

## Prerequisites and where to run commands

Run all commands below **from the extracted `notitle-v1` directory** on Linux, or in a WSL2 Linux distribution with Docker Engine running in the same Linux environment. Python 3.12, Node 24, npm, uv, Docker Engine and Docker Compose are required for complete setup. Use authorized access to npm, PyPI and the image registry.

The stack uses Linux host networking to reach the runner's loopback listeners. Native Windows/macOS Docker Desktop routing is not qualified by this implementation; do not change API binds to a public address to work around it. The least ambiguous Windows development path is WSL2 with the engine and CLI in the same Linux distribution. These local prerequisites do not change the managed-database production architecture.

No provider account, live payment key, support email or invented business identity is required to run the foundation. Provider/media/legal feasibility tests use separately supplied real infrastructure and reviewed facts.

## One-command initial setup

```bash
python3 ops/nt.py foundation setup
```

The command automatically:

1. Generates local private credentials without changing existing secrets.
2. Resolves actual Python/npm integrity locks and immutable image digests.
3. Creates `.venv` and installs the resolved hash-locked backend dependencies.
4. Verifies generated contracts and runs unit tests.
5. Starts disposable PostgreSQL, creates restricted roles and applies the foundation migration.
6. Typechecks/builds both Next.js exports into a fresh directory and records their hashes.
7. Starts the owned foundation API and the selected foundation Caddy configuration.

Open **http://127.0.0.1:8080** and **http://127.0.0.1:8081**. Expect the public foundation status and the separate private “Staff access is closed” screen. No product account, conversation, payment or moderator session is enabled by this mode.

Inspect or stop:

```bash
.venv/bin/python ops/nt.py dev status
.venv/bin/python ops/nt.py dev down
```

For a checkout with complete reviewed locks already committed, use `foundation setup --locked`. Dependency installation can still require registry access; the switch verifies existing locks rather than inventing a cache. `foundation setup --no-start` installs and checks the source without starting local services.

## Incremental dependency preparation

Resolution can be done independently on a suitably authorized machine:

```bash
python3 ops/nt.py configure
python3 ops/nt.py lock --scope python
python3 ops/nt.py lock --scope web
python3 ops/nt.py lock --scope images
python3 ops/nt.py lock --check
python3 ops/nt.py install
```

Python resolution does not require Docker merely to begin; image resolution requires a real Docker engine. The entire lock check remains closed until all three components are present and match their source inputs. Review/commit `requirements.lock`, `package-lock.json`, `infra/images.env` and the updated `versions.lock` together. Exact inputs are candidates until resolved and tested. Do not paste sample hashes into these files.

## Verification and evidence

Core checks run without Docker or provider credentials when Pydantic and cryptography are installed:

```bash
python3 ops/nt.py foundation verify --level core
```

This runs the core doctor, contract drift check, all unit tests and static source-boundary checks. Its success does **not** accept real PostgreSQL, frontend builds, cloud storage or media.

Stop any existing local owner before destructive integration tests. Then run:

```bash
.venv/bin/python ops/nt.py dev down
.venv/bin/python ops/nt.py foundation verify --level integration
.venv/bin/python ops/nt.py foundation verify --level stack
```

`integration` checks real locks/tooling, starts the disposable database, provisions roles, applies migration 0001 and runs the real PostgreSQL/process/HTTP/provider-fixture suites. It refuses to test over an existing local owner.

`stack` additionally builds/typechecks the actual static exports, starts foundation mode using those exact export bytes, verifies public/private HTML and HTTP denial/404/header boundaries, then stops only the owner that it started. A replaced PID is refused rather than terminated. Static HTTP qualification does not replace later mobile/browser/accessibility or real audio tests.

The collector writes a fresh report with command exit codes, logs, SHA-256s, environment and source digest. Missing tools, failed steps and blocked dependent checks remain visible. An old successful report is not reused. Exit 0 means the selected checks passed; exit 3 means a requested check failed or was blocked. `phase1_accepted` remains false until external gates are separately reviewed.

If you want the verified local stack running afterward:

```bash
.venv/bin/python ops/nt.py dev up --mode foundation --skip-build
```

`--skip-build` is accepted only when the source and output-byte manifest still match. It is not a way to serve an arbitrary or outdated export.

## Migration and recovery behavior

For manual foundation-only database work:

```bash
.venv/bin/python ops/nt.py db bootstrap
.venv/bin/python ops/nt.py db migrate --foundation
```

The database must already be running, and the owner must be stopped before migration. Local CLI commands reject another host, hostaddr, port, database, service or credentials that do not match the fixed generated local target. Managed deployment uses the separate managed setup tool; do not point this local dispatcher at production.

Migration 0001 creates the epoch sequence and foundation metadata. Checksums of the entire known applied history are checked even when requesting the foundation target. On a database already upgraded by later phases, `--foundation` does not down-migrate or delete anything. An isolated-database integration test covers initial schema 1 followed by the forward upgrade to schema contract 2.

Startup failure closes the lease, heartbeat and any sockets already reserved. Two listeners are bound before either server is scheduled. Losing ownership never reconnects the same owner session: restart acquires a new lock/epoch. Role-pool repair is separate and cannot restore owner authority. An interrupted local start/stop cannot overwrite a concurrently owned PID file.

## Feasibility acceptance checklist

| Gate | Required real evidence | Current implementation environment |
|---|---|---|
| F01 Dependencies/static builds | Resolved input-bound locks, reviewed advisories, actual Next builds and static HTTP checks | Registry probes return 403; Docker unavailable |
| F02 Ownership/migrations/process | Competing owner denied; epoch increases; DB loss shuts both listeners; partial bind cleans up; foundation upgrade and least privilege | Real PostgreSQL/runtime dependencies unavailable; test source included |
| F03 Independent journal | Tamper/truncation rejected; newer delete/hold survives old database and host loss using independent latest checkpoint | Local/fake-store fault tests pass; actual cloud/host-loss drill unrun |
| F04 Guarded audio | Two real browsers, exact coturn attribution, unknown/reused ports denied, RTP stops within five seconds, controller/owner failure and supported networks | Synthetic primitives included; coturn/nftables/hosts unavailable |
| F05 Merchant sandbox | Exact verified capture; stable unknown-outcome reconciliation; signature/replay behavior; required-remedy settlement | Provider fixtures included; merchant credentials/real sandbox execution absent |
| F06 Annual assessment | Approved late-remedy route beyond normal refund window | Annual365 remains unavailable; no invented provider commitment |
| F07 Operator/region/legal | Actual region/cost quote, operator facts and reviewed lawful no-email contact determination | Actual facts not supplied |

Use `docs/FEASIBILITY.md` for the spike commands. Preserve no support email, no voluntary refunds, no recurring billing, temporary ordinary chat, relay-only audio and truthful policies. A failed feasibility result requires correction or an explicit reviewed architecture decision before a dependent feature is enabled.

## Troubleshooting

| Symptom | Action |
|---|---|
| npm/PyPI 403 | Resolve on a network authorized for those registries; no proxy bypass or fake locks |
| Missing Docker/Compose | Install/start the engine in the same Linux environment before full setup |
| Lock inputs changed | Resolve the affected scope, review the diff, then run `lock --check` |
| Existing local owner | Use `dev status`, then the authorized `dev down`; verification refuses to kill an unrelated replacement PID |
| Port collision | Free the selected local port or configure distinct loopback ports consistently; the failed startup releases ownership |
| Foundation page says unavailable | Check the runner log, live PostgreSQL owner proof and Caddy routing; a static page alone is not readiness |
| Skipped build rejected | Rebuild the exports; never edit the manifest to match changed files |
| Migration drift | Restore the applied migration source/checksum; add a new forward migration for changes |
| Stack report blocked | Read the named prerequisite log and external gate; do not change the acceptance flag merely to continue |

When moving to the existing later-phase implementation, stop foundation mode and select `dev up --mode product`. Product startup applies the full migration inventory and its own configuration/security gates. Foundation mode cannot be selected in staging or production.
