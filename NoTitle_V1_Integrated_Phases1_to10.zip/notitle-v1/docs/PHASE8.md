# Phase 8 — verified one-off passes, financial records and required remedies

The full product runtime connects real Cashfree hosted checkout to the existing durable ledger and jobs. This supersedes the historical Phase 4 free-only ledger boundary. Partial `identity` and `realtime` qualification profiles remain free and cannot enable sales. Source implementation is distinct from merchant, browser, database, payment and production qualification.

## Implemented behavior

1. `/premium/` loads immutable database plan versions. Annual365 remains unavailable. A plan is on sale only when its exact amount, version, tax rule and current policy have a matching reviewed receipt configuration, a real configured provider, an approved public return origin, enabled payment configuration and open application admission.
2. `/checkout/` requires a registered account. It displays the reviewed net amount, tax lines, gross INR total, merchant identity, continuous duration, no renewal, and no voluntary refunds. Card details, UPI credentials and OTP are entered on Cashfree's hosted page. The required payment phone is sent only for payment and is not added to the conversation profile.
3. The client saves one immutable request/UUID in RAM. The backend locks current account authority and the financial subject before recording a purchase and durable reconciliation job. An unresolved existing order prevents accidental creation of a second order. Retrying the same nonce addresses the same purchase. No phone, payment intent, chat or receipt secret is written to browser storage.
4. The server supplies `return_url` using its configured public origin and an opaque purchase reference. The browser loads `https://sdk.cashfree.com/js/v3/cashfree.js` only after an explicit checkout action and uses `Cashfree({mode}).checkout({paymentSessionId, redirectTarget:'_self'})`. Merchant credentials never reach the browser. Checkout is entered and exited with full document navigation so its scoped third-party SDK and CSP cannot survive into temporary chat.
5. `/billing/status/` treats all return parameters as untrusted navigation hints. It reads owned server purchase state, polls at most 12 times at five-second intervals, and offers manual refresh. Only independently fetched matching order and payment facts can create an entitlement lot. A success URL, HTTP 200, screenshot or client SDK result never grants time.
6. `GET /billing/purchases` recovers the 20 most recent owned references after reload. `POST /billing/purchases/{ref}/resume` checks the existing provider order without creating a replacement: ACTIVE can reopen its session, PAID schedules independent capture verification, EXPIRED/TERMINATED close the checkout, and unknown responses remain pending. It rechecks current account authority before returning a checkout session.
7. `/account/receipts/` and `/billing/` load owned verified receipt facts, download JSON receipts, and paginate older receipts by server receipt number. Prepared financial-access credentials must be saved before confirmation. Financial-only cookies grant financial records; they cannot recover an account or impersonate normal account access.
8. Available pass time is a stable read-only projection from one PostgreSQL statement: subject ledger revision, last durable accounting time, current database statement time and currently available FIFO lots. Reads never mutate the revision. Held and revoked time are excluded; elapsed wall-clock time continues while signed out. Only durable grants, accounting and remedy changes advance the ledger revision. Guests and financial-only sessions receive zero matching entitlement.
9. A billing complaint uses Chat with Moderator. It creates a saved case, not an automatic hold or refund. Authorized private staff still require current permission, recent MFA, a version-bound preview, evidence and one of `payment_error`, `statutory_remedy`, or `provider_bank_direction` before a remedy is submitted. Unknown provider outcomes retain their hold and stable provider reference. Verified settlement changes only the originating lot and creates an immutable outcome receipt.

## API additions and changes

All ordinary APIs use existing cookie authority, current CSRF for writes, exact Origin/Host checks, ownership filters and the shared client coordinator. An explicitly selected financial cookie cannot acquire account authority.

| Endpoint | Contract |
|---|---|
| `GET /api/v1/billing/plans` | `items`, `renewal:none`, refund policy; each enabled item includes reviewed `receipt_preview` |
| `GET /api/v1/billing/entitlement` | Existing strict `{available_seconds,premium_until,entitlement_revision}`; read-only |
| `POST /api/v1/billing/purchases` | Existing immutable plan/policy/nonce/phone DTO; account only; returns `purchase_ref`, durable state and a session only for checkout |
| `GET /api/v1/billing/purchases` | Recent owned `{items}`; no merchant session, phone or secret |
| `GET /api/v1/billing/purchases/{ref}` | Owned state and authorized required-remedy status; inaccessible reference is 404 |
| `POST /api/v1/billing/purchases/{ref}/resume` | Empty JSON body; current account only; never creates a replacement provider order |
| `GET /api/v1/billing/receipts?cursor=N` | Owned `items` (20 maximum) and `next_cursor`; cursor is a positive bigint receipt number |
| `GET /api/v1/billing/receipts/{ref}` | Authorized immutable receipt facts |
| `POST /api/v1/billing/receipts/access/confirm` | Existing saved prepared proof; current fresh account authorization |
| `POST /api/v1/billing/receipts/access` | Saved reference and secret in request body; financial-only session and CSRF |
| `POST /api/v1/webhooks/cashfree` | Raw signed body, durable inbox dedupe and existing reconciliation job; no browser CSRF |

`0009_billing_reviews.sql` adds a column-level SELECT grant for the public remedy-status projection; private evidence and decision columns stay inaccessible to the runtime role. `0011_external_financial_reviews.sql` adds explicit external-hold ownership, a review revision, event references and the last independently verified resolution digest; only the private/jobs roles can access it. Apply the complete migration inventory before running the full product. The existing plan, purchase, subject, lot, payment attempt, receipt, refund, webhook and durable-job tables remain authoritative. No ordinary message transcript is added to PostgreSQL.

## External refunds, disputes and the mandatory sales gate

New and resumed sales additionally require `Billing.external_adjustments_ready()`; its default is **false**, including sandbox. The full runtime supplies it only from the reviewed `payment_exceptions` qualification evidence. This is a separate required production/release gate. The existence of the code below cannot by itself satisfy that evidence.

Every capture reconciliation now fetches the actual provider order refunds using authenticated `GET /orders/{order_id}/refunds`. Returned records must match the order, captured payment, INR, bounded exact amount, unique provider reference and a recognized state. A provider error or ambiguous response cannot create a grant. Known internally authorized refunds wake their existing stable remedy job. Externally initiated pending/successful refunds conservatively freeze the remaining **originating** lot, append a unique environment-bound ledger adjustment and an immutable financial-review receipt, and create a durable review item. They never initiate another refund. Duplicate events cannot hold the time twice.

The official refund webhook uses `data.refund.order_id`; this is accepted independently of ordinary payment `data.order.order_id`. Signed `DISPUTE_CREATED`, `DISPUTE_UPDATED` and `DISPUTE_CLOSED` notices use the documented `data.order_details` attribution. A valid signed financial notice is sufficient only for a protective freeze pending independent review, not money movement or final dispute adjudication. Every new signed financial notice fences the subject ledger revision, including an internally known refund. This stops a preview made before a new notice from releasing time while the provider listing is eventually consistent. Raw-body digests deduplicate delivery. A notice before capture marks the purchase for review; later capture cannot clear that state. Unsigned notices cannot freeze any account.

`financial_review` purchases are excluded from the stable matching projection and elapsed accounting until their review is resolved. This also prevents a later failed internal refund from reactivating that origin. Existing unrelated pass lots remain usable. Review receipts disclose the observed provider state, held seconds and whether verification is an independent refund lookup or a signed dispute notice awaiting independent review.

Capture reconciliation and backfill also query the documented `GET /orders/{order_id}/disputes`. A known signed dispute omitted from that list must be retrieved independently with `GET /disputes/{dispute_id}`; omission, 404, API restrictions or unknown status cannot be treated as a win. Similarly, a previously observed refund omitted from the order listing requires its specific provider lookup. Provider customer information is discarded from the retained projection. Only documented status values and exact order/payment/INR/amount associations are accepted. The worker schedules at most one oldest eligible captured/review order per minute for backfill, with a one-hour minimum recheck interval; signed webhooks are the primary timely notification path. Backfill is fair and bounded rather than a guarantee that every historic order is checked each hour.

### Private staff review workflow

The private Billing page includes the connected External refund and dispute holds panel. Its endpoints are:

| Private endpoint | Purpose |
|---|---|
| `GET /internal/v1/billing/reviews?cursor=REF` | Audited, paginated open holds, 20 per page |
| `POST /internal/v1/billing/reviews/{ref}/refresh` | Fetch real current provider records; preserve or add protective holds |
| `POST /internal/v1/billing/reviews/{ref}/preview` | `action:restore\|revoke`, optional `seconds_to_revoke`, decision `reason`, intent UUID |
| `POST /internal/v1/billing/reviews/confirm` | Confirm the exact single-use preview after another independent lookup |

1. An authorized reviewer opens the private Billing page, completes MFA step-up and selects an open hold. Both reads and writes require the current `billing.remedies` grant and MFA no older than five minutes. The backend locks/rechecks current staff account/session/role version after provider work and again before publishing a mutation; stale client grants never authorize it.
2. Refresh fetches current order, refund and dispute records. Missing known records trigger specific lookups. An upstream error or unresolved outcome keeps the origin held. The entire verification operation has a bounded deadline.
3. The reviewer requests restore or revoke and records a reason. Restore is allowed only with no verified successful-refund/lost-dispute principal and no unresolved outcomes. Revoke requires verified principal loss. Its minimum is `min(external_held, max(0, ceil(granted_seconds * verified_lost_paise / gross_paise) - already_revoked_origin_seconds))`. This prevents double revocation after an earlier internal or external remedy. A request below the minimum is raised to that minimum in the displayed preview; the reviewer may choose a higher amount up to the current externally owned hold. Only external-held time is affected; internal remedy holds remain separate.
4. The two-minute preview displays the actual revocation/restoration, verified facts and minimum. It binds the complete provider-facts digest, subject ledger revision, external-review revision, originating-lot revision and staff role version. Confirmation independently refetches provider records and checks all those bindings. New notices, provider state changes, role changes, expiry and concurrent ledger changes reject the stale preview.
5. Successful confirmation settles only the current external-held bucket, writes an immutable financial-resolution receipt and append-only ledger decision, records the access audit, and closes the associated review work. No provider refund/accept-dispute/money-transfer command is sent. Lost confirmations can retry the exact preview: the owned 24-hour operation result is checked before the short-lived preview, so preview cleanup does not lose the committed result. After that operation record is cleaned up, a current authorized reviewer can recover only the committed result from the indexed immutable receipt preview reference; recovery is audited and never refetches the provider or repeats a disposition. The UI preserves uncertain confirmation intent instead of starting a second disposition.
6. A later genuine provider change can open a new review cycle. Resolved provider-facts digests prevent periodic backfill from repeatedly freezing an already adjudicated unchanged loss. A post-notice capture or failed internal refund cannot slip available time out of an open freeze: it is absorbed into the explicit external hold before adjudication.

**Cases that deliberately remain held:** pending/intermediate outcomes, absent known references, unsupported provider states, restricted/unavailable merchant APIs, mixed successful refund plus terminal lost-dispute principal, or multiple negative dispute records without authoritative non-overlap reconciliation. The application returns a specific unavailable/pending/ambiguous result; it never guesses overlap or accepts an operator attestation as provider proof. Resolve the underlying provider records/binding reconciliation before a disposition can proceed. These cases must be included in merchant exception procedures and real qualification evidence. The code does not manufacture a financial outcome to open sales. Annual365 remains independently disabled.

## Configuration and real-world release work

Keep sales disabled until all the following have been completed and evidenced:

- Obtain merchant onboarding/website approval and sandbox/live credentials from the Cashfree merchant dashboard. Install `cashfree_client_id` and `cashfree_secret` using the project's private secret-file workflow. The runtime selects the production API only in the production environment; never mix sandbox orders with a live ledger.
- Have the actual entity, merchant address, legal contact route, tax treatment and policy reviewed. Install the real reviewed `receipt_configuration`; its `merchant.contact_route` must not expose a support email. Do not invent tax registration numbers, tax rates or evidence references. `ops/catalog.py` installs immutable reviewed plan versions and can enable the short plans; it always disables Annual365.
- Configure the real HTTPS public domain. The return is `/billing/status/?purchase_ref=...`; configure the signed webhook at `/api/v1/webhooks/cashfree` in the provider dashboard. Approve the actual checkout domain with the provider. Domain approval and signature verification must be tested in the chosen merchant environment.
- Generate CSP through `ops/csp.py`. Only `/checkout` and its descendants receive the official Cashfree SDK/script, connect and frame origins. Base pages keep third-party scripts and frames disabled. Verify the actual hosted flow in desktop and mobile browsers; do not broaden the CSP to wildcard origins if a provider integration fails.
- Complete one real sandbox hosted payment, duplicate/delayed webhook delivery, unknown order outcome, existing-order resume, capture/receipt verification, a required-remedy sandbox settlement and origin/CSP checks. Test database restore and deletion-journal replay before live launch. A sandbox transport probe alone is insufficient qualification of the product ledger and UI.
- Record source-bound release evidence using the main deployment/release workflow. Live enablement is still blocked by absent approval, reviewed legal/receipt facts, provider execution, or qualification evidence. No tests in this delivery fabricate a merchant approval or a real capture.

## Verification commands

Run these from the repository root after the documented development dependency setup:

```bash
PYTHONPATH=api python3 -m unittest tests.unit.test_phase8 tests.unit.test_payments tests.unit.test_external_reviews -v
```

The focused tests cover stable expiry/revision projection, held/revoked authority, zero guest entitlement, missing subjects, maintenance sale closure without disabling reconciliation, reviewed catalog gates, exact hosted order payloads, unsafe return URL rejection, immutable receipt facts, raw webhook signatures, exact amounts and uncaptured payment rejection.

The disposable PostgreSQL suite includes `tests/integration/test_billing_ledger.py`: concurrent reads must leave stored accounting untouched, a transactional hold changes matching authority atomically, and one account cannot enumerate another account's financial records. It also exercises durable external-hold dedupe, origin exclusion, private provider-verified minimum revocation, repeated confirmation, provider-change rejection and signed-notice races. Provider transport is synthetic in those database tests and is explicitly not merchant qualification. Start the documented isolated product stack and run the standard integration command; the tests refuse an unknown database target.

`tests/qualification/phase8.spec.ts` uses real application HTTP/DOM behavior with sales disabled. It checks no provider script or purchase on mount, forged success return rejection, financial save-before-confirm, mobile layout and empty browser storage. Run it through the full-product Playwright qualification workflow. Traces, video and screenshots are disabled for these credential-bearing tests.

At source handoff the focused Python tests and TSX/spec syntax checks passed. Database, full TypeScript/Next.js build, browser execution, actual provider operations, merchant approval and production acceptance require their own successful evidence; syntax or boundary tests do not substitute for them.

Official integration references: [hosted checkout](https://www.cashfree.com/docs/payments/online/web/redirect), [create order](https://www.cashfree.com/docs/api-reference/payments/latest/orders/create-order), [Cashfree SDK and CSP](https://github.com/cashfree/cashfree-js), [server payment lookup](https://www.cashfree.com/docs/api-reference/payments/latest/payments/get-payments-for-an-order), [refund lookup](https://www.cashfree.com/docs/api-reference/payments/latest/refunds/get-all-refunds-for-an-order), [disputes by order](https://www.cashfree.com/docs/api-reference/payments/latest/disputes/get-disputes-by-order-id), [dispute by ID](https://www.cashfree.com/docs/api-reference/payments/latest/disputes/get-disputes-by-dispute-id), [documented dispute states](https://www.cashfree.com/docs/payments/manage/disputes/disputes-states).
