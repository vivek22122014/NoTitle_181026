# Current V1 API inventory

The full product runtime registers the public and private decorators below plus the current wire-2 transport. Partial identity/realtime profiles deliberately filter this inventory. Public and private listeners remain separate; public routes never mount `/internal/`. Cookie authority, current CSRF on writes, exact Host/Origin checks, bounded inputs and ownership filters apply. Cashfree webhook signature verification replaces browser CSRF only for its explicit route.

Request bodies: `contracts/generated/http-requests.schema.json`. Identity/bootstrap responses: `contracts/generated/identity-responses.schema.json`. Current shared text/social/audio commands/events: `contracts/generated/conversation-v2.schema.json`. Historical `command.schema.json` is legacy wire 1, not the registered current conversation transport. `POST /interactions/end` takes the full scoped wire-2 End/Cancel envelope, never an unscoped empty body. The WebSocket ticket is sent only in its first JSON hello frame, never a URL.

API success envelopes are `{data,request_id}`; errors have `{error:{code,message,retryable},request_id}` and safe validation paths where applicable. A 2xx or redirect does not by itself imply durable money, evidence or delivery. Read the feature guides for transaction/nonce and state semantics.

| Method | Path | Body/path/query annotations | Handler |
|---|---|---|---|
| POST | `/api/v1/auth/guest` | dto: m.Guest | `guest` |
| POST | `/api/v1/auth/login` | dto: m.Login | `login` |
| POST | `/api/v1/auth/logout` |  | `logout` |
| POST | `/api/v1/auth/logout-all` |  | `logout` |
| POST | `/api/v1/auth/reauth` | dto: m.Reauth | `reauth` |
| POST | `/api/v1/auth/recover` | dto: m.Recover | `recover` |
| POST | `/api/v1/auth/register` | dto: m.Register | `register` |
| GET | `/api/v1/auth/session-limit` |  | `session_limit_list` |
| POST | `/api/v1/auth/session-limit/{session_ref}` | session_ref: UUID | `session_limit_resolve` |
| GET | `/api/v1/billing/entitlement` |  | `entitlement` |
| GET | `/api/v1/billing/plans` |  | `plans` |
| GET | `/api/v1/billing/purchases` |  | `purchases` |
| POST | `/api/v1/billing/purchases` | dto: m.Purchase | `purchase` |
| GET | `/api/v1/billing/purchases/{ref}` | ref: str | `get_purchase` |
| POST | `/api/v1/billing/purchases/{ref}/resume` | ref: str | `resume_purchase` |
| GET | `/api/v1/billing/receipts` | cursor: int \| None | `receipts` |
| POST | `/api/v1/billing/receipts/access` | dto: m.Access | `financial_access` |
| POST | `/api/v1/billing/receipts/access/confirm` | dto: m.Proof | `financial_confirm` |
| POST | `/api/v1/billing/receipts/access/prepare` | dto: m.Prepare | `financial_prepare` |
| GET | `/api/v1/billing/receipts/{ref}` | ref: str | `receipt` |
| POST | `/api/v1/billing/refund-requests` | dto: m.CaseCreate | `remedy_request` |
| GET | `/api/v1/blocks` | cursor: str \| None | `blocks` |
| POST | `/api/v1/blocks` | dto: m.Block | `block` |
| DELETE | `/api/v1/blocks/{ref}` | ref: str | `unblock` |
| GET | `/api/v1/bootstrap` |  | `bootstrap` |
| GET | `/api/v1/catalogs` |  | `catalogs` |
| GET | `/api/v1/friends` |  | `friends` |
| DELETE | `/api/v1/friends/{ref}` | ref: str, expected_relationship_revision: int | `remove_friend` |
| POST | `/api/v1/interactions/end` | full wire-2 HTTPControl envelope | `end` |
| GET | `/api/v1/me` |  | `me` |
| GET | `/api/v1/me/consent-proof` |  | `consent_proof` |
| POST | `/api/v1/me/consents` | dto: m.ConsentChange | `consent` |
| GET | `/api/v1/me/notices` |  | `notices` |
| POST | `/api/v1/me/notices/{ref}/seen` | ref: str | `notice_seen` |
| POST | `/api/v1/me/password` | dto: m.PasswordChange | `password_change` |
| POST | `/api/v1/me/policy-acceptance` | dto: m.PolicyAcceptance | `policy_acceptance` |
| PATCH | `/api/v1/me/preferences` | dto: m.Preferences | `preferences` |
| PATCH | `/api/v1/me/profile` | dto: m.ProfileUpdate | `profile` |
| POST | `/api/v1/me/recovery/rotate` | dto: m.RotateRecovery | `recovery_rotate` |
| GET | `/api/v1/me/sessions` |  | `sessions` |
| DELETE | `/api/v1/me/sessions/{ref}` | ref: UUID | `revoke_session` |
| POST | `/api/v1/operations/prepare` | dto: m.Prepare | `prepare` |
| POST | `/api/v1/privacy/delete` | dto: m.Delete | `delete` |
| POST | `/api/v1/privacy/exports` | dto: m.ExportRequest | `export_create` |
| GET | `/api/v1/privacy/exports/{ref}` | ref: str | `export_status` |
| GET | `/api/v1/privacy/exports/{ref}/download` | ref: str | `export_download` |
| POST | `/api/v1/privacy/requests` | dto: m.PrivacyRequest | `rights` |
| GET | `/api/v1/privacy/retention` |  | `retention` |
| GET | `/api/v1/privacy/status` |  | `deletion_status` |
| POST | `/api/v1/privacy/status/access` | dto: m.Access | `deletion_access` |
| POST | `/api/v1/reports` | dto: m.Report | `report` |
| POST | `/api/v1/reports/prepare` | dto: m.ReportPrepare | `report_prepare` |
| POST | `/api/v1/support/access` | dto: m.Access | `case_access` |
| GET | `/api/v1/support/cases` | cursor: str \| None, limit: int | `cases` |
| POST | `/api/v1/support/cases` | dto: m.CaseCreate | `create_case` |
| GET | `/api/v1/support/cases/{ref}` | ref: str | `get_case` |
| POST | `/api/v1/support/cases/{ref}/continuations` | ref: str, dto: m.CaseCreate | `continuation` |
| POST | `/api/v1/support/cases/{ref}/continuations/prepare` | ref: str, dto: m.Prepare | `continuation_prepare` |
| GET | `/api/v1/support/cases/{ref}/messages` | ref: str, after_sequence: int, before_sequence: int \| None, limit: int | `messages` |
| POST | `/api/v1/support/cases/{ref}/messages` | ref: str, dto: m.CaseMessage | `message` |
| POST | `/api/v1/support/cases/{ref}/reopen` | ref: str, dto: m.Versioned | `reopen` |
| POST | `/api/v1/support/cases/{ref}/seen` | ref: str, dto: m.Seen | `seen` |
| POST | `/api/v1/webhooks/cashfree` |  | `webhook` |
| WEBSOCKET | `/api/v1/ws` |  | `socket` |
| POST | `/api/v1/ws/ticket` | dto: Ticket | `ticket` |
| GET | `/health/live` |  | `live` |
| GET | `/health/ready` |  | `ready` |
| GET | `/internal/v1/analytics/series` | metric_id: int, start: datetime, end: datetime, resolution: str | `analytics_series` |
| GET | `/internal/v1/analytics/summary` |  | `analytics_summary` |
| GET | `/internal/v1/audit` |  | `audit` |
| POST | `/internal/v1/auth/login` | dto: m.Mfa | `staff_login` |
| POST | `/internal/v1/auth/logout` |  | `staff_logout` |
| POST | `/internal/v1/auth/recovery` | dto: m.StaffRecovery | `staff_recovery` |
| POST | `/internal/v1/auth/step-up` | dto: m.StaffStepUp | `staff_step_up` |
| POST | `/internal/v1/billing/refunds/confirm` | dto: m.Confirm | `refund_confirm` |
| POST | `/internal/v1/billing/refunds/preview` | dto: m.RefundPreview | `refund_preview` |
| GET | `/internal/v1/billing/reviews` | cursor: str \| None | `financial_reviews` |
| POST | `/internal/v1/billing/reviews/confirm` | dto: m.Confirm | `financial_review_confirm` |
| POST | `/internal/v1/billing/reviews/{ref}/preview` | ref: str, dto: m.ExternalResolution | `financial_review_preview` |
| POST | `/internal/v1/billing/reviews/{ref}/refresh` | ref: str | `financial_review_refresh` |
| GET | `/internal/v1/bootstrap` |  | `staff_bootstrap` |
| GET | `/internal/v1/cases` | cursor: str \| None, limit: int, status: str \| None, category: str \| None | `staff_cases` |
| GET | `/internal/v1/cases/{ref}` | ref: str | `staff_case` |
| POST | `/internal/v1/cases/{ref}/assignment` | ref: str, dto: m.Assignment | `assignment` |
| POST | `/internal/v1/cases/{ref}/claim` | ref: str, dto: m.Versioned | `claim` |
| POST | `/internal/v1/cases/{ref}/classification` | ref: str, dto: m.ObligationCreate | `classification` |
| GET | `/internal/v1/cases/{ref}/messages` | ref: str, purpose: str, after_sequence: int, before_sequence: int \| None, limit: int | `staff_messages` |
| POST | `/internal/v1/cases/{ref}/messages` | ref: str, dto: m.CaseMessage | `staff_message` |
| GET | `/internal/v1/cases/{ref}/notes` | ref: str | `notes` |
| POST | `/internal/v1/cases/{ref}/notes` | ref: str, dto: m.CaseMessage | `note` |
| POST | `/internal/v1/cases/{ref}/obligations/complete` | ref: str, dto: m.ObligationComplete | `obligation_complete` |
| POST | `/internal/v1/cases/{ref}/seen` | ref: str, dto: m.Seen | `staff_seen` |
| POST | `/internal/v1/cases/{ref}/status` | ref: str, dto: m.CaseStatus | `status` |
| POST | `/internal/v1/decisions/confirm` | dto: m.Confirm | `decision_confirm` |
| POST | `/internal/v1/decisions/preview` | dto: m.Decision | `decision_preview` |
| GET | `/internal/v1/health` |  | `private_health` |
| GET | `/internal/v1/legal/rules` |  | `legal_rules` |
| GET | `/internal/v1/privacy/holds` |  | `privacy_holds` |
| POST | `/internal/v1/privacy/holds/confirm` | dto: m.Confirm | `hold_confirm` |
| POST | `/internal/v1/privacy/holds/preview` | dto: m.HoldPreview | `hold_preview` |
| POST | `/internal/v1/privacy/holds/release/confirm` | dto: m.Confirm | `release_hold_confirm` |
| POST | `/internal/v1/privacy/holds/{ref}/release/preview` | ref: str, dto: m.Reason | `release_hold_preview` |
| GET | `/internal/v1/privacy/requests` |  | `privacy_queue` |
| GET | `/internal/v1/release/evidence` |  | `evidence` |
| GET | `/internal/v1/reports/{ref}` | ref: str, purpose: str | `report_read` |

Bounded receipt/block/history cursors are owner scoped. Generated DTO and service code define detailed limits. See `PHASE5_6.md`, `PHASE7_AUDIO.md` and `PHASE8.md` for current end-to-end contracts.
