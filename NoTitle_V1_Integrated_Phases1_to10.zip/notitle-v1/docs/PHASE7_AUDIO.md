# Phase 7 — free audio and enforced relay teardown

The integrated source supports a mutually accepted free audio call inside an existing text interaction. Audio is **closed by default** and must remain closed until the deployment's existing signed qualification gates and actual relay configuration permit it. Unit tests are not a substitute for that qualification.

## Runtime contract

`ConversationAudio(service,media).execute(binding,command,captured_revision)` separates mailbox transitions from mTLS controller effects. Request/response commands carry the current `interaction_handle`; every command after the request also carries `call_id`. Signaling, client-connected and refresh commands carry `negotiation_revision`. Server events carry the same scope. The request consents for the caller, and only the other current participant can accept within 30 seconds. Acceptance transitions the call to connecting before provisioning scoped TURN credentials. No microphone request occurs before `call.connect`.

Only the caller sends an offer, only the other participant answers, and one description per participant per negotiation revision is accepted. SDP is audio-only, bundled Opus with DTLS, and candidates must be UDP relay addresses in the configured relay range. Every advertised candidate's port is additionally checked against the exact participant username's current coturn allocation through the mTLS controller. Direct legacy `Media.signal` is deliberately closed so it cannot bypass attribution.

The controller route `POST /calls/{call_id}/candidate` accepts only `owner_epoch`, `side` (0/1) and an integer `port`, and returns `authorized`. This private route never returns credentials or allocation records. The guard still independently controls paired relay packet permissions with expiring kernel leases; candidate attribution does not replace enforcement.

## Capacity and races

`Media.reserved` is the authoritative accepted-call capacity set, capped at 25 across connecting, connected and teardown calls, including calls whose text interaction has already been removed. `Media.provisioning` prevents cleanup from acknowledging absence while an earlier create/refresh is still in flight. Capacity is released only after the controller confirms `allocations_absent`. Failed or unknown cleanup retains the reservation. End/Cancel only enqueue revocation inside the mailbox and never wait for controller I/O, so text teardown stays responsive.

Provisioning captures the interaction object, call object, call revision, both membership revisions and both socket generations, and validates them after external effects. Signals repeat current authorization/scope checks after allocation lookup. Ringing expires after 30 seconds; setup expires after 20 seconds; caller cooldown is 15 seconds. Credentials renew after five minutes through an existing connected call, without extending call/owner authority or automatically reacquiring a microphone.

Shutdown first marks calls for teardown and stops ordinary media pumping before closing the actor. `Media.shutdown()` then requests explicit controller denial for every known call with at most four concurrent requests and a four-second overall budget. It never sends a heartbeat or renews owner authority. Confirmed allocation absence releases capacity; errors and timeouts retain the deny queue and reservation. A cancelled provisioning effect can append deny work even after the actor mailbox closes, while preserving its original cancellation error. Independent kernel/owner expiry remains the final containment boundary; a successful controller response alone does not prove packet denial.

`AudioControls` subscribes directly to coordinator state so End/Next/Block/disconnect/takeover immediately fences pending permission promises, before React effects run. A late permission grant stops all returned tracks. Navigation unmount closes the peer and tracks. Reconnect never restarts audio. Local mute toggles track enablement and does not authorize or prolong relay leases.

## Reproducible source checks

From the repository root, after installing the pinned Python dependencies:

```bash
PYTHONPATH=api python3 -m unittest discover -s tests/unit -p test_audio_integration.py -v
node --test tests/qualification/audio-lifecycle.test.mjs
```

The Python tests exercise real actor/media transitions with a controlled external-effect boundary, including late create after End, cancellation, unconfirmed teardown capacity, stale negotiation, and a candidate lookup racing End. The Node tests execute the actual `AudioSession` implementation with controlled browser primitives for late grants, ICE restart races, relay-only configuration and cleanup. These are source-level tests, not real network or microphone qualification.

## Mandatory live qualification before enabling audio

Use the pinned coturn build, controller and narrow privileged guard in the existing relay deployment guide. Provision actual public TURN TLS and internal mTLS certificates; no self-signed bypass or direct ICE fallback is permitted. Verify both client networks can reach UDP/TCP 3478 and TLS 443. Capture only the approved test traffic; do not record live conversations.

1. Open two real browser/device sessions, match, request and accept. Verify permission is not requested before acceptance; reject and cancel variants must never acquire a microphone.
2. Verify browser WebRTC stats select relay candidates and the configured UDP relay allocations. Test microphone denial, unavailable devices, suspended tabs and autoplay permission.
3. Compare advertised candidate ports to exact issued coturn usernames. Attempt foreign-call candidate substitution, stale negotiation and old-credential reuse. The server/controller must reject them.
4. While exchanging real test RTP, run End, Next, Block, logout, deletion, socket takeover, signaling loss and normal navigation. Verify tracks close locally and relay packet denial occurs within five seconds.
5. Repeat with owner crash/SIGSTOP, controller/helper crash, network partition, expired certificates and reboot. No surviving owner permission may exceed 30 seconds. Confirm packet permissions expire without cooperation from a browser or controller.
6. Exercise port churn and rapid port reuse; ambiguous or reused ownership must trigger containment. Confirm an ordinary single-call End does not routinely restart unrelated calls.
7. Exercise 25 accepted calls, teardown backlog and a 26th acceptance; the last must fail without granting credentials. Release a slot only after proven allocation absence.
8. Refresh credentials at five minutes; stale credentials and previous negotiation revisions must not regain authority. Measure setup p95 on declared networks and record real CPU/memory/port-budget results.

This environment has not supplied relay certificates, coturn/kernel execution, real browsers with microphone devices or packet-capture evidence. Those live gates remain unverified; do not mark Phase 7 production acceptance complete or enable audio solely from the tests above.
