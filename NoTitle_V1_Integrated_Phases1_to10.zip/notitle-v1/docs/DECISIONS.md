# Current integration decisions — 17 October 2026

The full `product` runtime uses candidate Next exports, the current conversation actor and one wire-2 union for text/social/audio. The stable durable billing entitlement adapter is integrated. Role-specific pools, object-store journal adapter, user-facing audio controls and mTLS relay lifecycle code are present; actual provider/kernel/restore qualification is still open. Earlier decisions below record their original feasibility-stage boundaries and are superseded where the current implementation/feature guides differ.

- Static public/private exports remain separate. Production Caddy rejects public internal/admin and local interface/foundation review routes. Private data still requires authorized API access behind the private tunnel.
- There is one owner and shared actor, not parallel legacy actors. Priority End/call teardown and generation checks apply across all features.
- Report local protection happens immediately; server snapshot freezes before normal server End. Support/report retention is separate from ordinary RAM chat.
- New-account guest conversion imports optional private choices only with fresh consent; existing-account login imports none.
- Hosted checkout runs in a dedicated full-document route with a scoped provider CSP. Verified provider facts, durable jobs and receipts determine financial truth. Maintenance and payment-exception gates close new sales without stopping reconciliation.
- Account totals, account status and recent/live activity are separate metrics. No daily unique user activity log is introduced.
- Schema contract 3 remains stable. Migrations 0009–0012 add least-privilege financial-status access, aggregate-only total counts, external review ownership and startup migration verification; historical migrations are unchanged.
- Available-library checks are distinct from real database, browser, relay, merchant, security/legal and restore evidence. All production phase acceptances remain open.

## Historical feasibility decisions

# Phase 1 architecture decisions

## ADR-001 — preserve the V6 architecture

Keep Next.js static exports, one Python owner, FastAPI public/private ASGI apps, PostgreSQL SQL migrations, a separate guarded coturn relay and one operator CLI. No ORM, Redis, broker, Kubernetes or horizontal workers. The prior deployment kit was not copied into the application: it referenced a different module/CLI contract and would have mixed unverified deployment assumptions into the new source.

The foundation exposes only health routes. Staff API health returns 401 until real staff authentication and grants exist; loopback does not authorize access. Static private content contains no secrets or operational data. The generated public peer contract excludes username, internal IDs, Premium status and professional details.

## ADR-002 — authority is a live proof

The dedicated PostgreSQL connection holds an advisory session lock and increments a database sequence. A second owner fails before listeners start. The coordinator also checks monotonic proof age on every transition; a delayed heartbeat cannot revive expired authority. Losing a listener or the owner heartbeat fences memory synchronously before awaited cleanup. SIGKILL cannot execute Python cleanup, so the database disconnect releases ownership and independent relay leases must expire. These real process/DB behaviors require the supplied integration suite.

Migrations take both migration and owner locks. They reject edited/missing/applied-out-of-order migrations and never reverse a migration. The foundation runtime role can use the epoch sequence and read schema metadata; it cannot create tables or edit migration history. Role-specific application pools are a later implementation task; their V6 budgets are recorded now.

## ADR-003 — independent replay primitive, not a claimed cloud backup

The journal implementation encrypts each record with AES-GCM, binds sequence and previous ciphertext hash as authenticated data, and signs an external high-water anchor. A durable acknowledgment occurs only after local fsync, replica write and read verification. Reusing an operation ID with another payload fails.

The filesystem replica is a **local feasibility adapter**. Tests prove tamper detection, replay and retry behavior, not geographic independence or cloud immutability. Production must implement independent object storage and separately retained latest-anchor evidence. Rolling back both the replica and its trusted anchor is outside the local proof. Do not restore the anchor from the same database backup being recovered. Phase 3 integrates subject controls; Phase 9 implements the independent storage/operations adapter.

## ADR-004 — audio remains an explicit feasibility gate

The guard keeps per-boot allocation identity and refuses reused ports. Kernel permission timeouts are independent of Python heartbeat execution. The source contains a strict parser based on upstream CLI output and a one-call, local-stdin controller bench; its fixtures are synthetic. No pinned binary has yet supplied an actual CLI transcript. Unsupported format fails closed.

The socket helper accepts only bounded port pairs/timeouts from the configured Unix UID and writes only the `notitle_guard` table. It is not a production mTLS controller. The browser bench uses real WebRTC and relay-only candidates but manual signaling; do not mistake it for the future user-facing call feature. Production candidate sanitization, exact allocation cancellation/absence verification, mTLS, boot/secret rotation, repeated-call churn and physical-device qualification remain open. A Linux UDP probe alone cannot qualify browser RTP revocation.

## ADR-005 — payment truth comes from verified server facts

Cashfree is sandbox-only in this package. Browser callbacks do not grant access. Successful capture requires matching server-fetched order status, exact INR amount and one matching successful payment. Unknown network outcomes require fetching the same reference. Webhook verification uses the raw bytes plus the provider timestamp, and is separate from later durable deduplication.

The adapter supports required-remedy refunds only; change of mind is rejected before network work. Full V1 has no voluntary refund or auto-renewal. Annual365 stays disabled: the ordinary provider refund window does not cover its entire duration. The operator needs a lawful, provider-approved late-remedy route before enabling that plan. No merchant credentials or real money were used.

## ADR-006 — unresolved locks must fail visibly

Exact direct versions are candidate inputs. Registry access was denied; Docker and its image registry resolution were unavailable. No fabricated hashes or digests have been supplied. `lock` resolves them on a permitted development machine; `doctor`, builds and CI reject missing/mismatched locks. No production deployment path can bypass the gate. Versions require an advisory review and actual compatibility tests before qualification.

## ADR-007 — external facts remain external

Actual region availability, a current complete cost quote, merchant acceptance, legal entity/contact facts and lawful reconciliation of the no-email instruction are not available in the supplied inputs. Their fields remain unset in `external-inputs.json`, and the gates remain blocked. No infrastructure has been provisioned or billed, no business address invented, and no compliance approval inferred from source code.
