> Current runtime: `domain/conversation.py`, `services/conversation.py`, social/audio handlers and wire-2 `http/realtime.py`, owned by the shared `ClientCoordinator.conversation`. Full `product` uses the durable stable billing adapter. Earlier `realtime.py`/legacy wire-1 source is historical and is not registered as a second actor. Default frontend is `candidate`.

# Implementation reference

## Scope and source precedence

The current source is a V1 implementation candidate based on V6, not the missing V5 download. The user-confirmed constraints are Next.js + FastAPI, adults-only pseudonymous conversations, lightweight solo-operated infrastructure, Chat with Moderator with no support email, privacy-focused administrator analytics, and no voluntary refunds. The V6 reference supplies the feature contracts and plan values. Actual operator facts, regulatory applicability, merchant approval, domains and infrastructure credentials remain external inputs.

V1 does not include video, attachments, offline peer messaging, ordinary chat history, ads, social login, email recovery, automated renewals, Kubernetes, a message broker, or a separate analytics cluster.

## Component map

| Component | Responsibility |
|---|---|
| `web/public/components` | Static information/policies, connected identity/privacy, matching, safety, friends and billing screens; separate read-only review states |
| `web/admin/components` | Connected private cases, moderation, privacy, billing, analytics and operations; separate read-only review states |
| `web/shared/identity.ts` | Phase 3 request ownership, generated runtime contracts, in-memory authority/CSRF, bounded requests and stale-response fences |
| `web/shared/client.ts` | Later candidate HTTP client and explicit receipt download helper |
| `web/shared/audio.ts` | Relay-only audio, delayed microphone fencing, negotiation, credential refresh and track cleanup |
| `api/app/runner.py` | One owner lock, two loopback listeners, startup heartbeat, coordinated shutdown |
| `api/app/domain/conversation.py` | Current synchronous bounded RAM actor; no persistence or network awaits |
| `api/app/http/product.py` | Separate public/private API registration and authorization boundaries |
| `api/app/http/realtime.py` | Single-use ticket handshake, strict envelopes, command deduplication, generation checks and effect revalidation |
| `api/app/services/identity.py` | Account/guest/scoped/staff identities, consent, session limits, recovery and MFA |
| `api/app/services/support.py` | Transactional saved cases/messages, parent continuations, access scope, audited staff plaintext release |
| `api/app/services/social.py` | Durable normalized friendships and asymmetric blocks with symmetric exclusion |
| `api/app/services/media.py` | Call reservation, guarded relay RPC, signaling checks and verified teardown release |
| `api/app/services/billing.py` | Purchase intents, capture verification, FIFO accounting, receipts, required-remedy authorization and reconciliation |
| `api/app/services/privacy.py` | Export, deletion receipt binding, independent journal replay, holds and bounded case retention |
| `api/app/services/moderation.py` | Selected-evidence access and previewed human restrictions/appeals |
| `api/app/services/analytics.py` | Fixed metrics, deduplicated batches, exact transactional contributions, rollups and small-cohort suppression |
| `api/app/jobs/worker.py` | Leased reference-only jobs, bounded retries, retention and aggregation |
| `relay/` | Exact coturn session parsing, mTLS controller, peer-credential Unix helper, nftables rules and qualification probes |
| `ops/` / `infra/` | Configuration, migrations, locks, builds, operator provisioning, publication, deployment, backup/restore and monitors |

## Architecture

```mermaid
flowchart TD
  Browser[Public browser] --> Edge[Caddy public HTTPS]
  Operator[Operator SSH tunnel] --> Private[Private Caddy HTTPS]
  Edge --> Public[Public FastAPI listener]
  Private --> Staff[Staff FastAPI listener]
  Public --> Owner[Single owner and RAM actor]
  Staff --> Owner
  Owner --> PG[Managed PostgreSQL]
  Owner --> Jobs[In-process durable job runner]
  Jobs --> Provider[Cashfree]
  Jobs --> Journal[Independent encrypted journal]
  Owner --> Control[mTLS relay controller]
  Browser --> TURN[Guarded coturn]
  Control --> TURN
```

Public and private Uvicorn listeners run in one supervised process; they do not own separate match pools. One dedicated PostgreSQL advisory-lock connection proves ownership every second. Two-second uncertainty fences admission. Application database work uses 14 fixed connections: public six, support two, private two, jobs two and analytics two. The owner connection makes 15 steady connections. Operator migrations/backups are separate temporary connections.

Caddy serves two static Next exports. No browser gets a database credential or staff API through the public listener. Managed PostgreSQL uses verified TLS. Production admin is loopback-only behind the operator’s SSH tunnel and a trusted local CA.

## Journeys

```mermaid
flowchart TD
  Start[Guest or account] --> Consent[Explicit age and consent]
  Consent --> Queue[Shared compatible queue]
  Queue --> Text[Temporary text interaction]
  Text --> Audio{Both accept audio?}
  Audio -->|Yes| Call[Guarded relay audio]
  Audio -->|No| Text
  Text --> Friend[Mutual friend request]
  Text --> Safety[End, Next, Block or Report]
  Call --> Safety
  Safety -->|Next| Queue
  Safety -->|Report| Case[Encrypted moderator case]
  Friend --> Invite[Online invitation]
  Invite --> Text
```

Support creates a durable case only after the relevant receipt proof or account ownership is validated. A message becomes Sent only after its transaction commits. Identical nonces return the committed sequence; conflicting content returns 409. GET does not mark Seen. Client rendering triggers the explicit monotonic seen mutation. Staff content reads require an allowed purpose and committed audit before decryption is released.

Payments first create a stable intent/order reference. The provider phone remains request memory, never a profile field. A redirect only returns to status checking. Server-fetched order/payment facts must match amount, currency, environment and provider payment ID before one entitlement lot is granted. A required remedy reserves only the originating purchase’s money and time, uses fresh MFA and a bound preview, then enters the durable provider worker. Unknown outcomes remain pending/review rather than being guessed as failure.

Deletion requires recent account authentication and a saved status receipt. The actor fences participation before the journal effect. Independent checkpoint confirmation precedes durable acceptance and profile minimization. Receipt verifiers are included in the encrypted deletion instruction so a restore older than receipt creation can reconstruct status-only authority; plaintext secrets are never journaled.

## Database and transactions

`0001_foundation.sql` preserves the original sequence and migration identity. `0002_application.sql` adds the V1 model; `0003_roles.sql` separates database grants. Migrations through `0012_runtime_migration_contract.sql` are supplied. `0009_billing_reviews.sql` adds only user-visible financial-status column reads; `0010` appends a defined registered-account total to the aggregate-only operational view, `0011` tracks scoped external financial holds, and `0012` permits read-only migration identity checks before startup. Migrations are forward-only, checksummed and excluded while an owner is running. Product/identity startup verifies all required packaged migration names/hashes before listeners open and requires schema contract 3; foundation supports contracts 1–3; migration count and schema contract version are intentionally distinct.

Important constraints include unique usernames/session verifiers, normalized friend pairs, no self-blocks, immutable message sequence/nonce identity, unique provider capture, one lot per purchase, nonnegative lot conservation, bounded enum values, and exact case/deletion/financial receipt scopes. Application locks serialize cross-row money totals and case sequence allocation.

Lock order for money is subject controls → financial subject → purchase → lots → refund. Case writes lock the case before its messages/events. No provider HTTP request runs inside a money transaction. Password work is bounded to two concurrent Argon2id operations (64 MiB, three passes, one lane).

The source has no ordinary conversation-message or audio-recording table. Saved support, selected report evidence and exports use AES-256-GCM envelopes with per-field random data keys and associated data binding the scope. The implementation embeds the wrapped data key and envelope version in the ciphertext column rather than maintaining a separate data-key table. This is an explicit simplification; audited key rotation and backup recovery still require qualification.

## API contracts

Public prefix: `/api/v1`; private prefix: `/internal/v1`. Success: `{data, request_id}`. Error: `{error:{code,message,retryable}, request_id}`. Inputs use strict Pydantic models with extra fields forbidden. Public payloads never contain password/recovery verifiers, raw staff IDs, case notes, provider secrets or private professional categories in the peer DTO.

| Area | Principal routes |
|---|---|
| Bootstrap/identity | `GET bootstrap`; `POST operations/prepare`; `auth/guest`, `auth/register`, `auth/login`, `auth/reauth`, `auth/recover`, `auth/logout`, `auth/logout-all`; session-limit list/resolve |
| Profile/privacy primitives | `GET me`; `PATCH me/profile`, `me/preferences`; `POST me/consents`, `me/password`, `me/recovery/rotate`; session and notice list/revoke/seen |
| Realtime | `POST ws/ticket`; `WS ws` with ticket in the first hello frame; `POST interactions/end` fallback |
| Social/safety | friends list/remove; blocks list/create/remove; reports prepare/submit |
| Support | cases create/list/detail/messages/seen/reopen; exact receipt access; independently receipted continuations |
| Privacy | rights requests; export create/status/download; delete; deletion-status access; scoped financial-receipt preparation/confirmation |
| Billing | plans, purchases/status, entitlement, receipts, required-remedy complaint, signed Cashfree webhook |
| Staff cases | queue/detail/read/seen/claim/assignment/reply/status/notes; report evidence; legal-obligation completion |
| Staff authority | MFA login/recovery/logout; decision preview/confirm; refund preview/confirm; holds preview/confirm/release; privacy queue; audit; operations and release evidence |
| Administrator analytics | summary and bounded hour/day series; fixed metric IDs only |

The exact HTTP models are in `api/app/http/models.py`; the WebSocket payload allowlist and limits are in `api/app/http/realtime.py`. OpenAPI is not exposed publicly. Generate review schemas with the contract command, and use integration tests to validate actual routes.

Each WebSocket command carries protocol version, command UUID, owner epoch, socket generation and interaction revision. Command acknowledgements are bounded and exclude copies of text. Only one connection per identity is authoritative. Audio accepts one bundled Opus audio media section and exact relay candidates; direct ICE, video and data channels are rejected.

## Security and operational decisions

- Distinct host-only production cookies for account, guest, bootstrap, scoped receipts and staff. Development uses visibly separate loopback-only cookie names.
- Exact Origin and principal-bound CSRF on browser writes. Duplicate cookies, oversized bodies, unsupported content types and URL credentials are rejected.
- Endpoint and identity rate controls are RAM-bounded. Short-lived network rate keys use keyed digests; the trusted local proxy overwrites the client-address header. Ordinary request body/access logging is disabled.
- Staff grants are separate for queue, content, triage, assignment, replies, notes, legal actions, safety, money, privacy, analytics and audit. Roles are rechecked at request time. Initial staff accounts are created through a private operator CLI.
- No voluntary refund route or goodwill adjustment exists. Mandatory remedies remain possible. Annual365 is hard-disabled until a tested late-remedy route is implemented and approved.
- No optional analytics tracker, device fingerprinting, user timeline or external analytics database. Small historical counts return suppression in the API itself.
- The relay controller deliberately refuses ordinary restart reuse. A clean coturn/secret/kernel/history restart is an explicit operation requiring packet evidence.

## Qualification limitations and review items

The code must still undergo the supplied real integration/browser suites. High-risk review areas are concurrent receipt/session acknowledgements, guest conversion and durable friend promotion, staff permission changes during long reads, complete hold-release crash recovery, exact legal-clock classification, archive retention/rotation, provider-dashboard disputes, partial required remedies and production rollback across future migrations. Do not mark these accepted by reading the code alone.

Actual coturn cancellation does not make an already issued REST credential immediately cease authenticating. The controller blocks its media path and cancels newly observed allocations until expiry. This distinction is intentional and must be evaluated against the V6 teardown contract in the real packet tests before enabling audio. A failed media feasibility result requires correction or an explicit approved design change; it is not permission to enable unguarded TURN.

External legal, archive, financial-retention and notification duties are not satisfied merely by publishing these drafts. Populate the applicability matrix and obtain reviewed evidence for the actual service, operator and launch date. No self-generated document is a certification of compliance.


## Additional implementation boundaries and corrections

The transport now keeps at most two queued ordinary commands per connection and executes End/queue-cancel/call-end controls synchronously while ordinary effects await database or provider IO. Delayed matching effects recheck revisions before changing actor state. Relay polling runs in a separate supervised coroutine, so a stalled relay does not block text matching. The actual combined-load/control-priority test remains mandatory.

`domain/legal.py` consumes a reviewed, effective-dated rule pack. `domain/receipts.py` validates reviewed merchant/plan receipt facts and exact paise conservation. Production requires legal rules; payment activation additionally requires receipt configuration. These validators do not determine applicable law or tax.

Guest conversion retains the opaque peer identity, fences the old socket, tears down media and promotes mutually accepted friendships once both identities are accounts. Registration records an exact keyed request digest so acknowledgment loss can retry with the already-saved recovery proof. No plaintext password, receipt secret or session cookie is stored in that operation result.

Support history has backward pagination, seen markers and linked continuations. Staff controls include reviewed classification, obligation completion, assignment, report evidence, preview/confirm safety actions, fresh MFA and scoped holds. Session/grant scope is rechecked after staff read-audit commit and before releasing plaintext. Case/financial/deletion receipt authority is selected explicitly to prevent an unrelated receipt cookie from accidentally replacing account authority.

Deletion is locally fenced in the database and queued before remote confirmation. Separate durable confirmation jobs recover interrupted deletion/hold/release effects under the same operation identifiers. Startup repairs authenticated local pending journal instructions before admission and verifies the independent checkpoint. The journal uses conditional object writes, a hash chain and a separately authenticated latest checkpoint; it does not become independent merely by running the development filesystem adapter. Segment rotation and full failure-matrix qualification remain open.

Migration files 0002–0008 extend the original foundation. Phase 3 advances compatibility to contract version 3; this is not the number of migration files. Future incompatible changes must advance the compatibility contract and set release read/write ranges accordingly. Append-only records have restricted UPDATE grants; jobs can mark only `access_audit.archive_batch`, and the dedicated backup login has read-only backup access.

See `HANDOFF.md` for **remaining implementation findings**, including provider-dashboard adjustments, annual remedies, journal segments, key rotation, financial expiry/invoicing and missing external acceptance evidence. These are explicit release blockers, not silently assumed features.


## Phase 1 foundation update — 17 October 2026

`docs/PHASE1.md` and `PHASE1_DECISIONS.md` specify the foundation implementation and its current acceptance boundary. The local-only `APP_MODE=foundation` path constructs the foundation ASGI apps without the product runtime or later integrations. Its initial migration target is 0001, with applied-history checksum validation and no down-migration. Product mode remains separate and uses the full schema contract.

Lease cleanup now covers constructor/startup failures; both loopback ports are reserved before scheduling listeners. Closed role connections repair within the existing 14-slot budget, while ownership never silently reconnects. The mailbox matches V6's 2,048 ordinary/256 reserved control budget. Dependency checks bind locks to current inputs and selected image candidates. Local start/stop is serialized and PID-scoped. Static builds use fresh directories and verified output manifests, allowing CI to test existing exports without rebuilding them.

The `foundation setup` command automates the local path; `foundation verify` records real command outcomes and blocked external gates. Core verification has no authority to accept real PostgreSQL, Next.js, merchant, relay, cloud, cost or legal-contact feasibility. Production cannot use foundation mode.


## Phase 2 interface/publication update — 17 October 2026

`PHASE2.md` defines the current interface source, fixed routes, typed fixtures, static information/policy rendering, public/private export boundaries and publication guards. The separate `interface` build has no API or mutation effects; Phase 3 changes the default to the connected local `identity` profile. The preserved `candidate` build remains subject to identity/realtime/safety/media/money qualification. That Phase 2 update did not change schema/API contracts; Phase 3 below does.

Policy authoring now uses `policies/source.json` only; compilation produces the versioned publication and public frontend projection. Build and release guards bind source, rendered content, exact publication digest, real reviewed facts and existing evidence. Runtime admission and accepted consent versions remain separate operator-controlled release steps. Read `PHASE2_ACCEPTANCE.md` before accepting the phase.


## Phase 3 update — 17 October 2026

`PHASE3.md` documents exact policy/purpose proof, credential replay, database session-cap enforcement, owner/private projections, withdrawal cleanup, rights/export and journal ordering. `PHASE3_ACCEPTANCE.md` separates core tests from actual PostgreSQL, build/browser, assistive technology and restore acceptance. Schema contract 3 and migration 0008 are forward-only; release read/write ranges now require 3. Do not roll the previous contract-2 API back onto it.

The new memory-only coordinator and typed/runtime-generated contracts are used by both identity and candidate auth/privacy screens. Identity mode filters later APIs and excludes payment/refund worker handlers, while keeping support/privacy independent of conversation consent. Support validates a presented account under a restricted capability function without gaining SELECT access to credentials. Format-2 field envelopes authenticate wrapping-key versions and preserve legacy reads; automatic online key rotation remains open.
