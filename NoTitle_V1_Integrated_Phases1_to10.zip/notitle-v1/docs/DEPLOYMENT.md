> Current full local entry point: `python3 ops/nt.py release setup`. Verify with `release verify --level stack` after stopping the owner. Schema contract remains 3; browser conversation wire remains 2. Partial identity/realtime setup commands are preserved for historical qualification, not the default integrated application.

# Solo-developer deployment and operations

## What is automated and what you provide

The baseline follows V6: one application VM, one isolated relay VM, managed PostgreSQL, private object storage, and static Next exports served by Caddy. A single FastAPI owner controls temporary state. Do not put this owner behind automatic multi-replica scaling. No Kubernetes, Redis, Kafka, Celery or separate analytics service is required.

The supplied code has not completed a fresh-machine deployment rehearsal. Treat this guide and its scripts as an implementation candidate until that rehearsal passes. Do not manually mark release evidence as passed to bypass a failing setup.

| You do once | The supplied tools handle |
|---|---|
| Create provider accounts, approve regions/budgets, provision managed services and VMs | Generate local secrets; validate lock artifacts; build images/static exports |
| Choose real public/relay domains and set DNS | Caddy HTTPS certificate issuance/renewal after DNS is correct |
| Obtain database CA/connection details and merchant credentials | Forward-only migrations, fixed runtime pools, ownership checks |
| Configure private buckets, scoped access and offline recovery custody | Encrypted journal writes, database backup commands, finite backup pruning |
| Supply operator/legal/tax facts and review evidence | Versioned policy rendering and publication digest |
| Import staff TOTP enrollment and trust the private admin CA | Staff login, grants, audited case access and short session lifetimes |
| Run and review external qualification; retain signing key offline | Signed release checks, gated deployment, health probes and rollback tooling |

Do not buy production capacity solely from the source package’s historical price estimate. Obtain current quotes and egress costs from the chosen provider. Start with the blueprint’s 2-vCPU/4-GiB app candidate, separate relay candidate and managed database candidate only after region/capacity availability is confirmed. The combined load test determines the actual admission cap; it is not established by those sizes.

## 1. Get a local build working

On your development computer, install Python 3.12, Node 24, npm, uv and Docker with Compose from their official distribution channels. Open a terminal **in the extracted `notitle-v1` directory**.

```bash
python3 ops/nt.py release setup
```

`configure` writes private generated secrets without overwriting existing values. `lock` fetches the declared candidates, resolves transitive hashes and container digests, and writes `api/requirements.lock`, `package-lock.json`, `infra/images.env`, and the lock hashes. Review the actual resolved versions/advisories and commit these generated files. If a candidate does not exist or has a relevant advisory, choose and review a supported replacement in `requirements.in`/workspace manifests/`versions.lock`, resolve again, and rerun qualification. Never fabricate a lockfile or silently loosen a version during deployment.

`dev up` starts PostgreSQL, creates restricted roles, runs migrations, builds static exports, starts one API process, and serves the two loopback sites. Browse `http://127.0.0.1:8080`. The setup starts the full product runtime with candidate frontend; audio and sales stay closed pending their actual qualification. First verify identity, saved recovery, consent, support and privacy. Use two guest contexts for matching, text, End and Block. For the separately qualified candidate private UI, open `http://127.0.0.1:8081` after creating a staff account. Identity mode keeps this site as a static preview:

```bash
.venv/bin/python ops/staff.py owner_user --role owner
```

The tool prompts for the staff password and creates a private enrollment file containing the TOTP setup information and one-time recovery codes. Import it into an authenticator/password manager and remove the temporary enrollment file. Never commit it, screenshot it for a public report, or paste it into support.

Stop the API before the ownership/process suite:

```bash
.venv/bin/python ops/nt.py dev down
docker compose --env-file infra/images.env -f infra/compose.dev.yml up -d --wait db
.venv/bin/python ops/nt.py test --suite integration
```

These tests intentionally refuse a non-local target. They use synthetic data and may terminate the disposable owner connection. Never repoint their credentials at production.

```bash
npm ci --ignore-scripts
npx playwright install --with-deps chromium
.venv/bin/python ops/nt.py dev up --mode product
npm run test:e2e
.venv/bin/python ops/nt.py dev down
```

Verify the real Next typecheck/build separately. A static Python source check is not a frontend build.

## 2. Create isolated staging infrastructure

In the provider console, create an application VM and a separate relay VM in the approved region. Use a supported Ubuntu 24.04 LTS image. Add your SSH public key, verify the host fingerprint using the provider console, and restrict SSH to your operator address in the provider firewall. Keep staging credentials and domains separate from production.

Create managed PostgreSQL in an approved region. In **Connection Details**, obtain the real hostname, port, database name, administrative user/password and CA certificate. Restrict trusted sources to the app VM and the temporary restore/test host. Use direct PostgreSQL connections for the owner advisory lock; transaction-pooling proxies are not compatible with session-lock ownership.

Provider-native recovery is supplemented by an independent encrypted restic repository. Use a separate private journal bucket/prefix with versioning, deletion protection/retention, read-after-write behavior and conditional `If-Match`/`If-None-Match` writes. The included adapter uses AWS S3 through boto3. A generic “S3 compatible” provider is not accepted without testing these exact semantics. This is a deliberate feasibility gate when evaluating a single-provider Spaces setup.

Keep journal credentials separate from backup/prune credentials. The app must not delete journal object versions or change bucket policy. Keep a recovery copy of encryption/signing keys outside the VM and database backup lifecycle. Review region, processing and transfer arrangements before storing production data.

## 3. Bootstrap hosts and database roles

Copy the repository to the selected staging app host. Review `ops/host-bootstrap.sh`, then run **on that fresh host**:

```bash
sudo bash ops/host-bootstrap.sh
```

This installs distribution-signed host packages, enables the firewall/time synchronization and establishes directories. The operator still verifies SSH restrictions, persistent swap configuration, update/reboot policy and provider firewall rules. Record the exact installed host/relay versions in qualification evidence. Do not run the host script on an unrelated existing server.

Production database bootstrap must use the managed provider’s administrative connection and the database actually named in the connection details. The local `ops/nt.py db bootstrap` is intentionally tied to `notitle` on the disposable local environment; do not edit that test guard to point at production. Use the managed setup command:

```bash
.venv/bin/python ops/managed_database.py --secrets /etc/notitle/secrets
```

It prompts for the managed database host, port, database, CA path and admin credentials; writes restricted role DSNs privately; creates the runtime/migrator/support/private/jobs/analytics/backup roles and role timeouts. The provided PostgreSQL migrations assume these roles exist. Your provider administrator must have authority to create these restricted roles; if it does not, create the same roles in the console and review the grants rather than granting the app superuser privileges.

Run migrations only with the API owner stopped:

```bash
.venv/bin/python ops/managed_database.py --secrets /etc/notitle/secrets --migrate-only
```

Verify that runtime roles cannot create tables or read migration history as a writer, and that the analytics role cannot select saved case bodies. The real integration suite validates this locally; repeat the least-privilege probes against staging with synthetic content.

## 4. Generate and install private configuration

Use separate production secrets. `ops/nt.py configure` can generate random HMAC, wrapping and journal keys in an isolated clean checkout; copy only the necessary values into the host’s root vault using a protected channel. Do not reuse local or staging keys. For production, supply these files:

| Private file | Source |
|---|---|
| `runtime_dsn`, `support_dsn`, `private_dsn`, `jobs_dsn`, `analytics_dsn` | Managed setup tool; all include `sslmode=verify-full` and the actual CA path |
| `hmac_key`, `wrapping_key`, `journal_encryption`, `journal_signing` | OS-generated 256-bit values; keep offline recovery custody |
| `journal_config` | JSON with actual `bucket`, `prefix`, `region` |
| `journal_aws_credentials` | Scoped AWS credential profile `notitle-journal`, obtained through your IAM setup |
| `cashfree_client_id`, `cashfree_secret` | Approved merchant dashboard; test/live values isolated |
| `relay_config` | JSON with actual control `base`, `relay_ip`, `certificate`, `key`, `ca` paths |

The root vault is `/etc/notitle/secrets`, mode 0700 with files 0600. The public process receives **only its required files**, in `/etc/notitle/runtime-secrets`, owned by UID 10001 and mode 0400, mounted read-only as `/run/secrets`. Migrator, backup, deployment-signing and provider-administrator credentials must not be mounted into the API container. Put the database CA in the runtime subset and ensure every role DSN points at its container-visible CA path.

Build the web exports and place them in the release directory as `web-export/public` and `web-export/admin`. Create your nonsecret site-input JSON with these exact keys: `app_domain`, `turn_domain`, `app_ip`, `relay_ip`, `policy_version`, `policy_digest`, and reviewed `qualification`. The real domains/IPs come from your DNS registrar/provider console, not a sample domain in source.

```bash
.venv/bin/python ops/production.py render \
  --config site-input.json \
  --exports web-export \
  --output generated-production
```

Review and install the generated files under `/etc/notitle`. `application.json` starts with admission, payments and audio closed. CSP hashes are generated from actual exported HTML. Checkout-specific provider hosts must pass the hosted-checkout browser test before payment activation. Do not add an unrestricted script wildcard to make a failing checkout appear to work.

Initialize the independent journal prefix once, using its scoped environment and a private local work directory:

```bash
.venv/bin/python ops/journal.py \
  --secrets /etc/notitle/secrets \
  --work /var/lib/notitle/journal-initialization
```

This refuses a nonempty prefix. Test checkpoint verification, local/remote failure, rollback to an older database and retained receipt authority before production admission.

## 5. Domain, HTTPS and private admin

Create an A record for your actual application domain pointing to the app VM and an A record for the TURN name pointing directly to the relay VM. Do not put an ordinary HTTP proxy in front of TURN. Public inbound ports are 80/443 on the app; application listeners 8000/8001 remain loopback-only. Caddy obtains and renews the public certificate once DNS and firewall routing work.

The private admin listens on loopback port 8443 under `admin.notitle.internal`. Add `127.0.0.1 admin.notitle.internal` to your local hosts file, obtain and verify the Caddy **public root certificate** through the trusted SSH channel, and import that certificate into your local trust store. Never export the CA private key or disable TLS verification. Open the operator tunnel using your verified host alias:

```bash
ssh -N -L 8443:127.0.0.1:8443 notitle-app
```

Visit `https://admin.notitle.internal:8443`. Its exact Origin must match `application.json`. Test that the public site returns 404 for `/internal/v1/cases`, that the private listener cannot be reached over the public network, and that passwords without MFA cannot authenticate staff. Enable HSTS only after the domain/certificate rehearsal succeeds; do not preload/include all subdomains by default.

## 6. Relay and audio qualification

Run coturn on the isolated relay VM with UDP/TCP 3478, TLS 443, IPv4 relay address, UDP relay ports 49152–50175, no TCP relay, no mobility, user quota four and total quota 256. The CLI listens on loopback and uses a private password. Only the app host can reach the mTLS control port; only the unprivileged relay controller can call the narrow Unix guard helper. The helper owns only the `inet notitle_guard` nftables table.

Use `ops/relay_setup.py` to render the exact configuration and unit files from real host/certificate values. Review them against the pinned coturn build. The source CLI parser intentionally rejects unfamiliar/truncated output. A version change requires contract/packet requalification.

Before enabling audio, execute the existing `relay/packet_probe.py`, `relay/control_spike.py` and browser spike against actual RTP. Include End, Next, Block, logout, account deletion, socket loss, owner kill, controller stall, credential recreation, allocation cancellation, port reuse and long-call credential refresh. Record packet tails, tested build IDs and kernel behavior. A successful signaling response or unit test is not proof that media stopped.

The controller requires a verified clean relay restart after a controller/owner replacement; history cannot simply be removed while old coturn allocations survive. Run the generated restart unit, which stops controller/coturn, clears only its owned rule table, rotates the boot secret, removes old port-history state and starts the stack in order. Re-run a smoke call. Keep `audio=false` until the complete evidence is accepted.

## 7. Payment and policy setup

Create/approve the merchant account through Cashfree’s dashboard. Use sandbox credentials for staging. Configure the exact HTTPS webhook URL `/api/v1/webhooks/cashfree` and the reviewed event types. The adapter pins `x-api-version: 2026-01-01`; qualify that version against the real account. Test raw-body signatures, delayed callbacks, duplicate captures, unknown order creation, browser returns, held required remedies, refund retries and provider-dashboard actions.

Fill the actual tax rule, merchant identity and receipt requirements with the accountant. Do not claim tax registration or tax-inclusive treatment merely because the blueprint contains a price. Enable only the reviewed Short3/Week7/Month30 catalog versions after evidence passes. Annual365 stays disabled until a merchant-approved, tested late-remedy implementation exists. No voluntary refund, unused-purchase exception or automatic renewal may be added.

Policies are initially **drafts**. Supply the genuine operator/processor/contact facts and a reviewed applicability matrix. The current legal commencement schedule must be checked for the intended launch date; draft policy copy is not legal approval. A lawful outage/urgent contact and incident-notice route must work under the no-support-email rule.

Follow `PHASE2.md` to fill `policies/operator.template.json` with genuine facts and prepare a source/operator/version/date-bound review worksheet. Obtain current hashed evidence before compiling reviewed terms. The final commands are:

```bash
.venv/bin/python ops/nt.py policies publish \
  --operator .local/operator.json \
  --review .local/review.json \
  --version v1-reviewed-1 \
  --effective-at 2026-12-01T00:00:00+05:30
.venv/bin/python ops/nt.py policies check --require-reviewed
```

The date is syntax illustration, not a prescribed launch. Review every generated HTML page and actual provider/contact/retention fact. Configure the actual HTTPS build origin, select `candidate`, rebuild/audit both exports, and use the printed exact publication digest/version in runtime configuration. The render/release tools reject fixtures, mismatched policy/origin, stale artifacts and unreviewed copy. Publication does not enable admission or checkout; all release gates remain required.

### Journal capacity monitoring

The journal currently stops at 10,000 records. Monitor directory metadata and resolve lifecycle work before the 8,500-record warning; never reset its anchor or delete records. The dedicated monitor account needs directory-only access, while encrypted record files remain private. The fresh-host bootstrap installs this directory-only ACL automatically for the standard path. For an existing host or a different journal directory, after those directories exist:

```bash
sudo apt-get install -y acl
sudo setfacl -m u:notitle-monitor:rx /var/lib/notitle/journal /var/lib/notitle/journal/local
```

If your configured journal directory differs, substitute that actual directory and its `local` child. Configure the existing `ops/monitor.py setup` with your real HTTPS readiness URL and private alert/deadman files. It derives the journal path from the production application settings, or accepts `--journal-directory`. Missing metadata access raises `JOURNAL_CAPACITY_UNAVAILABLE` rather than showing a healthy capacity check. File reads are not granted by these directory ACLs.

## 8. Backups, alerts and maintenance automation

Initialize a private encrypted restic repository with a strong generated password in `RESTIC_PASSWORD_FILE`. Configure separate `[notitle-backup]` object credentials and PostgreSQL service `notitle_backup`. Copy `infra/backup.env.example` to the private host configuration and set the real repository URL obtained from the bucket console. Do not place passwords in shell command arguments.

`ops/backup.py backup` streams a custom-format PostgreSQL dump directly into restic, checks the repository and retains 30 daily snapshots. It does not write an unencrypted dump to disk. Configure service-user access and the backup status path, then install the two backup unit files:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now notitle-backup.timer
sudo systemctl start notitle-backup.service
sudo systemctl status notitle-backup.service
```

Provider backups and independent backups have different failure domains. Restore into a new isolated database; do not overwrite the live cluster:

```bash
.venv/bin/python ops/backup.py restore \
  --snapshot latest \
  --service notitle_restore \
  --isolated-target
```

The `notitle_restore` PostgreSQL service must name the new cluster. Before exposing restored data, verify the independent latest journal, replay deletions/holds, validate role grants/keys and run application invariants. If the latest checkpoint or recovery key is missing, keep admission closed. Backups are not searchable support archives.

Configure `monitor.json` with `health_url`, `backup_status_file`, and a private `alert_webhook_file`. The alert destination is an owner-controlled monitored channel; only status codes are sent. Install the monitor units and test actual delivery and human acknowledgment. Use an external availability check as well: a timer on the failed VM cannot notify you that the VM is gone. Review due cases/jobs and legal obligations in the private workspace; independent responder coverage is a launch dependency.

## 9. Qualify and sign the exact release

Run `ops/qualify.py collect` for available local evidence. It intentionally leaves production-required checks as `not_run`. Complete each item in `contracts/qualification-matrix.json` in the correct staging environment. Keep the resulting reports as files and record their SHA-256 hashes in the evidence index. An authorized reviewer changes a check to passed only after reviewing its real output. No script fabricates a passing payment, restore, packet or legal report.

Create an offline release signing key once:

```bash
.venv/bin/python ops/production.py keygen --key /secure/offline/notitle-release.key
```

Use a path on your actual encrypted offline device. Copy only the `.pub` file to `/etc/notitle/release-signing.pub` on the deployment host. After building and pushing the API image to your private registry, obtain its immutable digest from the registry output. Sign the release with that exact digest, source hashes, static-export hashes and reviewed evidence:

```text
.venv/bin/python ops/production.py release --evidence <reviewed evidence index> --image <registry image@sha256:digest> --release-id <your version> --key <offline key path> --output release.json
```

The angle-bracket values cannot be prewritten: they identify your built release and private credential location. Obtain them from the preceding build/evidence/key steps. The command refuses unresolved locks or missing/failing mandatory evidence.

## 10. Deploy, verify, update and roll back

Copy the reviewed release directory, built exports and signed manifest to `/opt/notitle/releases/<release-id>` using your trusted SSH/SFTP connection. Install `images.env` with the signed API digest and the locked Caddy digest. Run the deployment command **on the app host**, from its operator Python environment:

```text
sudo .venv/bin/python ops/production.py deploy --release-dir /opt/notitle/releases/<release-id> --manifest /opt/notitle/releases/<release-id>/release.json --caddy-image <locked Caddy image@sha256:digest>
```

Boot startup is supplied by `notitle-runtime.service`. The fresh-host bootstrap installs/enables it; it starts only the current release after a healthy committed deployment record, while holding the deployment lock. Interrupted/failed migrations remain closed on reboot. This is boot automation; unexpected owner loss requires the monitored operator restart/recovery workflow.

The tool checks signatures/source, validates Caddy, pulls the immutable API image, stops the previous owner, requires a backup, runs migrations, switches the current release symlink and checks readiness. A failure leaves admission stopped for inspection; it does not restore an old database or undo paid-user data. Rehearse this on a fresh staging host before calling it one-command production deployment.

Verify: public HTTPS and true 404; private tunnel/MFA; new guest matching/text/End/Block; case creation/reply/read audit; real approved checkout/receipt; guarded audio; independent journal; backup freshness; actual alert delivery. Only then enable the reviewed admission/payment/audio flags. Restart the owner through the same controlled process after configuration changes.

For an update, resolve/review changed dependencies, run CI and qualification affected by the change, back up, sign a new manifest and deploy. Planned owner replacement ends temporary conversations. Show maintenance in the application before the window and verify recovery afterward. Do not run two owners to hide this interruption.

Rollback uses the previous signed artifact only if it can read the current schema. Never down-migrate money/user data automatically. If the old artifact cannot read the expanded schema, forward-fix while admission stays closed. For data recovery, restore an isolated cluster and replay the independent journal; changing the image is not a data restore.

## Troubleshooting

| Symptom | Check and resolution |
|---|---|
| Dependency download returns 403 | Use a machine/network authorized for npm, PyPI and the container registry; do not invent packages or bypass access controls |
| Unresolved lock / image digest | Run the lock command, review/commit outputs, rebuild and requalify |
| Runner exits before readiness | Validate secret file ownership/mode, exact TLS DSNs, schema contract, owner lock and independent journal continuity; error output deliberately omits secrets |
| Owner already running | Stop the old supervised process; do not force a second owner or use multiple Uvicorn workers |
| CSRF or Origin rejected | Open the configured canonical URL; check proxy Host, private tunnel port and the correct scoped receipt session |
| API is ready but no audio | Audio gate, relay mTLS, exact coturn format, kernel helper or clean-boot history may be closed; never bypass relay-only rules |
| Payment is pending | Reconcile the same purchase/order reference; do not create a new charge based on a timeout |
| Support returns 409 | Reload the case version, or retry the same nonce/content after a lost response; use a new nonce for a genuinely new message |
| Analytics shows a gap | Inspect job/pool health; do not reconstruct missing activity from personal logs |
| Journal verification fails | Keep admission closed; compare the independently retained latest checkpoint and key custody; never reset the journal to match an old DB |
| Backup or alert overdue | Treat as an operational incident, test actual restore/delivery and acknowledgment, then reopen release gates |

Daily: review safety/support/rights deadlines, billing exceptions, backup success and alert delivery. Weekly: review dependency advisories, host patches, capacity and costs. Monthly: rehearse a restore, verify key recovery, review retention/holds and rotate only through a tested migration procedure. Before increasing admission caps, rerun the combined load and packet tests.

## Exact supplemental configuration commands

These commands complete the helpers introduced after the original Phase 1 scaffold. Run source commands from the repository root; commands using `/etc/notitle` run on the selected host as its authorized operator. Inputs named below must come from your own provider console or reviewed legal/accounting determination.

### Runtime secrets and reviewed rules

Create `legal_rules` in the root vault before installing the runtime subset. Start from `policies/legal-rules.template.json`. A reviewed rule has `id`, `version`, `authority_ref`, `categories`, `automatic` (boolean), timezone-aware `effective_from`/optional `effective_until`, and positive integer `acknowledge_seconds`/`act_seconds`. The acknowledgment deadline cannot exceed the action deadline. Record all six reviewed categories even where the review determines that no automatic rule applies. Supply the review evidence reference and change the pack state to `reviewed` only after that review.

```bash
.venv/bin/python ops/legal_rules.py \
  --reviewed-pack reviewed-legal-rules.json \
  --destination /etc/notitle/secrets/legal_rules
sudo .venv/bin/python ops/runtime_secrets.py \
  --vault /etc/notitle/secrets \
  --destination /etc/notitle/runtime-secrets \
  --ca /etc/notitle/secrets/db_ca.pem
```

`db_ca.pem` is the actual managed provider CA downloaded through its authenticated console. The destination must be new: the installer refuses to overwrite recovery keys. Add `--audio` only after placing `relay_config`, `relay-client.pem`, `relay-client.key` and `relay-ca.pem` in the vault; their JSON paths must be `/run/secrets/...` inside the container. Add `--payments` only after installing the merchant credentials and reviewed receipt configuration. For a staged feature activation, create a separate new runtime-secret directory, verify its allowlist, and change the mount through a signed/reviewed release. Never delete a live secret directory to bypass the guard.

Legal classifications use the original server receipt time. A first moderator reply acknowledges open clocks. Closing a case requires classification and completed obligations. Continuations inherit the root case; they do not reset deadlines. The worker updates overdue flags every minute. Human responder coverage and actual notice delivery remain required.

### Reviewed merchant receipt facts

Start from `policies/receipt-configuration.template.json`. Populate genuine merchant legal name, postal address, lawful contact route and any reviewed registration details. For each enabled Short3/Week7/Month30 plan, add a `plans` entry with `version`, `tax_rule`, integer `net_paise` and a `taxes` array of `{ "name": ..., "paise": ... }`. The net amount plus all components must equal that plan’s fixed gross price. A genuinely nontaxable determination can use an empty tax array; do not infer nontaxability from the template.

Set `state` to `reviewed` and include `review_evidence_ref` only after review. Save the same reviewed bytes privately as `/etc/notitle/secrets/receipt_configuration`. Use a **new plan version** whenever facts change:

```bash
.venv/bin/python ops/catalog.py \
  --secrets /etc/notitle/secrets \
  --reviewed-receipts reviewed-receipts.json \
  --policy-version v1.0
```

Replace `v1.0` with the exact published policy version. After merchant/legal/receipt/remedy qualification, run the same command with `--enable`. The application-wide payments gate still applies. Purchases snapshot those merchant/tax facts before the provider request; capture creates an append-only receipt with a unique database receipt number. No client controls price, tax or duration. This source produces **payment receipts**, not a blanket assertion that every required tax invoice or credit note has been implemented. Close the relevant finding in `HANDOFF.md` first.

### Private relay control certificates

Generate the private control PKI on the operator’s trusted machine. The prompts avoid placing invented host values in configuration:

```bash
read -r -p 'Actual relay IPv4 address: ' NT_RELAY_IP
read -r -p 'Actual TURN DNS name: ' NT_TURN_DOMAIN
.venv/bin/python ops/relay_pki.py \
  --relay-ip "$NT_RELAY_IP" \
  --relay-domain "$NT_TURN_DOMAIN" \
  --output .local/relay-pki
```

Keep `relay-ca.key` offline. Only the app receives `relay-client.key`; only the relay receives `relay-control.key`. Both receive their leaf certificate and the public `relay-ca.pem`. Verify ownership and control-port firewall restrictions. Private control leaf certificates expire after 90 days; monitor expiry and rehearse rotation before that deadline. This tool intentionally does not create the browser-facing public TURN TLS certificate.

On the isolated relay host, install the **qualified coturn version**, nftables, Python and an ACME client. Obtain the browser-facing certificate for the actual TURN domain using the ACME client’s documented DNS or HTTP challenge. If using Certbot’s standalone HTTP challenge, reserve port 80 for renewals; keep 443 for coturn. Configure a renewal hook that installs the renewed leaf/key with relay-user access and invokes the clean relay restart unit. Verify the hook in staging: replacing only the controller while allocations survive is unsafe. Public certificate renewal and private mTLS rotation are distinct operations.

Create a relay-input JSON with exactly `relay_ip`, `turn_domain`, `tls_certificate`, `tls_key`, `control_certificate`, `control_key`, `control_ca`. All certificate paths are absolute paths on the relay host. Render:

```bash
python3 ops/relay_setup.py --config relay-input.json --output generated-relay
```

Create the system account `notitle-relay` with UID 10002 on that host, install the generated configuration in `/etc/notitle-relay`, and the unit files in `/etc/systemd/system`. The controller’s config/key and rotated TURN/CLI secrets must be readable only by that service account/root. The guard is the narrow privileged process; coturn and the controller run as `notitle-relay`. Run `systemctl daemon-reload`, then `systemctl enable --now notitle-relay.service` only after the firewall/certificate/packet prerequisites are satisfied. See the exact setup source before applying it to your machine.

### Independent backup setup and recovery grants

Managed setup now creates the separate `nt_backup` login. It has SELECT privileges for a complete encrypted backup and is **never** mounted into the application container. Provide a private credentials file containing the `notitle-backup` object-store profile. Obtain the actual repository URL from the independent bucket console:

```bash
read -r -p 'Actual private restic repository URL: ' NT_BACKUP_REPOSITORY
sudo .venv/bin/python ops/backup_setup.py \
  --vault /etc/notitle/secrets \
  --repository "$NT_BACKUP_REPOSITORY" \
  --aws-credentials /etc/notitle/secrets/backup_aws_credentials
sudo cp infra/systemd/notitle-backup-init.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl start notitle-backup-init.service
sudo systemctl enable --now notitle-backup.timer
sudo systemctl start notitle-backup.service
```

The initializer runs only for a new repository. Preserve the generated restic password in independent recovery custody before relying on backups. The status file is `/var/lib/notitle/backup/status.json`. A snapshot is tagged `notitle-verified` only after pg_dump, repository backup and integrity checks succeed. The restore tool selects only verified snapshots and refuses a nonempty target. A failed partial dump may leave a `notitle-pending` object snapshot; investigate it, then remove it through a reviewed maintenance action.

For an isolated restore, provision the same restricted roles first; configure the `notitle_restore` PostgreSQL service to connect **as `nt_migrator` to the new empty database**. After restoration, no-owner/no-ACL backups need the grants reapplied:

```bash
.venv/bin/python ops/restore_grants.py --dsn-file /secure/recovery/isolated_migrator_dsn
```

The path must contain the new isolated database’s DSN. Do not use the live DSN. The helper reapplies only versioned GRANT/REVOKE/default-privilege statements and requires a stopped owner. It does not replay table-creation migrations or rewrite their checksums. Then apply any unapplied forward migrations, verify the independently retained latest journal, recover pending local instructions, replay deletion/holds and run restore qualification before admitting traffic.

### Audit archive automation

Configure `/etc/notitle/secrets/audit_archive_config` with real `bucket`, `prefix`, `region`, and `reviewed_retention_days: 180` only when the reviewed schedule/location supports those values. Configure `/etc/notitle/audit.env` with a dedicated archive AWS profile/credential-file path. Restrict it to the archive bucket/prefix. Create the operator environment with the exact hash-locked Python requirements at `/opt/notitle/operator-venv`.

```bash
sudo cp infra/systemd/notitle-audit.service infra/systemd/notitle-audit.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now notitle-audit.timer
sudo systemctl start notitle-audit.service
```

Each run archives at most 1,000 minimal audit records older than a day, encrypts them, verifies the remote object and only then marks the source rows. Source rows expire only once archived and older than 180 days. Configure provider retention/holds and recovery-key custody separately; a local mark is not an independent archive. Monitor backlog and failure; increase scheduling frequency within measured budgets if necessary.

### Compatible application rollback

Run on the app host with the exact previous signed manifest and locked Caddy digest:

```text
sudo /opt/notitle/operator-venv/bin/python ops/production.py rollback --release-dir /opt/notitle/releases/<previous-release-id> --manifest /opt/notitle/releases/<previous-release-id>/release.json --caddy-image <locked-caddy-image@sha256:digest>
```

Rollback verifies the previous source/signature against the **current** database schema, regenerates CSP hashes from the target exports, switches the release link and recreates both containers so bind mounts point at the correct files. It never runs the old migration inventory or rolls database contents backward. If the schema is incompatible, perform a forward repair. Keep the original manifest/artifact intact; renaming arbitrary source to a previous release does not make it an authorized rollback.


## Phase 3 update and rollback boundary

Migration 0008 advances schema compatibility to 3. Stop the owner before applying it. Existing migrations are unchanged and checksummed; no down-migration is provided. The previous contract-2 API cannot roll back onto contract 3. Use a tested compatible contract-3 artifact or forward repair. Any DB restore must replay the independent privacy journal before admission, including reconstructed deletion receipts and removed restored exports/sessions.

`identity verify --level stack` automates fixed-local configuration/migration/integration/build/browser startup and scoped cleanup; it never deploys. Changed package scripts/shared exports require fresh web locks. Local configuration preserves keys and refuses remote origins/production environments. Production secret reading accepts owned 0400/0600 regular files and the explicitly allowed root-owned group-readable 0440 mount profile, opened without following symlinks; no broadly readable file is accepted.
