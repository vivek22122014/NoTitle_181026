# Specification and technical references

Implementation basis: the recovered NoTitle Master Blueprint V6 and Phase 1 source supplied through the existing project files. Earlier V5/Phase 1 notes are retained as history, not as current acceptance evidence.

Official technical sources inspected during this implementation, 13 October 2026. Recheck version-sensitive contracts on the actual qualification date:

- Next.js static exports: https://nextjs.org/docs/app/guides/static-exports
- FastAPI WebSockets: https://fastapi.tiangolo.com/advanced/websockets/
- Psycopg connection/pool behavior: https://www.psycopg.org/psycopg3/docs/advanced/pool.html
- Cryptography Argon2id/PHC derivation: https://cryptography.io/en/latest/hazmat/primitives/key-derivation-functions/
- Cashfree API and webhook documentation: https://www.cashfree.com/docs/api-reference/payments/latest/overview
- Cashfree refund limits and behavior: https://www.cashfree.com/docs/payments/manage/refunds/overview
- Coturn CLI source: https://github.com/coturn/coturn/blob/master/src/apps/relay/turn_admin_server.c
- Coturn example configuration: https://github.com/coturn/coturn/blob/master/examples/etc/turnserver.conf
- Caddy TLS configuration: https://caddyserver.com/docs/caddyfile/directives/tls
- DigitalOcean PostgreSQL restoration: https://docs.digitalocean.com/products/databases/postgresql/how-to/restore-from-backups/
- S3 conditional writes: https://docs.aws.amazon.com/AmazonS3/latest/userguide/conditional-writes.html
- S3 Object Lock: https://docs.aws.amazon.com/AmazonS3/latest/userguide/object-lock.html
- Restic backup behavior: https://restic.readthedocs.io/en/stable/040_backup.html
- MeitY Digital Personal Data Protection Rules 2025 and associated commencement material: https://www.meity.gov.in/documents/act-and-policies/digital-personal-data-protection-rules-2025-gDOxUjMtQWa?pageTitle=Digital-Personal-Data-Protection-Rules-2025

These sources informed implementation choices. They do not establish that a particular merchant, hosting region, legal entity or deployment is approved, compliant, available at a quoted price, or qualified. No current-price quote has been invented.


Phase 1 update references rechecked on 17 October 2026: Next.js static export documentation above, and Psycopg connection classes/transaction/closed-connection behavior at https://www.psycopg.org/psycopg3/docs/api/connections.html. Official GitHub setup-action resolution was unavailable, so no new action SHA was invented; the existing pinned checkout is retained and CI obtains Node from its reviewed immutable image.


Phase 3 technical references rechecked on 17 October 2026: cryptography Argon2id/PHC documentation above; PostgreSQL explicit locking at https://www.postgresql.org/docs/18/explicit-locking.html; OWASP session lifecycle/cookie guidance at https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet.html. These support technical controls, not legal certification or a real-stack acceptance claim.
