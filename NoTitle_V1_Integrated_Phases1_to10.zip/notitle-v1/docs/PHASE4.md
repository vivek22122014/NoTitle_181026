# Phase 4 — matching, realtime and temporary text

This amendment implements V6 chapters 7–8, 22–24 and 58 on the saved Phase 3 project. It is the current implementation specification for the free conversation path. Source delivery and successful core checks do not equal full-stack or production acceptance. See `PHASE4_ACCEPTANCE.md` and `../evidence/phase4/REPORT.md`.

## Scope and resolved decisions

| Classification | Decision |
|---|---|
| Mandatory V1 | One shared pool; mutual filters and blocks; oldest feasible anchor; bounded relevance/repeat avoidance; temporary plain text; safe End/Next/Cancel; single owner; privacy and support remain separate |
| Implemented Phase 4 | Free matching, typed wire 2, explicit socket takeover, connected desktop/mobile chat, server/rendered receipts, bounded replay of the current RAM ring, HTTP End/Cancel fallback, queue invalidation and free/session Block |
| Deliberate phase boundary | Every deployed runtime uses `FreeLedger`. No endpoint, environment switch or admin action grants synthetic Premium. Account-only paid-filter scenarios inject a stable synthetic ledger in unit tests |
| Confirmed later V1 | Phase 5 selected reports/private operations; Phase 6 friends/invitations; Phase 7 audio/relay teardown; Phase 8 stable paid-ledger integration; Phase 9 aggregate analytics/operations; Phase 10 combined qualification |
| Correction | Replace the unsafe wire-1 conversation surface with wire 2. An unscoped late End must never end a newer interaction. Foundation protocol 1 / schema 3 are separate, unchanged contracts |
| Correction | Uniform server RNG resolves matching score/age ties; persistent peer references are no longer published on the Phase 4 wire |
| Correction | Professional interests allow ten choices; the other selection lists remain capped at five. Controlled catalog validation and consent remain mandatory |
| Preserved constraint | No support email; no ordinary transcript persistence; no voluntary refunds; required legal/payment remedies remain available |
| Inherited limitation | Phase 3 currently caps guest creation/resident actor identities at 200. Do not claim the historical 1,000-resident-guest target is qualified; increasing it needs a separate residency/admission design and load proof |

The previous `domain/realtime.py`, `domain/protocol.py`, legacy application screens and a byte-preserved `http/realtime_legacy.py` remain later-phase reference source. The legacy transport is not registered. Its social/media command vocabulary must be ported into versioned wire contracts and qualified in the relevant later phase. Those features must not be marked complete because source exists.

## Architecture and trust boundaries

```mermaid
flowchart TD
  UI["Next.js static Chat screen"] --> Client["Phase 3 identity coordinator"]
  Client --> Transport["Same-origin HTTP and WebSocket"]
  Transport --> Mailbox["Reserved control and ordinary mailboxes"]
  Mailbox --> Actor["Single-owner RAM actor"]
  Auth["Session, consent and policy checks"] --> Mailbox
  Auth --> DB["Existing managed PostgreSQL roles"]
  Actor --> Reservation["Versioned pair reservation"]
  Reservation --> Auth
  Actor --> Buffers["Bounded text and event rings"]
```

No Redis, broker, extra database, transcript table, separate matching worker or analytics service is introduced. Next remains statically exported and Caddy serves both independent public/private exports. FastAPI owns one conversation actor under the existing PostgreSQL owner lease; do not run multiple replicas or `uvicorn --workers >1`. Ownership uncertainty fences state rather than transferring live conversations.

`ConversationActor` subclasses the retained actor for compatibility with identity/privacy/social service calls, but overrides matching, projection, text, reconnect, output and teardown. Its transitions are synchronous and do no database/network work. `Conversation` performs external authorization, then dispatches a commit that checks the current binding, generation, interaction revision, pending intent, deadlines and reservation stamp again.

The shared mailbox has 2,048 ordinary slots and 256 reserved control slots. Each drain runs at most 64 control and 64 ordinary callbacks before scheduling another event-loop turn. End/Cancel/Next teardown uses the control path. Each socket independently limits waiting ordinary work to two commands and processes one authorization task at a time. A cancelled or obsolete effect cannot publish after a control transition. Saturated ordinary work is rejected; saturated control fences the owner and clears conversation RAM rather than silently dropping a safety action.

The scheduler runs every 100 ms, starts at most four concurrent pair validations and spends at most 100 ms / 10,000 candidate checks per pass. Pair validation has a two-second deadline, runs outside the actor, checks both identities and persisted blocks and publishes only the same reservation. The retained mailbox, actor scan and pool limits are distinct bounds. Core scan timing does not prove whole-system throughput.

## Matching algorithm

1. Admission authenticates a guest/account with current core consent and no participation fence. Account checks lock the current account/session, verify current adult/Terms proof and query restrictions. Account revisions include auth, profile, preference, consent and safety; the injected entitlement adapter adds its stable revision.
2. Search carries current profile/preference revisions and a unique operation ID. Everyone is the free filter. Specific declared-gender filters require a currently entitled registered account. Guest authorization always receives zero paid entitlement.
3. Add or update the waiter without resetting its age. A relevant profile/preference/optional-consent edit invalidates reservations and pauses a queued intent while retaining its age. The user explicitly searches again. An active conversation keeps its frozen peer profile and receives a current snapshot instead of being ended by an optional edit.
4. Scan waiters in ascending wait-start order. Select the oldest anchor with a feasible candidate, skipping an incompatible head without blocking others. Compatibility requires distinct identities, current connected socket/revision, no existing interaction, mutual gender acceptance, no block in either direction and no pair ended during the last four seconds.
5. Rank feasible candidates once per selection using the formula below. Highest score wins; then larger candidate wait age; then uniform `secrets.SystemRandom` choice. Tests inject a seeded generator. Payment does not create a separate pool or queue priority.
6. Reserve both identities for at most two seconds. Capture actor revision, socket generation, waiter object identity and whether entitlement is currently active. Reauthorize both outside the transition, hydrate saved blocks and recheck all captured state immediately before creating both memberships atomically.

For candidate wait `w`, anchor wait `a`, and seconds `d` since this pair last ended:

```text
fade = max(0, 1 - max(a, w) / 5)
repeat_penalty = 60 * exp(-(d - 4) / 10)  if 4 <= d < 300, else 0
score = w - repeat_penalty + fade * (topic + professional)
```

Pairs with `d < 4` are ineligible. Topic contributes 0.5 only for the same non-General declared topic. Per professional direction, each selected non-interest category contributes 0.1 for any overlap (OR within the category); interests contribute `0.1 * intersection_count / selected_distinct_count`. Cap each direction at 0.5 and average both directions, including a free/disabled direction as zero. Consent, an enabled saved preference and active paid entitlement are necessary. General Talk by either participant, or a General topic, disables professional influence in both directions. Maximum total positive relevance is one second and fades entirely after the older participant waits five seconds. Repeat metadata expires after five minutes.

Strict entitlement expiry pauses Search and preserves age; it never silently changes the filter to Everyone. Everyone keeps waiting and loses professional influence when entitlement expires. These paid paths are tested with synthetic ledger I/O; the shipped Phase 4 runtime provides no paid authority.

## User journey and screens

```mermaid
flowchart TD
  Lobby["Authenticated lobby: idle"] --> Search["Explicit Search"]
  Search --> Waiting["Shared queue"]
  Waiting --> Match["Temporary text conversation"]
  Waiting --> Cancel["Cancel: idle"]
  Match --> End["End or Block: clear text"]
  Match --> Next["Next: End first, then authorize Search"]
  Next --> Waiting
  Match --> Interrupted["Disconnect: sending paused"]
  Interrupted --> Resume["Explicit reconnect within 25 seconds"]
  Resume --> Match
  Interrupted --> Expiry["Grace expires: clear text"]
```

`/chat/` and `/talk/` render the same connected screen in `realtime` and `candidate` frontend profiles. Identity, profile, settings, privacy and basic saved Support use the existing shared coordinator. Public policies remain static and readable without JavaScript. The private export remains a read-only interface during this phase.

| Screen region / state | Interaction and implementation |
|---|---|
| Entry | Loading is read-only. An unauthenticated person chooses Guest or Log in. Identity creation and consent do not open a socket or start Search |
| Lobby context | Display the owner pseudonym/topic, Everyone and General Talk/selected topic. General topic forces General Talk. Other topics may toggle it before Search; changing saved profile/preferences invalidates queued work |
| Desktop | Context/safety panel beside the transcript and composer; bounded scroll region; visible End, Next, Block and Support controls |
| Mobile | Single-column conversation first, context below, no horizontal overflow, 44 px control targets and shared mobile navigation. Keyboard/zoom/screen-reader usability still requires browser/manual qualification |
| Waiting | Show searching and Cancel. Do not invent a queue position, ETA or paying-user priority |
| Matched | Show only peer pseudonym, gender, topic and bio. Render message strings as React text, including markup-looking text. No HTML rendering, Markdown parser or link-preview fetcher |
| Composer | Clamp to 2,000 code points / 6,144 UTF-8 bytes. Enter sends, Shift+Enter adds a newline; IME composition does not send. No automatic re-send of an uncertain message |
| Message status | Pending is local; Accepted is server RAM acceptance; Delivered follows a receiving browser acknowledgment after React commits the bubble. Never label it Read |
| Interrupted | Disable sending and Next, clear the draft, show a countdown and explicit reconnect. End and Support remain available |
| End / Next / Block | Immediately clear local text and mark the old handle ended so a delayed snapshot cannot restore it. End contacts the scoped server teardown. Next ends first and performs new authorization; failure leaves the old conversation ended |
| Takeover | Ticket conflict discloses only this identity’s current socket generation. A separate explicit button replaces that socket. The old tab clears ordinary content and does not reconnect or search automatically |
| Later features | Audio visibly disabled; friends, sales and report submission are not represented as connected/qualified Phase 4 flows |

The client is a member of `ClientCoordinator`, not a component-owned independent connection. React subscribes through `useSyncExternalStore`. Identity clear/replacement invokes conversation teardown, clears timers and removes the socket. Route changes through Next can preserve the same authorized in-memory connection; a full page unload closes it and the server applies its grace rules. Browser storage, service workers, IndexedDB, caches and analytics are not used for chat content.

## HTTP and WebSocket contracts

Authoritative Python DTOs: `api/app/domain/conversation_contracts.py`. Generate schemas and TypeScript with `python3 ops/nt.py contracts`; check drift with `--check`.

Generated files are `contracts/generated/conversation-v2.schema.json`, `web/shared/conversation.schema.json` and `web/shared/conversation.generated.ts`. `wire.ts` validates all browser inputs/events at runtime from the same JSON schema; TypeScript alone is not trusted. Unknown fields, coercions, invalid discriminators, non-finite values, oversized frames and invalid text are rejected. The server also rejects duplicate command JSON keys. Do not put validation inputs or tickets into error messages/logs.

| Endpoint | Request / response | Authorization |
|---|---|---|
| `POST /api/v1/ws/ticket` | `{takeover:false, known_socket_generation:0}` → `{ticket, expires_in:60, owner_epoch, protocol_version:2}` | Existing guest/account cookie, exact HTTP Origin/Host and purpose-bound CSRF; five tickets/minute/identity; global 400 / two outstanding per identity |
| `WS /api/v1/ws` | First text frame is Hello; subsequent typed commands/events | Exact public Origin and Host, no query string, no duplicate security/cookie headers; ticket binds the current cookie principal and captured revisions |
| `POST /api/v1/interactions/end` | Full wire-2 `interaction.end` or `queue.cancel` envelope → bounded ACK | Same cookie, current binding/generation, Origin and CSRF. End targets an explicit interaction; Cancel targets one Search operation |
| `POST /api/v1/blocks` | `{peer_handle}` → existing truthful `{persisted,scope,...}` result | Current or recent own conversation-scoped handle resolves server-side; immediate RAM exclusion/End precedes an account persistence effect |

The new HTTP End path intentionally rejects the former empty/unscoped body. A recognized old ended handle returns `already_ended` without touching a newer conversation. A stale socket/owner fails even if its interaction handle was valid earlier. WebSocket End and its one-second HTTP fallback reuse the **identical envelope and operation ID**. Late HTTP results are ignored after the browser changes its current intent/authority.

Hello, sent after connection open and before the five-second handshake deadline:

```json
{"protocol_version":2,"type":"session.hello","ticket":"single-use 43-character URL-safe ticket"}
```

The example describes the ticket format; it is not a usable ticket. Obtain a real value only from the authenticated ticket endpoint. Never put it in the URL, browser persistence or logs. A ticket is consumed before its asynchronous authorization, so a failed cookie binding cannot replay it.

All ordinary command envelopes contain:

```text
protocol_version: 2
command_id: canonical UUID string
type: one of the commands below
owner_epoch: positive owner-lease generation
socket_generation: current socket generation
interaction_epoch: current per-identity actor revision
payload: command-specific strict object
```

| Command | Payload | Effect |
|---|---|---|
| `queue.join` | `gender`, `general_talk`, `profile_revision`, `preference_revision` | Authorize, preserve valid age and enqueue; cannot join while matched |
| `queue.cancel` | `search_command_id` | Cancel exactly that pending/queued search; if it just matched, end only the interaction created by that search |
| `interaction.end` | `interaction_handle` | Clear only that current conversation, or acknowledge its known prior teardown |
| `interaction.next` | End handle + Search fields | End synchronously through reserved control before any new authorization/network work |
| `text.send` | `interaction_handle`, `text` | Validate current connected pair; assign random message ID and increasing per-interaction sequence; emit sender/recipient projections |
| `text.delivered` | `interaction_handle`, `message_id`, `sequence` | Only the opposite recipient can acknowledge the exact retained message; duplicates are harmless |
| `session.resume` | `last_server_sequence` | Send the authoritative bounded snapshot; no transcript archive, backlog guarantee or automatic resending |
| `heartbeat` | finite `client_time` | Liveness acknowledgment; does not renew foreground/idle authority |

Events include `session.ready`, `state.snapshot`, `queue.waiting/cancelled/paused`, `interaction.started/ended/interrupted`, `text.message/delivered`, `command.ack/error`, `heartbeat.ack` and `service.draining/unavailable`. Each carries protocol, owner/socket/interaction generations, strictly increasing per-identity `server_sequence` and server wall time. `interaction.started` includes the originating Search operation ID so Cancel/Next intent can be reconciled without guessing. A sequence gap asks for a snapshot; it does not replay text or Search.

Peer projection is exactly `{peer_handle, display_name, gender, topic_id, bio}`. The random peer handle changes each interaction. A message is `{id, sequence, sender:"me"|"peer", text, sent_at, delivered, command_id}`; the command ID is exposed only to its sender, never to the peer. The handle/ID maps remain server RAM and expire; they are not user-visible activity logs.

## Bounds, liveness and cleanup

| Resource | Enforced bound / behavior |
|---|---|
| Actor identities | 200 including disconnected grace; no active identity eviction to make space |
| Waiting identities | 100; the 101st receives an explicit capacity error |
| Pending handshakes | 32; first frame within five seconds; ticket valid 60 seconds |
| Ordinary frame | At most 8,192 UTF-8 bytes; binary not accepted. Uvicorn has an overall 64 KiB ceiling / eight buffered incoming frames and disables compression |
| Output | At most 64 queued events / 256 KiB per identity; one event removed per write, three-second write deadline. Slow readers disconnect; plaintext is not copied into an unbounded transport queue |
| Text | 1–2,000 Unicode code points and at most 6,144 UTF-8 bytes; reject controls other than tab/CR/LF and invalid surrogates |
| Transcript | At most 30 messages / 65,536 text bytes per interaction. Metadata is bounded by message count. Browser projection applies the same text/count limits, including pending messages |
| Command dedupe | At most 128 results/identity, 120 seconds, ACK ≤512 bytes. Digests/ACKs contain no chat text. Reused ID with different envelope is rejected within that window |
| Browser command memory | At most 16 outstanding frames, at most ten text sends; socket buffered bytes must be ≤64 KiB |
| Liveness | Browser heartbeat every 20 seconds; socket receives no frame for 45 seconds → disconnect. Absolute/idle authority remains independent |
| Disconnect | Remove waiter/reservation immediately. Sending is disabled while either member is disconnected. Current ring may resume for 25 seconds from the earliest disconnect, then both memberships/rings are removed |
| End / withdrawal / logout / deletion | Remove interaction, ordinary text ring, pending/reserved work and queued plaintext snapshots/events. Current-generation checks prevent late effects from republishing |
| Recent peer maps | Ended-handle mapping for Block / safe HTTP End proof up to ten minutes, at most 10,000 entries; repeat pairing record five minutes; no text |
| Owner loss / shutdown | Fence actor and clear tickets, bindings, queues, reservations, rings, caches and temporary relations. A restart never restores ordinary text from backup |

Monotonic time governs server deadlines/wait ages; wall time is a display value. Client timers/countdowns are advisory and can be delayed by browser suspension or clock differences. The server is authoritative. “Cleared” is logical removal of application references; Python/JavaScript do not promise forensic overwrite of RAM, and a peer/device may retain its own copy. Production host setup must keep core dumps and persistent swap disabled. The runner also sets `RLIMIT_CORE=0`, and the API container specifies zero core limits. Host hibernation/memory dumps and operator diagnostic tooling require the launch security review.

Heartbeat/resume/rendered-delivery commands never extend idle expiry. Meaningful foreground activity renews at most once per minute using the Phase 3 identity service. If current authority expires or policy/restrictions fail, conservatively end and disconnect; support/privacy access is separate. A dependency failure closes peer service until an explicit, fully authorized reconnect succeeds; it does not restart Search automatically.

## Data and persistence

There is **no Phase 4 migration**. Schema contract 3 and migrations 0001–0008 are byte-preserved. Existing account/session/consent/restriction/block tables supply authorization and saved account blocks; guests, queues, socket generations, match reservations, messages, delivery flags and repeat metadata remain RAM-only.

No ordinary text is written to PostgreSQL, journals, job payloads, logs, export files or backups. No per-user chat/matching analytics trail is introduced. Metrics use the existing fixed aggregate catalog; service counters have a fixed set of names and no identity labels. Basic Support is the intentionally retained, encrypted case system from Phase 3. Ordinary chat is not silently copied into a case. Selected report evidence is a separate explicit Phase 5 workflow; it is not enabled by this phase.

The current billing `entitlement()` advances accounting and `ledger_revision` on each read. Using it during ticket prepare and connect makes the revisions disagree even without a user change. Phase 4 therefore does not connect that method to conversation admission. Phase 8 must supply and test a stable read projection with atomic authoritative change detection, including holds/revocations/expiry, before paid filters are enabled. UI badges and a checkout redirect are never paid authority.

## Implementation map

| File | Responsibility |
|---|---|
| `api/app/domain/conversation.py` | Pure bounded actor, reservations, random tie-breaking, scoped projections, frozen peer profile, sequences, ring/delivery and erasure |
| `api/app/domain/conversation_contracts.py` | Strict wire DTO authority, byte/code-point/duplicate-key validation and limits |
| `api/app/services/conversation.py` | Tickets, current policy/session/restriction checks, test-injectable ledger boundary, prioritized dispatch, async authorization and effect revalidation |
| `api/app/http/realtime.py` | Origin/Host/hello guard; bounded reader/worker/writer; control preemption; HTTP End/Cancel |
| `api/app/http/realtime_legacy.py` | Unmounted historical wire-1 adapter, preserved for later porting |
| `api/app/runtime.py`, `settings.py`, `runner.py` | Local realtime profile, tick/pair tasks, owner shutdown, transport and core-dump limits |
| `api/app/services/identity.py`, `account_controls.py` | Exact session-expiry projection; choices invalidate reservations without unintentionally ending active free text |
| `web/shared/identity.ts`, `conversation.ts`, `wire.ts` | One memory-only identity/chat coordinator, generated runtime validation, bounded state, intents, receipts and teardown |
| `web/public/components/Conversation.tsx`, `Surface.tsx` | Connected Chat/Talk routes, responsive plain text and lifecycle-safe UI |
| `ops/conversation.py`, `identity.py`, `conversation_benchmark.py` | Shared setup/evidence pipeline and explicit actor-only timing |
| `tests/unit/test_phase4.py` | Actor/service/race/contracts/mailbox/expiry tests; synthetic repository/ledger I/O labelled as such |
| `tests/qualification/conversation-client.test.mjs` | Execute the real TypeScript coordinator with mock transport; no replacement client implementation |
| `tests/integration/test_conversation.py` | Real disposable PostgreSQL + Uvicorn TCP/WebSocket tests, account/guest pairing, auth, replay, takeover and End responsiveness |
| `tests/qualification/phase4.spec.ts` | Real two-context browser desktop/mobile text, delivery, End/Next/Block/reconnect/takeover tests |

## Local setup and manual steps

1. Install Python 3.12, Node 24/npm, uv, Docker Engine with Compose, and a modern browser on Linux/WSL2. Allow the actual Python/npm/container registries. The package deliberately contains no invented lockfile, image digest or cloud credentials.
2. Extract the archive and open a terminal in `notitle-v1`. Stop an existing owner with `.venv/bin/python ops/nt.py dev down`. Keep your existing keys and database; do not replace `.local/secrets` with another installation’s values.
3. Run `python3 ops/nt.py conversation setup`. For reviewed existing locks use `--locked`; `--no-start` configures/installs/checks without starting services. Setup resolves locks before installation/build, generates restricted local secrets, bootstraps roles, runs forward migrations, builds and starts one owner plus Caddy. Resolve a failing prerequisite before retrying.
4. Open `http://127.0.0.1:8080`. In two independent browser contexts, create guests with unchecked-to-explicit consent and choose Search in each. Two tabs sharing cookies exercise takeover instead of two participants.
5. Verify name-only peer projection, plain text, accepted/delivered status, End/Next/Cancel, Block and Chat with Moderator. Use `dev status` and `dev down` to inspect/stop local services. Never treat the local HTTP origin as a public deployment configuration.

Existing installation commands, from the project root:

```bash
.venv/bin/python ops/nt.py conversation configure
.venv/bin/python ops/nt.py lock
.venv/bin/python ops/nt.py install
.venv/bin/python ops/nt.py dev up --mode realtime
```

The few manual decisions are local prerequisites, access to real registries, review/commit of resolved locks/advisories and browser test observations. Ports, secret generation, role setup, migrations, builds, Caddy wiring and exact local profile are automated. No merchant account, public domain, relay VM, paid subscription or additional managed service is necessary for this phase.

## Verification, CI and release

```bash
.venv/bin/python ops/nt.py conversation verify --level core
.venv/bin/python ops/nt.py dev down
.venv/bin/python ops/nt.py conversation verify --level integration
npm ci --ignore-scripts
npx playwright install --with-deps chromium
.venv/bin/python ops/nt.py conversation verify --level stack
```

Core executes Python tests, both actual coordinator Node suites, generated contracts, policy/route/build/source guards and an actor-only scan benchmark. Integration adds resolved-lock/runtime/Docker checks, role bootstrap, real migrations and the whole disposable integration suite, including network WebSockets. Stack adds separate real export/API builds, npm typecheck, a realtime runner and five browser scenarios. It requires a stopped owner and tears down only the PID it created. Nonzero/blocked results remain failures; all evidence files bind source and output hashes. No command marks legal/production gates passed automatically.

CI preserves independent Phase 2 and Phase 3 qualification, adds the Phase 4 client suite, real network tests through the integration suite and a separate realtime build/typecheck/browser step. The older candidate browser matching controls now target the connected chat screen. Missing reviewed locks intentionally fail CI.

For a local update: stop the owner, preserve keys, replace reviewed source, resolve changed dependency inputs, migrate forward if needed, rebuild and restart in realtime mode. Phase 4 itself has no DDL to reverse. To roll back the wire-2 feature, stop admission/owner first and restore a known complete previous source/build profile; the resulting restart erases current ordinary conversations. Do not mix an old frontend with the new wire or point a schema-2 API at schema 3. Production deployment remains blocked by combined Phase 10 evidence and reviewed legal/provider facts; use the existing gated production guide only after those gates are satisfied.

## Troubleshooting and operations

| Symptom | Action |
|---|---|
| Registry returns 403 / Docker missing | Resolve registry access or install Docker on your development machine. Do not fabricate locks or call core evidence a build/integration pass |
| Static buttons still show preview/older wording | Run `conversation configure`, rebuild and restart; `--skip-build` accepts only a verified matching export |
| `SOCKET_EXISTS` | Another tab owns this identity. Choose explicit takeover or close that tab; do not retry takeover automatically |
| `TICKET_STALE` / expired | Identity/profile/consent/socket changed, or the first-frame window elapsed. Explicitly reconnect; never reuse a ticket |
| `REVISION_CONFLICT` / queue paused | Refresh identity, review profile/privacy choices and Search explicitly. Valid wait age is retained for a paused queued edit |
| Strict paid filter rejected | Expected in the shipped free profile. Do not add a fake ledger flag. Phase 8 owns paid activation |
| Peer disconnected | Stop sending. Reconnect explicitly inside the service grace; if it expires, current text is gone and cannot be recovered from Support/backups |
| Uncertain send / socket pressure | Show unconfirmed status. Do not auto-resend; the nonce cache only covers the bounded two-minute current-authority window |
| End not confirmed | Local content stays cleared; the connection is closed and no new search starts automatically. Reconnect explicitly and let the saved stop intent finish; contact Support if needed |
| Owner/database failure | Peer interactions end conservatively. Review aggregate health, restore owner/database health and reconnect explicitly; do not restore ordinary chat from a diagnostic dump |
| Browser suite fails | Keep its failing result, inspect synthetic test output and reproduce locally. Text/credential traces and automatic screenshots remain disabled |

Continue existing backups/restore testing for retained records, key custody, policy version review, dependency patching and public/private boundary monitoring. The Phase 4 actor adds no backup target. Observe aggregate request/loop latency and bounded service counters; never enable raw frame, body, cookie or transcript logging to troubleshoot matching.

Technical references reviewed for the transport design: [FastAPI WebSockets](https://fastapi.tiangolo.com/advanced/websockets/), [OWASP WebSocket security](https://cheatsheetseries.owasp.org/cheatsheets/WebSocket_Security_Cheat_Sheet.html), and [MDN bufferedAmount](https://developer.mozilla.org/en-US/docs/Web/API/WebSocket/bufferedAmount), and the [websockets asyncio client reference](https://websockets.readthedocs.io/en/stable/reference/asyncio/client.html). These references do not certify this implementation or replace the acceptance tests.
