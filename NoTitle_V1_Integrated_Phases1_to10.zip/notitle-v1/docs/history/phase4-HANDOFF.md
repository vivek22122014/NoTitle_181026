> Latest delivery is Phase 4 matching/realtime/temporary text. Start with `PHASE4.md` and `PHASE4_ACCEPTANCE.md`, and use `conversation setup` / `conversation verify`. Earlier evidence remains historical; combined production acceptance is still open.

> Phase 3 was updated on 17 October 2026. Read `PHASE3.md`, `PHASE3_ACCEPTANCE.md` and `../evidence/phase3/REPORT.md`. The current default is local identity/privacy, with later product APIs closed. Production acceptance remains open.

> Phase 2 was updated on 17 October 2026. Read `PHASE2.md` and `../evidence/phase2/REPORT.md` for the current interface/publication scope. The Phase 2 read-only preview remains available as `interface`; the broader candidate below remains unqualified.

> Phase 1 was updated on 17 October 2026. Start with `PHASE1.md` for that scope; the broader implementation findings below remain applicable.

# Implementation handoff — 13 October 2026

## What is delivered

This package extends the recovered Phase 1 project against Master Blueprint V6 with implementation across all ten requested phase areas. It contains source code, migrations, frontend screens, policy drafts, test suites, operational tools and deployment instructions. It is an **integration candidate**, not a production-qualified release. No public deployment, live payment or message to an external recipient was performed.

Use these files in this order:

1. `README.md`: local setup and the qualification boundary.
2. `docs/PHASES.md`: ten-phase deliverables and acceptance requirements.
3. `docs/IMPLEMENTATION.md`: architecture, ownership, contracts and security decisions.
4. `docs/API.md` and `contracts/generated/`: routes and generated strict request/command schemas.
5. `docs/DEPLOYMENT.md`: development, managed database, credentials, domains, relay, billing, backups, qualification, update and rollback.
6. `evidence/REPORT.md`: exactly what ran and what did not.
7. `docs/blueprint-v6-reference.txt`: the recovered authoritative specification; retain it when reviewing deviations.

## Code coverage by phase

| Phase | Main source |
|---|---|
| 1 Foundation | `api/app/coordinator`, `repositories`, `runner.py`, `ops/nt.py`, lock workflow |
| 2 Interface/policies | `web/public`, `web/admin`, `web/shared`, `policies`, `ops/policies.py` |
| 3 Identity/privacy | `services/identity.py`, `services/primitives.py`, `domain/security.py`, scoped receipts and consents |
| 4 Matching/text | `domain/realtime.py`, `domain/protocol.py`, `http/realtime.py` |
| 5 Safety/support | `services/support.py`, `services/moderation.py`, reviewed legal clocks, private staff controls |
| 6 Friends/profile | `services/social.py`, profile/preference endpoints, mutual requests/invitations and conversion promotion |
| 7 Audio | `web/shared/audio.ts`, `services/media.py`, `relay/controller.py`, kernel guard, PKI/setup and packet probes |
| 8 Payments/remedies | `services/billing.py`, `domain/ledger.py`, `domain/receipts.py`, Cashfree adapter, catalog configuration |
| 9 Analytics/operations | `services/analytics.py`, `jobs/worker.py`, privacy retention, journal adapters, backup/audit/monitor tools |
| 10 Qualification/handoff | Unit/integration/browser suites, CI, generated contracts, qualification matrix, signed releases and this guide |

“Source delivered” is different from “phase accepted.” Each phase still needs the acceptance evidence listed in the phase table.

## Remaining implementation findings

These are not merely missing credentials; review and close them before declaring the full V6 release complete:

- **Provider dashboard actions and disputes:** verified purchase/refund reconciliation and required-remedy jobs exist, but automatic ingestion and adjudication of every externally initiated refund, chargeback and dispute is not complete. The refund webhook currently wakes order reconciliation. Build and test the provider-specific external-adjustment path before enabling live payments; a dashboard refund must never leave an unjustified entitlement.
- **Annual365:** deliberately unavailable. A provider-approved late statutory-remedy settlement path has not been supplied or implemented. Do not work around the gate by using a shorter-window refund API.
- **Journal lifecycle:** the independently checkpointed journal is bounded to 10,000 instructions. Segment rotation, recovery custody across segments and expiry of obsolete tombstones need a reviewed implementation and restore test. Capacity must not be increased blindly.
- **Key rotation:** encryption/HMAC keys are isolated and purpose-bound, but online multi-key rotation and historical rewrapping are not automated. Use a tested maintenance migration before replacing keys; overwriting files would strand retained data or credentials.
- **Entity-specific financial retention and invoicing:** receipt snapshots include reviewed merchant facts and an exact integer net/tax breakdown. They are payment receipts. Any legally required invoice/credit-note numbering, customer information, tax reporting or statutory record-expiry procedure must be implemented from the operator’s actual determination. The template is not a substitute for that determination.
- **Legal operations:** rule-pack classification, independent clocks, escalation flags, completion evidence and held-case protection are implemented. Actual reviewed rules, an independent appeal reviewer, statutory notice delivery and the lawful outage-contact arrangement are external prerequisites. An empty rule pack cannot be justified merely by the installer accepting its schema.
- **Database reconnection and sustained performance:** loss of owner authority fails closed. Role-pool reconnection has local failure tests in the Phase 1 update; real connection repair, slow-provider fault behavior, starvation checks, full role/permission coverage and combined workload limits need the supplied integration environment and further correction if the tests expose failures.
- **Frontend qualification:** the Next.js apps have not been typechecked, built or run in a browser in this environment. Complete type/build, keyboard/focus, mobile overflow, receipts/history, six-session recovery and multi-tab takeover testing before treating the UI as accepted.

## First completion session on your computer

Follow `README.md` to resolve real locks, install dependencies, bootstrap a disposable PostgreSQL database and run the integration/browser suites. Fix failures in the actual components; do not replace them with mocks to obtain a green release. Keep audio and payments off while testing identity, text, support and privacy. Then qualify the isolated relay and merchant sandbox separately, close the findings above, rehearse an old-database restore, and sign the exact tested artifacts.

Production configuration refuses missing mandatory qualification flags. The signed release tool requires eight passed checks and existing evidence hashes. Neither local unit tests nor a signed report alone proves packet teardown, legal applicability or provider behavior.
