# NoTitle V1 — Phase 2 interface and policy publication

This update implements Master Blueprint V6 chapter 56 on the preserved Phase 1 foundation. It delivers read-only public and private interfaces, all eleven typed screen groups, fixed static routes, readable policy drafts, guarded publication, and verification tooling. **It is source ready for local qualification, not an approved production release.**

Start with `docs/PHASE2.md`. Phase 1 remains documented in `docs/PHASE1.md`; later-phase integration source and its known findings remain in `docs/HANDOFF.md`.

## Preview the interface

Run these commands from this extracted `notitle-v1` directory on Linux/WSL2. Prerequisites: Python 3.12, Node 24/npm, uv, Docker Engine/Compose, and authorized access to package/image registries. If Phase 1 already resolved and installed the current locks, begin at `interface configure`. Changes to package scripts/exports require resolving the web lock again.

```bash
python3 ops/nt.py lock
python3 ops/nt.py install
.venv/bin/python ops/nt.py interface configure --mode interface
.venv/bin/python ops/nt.py interface verify --level core
.venv/bin/python ops/nt.py build --target web
.venv/bin/python ops/nt.py interface serve
```

Open http://127.0.0.1:8080 for the public UI and http://127.0.0.1:8081 for the private example workspace. Review all states at `/interface/` on each listener. Stop the existing Phase 1 local stack first if it owns these ports. Ctrl+C stops this preview. No database, API, sign-in, conversation, microphone, support submission or payment is started by the preview server.

The existing integration candidate is preserved behind an explicit `interface configure --mode candidate` build. That setting does not qualify or enable its features. Foundation API mode is independent of the interface build profile.

## Check and qualify

```bash
python3 ops/nt.py interface check
python3 ops/nt.py policies check
node ops/check-web.mjs
.venv/bin/python ops/nt.py test --suite unit
```

After exports are built and browser dependencies are installed:

```bash
npm ci --ignore-scripts
npx playwright install --with-deps chromium
NT_PYTHON=.venv/bin/python npm run test:interface
```

`test:interface` starts and stops the loopback-only static preview itself; ports 8080/8081 must be free. Browser/OS dependency installation may require local administrator access. It never deploys the application.

**Executed evidence:** 136 unit tests passed; policy/route/build guards and contract checks passed. TS/TSX syntax was parsed using the provided runtime parser. **Not executed:** actual TypeScript/Next builds, real exported-asset audit, browser/keyboard/mobile/zoom qualification, Caddy validation, and reviewed legal publication. npm registry access returned HTTP 403; Docker and the application frontend dependencies are absent here. Read `evidence/phase2/REPORT.md` and `latest.json` for the exact boundary. Syntax or synthetic HTML tests do not count as a real build.

## Policies

Edit `policies/source.json`; never independently edit generated policy copies. Seven policy documents and operator/contact/grievance/processor pages are statically rendered. Drafts stay labelled, noindex, and ineffective. No support email address is supplied. Successful purchases have no voluntary refunds; non-waivable statutory, verified payment-error and binding provider/bank remedies remain available.

The publication command requires genuine operator/provider records and current hashed evidence bound to the policy source, operator, version and effective date. The full procedure is in `docs/PHASE2.md`. It does not change runtime consent acceptance, admission, payment flags or deployment.

## Documentation

- `docs/PHASE2.md`: scope, decisions, screen/route map, publication and exact local commands.
- `docs/PHASE2_ACCEPTANCE.md`: browser, assistive technology, legal and artifact checklist.
- `evidence/phase2/REPORT.md`: executed checks and blocked work.
- `docs/PHASE1.md`, `docs/PHASE1_DECISIONS.md`: preserved foundation implementation.
- `docs/PHASES.md`, `docs/IMPLEMENTATION.md`, `docs/HANDOFF.md`: full V1 and known gaps.
- `docs/DEPLOYMENT.md`: managed production deployment and operations.
- `docs/blueprint-v6-reference.txt`: recovered source authority.

No public deployment or live financial action was performed. The source archive excludes generated secrets, installed dependencies and build caches.
