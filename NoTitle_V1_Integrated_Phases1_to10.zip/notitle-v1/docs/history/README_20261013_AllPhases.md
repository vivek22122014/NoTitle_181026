# NoTitle V1 — phases 1–10 implementation candidate

This repository extends the recovered Phase 1 source against **Master Blueprint V6**. It contains the Next.js public and private applications, FastAPI HTTP/WebSocket services, PostgreSQL migrations, domain logic, relay controller, payment/retention workers, policy drafts, deployment tools, and qualification tests.

**This is not a qualified production release.** The source has been implemented across the ten phase areas, but the production release remains blocked. This environment cannot download npm/PyPI dependencies and has no Docker daemon, PostgreSQL server, or coturn/nftables host. **90 unit tests passed**; see `evidence/REPORT.md` for what actually ran and `docs/HANDOFF.md` for remaining implementation findings. Do not confuse the included test suites or deployment scripts with evidence that those systems have passed.

Start with `docs/HANDOFF.md`, then `docs/DEPLOYMENT.md`. The phase-by-phase acceptance map is `docs/PHASES.md`; contracts and implementation decisions are in `docs/IMPLEMENTATION.md`. `docs/blueprint-v6-reference.txt` preserves the source document used for this implementation.

## Local development

Use a machine with Python 3.12, Node 24, npm, uv, Docker Engine and Docker Compose, with authorized access to package/container registries. Run from this repository root:

```bash
python3 ops/nt.py configure
python3 ops/nt.py lock
python3 ops/nt.py install
.venv/bin/python ops/nt.py test --suite unit
.venv/bin/python ops/nt.py dev up
```

Open `http://127.0.0.1:8080`. The private workspace is at `http://127.0.0.1:8081`. Create an operator account separately:

```bash
.venv/bin/python ops/staff.py owner_user --role owner
```

The enrollment file is generated privately; import its TOTP secret and recovery codes into your authenticator/password manager. No credentials are embedded in this repository. Use a separate moderator account with `--role moderator` or a metrics-only account with `--role analyst`.

Local configuration enables synthetic conversation development. Audio and payments remain disabled until their actual integrations are configured and tested. All plans start disabled in the database; Annual365 remains disabled in application code.

To stop and run database/process tests:

```bash
.venv/bin/python ops/nt.py dev down
# Start only the disposable database; do not run a competing API owner.
docker compose --env-file infra/images.env -f infra/compose.dev.yml up -d --wait db
.venv/bin/python ops/nt.py test --suite integration
```

For the browser suite:

```bash
npm ci --ignore-scripts
npx playwright install --with-deps chromium
.venv/bin/python ops/nt.py dev up
npm run test:e2e
.venv/bin/python ops/nt.py dev down
```

`ops/nt.py lock` resolves and records actual dependency hashes and image digests. Those lock artifacts could not be generated in the restricted implementation environment. Builds and CI intentionally reject missing or mismatched locks. Review and commit generated locks before qualification; never hand-fill hashes.

## What the application includes

- Guest/account access; explicit adult/Terms/core/optional consent; Argon2id passwords; recovery preparation; account-session limits; scoped case, finance and deletion receipts.
- One-owner compatible matching, temporary bounded text, explicit takeover, reconnect expiry, End/Next/Block, mutual friends and online invitations.
- Saved encrypted moderator support, case history/seen state, optimistic revisions, separate private notes, committed staff content-read audit, reports with selected server evidence and human restriction decisions.
- Relay-only audio signaling and client microphone teardown; controller leases, short kernel permissions, exact allocation checks and cancellation. Actual packet qualification is mandatory.
- Cashfree hosted checkout adapter; sanitized webhook inbox; verified captures; integer FIFO entitlement lots; evidence-backed required remedies with preview/confirm and durable jobs. No voluntary refunds and no renewal.
- Privacy exports/deletion/holds, independently checkpointed restore instructions, aggregate-only analytics, retention workers, health checks, backup/restore and signed operator deployments.
- Responsive public and moderator screens; policy drafts and a guarded publication workflow. No support email links or ordinary email/phone identity collection.

## Important release boundaries

The included implementation is a candidate for integration testing, not a guarantee that every V6 acceptance criterion has passed. In particular, real browser builds, live PostgreSQL transactions, Cashfree merchant behavior, coturn CLI parsing/kernel packet enforcement, retention/restore failure injection, applicable legal duties, and the combined 200-identity/100-waiter/25-call workload remain unqualified. The phase table identifies additional review items. Production, media, payments and the annual pass must stay closed until the corresponding evidence is obtained.

Do not upload local secret/enrollment files, database dumps, provider payloads, ordinary chat content, or real-user browser traces to a public repository. The source archive excludes all generated local secrets.
