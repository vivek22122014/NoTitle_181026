# Feasibility execution guide

Use synthetic participants and an isolated environment. These commands provide evidence only for the behavior actually exercised. Store sanitized measurements under `evidence/runs/`; do not commit packet captures, test credentials or phone numbers.

## A. Owner and migration failures

Follow README setup and run `ops test --suite integration` with the local app stopped. Tests acquire two real owner connections, prove rejection, release/reacquire a larger epoch, terminate a backend, detect checksum changes, deny runtime DDL, kill/restart a runner, and verify both listeners close after database loss. Unit supervision tests additionally inject a listener's early exit. Add a host suspend/partition experiment before release; unit scheduling mocks do not prove kernel behavior.

## B. Independent journal replay

`tests/unit/test_journal.py` exercises an older database image plus a newer independently acknowledged delete, tampered ciphertext, truncated replica, missing middle record, corrupt anchor, conflicting retry and replica outage. Run with `ops test --suite unit`. All data is synthetic and temporary.

Before production: implement a separately governed object store replica and latest-anchor provider; delete the app host, restore a deliberately old database, fetch current independent anchor, verify the full encrypted chain, reapply deletes/holds, then reopen admission. Demonstrate missing keys, object tampering and unavailable latest-anchor authority block reopening. This cloud/host-loss drill is not complete in Phase 1's local test environment.

## C. Cashfree sandbox

Obtain **sandbox** credentials from your approved Cashfree merchant dashboard; never enter live keys. From repository root after `.venv` installation:

```bash
PYTHONPATH=api .venv/bin/python -m ops.payment_spike create --order nt_phase1_001
PYTHONPATH=api .venv/bin/python -m ops.payment_spike fetch --order nt_phase1_001
PYTHONPATH=api .venv/bin/python -m ops.payment_spike refund --order nt_phase1_001
PYTHONPATH=api .venv/bin/python -m ops.payment_spike fetch-refund --order nt_phase1_001
```

Credentials and test phone are prompted without terminal echo. The stable intent is saved before the provider request. Complete the provider's sandbox payment using its documented test checkout process and the private response in `.local/cashfree/`; then run fetch. `refund` demonstrates a synthetic verified-payment-error remedy, not a voluntary-refund product feature. No call grants Premium.

On UNKNOWN, fetch the existing order/refund before retrying. Never replace the order ID to hide an unknown result. Record server-observed status, sanitized test reference and time. Verify delayed/duplicate webhooks against an eventual durable inbox in Phase 8. Obtain written late-remedy terms before Annual365 can pass its gate.

## D. Relay kernel and browser bench

This is a specialist **isolated test-host** experiment, not the solo developer's production installation procedure. Do not run the privileged helper on your workstation or existing production firewall. It creates only its own nftables table; it does not flush the host ruleset. The actual V6 relay design still needs qualification before Phase 7.

Provision an isolated IPv4 Linux relay with coturn, nftables, a nonroot controller user, TLS certificate, and private administration password. Record exact binary SHA-256, coturn version, kernel, network and configuration. Configuration requirements: relay range 49152–50175, no TCP relay/IPv6/mobility, REST credentials, four allocations per username, no general peers except the approved self-relay IPv4, CLI on loopback, TLS listener and deny-first firewall. Keep certificate/secret files private. These live host values cannot be generated truthfully without a host/domain.

1. With coturn stopped, start `python3 -m relay.guard_socket --relay-ip ACTUAL_IPV4 --controller-uid NUMERIC_UID` as the privileged isolated-host helper. The numeric UID is the nonroot controller user's `id -u`. An existing table/socket causes failure; inspect and stop the prior bench rather than deleting an unknown service.
2. As that controller user, run `python3 -m relay.packet_probe --relay-ip ACTUAL_IPV4 --output evidence/runs/kernel.json`. This tests positive delivery, default deny, explicit deny and timeout on the kernel's self-relay path. A failure means fix/reevaluate routing, not widen rules.
3. Start coturn with the recorded configuration and empty pair set. Generate two distinct ten-minute test credentials using the configured coturn REST secret. Use distinct usernames for the two test participants. Do not reuse them between test boots.
4. Serve `relay/spike.html` on **localhost or HTTPS**, with no third-party scripts; for local desktop testing use `python3 -m http.server 8090 --bind 127.0.0.1 --directory relay`. Open http://127.0.0.1:8090/spike.html in two separate browsers. Remote mobile devices need a trusted HTTPS test origin. Enter the test TURN URL and credentials separately and confirm mutual test consent.
5. Create an offer in browser A; copy its local description into B. Accept/create answer in B; copy its local description into A and apply the answer. No direct/STUN fallback is allowed. Get both exact-user CLI snapshots and archive only redacted format evidence.
6. Run the isolated controller as the nonroot user: `python3 -m relay.control_spike --relay-ip ACTUAL_IPV4 --left LEFT_USERNAME --right RIGHT_USERNAME --password-file PRIVATE_CLI_PASSWORD_FILE`. It polls exact-user allocations, enables only paired ports, refreshes bounded timeouts and denies on parser/port errors. It expires after 120 seconds; Enter explicitly revokes. Test usernames are synthetic and may appear in process arguments; production credentials must not be used.
7. Capture real RTP on client and relay. Press Enter in the controller while browsers continue trying to send, and measure the last delivered media packet relative to revocation. Require no more than five seconds. Clicking browser End alone is insufficient: it only tests client cooperation.
8. Repeat with SIGSTOP/controller failure, helper failure, stale credentials, unknown allocations, mismatched candidate, allocation changes and rapid port reuse. An unknown/reused port must contain the relay. Test owner expiry within 30 seconds and retain timing evidence. Stop coturn before rebooting/resetting the bench.

The local controller has no production mTLS lease endpoint and does not implement cancellation/absence proof; its final step revokes packets only. Actual coturn cancellation and safe slot release must be demonstrated before accepting F04. Physical mobile networks, TLS routing, guard systemd privileges and 25-call churn remain additional tests. Do not mark F04 passed from the synthetic parser or UDP probe.

## E. Close acceptance

Update gate evidence only after a reproducible result tied to source/version/config/host and review date. Record measured region/base cost and the legal/no-email determination. `docs/gates.json` is a tracking manifest, not a production authorization switch. A later audited release-evidence system replaces it. Full Phase 1 is not accepted while F01/F02/F04/F05 and external determinations remain open.
