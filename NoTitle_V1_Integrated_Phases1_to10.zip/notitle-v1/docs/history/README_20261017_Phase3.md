# NoTitle V1 — Phase 3 identity, consent and privacy primitives

This implements Phase 3 against Master Blueprint V6 chapter 57, preserving the Phase 1 foundation, Phase 2 interfaces/policy publication and later integration candidates. It adds identity/privacy screens, exact consent proof, guarded credential retries, a database-enforced five-session cap, scoped receipts, exports, rights intake and deletion replay protections. **Production acceptance remains open.**

Start with `docs/PHASE3.md`. The default frontend profile is now `identity`: identity, privacy and basic saved support intake connect to the local FastAPI backend. Matching, sockets, media, checkout, analytics and staff case content remain outside this profile. Policies remain readable as labelled drafts. Nothing was publicly deployed.

## Start locally

Run from this extracted `notitle-v1` directory on Linux/WSL2. Install Python 3.12, Node 24/npm, uv, Docker Engine/Compose and allow approved package/image registry access. Stop an earlier owner with `.venv/bin/python ops/nt.py dev down` before changing profiles.

For a new installation:

```bash
python3 ops/nt.py identity setup
```

This generates private local values, resolves actual locks, installs Python dependencies, runs core checks, starts disposable PostgreSQL, bootstraps roles, migrates, builds static exports and starts one API owner behind Caddy. Review/commit resolved locks and advisories before treating them as deployment inputs. Missing prerequisites stop setup.

For an existing Phase 1/2 installation:

```bash
.venv/bin/python ops/nt.py identity configure
.venv/bin/python ops/nt.py lock
.venv/bin/python ops/nt.py install
.venv/bin/python ops/nt.py dev up --mode identity
```

Changed package manifests require a fresh web lock. Configuration preserves keys, selects fixed loopback origins/current displayed policy, disables audio/payments and refuses an active owner or non-local environment. Schema contract **3** requires migration **0008**; migrations 0001–0007 remain unchanged. Do not overwrite keys or roll a schema-2 API back onto this database.

Open http://127.0.0.1:8080. Try guest entry, registration with a saved recovery code, profile/preferences, Security, Privacy controls and Chat with Moderator. Consent boxes begin unchecked. No matching or microphone starts on entry. The private site remains the Phase 2 interface preview; private case-management qualification is Phase 5.

```bash
.venv/bin/python ops/nt.py dev status
.venv/bin/python ops/nt.py dev down
```

## Verify

```bash
.venv/bin/python ops/nt.py identity verify --level core
```

For full local qualification, stop the owner, install browser OS prerequisites once, then run:

```bash
npm ci --ignore-scripts
npx playwright install --with-deps chromium
.venv/bin/python ops/nt.py identity verify --level stack
```

The collector uses only the fixed disposable database, includes process-failure tests, starts/stops the identity PID it created and writes hashed evidence under `evidence/phase3/`. `--level integration` omits frontend build/browser work. No collector automatically accepts production or legal gates.

**Verified here:** 162 Python unit tests and 11 tests executing the actual frontend coordinator, plus contract, policy, route and source guards. **Not verified here:** real PostgreSQL migrations/locking/ACLs, Next/TypeScript builds, browser/Caddy behavior and cloud restore. Docker and required application packages are absent; normal package-registry probes returned HTTP 403. See `evidence/phase3/REPORT.md`. Syntax parsing and scripted DB I/O are not full-stack passes.

## Rules and references

Guest identities/proof remain in owner RAM; accounts use Argon2id and saved recovery codes without email recovery. Optional withdrawal erases professional categories/preferences and invalidates matching intents. Core withdrawal ends participation while support/privacy remain available. Case, financial and deletion receipts grant only their stated scopes and cannot recover an account.

No support email is published. No ordinary chat/audio history is added to PostgreSQL. Payments have no voluntary refunds; non-waivable legal, verified payment-error and binding provider/bank remedies remain. Payments stay disabled in identity mode. Real operator/jurisdiction/processor facts and reviewed policies remain launch prerequisites.

Read `docs/PHASE3.md` for implementation, APIs, commands and troubleshooting; `PHASE3_ACCEPTANCE.md` for remaining checks; `PHASES.md`, `IMPLEMENTATION.md`, `API.md`, `DEPLOYMENT.md` and `HANDOFF.md` for the full V1. `blueprint-v6-reference.txt` remains the source authority. Phase 1/2 guides, evidence and the independent read-only `interface` profile are preserved.

The archive excludes generated credentials, installed dependencies, build outputs and caches.
