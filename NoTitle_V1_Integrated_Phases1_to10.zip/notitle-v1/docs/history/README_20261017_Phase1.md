# NoTitle V1 — Phase 1 foundation and feasibility

This update implements a local foundation mode while preserving the existing phases 2–10 source. It follows Master Blueprint V6, chapter 55. Start with `docs/PHASE1.md` for setup, architecture, acceptance gates and troubleshooting.

## Start locally

From this extracted `notitle-v1` directory, on Linux/WSL2 with Python 3.12, Node 24, npm, uv and Docker Engine/Compose in the same environment:

```bash
python3 ops/nt.py foundation setup
```

The command generates private local configuration, resolves real dependency/image locks, installs dependencies, checks contracts/tests, applies the foundation schema, builds the two Next.js exports and starts the owned API and local proxy. Open http://127.0.0.1:8080 and http://127.0.0.1:8081.

Foundation mode keeps product admission, staff actions, payments and media closed. It does not construct later-phase integrations. Product mode remains available separately.

```bash
.venv/bin/python ops/nt.py dev status
.venv/bin/python ops/nt.py dev down
```

## Verify Phase 1

Core verification, using the available Pydantic/cryptography environment:

```bash
python3 ops/nt.py foundation verify --level core
```

Complete local qualification after stopping the current owner:

```bash
.venv/bin/python ops/nt.py foundation verify --level stack
```

**113 unit tests passed** in this update, with contract drift, Python syntax, source-boundary and configuration parsing checks. These ran with the available installed libraries, rather than a fully resolved production lock. Details and machine-readable command logs are in `evidence/phase1/`.

**Phase 1 acceptance remains open.** npm/PyPI requests return HTTP 403 here, and Docker/PostgreSQL/coturn/nftables are unavailable. Actual static builds, PostgreSQL/process tests, RTP teardown, independent cloud host-loss recovery, merchant tests and operator/legal/cost determinations remain unverified. No dependency hash, provider agreement, legal conclusion or test pass has been invented.

## What changed

- Isolated foundation runtime and public/private static pages.
- Scoped owner lease cleanup, immediate proof-failure fencing and both-port reservation.
- Foundation-only migration target, full applied-history validation and forward upgrade test.
- Fixed-budget role-pool recovery and cancellation handling; ownership never silently reconnects.
- Input-bound dependency locks, separate resolution scopes and immutable-image CI runtime setup.
- Fresh static exports with byte/source verification for reuse.
- Disposable-database credential binding, serialized local start/stop and replacement-PID protection.
- One-command setup, actual feasibility collectors, focused integration cases and operator documentation.

## Documentation

- `docs/PHASE1.md`: the current foundation implementation and exact commands.
- `docs/PHASE1_DECISIONS.md`: decisions, corrections and evidence boundaries.
- `docs/FEASIBILITY.md`: journal, guarded-relay and payment experiments.
- `evidence/phase1/REPORT.md`: what ran and what remains blocked.
- `docs/HANDOFF.md`, `docs/PHASES.md`, `docs/IMPLEMENTATION.md`: the broader V1 implementation and remaining findings.
- `docs/DEPLOYMENT.md`: managed production setup and operational procedures.
- `docs/blueprint-v6-reference.txt`: the source specification.

No public deployment or live financial action was performed. Generated local secrets, caches and dependency directories are excluded from the source archive.
