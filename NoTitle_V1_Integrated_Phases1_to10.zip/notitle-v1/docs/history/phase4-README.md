# NoTitle V1 — Phase 4 matching, realtime and temporary text

Phase 4 implements the free conversation path on the Phase 3 Next.js + FastAPI foundation: one shared matching pool, a versioned WebSocket protocol, a connected desktop/mobile lobby and temporary text. Phases 1–3, policies, migrations and later integration candidates are preserved. **Phase 4 source is implemented; full-stack and production acceptance remain open.**

Read [docs/PHASE4.md](docs/PHASE4.md) for the design, protocol, security rules and implementation map, and [docs/PHASE4_ACCEPTANCE.md](docs/PHASE4_ACCEPTANCE.md) for qualification. The default frontend profile is `realtime`. It connects identity/privacy, basic saved support intake, free matching/text and Block. Audio, friend invitations, sales, report submission and private case management remain later-phase integration work. Draft policies remain labelled drafts. Nothing was publicly deployed.

## Start locally

Run every command from the extracted `notitle-v1` directory on Linux/WSL2. Install Python 3.12, Node 24/npm, uv and Docker Engine/Compose, with access to the approved package/image registries. Stop an existing local owner first with `.venv/bin/python ops/nt.py dev down`.

For a new installation:

```bash
python3 ops/nt.py conversation setup
```

The command generates private local values, selects the loopback realtime profile, resolves dependency/image locks, installs Python dependencies, runs core checks, starts PostgreSQL, provisions database roles, migrates, builds separate static exports and starts one FastAPI owner behind Caddy. Missing prerequisites stop it. Review and commit the generated locks and dependency advisories before using them as deployment inputs. Use `--locked` when those artifacts have already been resolved and reviewed, or `--no-start` to stop after setup/core checks.

For an existing installation:

```bash
.venv/bin/python ops/nt.py conversation configure
.venv/bin/python ops/nt.py lock
.venv/bin/python ops/nt.py install
.venv/bin/python ops/nt.py dev up --mode realtime
```

Configuration preserves keys, uses the current displayed policy and fixed loopback origins, disables payments/media and refuses an active owner or non-local environment. Schema contract **3**, through migration **0008**, is unchanged: Phase 4 creates no transcript, presence or queue tables. Browser conversation wire **2** is independent of foundation protocol **1**. Old conversation wire 1 is rejected.

Open http://127.0.0.1:8080 in two independent browser profiles or contexts. Create one guest in each, open Chat and choose **Search** explicitly in both. Separate tabs share cookies and require an explicit takeover; they are not independent participants. Send text, observe Delivered, then End, Next or Block. The private site is still the read-only interface; private operations qualification belongs to Phase 5.

```bash
.venv/bin/python ops/nt.py dev status
.venv/bin/python ops/nt.py dev down
```

## Verify

```bash
.venv/bin/python ops/nt.py conversation verify --level core
```

To execute real PostgreSQL and network WebSocket tests, stop the owner and use `--level integration`. For build/typecheck/browser qualification, install browser OS prerequisites once and use the full stack collector:

```bash
npm ci --ignore-scripts
npx playwright install --with-deps chromium
.venv/bin/python ops/nt.py conversation verify --level stack
```

The collector writes source-bound, hashed evidence under `evidence/phase4/`, uses only the fixed disposable database and stops only the runner PID it started. Missing locks, dependencies, Docker or a failing check are not passes. `phase4_accepted` and `production_ready` remain false until the separate acceptance review.

The delivered evidence distinguishes actual unit/client/source checks from blocked PostgreSQL, Next/TypeScript, Caddy and browser execution. See [evidence/phase4/REPORT.md](evidence/phase4/REPORT.md). Scripted database I/O, syntax parsing and actor-only timing do not establish production capacity.

## Privacy and scope

Ordinary text stays in bounded service/browser memory: 30 messages / 64 KiB per interaction, 2,000 Unicode code points / 6,144 UTF-8 bytes per message. End clears both service memberships, rings and queued content. Disconnect removes Search; current text may resume within a 25-second server grace window. Reconnect never replays unsent text or starts Search/audio automatically. Message Accepted means RAM acceptance; Delivered means the receiving browser acknowledged rendering, not that a person read it.

No support email is published. Chat with Moderator uses the separate retained case system. Paid matching stays disabled in every Phase 4 runtime; a fake ledger exists only inside tests. The Phase 8 adapter must expose a stable, read-only entitlement revision rather than the older billing read that advances its revision. No voluntary refunds remain the policy, while required legal/payment remedies are preserved.

Profiles expose only a fresh conversation-scoped peer handle, display name, declared gender, topic and bio. Private usernames, professional categories, persistent account references and credential material are excluded. Optional professional withdrawal preserves free participation; core withdrawal, logout, deletion and owner loss fence participation. Policies, legal/operator facts and infrastructure still require the launch review.

The full roadmap is in [docs/PHASES.md](docs/PHASES.md), with broader implementation, API, deployment and handoff references in `docs/`. `docs/blueprint-v6-reference.txt` remains the historical master reference; the Phase 4 amendment resolves the wire-version and entitlement-adapter issues explicitly. Earlier README copies and qualification evidence are retained in `docs/history/` and `evidence/phase1`–`phase3`.

The archive excludes generated credentials, installed dependencies, build outputs and caches.
