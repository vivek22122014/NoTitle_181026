# NoTitle V1 — Phase 1 foundation and feasibility

Source implementation against Master Blueprint V6, chapter 55. This is a **local-only development package**. Phase 1 acceptance is still open: the implementation environment could not download packages and had no Docker, PostgreSQL, coturn or nftables. The core tests ran successfully; the application build and external feasibility checks have not run. See [evidence/REPORT.md](evidence/REPORT.md).

## Implemented

- Separate Next.js public/private static-export projects and shared types/styles.
- One FastAPI runner, two loopback listeners, central signals and shutdown.
- PostgreSQL advisory owner lock, monotonic epochs, heartbeat fencing and checksummed forward migrations; distinct runtime/migrator roles.
- Strict Pydantic DTO/event skeleton and generated JSON Schemas. Public peer fields match V6; API gender values `male`, `female`, `other` map to Male, Female, Other.
- Bounded synchronous coordinator primitives and a separate control mailbox reserve.
- AES-256-GCM journal with authenticated hash-chain records, immutable local replica writes, fsync, idempotent retry and independent-anchor replay checks.
- Sandbox-only Cashfree order/fetch/refund adapter and raw-body signature/verified-capture primitives.
- Relay exact-user CLI parser, per-boot port history, five-second kernel permission generation, narrow Unix socket helper, UDP packet probe and two-browser audio bench.
- Local operator CLI, Docker/Caddy files, CI workflow, requirement/gate manifests and executable tests.

There are no user accounts, active chat, payments or staff data in this foundation. Product admission cannot be opened. Future feature directories are boundaries, not fake completed implementations.

## First setup — Linux or Windows with WSL2

Use an ordinary development computer with **Python 3.12**, **Node.js 24**, npm, **uv**, and **Docker with Compose and BuildKit**. Use Docker Engine inside Linux/WSL2, or Docker Desktop with Linux host networking explicitly enabled. Host networking in this local setup is required for Caddy to reach the host Python runner. macOS without compatible Docker host networking is not qualified.

Obtain tools from their official installers: [Python](https://www.python.org/downloads/), [Node](https://nodejs.org/en/download), [uv](https://docs.astral.sh/uv/getting-started/installation/), [Docker](https://docs.docker.com/engine/install/). Do not paste credentials into commands or commit `.local`.

Unzip this package, open a terminal **inside `notitle-v1`**, then:

```bash
python3 ops/nt.py configure
python3 ops/nt.py lock
python3 ops/nt.py install
.venv/bin/python ops/nt.py doctor
.venv/bin/python ops/nt.py contracts --check
.venv/bin/python ops/nt.py test --suite unit
.venv/bin/python ops/nt.py dev up
```

`lock` is intentionally an explicit, first-time developer step because package downloads were denied in the implementation environment. It resolves the exact direct inputs into hashed Python requirements, npm integrity locks and immutable container digests. Review changes and security advisories, then commit `versions.lock`, `api/requirements.lock`, `package-lock.json`, and `infra/images.env`. Later checkouts run `lock --check`, never silently resolve new versions. A registry/image error must be corrected in a reviewed input change; do not remove integrity checks.

`install` creates `.venv`; use its Python for application commands. `configure` creates private random local passwords and journal keys and preserves existing values. `dev up` starts local PostgreSQL, creates restricted roles, applies migrations, builds static exports, starts the single API runner and serves two separate frontends. It prints the URLs:

- Public shell: http://127.0.0.1:8080
- Private shell: http://127.0.0.1:8081 — no staff data; private API returns 401
- API: http://127.0.0.1:8000/health/ready — reports `maintenance`

To run the integration checks, stop the ordinary development runner first. Keep the local database:

```bash
.venv/bin/python ops/nt.py dev down
# down preserves the database volume; never use a production database here.
docker compose --env-file infra/images.env -f infra/compose.dev.yml up -d --wait db
.venv/bin/python ops/nt.py db bootstrap
.venv/bin/python ops/nt.py db migrate
.venv/bin/python ops/nt.py test --suite integration
.venv/bin/python ops/nt.py build
```

Integration tests intentionally terminate local owner connections and kill local runner processes. They use only `.local` credentials, port 55432, database `notitle`, and test listeners 18000/18001. Never substitute a production DSN. A failed prerequisite is a failure, not a skipped passing test.

## Commands

| Command | Effect |
|---|---|
| `doctor --core` | Check Python and the dependencies needed by unit tests |
| `doctor` | Check full local prerequisites and resolved locks |
| `configure` | Generate private local configuration idempotently |
| `lock` / `lock --check` | Resolve reviewed dependency inputs / verify committed lock digests |
| `install` | Create the isolated Python environment from hash-locked dependencies |
| `contracts` / `contracts --check` | Generate strict schemas / detect schema drift |
| `db bootstrap` / `db migrate` | Create restricted local roles / forward-only migrations |
| `dev up`, `dev status`, `dev down` | Start, inspect or stop local development |
| `test --suite unit|integration|all` | Run explicit tests, fail on missing dependencies |
| `build --target web|api|all` | Build static exports and API image with pinned bases |
| `feasibility` | List outstanding gates and return a nonzero status until accepted |

Exit codes: 0 success; 3 unmet prerequisite/feasibility gate; 4 execution/configuration failure. Commands do not perform public deployment or real payments. Production setup/update/rollback belongs to later phases and is not simulated by a success-printing stub here.

## Repository

`web/` holds separate frontends; `api/app/` holds the single runner and domain boundaries; `db/` holds SQL; `relay/` holds the isolated audio spike; `ops/` holds the local dispatcher; `contracts/` and `policies/` hold machine-readable constraints; `tests/` contains unit and PostgreSQL/process tests; `docs/` contains decisions and acceptance gates.

Read [docs/FEASIBILITY.md](docs/FEASIBILITY.md) before running sandbox or privileged network probes. Read [docs/DECISIONS.md](docs/DECISIONS.md) for the scope and unresolved feasibility risks. Full Phase 1 acceptance requires the remaining evidence; do not label this package production-ready.
