> Current delivery: full product integration across phases 1–10. Use `release setup` and `release verify`; source presence never implies production acceptance.

# Phase implementation and acceptance map

“Source present” means code/configuration has been added. It does not mean the phase is accepted for production. See `../evidence/release/latest.json` for current executed/blocked checks. Earlier phase reports are historical. Dependency order remains 1→2→3→4; safety/support follows identity and realtime; social follows safety; media follows owner/teardown feasibility; money follows identity/privacy/support; operations and qualification cover the combined release.

| Phase | Source deliverables | Acceptance evidence still required |
|---|---|---|
| 1 Foundation and feasibility | Isolated foundation mode, scoped owner lifecycle, fixed-pool repair, targeted/checksummed migrations, input-bound locks, verified export reuse, local command/PID protection, setup/evidence CLI and existing risk probes | Resolve real locks; execute PostgreSQL ownership/process tests; validate chosen coturn/kernel/provider/storage feasibility |
| 2 Interface and policies | Eleven typed screen groups, 46 public/10 private generated routes, shared accessible controls, read-only preview, one-source policies/digests, bound review/version workflow, metadata/robots/sitemap, source/build/export/CSP guards, CI/browser suite | Real locked Next typecheck/build and artifact/Caddy audit, desktop/mobile/keyboard/native zoom/screen-reader evidence, genuine operator/processors/legal/practice review, operator-reviewed runtime acceptance |
| 3 Identity and privacy primitives | Connected identity/privacy screens, memory-only coordinator/generated contracts, exact consent/withdrawal proof, locked recovery/rotation retries, DB-enforced session cap, scoped receipts, rights/export/deletion replay, local setup/CI/evidence | Real PostgreSQL migrations/ACL/concurrency and lost-response matrix, actual Next/browser/HTTPS/assistive technology, old-backup/host-loss replay and key-maintenance rehearsal |
| 4 Matching, realtime and temporary text | Connected free Chat/Talk; wire-2 contracts; prioritized control; reserve/reauthorize/publish; random scoring ties; scoped peers; bounded text/delivery; reconnect and HTTP teardown; race/client suites and local automation | Real PostgreSQL/WebSocket, Next/typecheck/Caddy/browser and mixed-state load; merchant/paid ledger qualification (stable adapter is integrated) |
| 5 Safety/support/private operations | Report snapshot/evidence, blocks, encrypted saved cases, messages/seen/status, audited staff reads, private notes, decisions/appeals | Staff role/scope matrix, report-and-block failures, private route isolation, independent appeals, reviewed rule-pack deadlines, failure recovery and operator coverage |
| 6 Friends/invitations/profile | Public profile whitelist, private profession categories, normalized durable friends, mutual requests, online invitations | End/Block versus promotion races, conversion handoff, invitation crossing/expiry, 100-friend caps and privacy projection |
| 7 Free audio/teardown | Mutual audio flow, client track fences, Opus/relay validation, mTLS control, kernel pair leases, cancellation, refresh | Actual RTP tail after every safety event, controller/owner kill, credential recreation, port reuse, pinned CLI, mobile/network matrix and 25 calls |
| 8 Payments/remedies | Plan catalog, stable intents, hosted adapter, signed inbox, verified captures, FIFO lots, receipts, no-voluntary-refund rule, previewed required remedies | Merchant sandbox/live contract, reviewed merchant/tax receipt facts, webhook replay/delay, duplicates, unknown outcomes, partial remedies, dashboard disputes and deletion races; annual remains off |
| 9 Analytics/operations | Fixed aggregate catalog, exact outbox metrics, rollups/cleanup, signed release tools, encrypted backups, restore/monitor timers | Actual retention, archive continuity, suppression/query budgets, managed service permissions, cost/egress measurements and fresh-machine deployment rehearsal |
| 10 Qualification/handoff | Unit/integration/browser suites, gate matrix, source checks, evidence collector, deployment/incident/maintenance guides | Every mandatory release check on exact artifacts; restore rehearsal; alerts acknowledged; operator independently performs update/rollback; reviewed remaining implementation findings |

## Release priorities

1. **P0:** Owner fencing, authorization, temporary-chat deletion, safety teardown, saved-case integrity, money conservation, required legal remedies, deletion surviving restore, private staff access.
2. **P1:** Usable mobile/desktop flows, complete receipts/recovery, efficient aggregate insights, simple deployment/backup/rollback, operational alerts.
3. **Future:** Multiple owners/regions, video, attachments, offline peer messaging, social login, push notifications, elaborate analytics or recommendation models. None is required to finish V1.

Do not enable a dependent feature while its prerequisite evidence is missing. In particular, do not sell passes before identity/support/receipts/remedies/tax/merchant qualification, and do not offer unguarded audio as a shortcut around media feasibility.

Remaining code-level findings are listed separately from missing test evidence in `HANDOFF.md`. All ten phase acceptances are still open until their stated gates are satisfied.
