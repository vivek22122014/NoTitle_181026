# Phases 9 and 10: aggregate analytics and operational qualification

The candidate uses the existing one-owner FastAPI service, PostgreSQL role pools, static Next.js exports, Caddy HTTPS edge, independent encrypted restic backup and signed CLI releases. No analytics SaaS, session replay, raw activity table, transcript database or extra microservice is introduced.

## Local commands

Run from the extracted project root with Python 3.12 and Node 24. Docker Engine/Compose must run for real database integration. Dependency resolution needs ordinary access to PyPI, npm and container registries.

```sh
python3 ops/nt.py release setup
```

This preserves generated keys, configures fixed loopback development origins and the full candidate UI, resolves/reviews locks via the existing lock gate, creates the Python environment, installs dependencies, runs core verification, builds exports, starts PostgreSQL, bootstraps least-privilege roles, applies migrations and starts the local owner/edge. Existing secrets are not overwritten. Audio and payments stay disabled until actual relay and merchant configuration are qualified. It does not deploy publicly.

For a reviewed existing lock set, use `release setup --locked`. To prepare without starting services, use `--no-start`.

```sh
.venv/bin/python ops/nt.py dev down
.venv/bin/python ops/nt.py release verify --level stack
```

`stack` verifies actual dependencies, database migrations/integration, build/typecheck and candidate browser tests. It refuses failure injection while an owner is already running. `--level core` runs available-library unit tests, actual frontend coordinator tests, contracts, policies, source boundaries and bounded matching benchmark. `integration` stops before the frontend build/browser work. Reports under `evidence/release/` include source SHA-256, log SHA-256, exact pass/fail/blocked status and all ten phase acceptance flags. Editing the source during a run makes the report fail; rerun after integration finishes.

## Analytics

Only staff with `analytics.read` can fetch the dashboard. Authorization runs before the 60-second summary cache. The dedicated database role can read aggregate buckets and an operational count view; it cannot read support bodies or account tables directly. The UI provides retained registered-account totals, active-status accounts, active admitted identities now, open cases, fixed 24-hour feature/event counters, performance histogram samples/means and historical UTC tables with approximate p95 upper bounds. Small positive cohorts under ten suppress counts and derived statistics. Missing history is unavailable rather than silently zero. Active now includes guests and is explicitly not a daily unique user metric.

RAM metrics flush once a minute. A failed flush retains one immutable retry batch, while new samples remain separately bounded by the fixed metric catalog. Durable registration/support outbox rows are claimed and marked in the same transaction as bucket updates. Batch IDs prevent duplicate additions after an uncertain commit. RAM counters can be lost on process failure; this is stated in the dashboard. No claim of complete historical person tracking is made.

Hourly maintenance recomputes rollups idempotently and removes minute buckets after 7 days rounded to an hour boundary, hours after 30 days rounded to a day boundary, days after 90 days rounded to a month boundary and months after 12 months, only after finer data has a verified rollup. Whole-period boundaries prevent a partial retained source from overwriting a previously complete aggregate. Delayed exact outbox events retain their event time, update retained coarser sources and amend already materialized totals; events older than the published aggregate window contribute only to the dropped-sample counter. Batch dedup records expire after 7 days and rollup metadata after 13 months. A 200 MiB aggregate-table budget fails visibly. Journal capacity monitoring warns at 8,500 of the bounded 10,000 records; directory-only monitor access is documented in DEPLOYMENT.md. Missing access raises an unavailable check. Safe journal rollover is still unfinished. Database requests have a 500 ms local timeout and bounded date ranges, fixed metric IDs and at most 2,000 results. No demographic/custom-label queries are accepted.

Durable job attempts run within a 45-second timeout, shorter than their 60-second lease. Idempotent handlers retry by object reference. Timeouts and errors persist safe codes, never content or credentials; exhausted work enters manual review.

## Production operations

Use the existing `docs/DEPLOYMENT.md` and operator scripts for real provider configuration, managed PostgreSQL TLS, object storage credentials, DNS, host firewall and relay. The production launch gate is deliberately separate from a local build:

1. Review legal publication and policies for actual operator, launch region, retention obligations and remedies.
2. Resolve and review dependency locks and immutable image digests; run real-stack tests and security/load checks.
3. Complete actual relay deny/kill proofs and merchant sandbox/webhook qualification.
4. Rehearse independent host-loss restore against an empty isolated database; replay the independent journal before admission.
5. Produce a fresh evidence report with all required real artifacts, source digest and `source_unchanged: true`. Approved production evidence expires after seven days. Artifact paths must remain inside the evidence directory, with matching byte hashes.
6. Sign the source manifest using the offline operator key. Deploy with `ops/production.py deploy` on the approved host; it validates assets, backs up, migrates, atomically switches release and performs health checks. The generated application settings initially close admission, audio and payments.
7. Deployment and rollback hold an exclusive host lock and atomically record safe stage metadata in `/var/lib/notitle/deployment.json`. If interrupted, keep admission closed and rerun the same signed operation after repair; backup and migration steps are idempotent and the previous-release pointer is preserved on same-release retries. This is operator-mediated recovery, not an automatic successful deployment claim.
8. For a faulty application artifact, `ops/production.py rollback` validates the signed previous release and schema compatibility, switches application/edge assets and runs health checks. It never runs reverse migrations or silently restores old database contents.

Existing systemd timers perform backups, health/backup-age/disk/TLS checks and audit archives. To install monitoring on the approved host after host bootstrap, place the actual owner-controlled alert webhook URL and external deadman ping URL into separate mode-0600 files. Obtain these URLs from the chosen monitoring/alert service dashboard; they are credentials and must never enter Git or frontend environment variables. Then run:

```sh
sudo python3 /opt/notitle/current/ops/monitor.py setup --health-url https://YOUR_REAL_APP_DOMAIN/health/ready --alert-webhook-file /secure/path/alert-url --heartbeat-url-file /secure/path/deadman-url
sudo systemctl daemon-reload
sudo python3 /opt/notitle/current/ops/monitor.py check
sudo systemctl enable --now notitle-monitor.timer
sudo systemctl status notitle-monitor.timer --no-pager
```

Replace the domain and two local private file paths with the actual configured values; the URL files are copied into root-owned files readable by the dedicated monitor group. Setup refuses existing files rather than overwriting secrets. A successful local check sends a heartbeat only when all checks are healthy. Configure the external deadman to alert when a one-minute heartbeat is missing beyond the chosen tolerance, and deliberately rehearse a stopped timer/host with the responder before launch. TLS warnings start at 21 days and disk warnings at 85% usage. The setup command itself sends no test messages.

 Alert webhooks contain fixed service status codes only and are operator configuration, not an application support address. Operators must independently monitor alert delivery, backup age and restore rehearsal results. No script creates merchant credentials, legal approval or fabricated hosting evidence.

## Verification limits for this delivery

The editing environment has no Docker/PostgreSQL binaries and lacks FastAPI/Uvicorn/psycopg/httpx. Ordinary PyPI and npm requests returned HTTP 403. Available-library tests execute; real database, frontend build/typecheck, browser, live relay/provider and independent recovery evidence cannot be claimed here. Every phase remains unaccepted for production until its actual checks pass.


## Host reboot and crash behavior

Host bootstrap installs and enables `notitle-runtime.service` without starting it before configuration exists. The oneshot service starts the current Compose release at boot only after Docker/network readiness and actual configuration files exist. The boot guard holds the deployment lock while running `/usr/bin/docker compose --env-file /etc/notitle/images.env -f /opt/notitle/current/infra/compose.production.yml up -d --wait`, avoiding a check/start race with migrations. It requires the last deployment operation to be healthy and to name the same current release directory. Interrupted/failed deployments stay closed across reboot and require the signed deploy/rollback workflow for repair. Existing installations created before the boot guard must complete a successful signed deployment to populate this record.

The API retains Docker `restart: no`; systemd uses `RemainAfterExit=yes` and `Restart=no`. This unit does not restart the API during intentionally stopped migrations or after owner loss. A failed owner triggers monitoring and an explicit operator investigation/restart. After a healthy signed deployment, the CLI enables the unit for subsequent boots. Verify with `sudo systemctl is-enabled notitle-runtime.service` and rehearse an actual staging host reboot before launch. Use the signed workflow for updates rather than treating a systemd restart as a deployment.
