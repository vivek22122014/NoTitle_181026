# Phase 3 — identity, consent and privacy primitives

Implemented 17 October 2026 against Master Blueprint V6 chapter 57 and the user-confirmed Next.js/FastAPI, solo-operation, no-support-email and no-voluntary-refund requirements. Source is delivered; production acceptance and legal review remain open. See `PHASE3_ACCEPTANCE.md` and `../evidence/phase3/REPORT.md`.

## Scope

The local `identity` profile connects guest/register/login/recovery, profile/preferences, Security, privacy and basic saved support to FastAPI. It does not install WebSocket routes, checkout, social/media APIs, analytics or private case content. The worker cannot claim payment/refund jobs in this mode. `APP_MODE=identity` is local-only; production release tooling still requires qualified `candidate` artifacts. Later candidates and the separate read-only `interface` profile remain available.

Staff MFA/recovery/session APIs remain behind the private origin. The private frontend stays the Phase 2 read-only workspace in identity mode; case-management UI/operations qualification remains Phase 5. Public support is available now so withdrawal does not remove help.

```mermaid
flowchart TD
  Browser[Next identity screens] --> Edge[Loopback Caddy]
  Edge --> API[FastAPI identity boundary]
  API --> Identity[Identity and owner controls]
  Identity --> PG[PostgreSQL contract 3]
  Identity --> RAM[Guest and preparation RAM]
  API --> Privacy[Privacy service and worker]
  Privacy --> PG
  Privacy --> Journal[Independent deletion and hold journal]
```

Local filesystem journal replicas are development fixtures. Production independence requires the existing private object-store adapter, authenticated checkpoint and tested recovery custody; another local folder is not host-loss protection.

```mermaid
flowchart TD
  Review[Review current policy and choices] --> Kind{Account?}
  Kind -->|Guest| Guest[Temporary identity and RAM proof]
  Kind -->|Yes| Save[Prepare and save recovery code]
  Save --> Commit[Commit account and first session]
  Guest --> Idle[Idle owner controls]
  Commit --> Idle
  Idle --> Control{Privacy action}
  Control -->|Optional withdrawal| Erase[Erase categories and cancel intents]
  Control -->|Core withdrawal| End[End participation, keep help access]
  Control -->|Deletion| Receipt[Save scoped receipt and confirm]
  Receipt --> Journal[Disable account and confirm journal]
```

Page mount fetches bootstrap and, if authorized, `/me`. It never accepts consent, creates an identity/case, starts search or requests microphone permission. After later qualification, entering the full lobby still requires a separate Find action.

## Components and contracts

| Source | Responsibility |
|---|---|
| `domain/policy.py` | Verify exact publication bytes/content/version/effectiveness; expose purpose and independent withdrawal-control digests |
| `domain/security.py` | Purpose-bound HMAC, derived retry cookies, versioned authenticated data-key envelopes |
| `domain/projections.py` | Strict owner/bootstrap/preparation/staff contracts; never serialize an account row |
| `services/primitives.py` | Bounded Argon2 worker, limiter, prepared proof/intent and principal types |
| `services/identity.py` | Resolve authorities; register/login/recover; challenge/reauth/rotations/logout/fences |
| `services/account_controls.py` | Revisioned profile/preferences, policy reacceptance, immutable proofs, withdrawal, sessions |
| `services/privacy.py` | Rights skeleton, receipts, exports, deletion ordering, restore replay and hold/retention interlocks |
| `http/identity_scope.py` | Local Phase 3 route filter |
| `web/shared/identity.ts` | One memory-only request coordinator, schema validation, scoped CSRF, bounds and stale-response fences |
| `IdentityApplication.tsx` | Identity, Security, profile/preferences, privacy and saved deletion-status screens |
| `IdentitySupport.tsx` | Basic saved case intake/access/history/replies |
| `ops/identity.py` | Safe local configuration, setup and honest evidence collection |

Pydantic is the schema authority. `ops/nt.py contracts` generates TypeScript declarations and JSON runtime schemas; `--check` rejects drift. Both `identity` and full `candidate` profiles use the updated Phase 3 forms. Later candidate screens retain the older shared client until their phases are qualified.

The coordinator owns in-memory authority/CSRF, coalesces initial loading, limits responses to 512 KiB and requests to 15 seconds, rejects credential URLs, checks generated request/response shapes and prevents late responses from restoring cleared state. Logout/owner replacement/failed authority refresh clear owned plaintext/scopes. It never automatically retries a mutation. Secrets use explicit reveal/copy/download, never browser storage, URLs, application logs or analytics. Credential browser tests disable tracing/screenshots/video.

## Identity and authority

Usernames normalize to lowercase ASCII `[a-z0-9_-]{4,24}` with reserved staff/brand names. Display names are 2–24 codepoints; bios at most 160. Control/format/surrogate characters and reserved staff names are rejected. This is a basic safeguard, not universal Unicode-confusable detection. Passwords preserve whitespace and require 12–128 codepoints, at most 512 UTF-8 bytes.

Argon2id uses PHC encoding, random salts, 64 MiB, three iterations and one lane. Two CPU slots, a two-second acquisition limit and cancellation shielding prevent unbounded concurrent hashing. Unknown accounts verify a dummy hash. Corrupt/resource-excessive PHCs cannot request unbounded memory; supported older parameters rehash only after a successful locked login.

| Authority | Idle limit | Absolute limit | Storage |
|---|---|---|---|
| Public/private bootstrap | 30 minutes | 30 minutes | Bounded RAM, separate realms/cookies |
| Guest | 30 minutes | 24 hours | Owner RAM; lost on restart |
| Account session | 7 days | 30 days | Verifier/generation in PostgreSQL |
| Case/financial/deletion session | 30 minutes | 24 hours | Exactly one named receipt scope |
| Staff session | 15 minutes | 4 hours | Staff role version/MFA/verifier |
| Session-limit challenge | 5 minutes | 5 minutes | One per bootstrap, 64 globally |
| Prepared proof | 10 minutes | 10 minutes | Four per principal, 512 globally |

Production cookies are host-only `__Host-` cookies, Secure, HttpOnly, SameSite=Lax, Path `/`. Local HTTP uses separate `nt_local_` names without claiming transport encryption. Server expiry is authoritative. Meaningful authenticated foreground mutations renew idle time at most once/minute; GET/polling/heartbeat do not. Absolute expiry never extends.

Protected routes verify Host, exact mutation Origin, purpose-bound CSRF and explicit account/case/financial/deletion authority. Duplicate sensitive headers/cookies and credential query parameters are rejected. The two status-only health routes also accept internal loopback probe Hosts. Validation errors show safe field paths rather than submitted values. No cross-origin credential sharing is introduced.

Mutations lock the account and verify the exact session, generation, status and expiry. Sensitive actions require a password reauthentication no older than five minutes under that lock. A hash/generation race while verifying a password cannot grant a stale reauthentication.

The issuer and database trigger enforce at most five live sessions. The trigger updates a locked account revision, forcing incompatible repeatable-read writers to fail as well. A valid sixth login issues no account cookie; it creates a five-minute bootstrap/account-generation-bound challenge. Resolution consumes the challenge before I/O, revokes one owned live session and creates one replacement under the same lock. Failure requires a new password-verified challenge.

Guest conversion retains its opaque identity. Before hashing it captures profile/preference/consent and actor revisions; before insertion it rejects a winning End, Block, withdrawal, expiry or relevant edit. It never recreates an ended interaction. Changes during commit can only fence the actor further. Old guest cookies cannot regain authority after conversion.

## Prepared secrets and exact retries

Recovery and scoped receipt secrets use 256 random bits. `/operations/prepare` returns the final reference/secret before commit; the UI requires a saved acknowledgment. Leaving/reloading an uncommitted form can lose its RAM proof. The saved file is held by the user, never recreated by staff.

Preparation and commit nonces differ. A claimed preparation binds principal, kind, proof, commit nonce and keyed payload; conflicting reuse fails. Saved flag/scope/principal/expiry are checked again before writing. Do not create a new nonce merely because an acknowledgment is unknown: retain the intent, check status or retry exactly.

Durable operation results retain keyed request digests and safe identifiers for 24 hours, with no password/code/session plaintext. Registration retries require the complete original payload/nonce and current saved recovery proof and return the original still-live cookie without an extra session. They work after preparation RAM loss. Derived cookies bind a server key, strong proof and immutable operation identity.

Recovery replaces password and recovery verifier, increments authority generation and revokes all sessions; it does not log in. Exact retries use the saved replacement proof after RAM loss. A different action cannot reuse the spent old recovery code.

Password change/recovery rotation revoke older sessions and issue one replacement cookie/CSRF pair. Only dedicated credential routes can accept a spent source account cookie to prove an exact recorded retry, with original-cookie CSRF, current generation and the original still-live target. It cannot authenticate `/me`, perform another mutation or accept a scoped receipt. Source-session rows survive the operation retry window. Changed payloads return 409; later logout/rotation/deletion or target expiry cannot be undone.

Ordinary login is not automatically retried; an unknown result can require checking the current session or signing in again. Its session cap/challenge stays authoritative. No retry creates fresh authority after a later revocation.

## Consent and private preferences

Bootstrap supplies exact publication version/digest, purpose labels/digests, document references and stable withdrawal labels/digests. Signup requires explicit adulthood, Terms and core processing; optional professional processing starts false. Stale publication submission returns `POLICY_CHANGED` and requires fresh unchecked choices.

Account proof stores purpose/choice, version/publication digest, exact decision text, purpose/control digest, proof format, decision revision and server time. Guest proof remains downloadable in RAM while valid. Legacy records remain format 1; migration never invents stronger evidence. New format-2 writes reference immutable policy versions. Runtime/support/private roles cannot update/delete proof; jobs delete only through retention/hold logic. Policy snapshot bodies cannot change in place.

Withdrawal validates an independent control digest and does not force current-policy acceptance. The deployed snapshot recorded with that withdrawal is not an acceptance of new Terms. Explicit current-policy reacceptance starts unchecked; core may stay off while privacy/support access remains.

Optional withdrawal erases DB/actor categories and preference arrays, disables relevance, advances revisions and invalidates tickets/queue intents. Free participation remains available. Core withdrawal fences participation without the authentication/deletion fence, leaving support, receipts and privacy reachable. Regrant never automatically rejoins a queue.

Profile/preferences use optimistic revisions and 409 conflicts. Profile edits during an interaction are staged for the next peer snapshot. Professional categories use controlled catalogs only, at most five selections/category, no duplicates, no free-text employer. Processing consent and relevance enablement are independent. General Talk ignores relevance; Phase 3 does not enable paid gender controls. Peer projection remains display name, declared gender, topic, bio and opaque handle; private usernames/professional categories are excluded.

## Privacy and retention

Rights intake creates a stable encrypted support case and nonce-deduplicated rights skeleton, initially pending verification. It neither completes a legal request automatically nor invents a universal deadline or remedy waiver. Restricted/core-withdrawn accounts retain access. Unbound users can open saved support/privacy cases without conversation consent.

Export requests require fresh reauthentication, deduplicate by subject/nonce and allow two live jobs/subject. The jobs role excludes credentials/staff notes/private peer identifiers/ordinary chat, bounds collections and total output to 8 MiB, encrypts the package and expires it after 24 hours. Downloads recheck live owning authority/subject controls. Oversized collections require review rather than a misleading partial export.

Deletion requires fresh reauthentication, a saved deletion receipt and typed `DELETE MY ACCOUNT`. The actor fences before write completion; a local transaction disables the account, advances generation, revokes sessions, removes exports and queues confirmation. Durable acceptance requires authenticated independent journal acknowledgment plus committed progress. Unknown acknowledgment stays pending with the same durable operation/job identity.

Before listener admission, startup repairs authenticated pending instructions, verifies the independent checkpoint and replays deletion/holds. It reconstructs status-only receipt verifiers if a restored DB predates their creation, revokes restored sessions, removes restored exports and queues minimization. Purge serializes against pending/active holds and journal instructions. A receipt cannot recover an account. Backup expiry uses the actual reviewed provider schedule, with no invented universal 30-day promise.

The registry labels engineering targets: prepared proofs ten minutes; operation results/exports 24 hours; closed general support normally 90 days; safety/privacy/appeal/security/consent normally 180 days with hold/obligation checks. Finance requires an operator-reviewed schedule. Hourly cleanup is batched; expired authority is rejected immediately, before row cleanup. Ordinary peer text stays in bounded RAM; no audio recording/history table is added.

AES-256-GCM envelopes contain random per-field data keys and authenticated format/wrapping versions/scope. Format 2 reads legacy format 1. A supplied historical wrapping-key ring supports controlled maintenance, but the runtime currently loads active version 1. Online HMAC rotation, historical rewrapping and backup-key retirement are not automated: overwriting files can strand records/credentials. Row deletion is not proof of encrypted-backup erasure.

## Schema/API

`0008_identity_privacy.sql` advances compatibility contract 2→3. Earlier migrations remain unchanged. It adds owner revisions, verifier versions, exact consent fields/immutable prompt facts, export/rights nonces, expiry/retry indexes, the session-cap trigger and a restricted security-definer support account-capability lock. Support still cannot SELECT credential/session tables. Schema-2 API rollback is incompatible.

| Endpoint | Contract |
|---|---|
| `GET bootstrap` | Policy/purposes, gates, identity kind, scoped subjects/CSRF, epoch/time |
| `POST operations/prepare` | Kind + preparation nonce → final reference/secret/expiry |
| `POST auth/guest`, `auth/register` | Profile, four choices/version/digest; registration adds username/password/saved proof/commit nonce |
| `POST auth/login` | Credentials; explicit `end_guest` when replacing a guest |
| `GET/POST auth/session-limit[/{session_ref}]` | Bound list / single-use revoke-and-replace |
| `POST auth/reauth`, `auth/recover` | Fresh password proof / old code + saved replacement + new password + nonce |
| `POST me/password`, `me/recovery/rotate` | New password or saved proof + nonce → replacement cookie/CSRF |
| `GET me` | Strict owner projection, policy-current flag and entitlement projection |
| `PATCH me/profile`, `me/preferences` | Whitelisted values + expected revision |
| `POST me/consents` | One purpose/choice, control digest, policy metadata, expected revision and nonce |
| `POST me/policy-acceptance` | Four new choices/version/digest + expected revision/nonce |
| `GET me/consent-proof`, `me/sessions` | Bounded owned evidence / owned live sessions |
| `DELETE me/sessions/{ref}` | Fresh owned-session revocation |
| `POST privacy/requests`, `privacy/exports` | Kind/body/nonce → rights case; nonce → pending export |
| `GET privacy/exports/{ref}[/download]` | Owner status / authorized binary download |
| `POST privacy/delete`, `privacy/status/access` | Saved proof/typed confirmation; saved receipt → deletion-only cookie |
| `GET privacy/status`, `privacy/retention` | Scoped status / public target registry |

Public prefix is `/api/v1`. Success uses `{data,request_id}`; errors sanitize `{error,request_id}`. One-time prepared secrets are an intentional plaintext response exception. Generated schemas are in `contracts/generated/` and `web/shared/identity.schema.json`. `API.md` lists the whole candidate; identity mode filters it.

## Run, verify and maintain

All commands run from project root on Linux/WSL2. Prerequisites and one-command `identity setup` are in `../README.md`. For an existing installation, stop the owner, run `identity configure`, resolve/review new locks with `lock`, install, then `dev up --mode identity`. Keys are preserved; migrations/build/API/Caddy are automated. `--skip-build` accepts matching verified exports only.

```bash
.venv/bin/python ops/nt.py identity verify --level core
```

For real checks, stop the owner. `--level integration` runs the fixed disposable PostgreSQL/process suite. Install browser OS prerequisites once, then:

```bash
npm ci --ignore-scripts
npx playwright install --with-deps chromium
.venv/bin/python ops/nt.py identity verify --level stack
```

The stack collector configures/migrates, runs real backend tests, builds, starts identity mode, installs browser binaries, runs `test:identity` and stops only its own PID. It records blocked prerequisites/nonzero results instead of silently skipping. CI also preserves Phase 2 and full-candidate suites. A local green run is not legal or host-loss qualification.

| Manual responsibility | Automation |
|---|---|
| Install runtimes/Docker; approve registry access | Resolve locks, install dependencies, generate private local values |
| Review real artifacts/advisories; use disposable DB | Restricted roles, checksummed forward migration, supervised owner/Caddy |
| Save codes outside browser; retain recovery custody | Prepared-proof validation, bounded exact retries and scoped access |
| Supply operator/jurisdiction/processor facts | Display/accepted-policy byte checks; drafts and production gates |
| Review actual release/restore evidence | Hashed local reports, compatible artifact rollback, existing backup/monitor tooling |

Troubleshooting:

- Registry 403/missing Docker: fix prerequisites on an approved development network. Core checks do not substitute for a real stack.
- Policy mismatch/immutable version: synchronize local selection with `identity configure`; accepted prompt/body changes require a new policy version. Never rewrite proof or reset production history.
- `NONCE_CONFLICT`: check the original outcome before creating another intent. `PREPARATION_REQUIRED` means expired, wrong scope/principal, unsaved or no matching uncommitted preparation.
- `REAUTH_REQUIRED`: verify the current password in Security, then retry the original action. Receipts cannot substitute.
- Challenge consumed/expired: start another password-verified login; never issue a sixth cookie.
- Deletion pending: keep the status receipt; repair independent journal/worker continuity before reporting acceptance.
- Ports/PID in use: use `dev status/down`; do not kill an arbitrary process or reuse unverifiable exports.
- Schema-2 rollback: use a compatible contract-3 artifact/forward repair. Any older database restore must replay the newer independent privacy journal before admission.
- Lost all account credentials: no staff reset/email/receipt recovery promise exists; scope receipts still grant only their own retained access.

Existing production deployment, monitoring and backup commands remain in `DEPLOYMENT.md`. Before launch, complete managed-service permissions, independent restore/backup expiry, key maintenance, legal/contact review and later phases. The 10,000-instruction journal lifecycle bound remains an explicit open implementation finding.
