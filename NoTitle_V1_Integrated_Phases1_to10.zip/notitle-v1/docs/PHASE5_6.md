# Phases 5–6: safety, support and relationships

This is the current integration amendment to the historical master reference. Run with the full `product` runtime and `candidate` frontend. No additional service, message broker, transcript table or browser persistence is introduced.

## Report and block

The Chat screen keeps `SafetyPanel` mounted after interaction teardown. Clicking Report and block captures the exact current peer/interaction scope, clears local transcript/draft and fences microphone callbacks synchronously. It does not send a server End before the report snapshot can freeze. `POST /api/v1/reports/prepare` accepts the scoped peer/interaction handles and `block:true`; the service freezes only the bounded server text ring and attribution, applies RAM exclusion and End before durable report I/O, then returns an expiring snapshot reference and message IDs. If the preparation fails or its outcome is unknown, the client sends the captured scoped End, with the same HTTP control fallback used by normal End. Late callbacks cannot affect a newer conversation or identity.

The user explicitly selects server message IDs, a reason and explanatory text. Evidence already erased cannot be invented from the browser: the UI offers attribution-only reporting with separate acknowledgement. Registered users submit under their account; guests first save a private prepared case receipt and confirm possession. The final `POST /api/v1/reports` validates ownership, reason/evidence and the immutable nonce. Only a confirmed case reference is displayed as saved. A lost response retries the same payload; it never claims that selected evidence was saved without a committed case. Normal chat is still transient; selected report evidence becomes retained case data.

Blocks are asymmetric owned records but exclude both directions from matching, invitations and future contact. Guest blocks last for the identity session; new identities may evade them. Registered block pages are owner-only, use bounded keyset pagination and expose generic labels/dates, never incoming blocks. Unblock requires explicit confirmation and changes RAM only after commit; it does not restore friendship or rematch anyone.

## Chat with Moderator

Support and Support status use the real retained case system. No support email is displayed. The user can create a category/subject/message, read history, send follow-ups, explicitly acknowledge seen sequences, and observe status. Sending uses a stable nonce and committed message sequence, not optimistic delivery claims. Case-only credentials authorize that case and cannot authenticate an account, privacy request or financial records. The browser coordinator keeps secrets/CSRF only in memory and clears views on authority replacement. Visible polling is bounded and never renews participation automatically.

Support bodies and selected evidence use scope-bound encrypted envelopes. Staff reads require current identity, permission, purpose and committed audit before plaintext release. Private notes are never included in user history or exports. Authorized private staff can assign, reply, change status and create reviewed moderation decisions. Dangerous decisions use a version-bound preview and recent MFA, then recheck grants/current target at confirmation. Guest restrictions are serialized with new-account conversion and follow the preserved public reference. Guest/account appeals resolve ownership from the original user case; independent-review restrictions are checked at confirmation as well as preview. Legal clocks and escalation depend on reviewed operator rules and actual staffing; no emergency/continuous response guarantee is made.

## Friends and online invitations

`ConversationSocial` handles the generated `friend.request`, `friend.respond`, `friend.invite` and `friend.invite.respond` commands through the shared socket and actor. A request uses the current interaction scope; an acceptance uses the scoped request handle. Mutual crossed requests converge to one relationship. End/Block/expiry invalidate requests. Both peers have a 100-relationship limit. A friendship is temporary unless both identities are registered and one normalized PostgreSQL pair commits. The UI uses Temporary, Saving and Saved according to actual server events.

`Social` protects durable promotion with relationship revisions/tombstones, current session/consent checks and a tracked shielded write. Cancellation cannot abandon an insert that may commit: late-invalid writes are compensated using the exact committed acceptance identity. Delayed loads cannot resurrect removed/blocked relationships. Runtime shutdown waits for these repair tasks before closing database pools.

`GET /api/v1/friends` returns only an opaque relationship handle, approved public profile, revision, persistence and coarse presence. `DELETE /api/v1/friends/{ref}` requires `expected_relationship_revision`; it never treats an obsolete revision as a successful removal. Online invitations require both sides to be eligible and idle, explicit acceptance, a current relationship and no block. Crossing invitations create exactly one interaction. Named friend text/audio is free; anonymous paid filter restrictions do not apply. No offline messages or retained peer transcript exist.

New guest registration preserves the same identity reference and existing temporary relationships; promotion occurs only after durable account/friendship commit. Existing-account login ends the guest identity and imports no guest relationships or private choices. New registration imports validated optional professional choices only when renewed optional consent is true.

## Profile and preference privacy

Public peers receive only the conversation/relationship-scoped handle, display name, declared gender, topic and bio. Guests receive generated pseudonyms. Usernames, professional fields, account IDs, receipt secrets and financial data never enter peer events. Professional categories are controlled private IDs with selection limits and No preference. Guest choices stay in RAM. Account edits use expected revisions and transactional storage. Choice edits invalidate queue admission while preserving the defined wait-age policy. A current interaction retains its frozen public projection; private matching inputs update for future searches. Core withdrawal ends participation; optional withdrawal erases optional matching inputs while retaining free participation and access to policies/support/privacy.

## Verification

Run available-library regressions from the repository root:

```bash
PYTHONPATH=api:. python3 -m unittest tests.unit.test_phase5 tests.unit.test_phase6 tests.unit.test_integrated_v1 -v
node --test tests/qualification/social-client.test.mjs tests/qualification/integrated-client.test.mjs
```

The integration files `test_safety.py`, `test_social_v1.py` and the browser file `phase5-6.spec.ts` use actual application boundaries and the fixed disposable PostgreSQL target. They are included in the full release workflow. Their presence or syntax check does not mean their real database/browser execution passed.
