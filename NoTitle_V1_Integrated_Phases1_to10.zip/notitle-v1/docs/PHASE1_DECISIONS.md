# Phase 1 implementation decisions — 17 October 2026

| Decision | Reason and resulting behavior | Evidence |
|---|---|---|
| P1-01 Isolate foundation construction | Phase 1 must start before policy, payment, relay or saved-data features are configured. A local-only mode mounts the foundation apps and owner lease; product mode preserves the later-phase runtime. | Settings/lifecycle unit tests; real mode-isolation integration tests included |
| P1-02 Own cleanup from acquisition | A configuration/constructor exception previously occurred outside the runner cleanup block. Lease/heartbeat ownership is now scoped around all startup and shutdown work. Both ports are reserved before servers are scheduled. | Constructor/proof-failure unit tests; second-port collision process test included |
| P1-03 Keep ownership and role repair separate | Role connections can recover inside fixed pool slots. The advisory-lock connection must fail closed and acquire a new epoch on restart. | Pool cancellation, partial-open, exhaustion and repair unit tests; real DB loss remains an external gate |
| P1-04 Bind locks to inputs | Hashing output lockfiles alone did not detect edited requirements/workspaces or changed image candidates. Input digests and candidate bindings are now mandatory. | Mutation rejection unit tests; real resolution blocked by current registry access |
| P1-05 Serialize local operations | Concurrent local start/stop must not orphan a runner or signal a replacement PID. The dispatcher takes a local file lock and supports expected-PID shutdown. | Nested dispatcher and replacement-PID unit tests |
| P1-06 Bind static reuse to bytes | The previous local startup rebuilt previously tested exports and could retain removed routes. Builds now use an empty directory and an input/output manifest; reuse verifies every file. | Stale source/extra output/missing route tests; actual Next build remains unrun here |
| P1-07 Match the blueprint control budget | V6 specifies 2,048 ordinary mailbox entries plus 256 reserved control entries. The previous 512-entry implementation had no documented deviation. | Saturation and reserved-control unit tests |
| P1-08 Keep evidence factual | Core fixtures do not prove cloud durability, real SQL, hosted checkout or packet cessation. Reports retain blocked/unrun states and bind observed results to source and command logs. | Evidence replacement test; current core/stack-attempt reports |

No product permissions, payment prices, refund policy, legal claims, privacy promises, matching fairness or media fallback architecture were broadened by this phase update.
