# Phase 2 acceptance checklist

Status at delivery: source/guard/unit checks executed; real Next/browser/Caddy/legal acceptance open. Check a box only with dated evidence for the exact commit/source/export hash. A synthetic fixture is not production evidence.

## Source and artifacts

- [ ] Resolve and review current Python/npm/image locks; run lock check on Node 24/Python 3.12.
- [ ] `interface verify --level core` succeeds; no test failures or unexplained skips.
- [ ] Run the locked TypeScript check and both Next static builds through `ops/nt.py build --target web`.
- [ ] Actual exported HTML/assets pass `interface audit`; content and publication digests match the backend acceptance contract.
- [ ] Confirm all 42 public and 10 private inventory routes, foundation pages and genuine 404 outputs.
- [ ] Validate generated Caddy files with the reviewed image. Fetch unknown public/private paths and verify actual HTTP 404, not 200.
- [ ] Inspect actual public assets for private bundles, source maps, credentials and unsupported resource loads.
- [ ] Verify policy/information initial JavaScript is at most 150 KiB compressed or formally resolve the measured exception.
- [ ] Confirm no private bundle appears publicly; direct public `/internal` and `/admin` paths are denied.
- [ ] Verify no-store, nosniff, referrer, framing, permissions and generated CSP headers on both real listeners.
- [ ] Confirm robots/sitemap exclude scoped/private routes; drafts/previews remain noindex.

## Public interface

- [ ] Review U01–U09 on 1280px desktop, 390px and 320px mobile. Inspect every workflow and generic response state.
- [ ] Entry has no default gender and four independent unchecked confirmations; optional refusal leaves free entry available when identity is enabled.
- [ ] Entry policy links open in a disclosed new tab and keep current form choices.
- [ ] Recovery/receipt views never show a fabricated credential, save result or download. No secret enters a URL, console, cache or browser storage.
- [ ] Conversation idle/searching/matched/interrupted/replaced/ended states have truthful control and delivery labels.
- [ ] Interrupted/resumed examples do not suggest automatically searching or capturing media.
- [ ] U04 call/report/block views distinguish acceptance, permission, selected retained evidence, allegation and identity-limited block.
- [ ] Friends show Temporary/Saving/Saved and current Available/Busy/Offline; no offline messages or automatic interruption.
- [ ] Peer preview excludes private username, professional fields, contact details and employer.
- [ ] Premium states explain one-time duration, continuous time, no priority and no automatic renewal; Annual365 stays unavailable.
- [ ] Checkout acknowledgment is unchecked; no voluntary refunds wording retains required statutory/payment-error/provider remedies.
- [ ] Unknown payment says not to pay again; no browser-only entitlement or receipt success.
- [ ] Support is named Chat with Moderator; saved history is distinguished from temporary chat; no support email appears.
- [ ] Privacy distinguishes optional withdrawal, core withdrawal, pending/ready/expired export, deletion preparation and actual deletion progress.
- [ ] All controls navigate, open a functioning local review control, or have a disabled prerequisite with visible reason. No mock success is shown.

## Private interface

- [ ] Review A01–A02 on desktop and mobile; no real records exist in fixtures.
- [ ] Separate password/MFA and current grant requirements are clear; tunnel access is not presented as authentication.
- [ ] Public reply and internal note have distinct labelled fields/audiences.
- [ ] Content access, purpose/audit, assignment/revision and sensitive preview/MFA requirements are visible.
- [ ] Analytics cards/table show interval, UTC, unit, suppression and gaps; active-now identities are not called daily unique users.
- [ ] No timeline, demographic drilldown, raw user export, live ordinary-chat viewer or runtime secret values are exposed.
- [ ] Billing is limited to required remedies; unknown provider outcomes are not retried as new payments.
- [ ] Legal clocks, independent appeal review, private audit metadata and CLI-only release procedures remain distinct.

## Accessibility and devices

- [ ] Keyboard only: skip link, logical focus order, all enabled controls, visible focus, no keyboard trap outside a modal.
- [ ] Native dialog: initial focus, Tab/Shift+Tab containment, Escape and focus restored to trigger.
- [ ] Validation: first invalid field focused; clear label/error relationship and no color-only state.
- [ ] Native browser 200% zoom and narrow reflow: no clipped text, overlapping controls or essential horizontal scrolling.
- [ ] Supported mobile software keyboard: composer remains visible; no blocked Send/End/safety controls or safe-area overlap.
- [ ] VoiceOver or NVDA: headings/landmarks/forms/statuses are meaningful; no duplicate message announcements.
- [ ] Contrast checked for text, hints, focus, disabled controls and warning/destructive states.
- [ ] Reduced motion, text resizing and long names/translated-like strings do not break the layout.
- [ ] Information and all policy/contact/processor/grievance/deletion guides remain readable with JavaScript disabled.

## Publication and launch handoff

- [ ] Real operator/entity/address/territories and all providers/locations/transfers supplied; no sample facts.
- [ ] Reviewed lawful processing basis, deadlines, retention/trigger/location and actual cleanup/backup behavior.
- [ ] Lawful no-email/contact/outage arrangements and independent appeal reviewer tested. Resolve applicable conflicts before launch.
- [ ] Current hashed evidence binds source, operator/processor record, version and effective date. Exact reviewer/coverage evidence is retained appropriately.
- [ ] Review the generated HTML, not only source JSON, for unsupported claims, addresses, remedies and retention.
- [ ] New immutable version used for material changes; old consent/purchase snapshots preserved appropriately.
- [ ] Runtime accepted version/publication digest equals the displayed copy. Required acceptance waits for the applicable effective version.
- [ ] Interface fixtures cannot be signed/released as the production product. Candidate remains subject to all later-phase gates.
- [ ] Phase 1 feasibility and known later-phase code findings remain tracked; no dependent feature enabled without evidence.

Record the reviewer, date, tested environment, exact source/export hashes, findings and evidence paths in the release evidence record. This checklist is intentionally not pre-approved.
