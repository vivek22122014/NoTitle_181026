# Integrated V1 handoff — 17 October 2026

The saved Phase 4 source was extended and integrated across all ten phase areas. Start with `../README.md`, use `release setup` for the full local candidate and `release verify --level stack` for real-stack qualification. `evidence/release/latest.json` is the current source-bound result; earlier evidence is historical. Production admission is not authorized by this handoff.

## What changed in this implementation session

- Social/audio commands and events share one strict generated wire-2 union and one conversation coordinator. No separate socket owner or automatic microphone reconnection was introduced.
- Product matching reads the stable durable billing entitlement snapshot; partial qualification profiles remain free. Background ICE/SDP/refresh and heartbeat do not renew foreground authority.
- Report starts immediately clear local text and microphone authority, then freeze server evidence and block before retained submission. Failed preparation requests the captured exact interaction End. Newer interactions cannot be ended by late callbacks.
- Moderator cases have encrypted bodies, durable history, seen/status tracking, scoped guest receipts, current grants/MFA, audited plaintext reads and independent appeal checks. No support email is exposed.
- Friend promotion survives cancelled callers with exact-row compensation; stale reads cannot resurrect removed or blocked relationships. New registration preserves a guest identity and imports private choices only with fresh optional consent. Login imports no guest data.
- Startup checks required packaged migration names/hashes before opening listeners; additive grants/tables cannot be silently omitted while reporting schema contract 3. Boot startup requires a healthy committed deployment under the deployment lock.
- Media shutdown explicitly denies active calls and retains unresolved reservations until absence is proven. A late relay provisioning result cannot reopen a stopped call.
- Billing screens use owned immutable intents, existing-order resume, reviewed receipt facts, bounded status polling and financial-scope receipts. Hosted checkout is isolated to a full-document `/checkout/` navigation and route-specific CSP. Sales close during maintenance; capture/remedy reconciliation continues.
- The private HTTP client now bounds replies, times out requests, rejects credential URLs, fences stale responses after login/logout, and never retries an uncertain mutation. Private views clear owned data on authority failure and prevent case selection during writes.
- Admin metrics use aggregates, suppression and bounded retention. Operational tooling adds source-bound all-phase checks, serial deployment state, atomic backup status and monitoring without an analytics service.

## Launch work that is not completed by source tests

| Area | Required completion |
|---|---|
| Dependencies and build | Resolve/review real Python/npm locks and image digests; install runtime dependencies; run Next TypeScript/build/export and actual browsers |
| PostgreSQL | Run migrations, least-privilege ACLs, concurrency/process-failure suites and the complete product integration tests on the fixed disposable target |
| Relay | Supply real domains/mTLS/coturn/kernel configuration; qualify actual RTP termination, owner/controller loss, late allocation, mobile/network behavior and the 25-call bound |
| Merchant | Supply reviewed merchant/tax facts and credentials; complete actual hosted sandbox payment, callbacks, independent verification, exceptions/remedies and receipts before sales |
| Legal | Supply actual entity, territories, privacy/contact/outage process, processors, deadlines, financial retention and legal review; publish the reviewed policy digest |
| Recovery | Restore an old independent backup on an empty host, replay deletion/hold journal and verify key recovery before admission |
| Operations | Validate provider permissions/regions/cost, real alerts, load/security/accessibility checks and a solo update/rollback rehearsal |

The editing environment has no Docker/PostgreSQL binaries or FastAPI/Uvicorn/psycopg/httpx/Next/React/TypeScript/Playwright installation. Ordinary PyPI/npm requests returned HTTP 403. Available-library Python and actual Node coordinator tests run here; SQL, typecheck/build, browser, actual packet/provider and host recovery execution cannot be inferred from them.

## Remaining implementation limits

- **Payment exceptions:** inspect the current Phase 8 guide and sale gates. Independent provider refunds are conservatively frozen and reported; signed disputes cannot restore funds or time without independent review. The private provider-verified restore/revoke workflow, independent dispute lookups and bounded backfill are now implemented, with current-role/MFA checks, source-bound previews, independent refetch, audited confirmation and receipt-based lost-result recovery. Actual merchant/database/browser qualification remains open. Mixed or ambiguous principal losses deliberately stay held until authoritative provider reconciliation. Never enable sales merely because a redirect or capture test succeeds.
- **Annual365:** unavailable until a provider-approved late required-remedy route is implemented and tested. Do not bypass this gate with a short-window refund API.
- **Independent journal lifecycle:** authenticated deletion/hold instructions are bounded to 10,000 entries and fail closed at capacity. Safe segment rollover, archival custody and expiry of obsolete tombstones remain unfinished. Plan completion before the bound; do not delete journal files, reset anchors or increase the cap to hide it.
- **Key maintenance:** versioned encryption envelopes can read retained wrapping-key versions, but automated online rotation and historical rewrapping are absent. A maintenance migration plus restore rehearsal is required before key replacement. Overwriting keys would strand data or credentials.
- **Entity-specific invoices/retention:** reviewed payment receipts are not a determination of legal invoice/credit-note/reporting duties. Implement any additional duties required by the actual operator and launch market before sales.
- **Human legal operations:** staffing, independent appeal reviewer, statutory notice/escalation and lawful outage contact are actual operating dependencies. Source code cannot provide them.

These limits are explicit unfinished work, not accepted V1 functionality. The application uses closed feature/release gates instead of placeholder provider responses or fabricated evidence. All ten phase production acceptance flags remain false pending their mandatory checks.

## Maintaining this candidate

Use current guides before historical Phase 1–4 scope notes. Keep ordinary conversation RAM separate from retained evidence. Preserve schema contract 3, independent protocol numbering, purpose-bound keys, public/private export isolation and the subject-control → financial-subject → purchase → lot → remedy lock order. Never change historical migration bytes, repoint disposable tests at production, add a second actor owner or restore database contents during an application rollback.
