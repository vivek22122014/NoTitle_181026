# Phase 2 — Interface, static pages and policy publication

## Scope and authority

This implementation follows Master Blueprint V6 chapters 08–19 and 41–44, with chapter 56 defining Phase 2 acceptance. The current package continues the Phase 1 update rather than replacing its runner, migration or ownership design. No database migration or new dynamic HTTP contract is necessary for this phase.

**Confirmed V1 requirements:** adults 18+, pseudonymous one-to-one text, free mutual audio, mutual friends, private professional categories, optional Premium preference controls, saved Chat with Moderator, separate staff permissions, privacy controls, no outgoing/support email, lightweight aggregates, no voluntary refunds and preserved required remedies. Ordinary text is temporary; support and selected report evidence are separately retained. Premium is a one-time pass without automatic renewal or queue priority. Annual365 remains unavailable.

**Phase 2 decision:** default to a clearly labelled, read-only `interface` build. Typed synthetic records never appear as live records. Actions needing identity, realtime, safety, media, payments or staff grants are disabled with visible prerequisites. Existing broader candidate business code remains available under the explicit `candidate` build profile. A build profile is neither authentication nor feature qualification.

**Outstanding external facts:** actual operator/entity, lawful contacts and outage routes, launch territories, providers/regions/transfers, lawful processing basis, applicable deadlines/retention, independent appeal reviewer and current legal/practice evidence. None is inferred from a proposed hosting provider or a historical India cost estimate. No compliance approval is invented. Missing Phase 1 feasibility evidence remains open.

## Audit and corrections

| Finding in previous source | Phase 2 correction |
|---|---|
| Home/legal index depended on the client application and bootstrap | Server-rendered information, legal index and seven policies; no bootstrap required |
| `content.json`, `meta.json` and publication could drift | One authoring source, deterministic compilation, public projection and independent content/file hashes |
| Reviewed metadata could be attached to unresolved draft text | Operator slots are rendered from the reviewed record; reviewed copy rejects unresolved values |
| Review booleans did not bind exact facts or evidence | Version/source/operator/date binding, evidence file hashes, expiry, immutable reviewed version snapshots |
| Several required routes were absent or combined under legacy paths | Generated fixed inventory, canonical paths, useful compatibility routes |
| No eleven-screen fixture/state coverage | U01–U09 public and A01–A02 private typed workflow examples and generic response states |
| Metadata, sitemap and publication lints were incomplete | Per-route metadata/canonical/robots, allowlisted sitemap, source/build/export guards |
| Private bundle or credential GET fallback was insufficiently guarded | Import/export scans, separate assets, public denial routes, POST fallback on preserved credential forms |
| No isolated UI preview or automated accessibility exercises | Read-only two-listener preview, native dialog, Playwright suite and explicit manual checklist |

No Phase 3–10 business source is asserted to be qualified by these corrections. In particular, candidate client ownership, recovery/takeover, money, retention and provider gaps still need their own phase acceptance.

## Presentation architecture

```mermaid
flowchart TD
  R["Fixed route inventory"] --> P["Public route pages"]
  R --> A["Private route pages"]
  P --> PS["Public shell and U01–U09"]
  A --> AS["Private shell and A01–A02"]
  PS --> PE["Public static export"]
  AS --> AE["Private static export"]
  PE --> G["Artifact and CSP checks"]
  AE --> G
  G --> L["Separate loopback listeners"]
```

`contracts/interface-routes.json` is the route authority. `ops/nt.py interface generate` emits route wrappers and a separate `route-data.json` for each application. Editing a wrapper by hand causes `interface check` to fail. Foundation pages remain separate and preserved.

`Surface.tsx` selects an information page, policy renderer, typed static screen or review workbench. It dynamically imports the preserved integration candidate only for the explicit candidate profile. The public application never imports the private application. Shared code contains presentation types, controls, CSS and public-only build settings; no private fixtures or service credentials.

- `web/public/components`: public shell, information, policy renderers, screen views, typed fixtures and review controls.
- `web/admin/components`: distinct staff shell, private fixtures, screen views and review controls.
- `web/shared`: Field, Checkbox, DisabledAction, StatusNotice, EmptyState, Pager, RouteState, native Dialog/Sheet, visual tokens and public configuration.
- `web/public/app/Application.tsx`: preserved later-phase public candidate, with explicit initial identity mode and POST fallback forms.
- `web/admin/app/Candidate.tsx`, `Controls.tsx`: preserved private integration candidate, with explicit initial panel and POST fallback forms.
- `ops/interface.py`: generation, source boundary checks, configuration and CLI routing.
- `ops/export_audit.py`: inspection of actual exported HTML/assets.
- `ops/interface_server.py`: read-only local preview of verified exports.
- `ops/phase2.py`: command evidence with blocked/not-run states.

The static preview makes no API calls. It has no session or domain state to persist. Forms hold only temporary editing state; no service worker, browser storage, hidden draft cache or mock mutation is added. The review workbench changes examples in React memory. The later single ClientCoordinator remains a Phase 3/4 qualification dependency; these fixtures do not simulate it.

## Screens and workflow states

Every screen group has loading, empty, validation, error, forbidden, stale, rate-limited and maintenance examples, in addition to ready. `error` means the result is unconfirmed; it does not invent a failed or successful payment. Retry timers and server deadlines are not fabricated. Foundation health continues to use its separate real endpoint.

| Group | Routes | Principal controls and designed states |
|---|---|---|
| U01 Entry/information | `/`, `/join/`, `/how-it-works/`, `/safety/` | Start navigates to entry; guest/account choice; no default declared gender; separate unchecked adult/Terms/core/optional confirmations; admission unavailable |
| U02 Identity | `/register/`, `/login/`, `/recovery/` | Private username; disabled real credential entry; prepared-code copy/download/saved acknowledgment; generic login errors; explicit five-session choice |
| U03 Conversation | `/chat/` | Idle, searching, matched, interrupted, replaced and ended; topic/effective choices; plain text; accepted versus delivered; Search/Cancel/Send/End/Next/Report/Block prerequisites |
| U04 Audio/safety | `/chat/` overlay contract; public review workbench | Request, permission, connected, report, block; mutual acceptance before microphone permission; distinct retained evidence/allegation; no media access in preview |
| U05 Friends | `/friends/` | Temporary/Saving/Saved; Available/Busy/Offline; invitation, accept/decline, remove/block; 30-second invitation and 100-friend rules explained |
| U06 Profile/account | `/profile/`, `/preferences/`, `/settings/` | Peer preview; private professional fields; saved/effective choices; General Talk; expiry pause; sensitive authentication, sessions, blocks, logout |
| U07 Premium | `/premium/`, `/account/premium/`, `/payment/status/`, `/account/receipts/` | Four disabled plans; unchecked checkout acknowledgment; phone only if provider requires; pending Do not pay again; entitlement/receipt states without invented success |
| U08 Saved support | `/support/`, `/support/status/` | Chat with Moderator; list/category/status/unread; subject/message/thread; scoped receipt access; Sent/Seen explanation; closed/reopen/continuation contract |
| U09 Privacy | `/account/privacy/`, `/account-deletion/` | Purpose withdrawal, export pending/ready prerequisite, deletion receipt/saved confirmation, locally pending versus durably accepted/retained/completed |
| A01 Staff cases | Private `/`, `/cases/`, `/reports/`, `/privacy/` | Separate password/MFA; assignment/version; audited access purpose; distinct public reply/internal note; obligation clocks, safety previews, holds and independent review |
| A02 Staff operations | Private `/analytics/`, `/billing/`, `/audit/`, `/settings/`, `/release/` | Aggregate cards/table, UTC/units/suppression/gaps; required-remedy preview/MFA; metadata audit; scoped grants; component/evidence health; CLI deployment |

`/interface/` on the public listener contains only U01–U09. `/interface/` on the private listener contains only A01–A02. Private examples are synthetic and do not require case access because no real case data is loaded. Actual staff data remains protected by the separate backend’s authentication and grants.

Public policy/information routes are `/privacy/`, `/terms/`, `/community-guidelines/`, `/refund-policy/`, `/grievance/`, `/contact/`, `/cookies/`, `/data-retention/`, `/your-rights/`, `/legal/`, `/processors/` and `/account-deletion/`. `/maintenance/` is a readable unavailable view. `/talk/`, `/policies/` and the seven existing `/policies/{id}/` paths remain readable compatibility routes with canonical metadata pointing to the primary path. They are not catch-all rewrites.

## Visual and accessibility contract

The shared theme uses light neutral surfaces, dark text and deep teal actions. Destructive controls use red plus a text label, never color alone. System fonts avoid a remote font provider. Body text is at least 16px, auxiliary labels remain readable, interactive targets are at least 44px, and visible focus uses a separate high-contrast outline.

Desktop uses a bounded content shell, left app navigation and paired feature panels. Mobile reflows to one column from 320px with Chat, Friends, Support and Account bottom navigation, safe-area padding and dynamic viewport sizing. Conversation context collapses into native details; the composer has a mobile sticky position. Actual software-keyboard/viewport behavior remains a device acceptance check.

There is one H1 per rendered route, a skip link, labelled fields and controls, `aria-current` navigation, descriptive disabled-action prerequisites and meaningful status/error text. Real information/policy navigation works without JavaScript. Entry policy links open a disclosed new tab so form choices remain in the original tab without storing consent.

The native dialog provides modal focus containment, background inertness, Escape and focus restoration. The review validation state focuses its first invalid field. Reduced-motion preferences disable animations/transitions. Aggregate cards have a table alternative with captions and scoped headers.

This is an implemented accessibility design, not a WCAG certification. Native 200% zoom, screen readers, keyboard-only use and the software keyboard require the checklist and actual browser/device evidence.

## One-source policy publication

```mermaid
flowchart TD
  S["Versioned policy source"] --> C["Compile and lint"]
  O["Actual operator and processors"] --> V["Validate facts and hashed review"]
  V --> C
  C --> D{"Reviewed facts complete?"}
  D -->|No| P["Labelled draft, noindex"]
  D -->|Yes| R["Immutable reviewed version"]
  P --> H["Static HTML and displayed digests"]
  R --> H
```

`policies/source.json` is the only prose authoring source. It contains seven document bodies and explicit operator slots. `policies/publication.json` is a deterministic compiled record; `web/public/app/policies/generated.json` is its public projection. The old independently editable `content.json` and `meta.json` were removed.

The source covers actual V1 categories, temporary text versus durable support/evidence, payment/provider separation, optional purposes, analytics minimization, staff access, retention exceptions, scoped receipts, deletion/backups, complaints, children, incident/contact arrangements and changes. It does not promise anonymity, perfect security, instantaneous backup erasure, guaranteed matches or legal approval.

- `source_sha256`: canonical source JSON hash.
- `content_sha256`: hash of the public version/state/effective date/operator/processors/policy bodies.
- `publication_sha256`: hash of the exact canonical `publication.json` bytes, matching the existing backend configuration contract.
- Review binding: source hash, actual operator/processor hash, version, effective date, current review dates and existing evidence files with SHA-256.
- Reviewed snapshots: `policies/history/{version}.json`; attempting to change an existing version fails. Renewal or material changes use a new version. Retain old purchase/consent snapshots under their lawful schedule.

Draft compilation replaces operator slots with a visible publication-blocked statement. It does not supply a fake business, contact, tax registration, governing law, provider contract or deadline. Draft pages display a warning and null effective date. All preview pages are noindex, the sitemap is empty and robots disallows crawling. Robots is not access control.

### Prepare genuine facts — manual

Create local working records:

```bash
mkdir -p .local
cp policies/operator.template.json .local/operator.json
```

Fill every operator field using actual records and determinations:

| Field | Obtain and verify |
|---|---|
| Legal name/entity/address and registration/tax disclosures | Actual business records, a legally adequate public address, applicable registration/tax identifiers or a reviewed explanation of non-applicability; no invented registration |
| Contact/outage routes | Owner-controlled monitored HTTPS intake or international phone; test both, including application outage; no email or secret in URLs |
| Privacy/grievance roles | Actual responsible roles and staffing arrangements |
| Law/forum/territories | Current jurisdiction/service applicability review; preserve non-waivable rights |
| Basis/deadlines/escalation | Applicable legal determinations, actual rights workflows and statutory appeal routes |
| Finance/security/backup retention | Entity-specific statutory triggers and actual tested cleanup, archive, location and recovery schedules |
| Independent appeal route | Designated independent reviewer and tested access/coverage for owner-conduct appeals |
| Processors | Actual contracted provider, purpose, categories, regions, subprocessors, transfer arrangement and HTTPS privacy notice for every relevant service |

Operator/provider fields are intended public facts, not secret stores. Never put API keys, account passwords or payment credentials in these files. The validator cannot determine whether an assertion is true; review evidence and deployment qualification remain necessary. The maximum 180-day review window is an engineering freshness limit, not a claim about a statutory review period.

Generate a bound review worksheet. Replace the example version/date with the actual approved choices; this sample date is not an approval:

```bash
python3 ops/nt.py policies prepare-review \
  --operator .local/operator.json \
  --version v1-reviewed-1 \
  --effective-at 2026-11-01T00:00:00Z \
  --output .local/review.json
```

A worksheet is created with all review checks false. Have the responsible reviewer verify applicable law, commencement, provider locations, no-email feasibility, deadlines, financial retention, incidents, deployed practices and independent appeal coverage. Set `reviewed_at`, `expires_at` (maximum 180 days; use a shorter period when needed), and each verified check. Add existing project-relative evidence files with their SHA-256 hashes; retain appropriate access controls for review records. Use `sha256sum evidence/path` on Linux to obtain each file hash. Do not upload sensitive evidence into public assets.

A legal requirement for a published email is not satisfied by suppressing it in the UI. Under the no-email V1 instruction, any unresolved applicable duty remains a launch/processing block until the operator finds and documents a lawful resolution. Likewise, no outage contact or independent reviewer is invented.

### Compile and inspect — automated, then manual

```bash
python3 ops/nt.py policies publish \
  --operator .local/operator.json \
  --review .local/review.json \
  --version v1-reviewed-1 \
  --effective-at 2026-11-01T00:00:00Z
python3 ops/nt.py policies check --require-reviewed
python3 ops/nt.py interface check
```

`publish` prepares reviewed copy; it is not deployment or legal certification. It refuses incomplete/extra fields, unsafe contacts, email exposure, unresolved copy, unsupported claims, missing no-voluntary-refund/required-remedy/no-renewal wording, stale evidence, changed facts or mutation of an existing version. It saves no changes when initial validation fails. If interrupted between deterministic output writes, consistency checks fail until the same reviewed publication is regenerated. Runtime acceptance remains unchanged.

Build and inspect all rendered pages without JavaScript. Confirm provider records/contacts, actual practice descriptions, retention and legal terms with the reviewer. Before a product release, configure the actual public origin, explicitly select the candidate profile, rebuild, bind the printed policy version and exact publication hash into runtime configuration, and complete the separate release gates. Material changes require affected user acceptance in the identity phase.

## Build, metadata and security boundaries

Per-route title, description, canonical URL and truthful Open Graph fields come from the route inventory and public-only `web/shared/site.json`. No unsupported structured identity/ratings/online counts are added. Canonicals use the configured origin; local development uses real loopback rather than an invented production domain. Do not index a preview. Indexability requires a candidate HTTPS build and reviewed policies; release qualification remains independent.

The sitemap is an explicit allowlist of public information/policy pages. Account, chat, support, payment status, receipts, compatibility, foundation, maintenance, review and private routes are excluded. Private metadata/robots and HTTP `X-Robots-Tag` always deny indexing. Sensitive and private responses use `Cache-Control: no-store`.

Two Next.js exports remain independent. `ops/builds.py` binds their bytes to source, policy/route inputs, public build settings and the reviewed Node image. The Docker build runs type checking and Next builds. Native/workspace npm prebuild hooks run the dependency-free Node consistency guard. Python validation additionally checks actual review files. Neither guard substitutes for legal review.

The actual-export audit requires all fixed routes and foundation/404/robots/sitemap outputs; checks one H1, metadata, canonical/noindex, local links/assets, visible policy text/digests, private markers, credential GET fallback, source maps and unsafe inline handlers. It rejects symlinks and public/private contamination. Information/policy initial scripts must fit 150 KiB compressed; actual measurement happens only after a real build. No result is fabricated from source size.

CSP hashes are generated from exact exported inline script bytes. Policies deny inline script attributes, arbitrary frames/workers, objects, base changes and framing. Styles currently permit inline style declarations for Next and preserved candidate components; `unsafe-eval` is never permitted. Checkout-specific third-party allowances remain scoped to the existing Premium route and are absent in the interface preview. Generated public/private CSP files are separately mounted into Caddy; the foundation proxy also receives them. Unknown paths remain HTTP 404, with no SPA success fallback. Public `/internal` and `/admin` prefixes are explicitly denied.

`interface serve` is a read-only, no-API, loopback-only HTTP preview. It validates export source/bytes and audit results before binding, reserves both ports before serving, disables URL logging, refuses queries/traversal/symlinks/listings, emits no-store/noindex/security headers and never proxies the backend. It is not a TLS or production server. The production Caddy architecture and private tunnel remain unchanged.

The production release/render tools reject an interface fixture release, missing reviewed policies, stale exports, origin mismatch or runtime/displayed policy mismatch. Full release signing, authentication, backups, recovery and later-phase qualification still apply.

## Exact local workflow

From the project root on Linux/WSL2 with the Phase 1 tool prerequisites:

1. Stop an existing local stack with `.venv/bin/python ops/nt.py dev down` if it owns ports 8080/8081. This command also stops the local containers; do not run it against unrelated services.
2. Resolve current locks with `python3 ops/nt.py lock` on an authorized network. Web workspace exports/scripts changed. Hashes/digests are resolved, never supplied as dummy values. If access returns 403, fix the approved network/account route; do not bypass restrictions.
3. Install with `python3 ops/nt.py install`. This creates the application Python environment from resolved hashes. Do not replace existing secrets. No Phase 2 database setup is required.
4. Run `.venv/bin/python ops/nt.py interface configure --mode interface`. This selects only public build settings, with loopback origin and noindex.
5. Run `.venv/bin/python ops/nt.py interface verify --level core`. Inspect `evidence/phase2/latest.json` and logs.
6. Run `.venv/bin/python ops/nt.py build --target web`. The immutable Node build typechecks and exports both applications; actual HTML/assets, policy text and CSP are audited before replacing previous exports.
7. Run `.venv/bin/python ops/nt.py interface serve`. Open public `http://127.0.0.1:8080` and private `http://127.0.0.1:8081`. Review the `/interface/` route on both. Stop with Ctrl+C.
8. After stopping the preview, install browser tooling with `npm ci --ignore-scripts` and `npx playwright install --with-deps chromium`. That installation may require local administrator access for OS packages.
9. Run `NT_PYTHON=.venv/bin/python npm run test:interface`. It starts its own verified read-only server, tests, then stops it. Ports must be free. Review failure traces and logs; do not add ignores simply to pass.
10. Complete `PHASE2_ACCEPTANCE.md` manually, then the real operator/review procedure. Do not open production admission or checkout because an interface suite passed.

`interface verify --level build` additionally tries the immutable build after prerequisite checks. `--level browser` also runs the browser suite, which assumes its browser tooling has already been installed. Missing prerequisites replace stale results with blocked evidence. `phase2_accepted` and `production_ready` remain false until independently reviewed manual/external gates are completed; the collector does not invent their approval.

The CI workflow runs core guards, the separate Phase 2 export/browser suite, then the preserved candidate integration pipeline. Candidate failures are not waived by fixture success. CI never receives production secrets or deploys automatically.

## Acceptance, operations and troubleshooting

- **Source gate:** generation/policy checks, no private import, Node build guard, strict API contract drift and all existing/new unit tests pass.
- **Artifact gate:** real locked TypeScript/Next build, export audit, initial-JS budget and generated Caddy configuration validation pass.
- **Browser gate:** all eleven screen groups/workflow variants/response states, correct disabled actions, no mutation/network traffic in preview, no overflow, focus/dialog/consent preservation, no-JavaScript information and real HTTP boundaries.
- **Manual gate:** keyboard, 200% native zoom, supported software keyboard, screen reader, contrast and responsive review on target devices.
- **Publication gate:** genuine operator/processors, current legal and deployed-practice review, exact HTML/hash review, lawful no-email/contact/outage/appeal resolution, acceptance version integration and signed release evidence.

A missing source wrapper means run `interface generate`; do not create a second route map. Policy drift means edit source and compile a draft or review a new version, never hand-edit generated JSON. `policies compile` intentionally cannot overwrite reviewed terms. A missing/stale lock means resolve/review the changed inputs. Missing CSP files mean the web build did not complete; never replace them with `unsafe-inline` scripts. A busy preview port means stop only the known local owner or choose two distinct unprivileged ports. Source changes invalidate exported-byte reuse. A policy claim rejected by the linter needs corrected copy and evidence, not disabling the linter.

Keep evidence, reviewed snapshots and policy/version associations with each qualified release. Review policies/providers whenever functionality, purpose, location, pricing, law or retention changes. Re-run the artifact/browser/accessibility checks when shared shells, controls, legal rendering or CSP change. Continue remaining operational work under `DEPLOYMENT.md` and the later phase gates.

## Sources checked for implementation patterns

- Next.js static exports: https://nextjs.org/docs/app/guides/static-exports (checked 17 October 2026).
- Next.js sitemap metadata: https://nextjs.org/docs/app/api-reference/file-conventions/metadata/sitemap (checked 17 October 2026).
- W3C modal dialog pattern: https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/ (checked 17 October 2026).

These describe implementation patterns; they are not evidence that this unbuilt package passes browser tests. Existing package candidates remain unchanged until real resolution/advisory review, rather than being silently upgraded to the documentation site's current version.
