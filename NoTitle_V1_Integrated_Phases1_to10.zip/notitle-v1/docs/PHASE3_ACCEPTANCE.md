# Phase 3 acceptance checklist

Source delivered is distinct from accepted production behavior. Current results are in `evidence/phase3/latest.json`; do not change qualification flags to bypass a failure.

Run `identity verify --level core`, `--level integration`, then `--level stack` from project root. Real checks require reviewed locks, Docker, a stopped owner and the fixed disposable local database. No remote target is accepted.

## Backend qualification

- [ ] Apply 0008 to the Phase 2 schema and migrate fresh from 0001; verify contract 3, FKs/indexes, function ownership and restricted roles.
- [ ] Prove runtime cannot change/delete consent evidence or policy bodies; support cannot SELECT credentials/sessions; its capability lock validates only the presented live account.
- [ ] Lose registration acknowledgment/RAM preparation; identical proof/payload/nonce returns the same cookie and one session/metric. Changed payload, revoked/expired target or later generation fails.
- [ ] Race two fifth logins and multiple sixth attempts. Prove the five-session cap through normal, direct-SQL and repeatable-read issuers. Challenges are bounded, bootstrap/generation-bound and single-use.
- [ ] Race reauthentication against credential rotation, logout-all, deletion and expiry; no stale authority gains freshness or commits private changes.
- [ ] Lose rotation Set-Cookie; exact source-cookie/CSRF retry returns only the original live target. Unrelated source, changed payload/generation, expired target and scoped receipts fail.
- [ ] Recover with a saved replacement; retry after RAM loss; reject spent-code reuse. Recovery itself issues no account cookie.
- [ ] Race guest conversion against End/Block/withdrawal/expiry/profile edits; never restore old sockets, queues, text, calls or ended links.
- [ ] Withdraw optional consent: erase DB/actor categories/preferences, invalidate queue/tickets/revisions, preserve free participation; exact retry is idempotent.
- [ ] Withdraw core consent: end participation while support/privacy/receipts remain accessible to restricted accounts and guests.
- [ ] Validate exact policy/prompt/control digests, unchecked defaults, old-version withdrawal, explicit reacceptance, immutable proofs and visibly legacy historical evidence.
- [ ] Verify idle/absolute limits, foreground-only renewal once/minute, guest expiry/restart and actual HTTPS cookie attributes.
- [ ] Verify account/case/financial/deletion isolation, public/private bootstrap realms, CSRF/Origin/Host/duplicate input rejection and no credential query parameters.
- [ ] Verify rights/export deduplication, two-job/collection/size bounds, owner/freshness checks, omitted secrets/staff notes/private peer identifiers, 24-hour cleanup and deletion cancellation.
- [ ] Interrupt independent deletion acknowledgment, restore old database and replay before admission: receipt reconstruction, restored-session revocation and restored-export removal. Included row-restore integration is not a full backup/host-loss rehearsal.
- [ ] Race holds/release/purge/retention; reject unavailable/rolled-back independent checkpoints and recover pending instructions with restored keys.
- [ ] Verify identity-mode 404s for sockets, checkout, analytics/private case content; no payment/refund jobs execute.

## Browser and operational qualification

- [ ] Run locked TypeScript/Next builds and real export/CSP audits. Syntax parsing is insufficient.
- [ ] Run `npm run test:identity` on the local identity stack; check no mount mutation, unchecked choices, saved code, withdrawal/support and sign-out.
- [ ] Rehearse sixth-session, unknown acknowledgment, rotation, deletion-pending and receipt flows on desktop/mobile and multiple tabs. Do not capture real secrets in traces/screenshots.
- [ ] Check keyboard/focus/error recovery, password managers, clipboard denial, downloads, software keyboard, native 200% zoom and screen readers.
- [ ] Confirm no support email, persisted browser credentials, public bundle secrets, misleading message/seen claims or automatic search/microphone.
- [ ] Review actual operator/jurisdiction/processor/retention practices and lawful contact obligations against published policies. Software tests cannot establish legal applicability.
- [ ] Rehearse production setup, managed PostgreSQL/independent object-store restore, backup expiry, alerts, compatible update/rollback and recovery-key custody.

All phase acceptance remains open while mandatory evidence is missing. Media, payments and Annual365 retain their independent gates.
