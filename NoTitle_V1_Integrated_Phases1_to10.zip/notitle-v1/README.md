# NoTitle V1 — integrated phases 1–10

This is the integrated Next.js + FastAPI implementation candidate based on the saved Phase 4 project and Master Blueprint V6. Identity, consent/privacy, matching/temporary text, safety/support, friends, audio controls, hosted billing/receipts, admin analytics and operational automation are connected in the full `product` runtime. **Source implementation is not production acceptance.** Real database, build/browser, relay, merchant, legal and recovery qualification remain required. No public deployment or live payment was performed.

## Start on your computer

Run in the extracted `notitle-v1` folder on Linux or WSL2. Install Python 3.12, Node 24/npm, uv, Docker Engine and Compose. Registry access is required. Start with:

```bash
python3 ops/nt.py release setup
```

This configures fixed local origins and generated private keys, resolves dependency/image locks, installs dependencies, runs core checks, starts PostgreSQL, provisions roles, migrates, builds the separate public/admin exports and starts the application. It stops on missing prerequisites. Review resolved dependency versions, hashes and advisories before committing locks or preparing production. Existing keys are preserved. Use `--locked` after reviewing the generated lock set, or `--no-start` to prepare only.

Open http://127.0.0.1:8080. Use two independent browser profiles for two identities. Create a guest or account, choose Chat and explicitly Search. Guests receive generated pseudonyms. Text is temporary. Friends require mutual acceptance, invitations require explicit acceptance, and microphone access requires mutual audio consent. Audio and sales remain unavailable until their real configuration and qualification are supplied; no simulated provider or peer-to-peer audio fallback is used.

```bash
.venv/bin/python ops/nt.py dev status
.venv/bin/python ops/nt.py dev down
.venv/bin/python ops/nt.py release verify --level stack
```

The full collector requires the owner to be stopped before destructive disposable-database checks. It verifies actual database/integration, Next build/typecheck and browser flows and writes `evidence/release/latest.json`. Missing dependencies are blocked checks. Core-only checks can run with `--level core`; they do not qualify production.

The private site is http://127.0.0.1:8081. To create your local owner account after database setup:

```bash
.venv/bin/python ops/staff.py owner_user --role owner
```

Follow the password prompt and securely import the private TOTP enrollment/recovery file. Never commit that file. Production private access uses the documented SSH tunnel and trusted private TLS, rather than a public admin endpoint.

## What is connected

| Phase | Implementation |
|---|---|
| 1 | Single leased owner, bounded actor, fixed PostgreSQL pools, checksummed migrations, setup and feasibility gates |
| 2 | 46 public/10 private routes, responsive UI, accessible controls and versioned policy publication workflow |
| 3 | Account/guest/session authority, recovery, consent, rights/export/deletion, scoped case/financial/deletion receipts |
| 4 | Shared matching pool, strict wire 2, temporary text, rendering receipts, explicit reconnect and priority End/Block |
| 5 | Selected report evidence, encrypted Chat with Moderator/history/status, private staff permissions/MFA/audit and appeals |
| 6 | Mutual friends, temporary/saved promotion, online invitations, private preferences and owned block management |
| 7 | Mutual audio, relay-only signaling, microphone fencing, bounded capacity and explicit guarded teardown |
| 8 | One-time pass catalog, Cashfree hosted checkout, verified ledger, receipts, required remedies and sale gates |
| 9 | Suppressed aggregate admin metrics, bounded retention/jobs, encrypted backup/restore, monitoring and deployment tooling |
| 10 | CI, source-bound qualification, signed releases, compatible rollback, launch gates and operational handoff |

## Read next

- [Phase map and acceptance](docs/PHASES.md)
- [Implementation and current architecture](docs/IMPLEMENTATION.md)
- [Safety and social integration](docs/PHASE5_6.md)
- [Audio implementation and qualification](docs/PHASE7_AUDIO.md)
- [Payments and required remedies](docs/PHASE8.md)
- [Analytics and operations](docs/PHASE9_10_OPERATIONS.md)
- [Complete deployment guide](docs/DEPLOYMENT.md)
- [Current handoff and remaining work](docs/HANDOFF.md)
- [Historical master blueprint](docs/blueprint-v6-reference.txt)

The latest report records what actually ran. Historical phase reports and earlier READMEs remain history. Policies remain visibly draft until real operator, jurisdiction, processor and retention facts are reviewed. There is no support email. Ordinary chat is never written to PostgreSQL or browser storage; selected reports and support are separately retained. No voluntary refunds are offered, while mandatory legal/payment remedies are preserved. Annual365 remains disabled.

The source archive excludes generated credentials, installed dependencies, build outputs and caches.
